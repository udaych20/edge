"""
P21 - CrewAI Hierarchical Market Intelligence: Streamlit UI
"""

import streamlit as st

from market_intelligence import MARKET_SCENARIOS, run_market_intelligence_crew

st.set_page_config(
    page_title="P21 - CrewAI Hierarchical Market Intelligence",
    page_icon="CHART",
    layout="wide",
)
st.title("P21 - CrewAI Hierarchical Market Intelligence")
st.caption("Hierarchical CrewAI with manager delegation, custom tools, structured outputs, and approval routing")

with st.sidebar:
    st.header("Sample Market Briefs")
    for i, scenario in enumerate(MARKET_SCENARIOS):
        if st.button(scenario[:58] + "...", key=f"scenario_{i}", use_container_width=True):
            st.session_state["market_brief"] = scenario

    approval_mode = st.radio(
        "Leadership approval mode",
        ["approve", "request_more_research", "no_go"],
        format_func=lambda value: {
            "approve": "Approve launch direction",
            "request_more_research": "Request more research",
            "no_go": "No-go due to risk",
        }[value],
    )

    st.divider()
    st.markdown("**Crew Concepts Covered**")
    st.markdown("- Hierarchical process")
    st.markdown("- Manager delegation")
    st.markdown("- Custom tools")
    st.markdown("- Structured outputs")
    st.markdown("- Approval routing")

default_brief = st.session_state.get("market_brief", "")
brief = st.text_area("Market intelligence brief", value=default_brief, height=180)

if st.button("Run Hierarchical Crew", type="primary", use_container_width=True):
    if not brief.strip():
        st.warning("Please enter a market brief or choose a sample from the sidebar.")
    else:
        try:
            with st.status("Crew is building the market memo...", expanded=True) as status:
                result = run_market_intelligence_crew(brief, approval_mode=approval_mode)
                status.update(label=f"Done in {result['total_time']:.1f}s", state="complete")
        except Exception as exc:
            st.error(str(exc))
            st.info("Set OPENAI_API_KEY in your shell or add it to a .env file in this project folder, then rerun.")
            st.stop()

        col1, col2 = st.columns([1, 1])
        with col1:
            st.subheader("Crew Setup")
            st.markdown(f"**Process:** `{result['process']}`")
            st.markdown(f"**Manager:** {result['manager_role']}")
            st.markdown(f"**Approval mode:** `{result['approval_mode']}`")
            st.markdown("**Specialists:**")
            for role in result["specialist_roles"]:
                st.markdown(f"- {role}")
        with col2:
            st.subheader("Run Info")
            st.markdown(f"**Model:** `{result['model']}`")
            st.markdown(f"**Duration:** `{result['total_time']:.1f}s`")

        st.subheader("Executive Memo")
        st.markdown(result["final_output"])

        st.subheader("Approval Decision")
        if result["approval_decision"]:
            st.json(result["approval_decision"])
        else:
            st.info("Approval decision was returned as free text rather than JSON.")

        st.subheader("Tool Access by Agent")
        st.json(result["tool_summary"])

        with st.expander("Structured Analyst Outputs", expanded=True):
            shown_any = False
            for item in result["task_outputs"]:
                if item["parsed_output"] is not None:
                    shown_any = True
                    st.markdown(f"### {item['agent']}")
                    st.json(item["parsed_output"])
            if not shown_any:
                st.info("No structured JSON outputs were parsed from the run.")

        with st.expander("Raw Task Outputs"):
            for item in result["task_outputs"]:
                st.markdown(f"### {item['agent']}")
                st.caption(item["description"])
                st.markdown(item["output"])
