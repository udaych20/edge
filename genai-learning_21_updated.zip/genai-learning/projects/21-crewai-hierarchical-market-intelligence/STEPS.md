# P21 - CrewAI Hierarchical Market Intelligence

## Concept
This project demonstrates a stronger **hierarchical CrewAI** workflow:
- A **manager agent** acts as a research director
- The manager **delegates work** to specialist analysts
- Agents use **custom tools** to pull mock market, customer, competitor, pricing, and risk data
- Specialist tasks return **structured JSON outputs**
- Final review uses **approval routing** to approve, request more research, or no-go the opportunity
- The crew uses **planning** before execution
- Final output is a polished **executive strategy memo**

## Real-World Scenario
Leadership wants to evaluate whether a new AI product should enter a market. Instead of
using a fixed step-by-step chain, a research director coordinates a team of specialists
to study demand, competition, customer pain, pricing, and launch risks before making
a recommendation.

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/21-crewai-hierarchical-market-intelligence
python3 market_intelligence.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8521
```

### Step 3: Try Different Market Briefs
Use the sidebar examples or paste your own:
- AI meeting notes product for B2B sales teams
- AI support copilot for Shopify merchants
- AI compliance assistant for financial services

Also choose a leadership approval mode:
- `approve`
- `request_more_research`
- `no_go`

The crew will generate structured specialist outputs, synthesize an executive memo,
and then route to a final approval decision based on leadership posture.

## Key Takeaways
- `Process.hierarchical` is different from a fixed sequential handoff
- A **manager agent** can coordinate specialists instead of pre-assigning every task
- **Tools** make the crew feel more like a real business workflow than a prompt-only demo
- **Structured outputs** make downstream synthesis and UI rendering easier
- **Approval routing** introduces human-style decision flow after analysis
- This pattern is useful for market research, diligence, strategy reviews, and leadership briefs
