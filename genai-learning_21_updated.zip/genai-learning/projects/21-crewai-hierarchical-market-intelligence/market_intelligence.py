"""
P21 - CrewAI Hierarchical Market Intelligence
============================================
Manager-led market intelligence workflow using CrewAI's hierarchical process,
custom tools, structured outputs, and approval routing.
"""

from __future__ import annotations

import json
import os
import re
import time
from typing import Any

from crewai import Agent, Crew, Process, Task
from crewai.tools import tool
from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


MARKET_SCENARIOS = [
    (
        "Evaluate whether we should launch an AI meeting notes and action-tracking product "
        "for mid-market B2B sales teams. Consider target segment, competitive pressure, pricing, "
        "adoption risks, and the best go-to-market wedge."
    ),
    (
        "Assess the market opportunity for an AI support copilot for Shopify merchants. "
        "Cover customer pain points, likely competitors, packaging strategy, and the biggest "
        "risks to product differentiation."
    ),
    (
        "Prepare a market intelligence brief for an internal AI compliance assistant aimed at "
        "regulated financial services teams. Review buyer needs, vendor landscape, pricing model, "
        "risk factors, and launch recommendation."
    ),
]


MARKET_DATA = {
    "sales": {
        "market_size": "Large and expanding B2B productivity market with strong AI budget interest.",
        "growth_signals": [
            "Revenue teams are standardizing call intelligence and meeting automation.",
            "Managers want automatic action items, CRM sync, and coaching insights.",
            "AI note-taking is crowded, so workflow depth matters more than transcription alone.",
        ],
        "adoption_barriers": [
            "Buyers may see the category as commoditized.",
            "CRM and calendar integration quality strongly affects adoption.",
        ],
    },
    "support": {
        "market_size": "Strong SMB and mid-market support automation demand, especially in commerce.",
        "growth_signals": [
            "Merchants need faster support without hiring linearly with ticket volume.",
            "Support leaders want AI copilots before full automation.",
            "Channel fragmentation across chat, email, and social creates workflow pain.",
        ],
        "adoption_barriers": [
            "Accuracy and hallucination risk in customer-facing replies.",
            "Store-specific context is required for high-quality automation.",
        ],
    },
    "compliance": {
        "market_size": "Smaller but high-value enterprise market with longer sales cycles.",
        "growth_signals": [
            "Regulated teams are actively evaluating AI for policy review and control evidence collection.",
            "Buyers care about auditability more than flashy automation.",
            "Budgets exist where compliance cost or review complexity is high.",
        ],
        "adoption_barriers": [
            "Security review and procurement cycles are lengthy.",
            "Trust, explainability, and approval workflows are mandatory.",
        ],
    },
}

COMPETITOR_DATA = {
    "sales": {
        "competitors": [
            {"name": "Gong", "strength": "Deep revenue intelligence", "gap": "Heavy platform footprint for smaller teams"},
            {"name": "Avoma", "strength": "Meeting workflow depth", "gap": "Less differentiated for broader revenue ops"},
            {"name": "Otter", "strength": "Fast note capture", "gap": "Weaker sales-specific execution layer"},
        ],
        "whitespace": [
            "Action-tracking tied to CRM hygiene and manager accountability",
            "Lighter-weight product for mid-market teams priced below enterprise revenue intelligence",
        ],
    },
    "support": {
        "competitors": [
            {"name": "Gorgias", "strength": "Strong Shopify ecosystem position", "gap": "Can feel workflow-heavy for smaller merchants"},
            {"name": "Zendesk AI", "strength": "Enterprise support breadth", "gap": "Less commerce-native for merchants"},
            {"name": "Intercom Fin", "strength": "AI-first support narrative", "gap": "Not specialized for merchant operational context"},
        ],
        "whitespace": [
            "Commerce-native AI copilot with refund, order, and policy context",
            "Hybrid copilot mode before full auto-resolution",
        ],
    },
    "compliance": {
        "competitors": [
            {"name": "Workiva", "strength": "Enterprise governance credibility", "gap": "Broad platform can be slow to adopt"},
            {"name": "Drata", "strength": "Control automation", "gap": "Focused more on security/compliance ops than AI review assistants"},
            {"name": "Vanta", "strength": "Strong compliance workflow brand", "gap": "Less focused on internal advisory copilots"},
        ],
        "whitespace": [
            "Approval-centric AI assistant for policy interpretation and evidence preparation",
            "Assistant positioned as analyst accelerator rather than autonomous compliance agent",
        ],
    },
}

CUSTOMER_DATA = {
    "sales": {
        "ideal_customer_profile": "VP Sales, Sales Enablement, and RevOps leaders at 100-1000 employee B2B SaaS companies.",
        "pain_points": [
            "Managers lose follow-through after meetings.",
            "CRM data quality is inconsistent.",
            "Reps dislike manual notes and action tracking.",
        ],
        "buying_triggers": [
            "Missed forecast accountability",
            "Rep productivity pressure",
            "CRM hygiene initiatives",
        ],
        "objections": [
            "We already have call recording software.",
            "We do not want another workflow tool reps ignore.",
        ],
    },
    "support": {
        "ideal_customer_profile": "Support leaders or founders at Shopify brands with growing ticket volume and lean teams.",
        "pain_points": [
            "Agents spend time hunting order, policy, and refund context.",
            "Ticket backlogs grow during promotions or seasonal demand spikes.",
            "Reply quality varies across agents and channels.",
        ],
        "buying_triggers": [
            "Rising ticket volume",
            "Pressure to reduce first-response time",
            "Need to scale support without proportional headcount growth",
        ],
        "objections": [
            "We cannot risk wrong responses to customers.",
            "Generic AI tools do not understand our commerce workflows.",
        ],
    },
    "compliance": {
        "ideal_customer_profile": "Compliance operations, risk, and control teams inside regulated financial institutions.",
        "pain_points": [
            "Manual policy review is slow and expensive.",
            "Evidence gathering across teams is fragmented.",
            "Approvals and traceability requirements create process bottlenecks.",
        ],
        "buying_triggers": [
            "Audit remediation",
            "Regulatory change programs",
            "Pressure to reduce review cycle time with full traceability",
        ],
        "objections": [
            "We need clear audit logs and review controls.",
            "Sensitive data handling and model governance are major concerns.",
        ],
    },
}

PRICING_DATA = {
    "sales": {
        "pricing_model": "Per-seat plus usage-based premium for CRM sync and team analytics.",
        "benchmarks": [
            "$30-$80 per user per month for meeting intelligence tools",
            "Premium add-ons for analytics, admin controls, and CRM workflow automation",
        ],
        "packaging_notes": [
            "Starter tier for rep productivity",
            "Growth tier for manager workflows and CRM sync",
            "Avoid enterprise-first packaging if targeting mid-market",
        ],
    },
    "support": {
        "pricing_model": "Platform fee plus ticket-volume tiers, with premium actions for commerce workflows.",
        "benchmarks": [
            "Support AI tools often mix seat pricing with automation or resolution volume",
            "Commerce buyers react well to ROI framed around deflection and faster handle time",
        ],
        "packaging_notes": [
            "Core copilot tier for agents",
            "Automation tier for suggestions plus order or refund workflows",
            "Keep onboarding simple for smaller merchant teams",
        ],
    },
    "compliance": {
        "pricing_model": "Annual platform pricing with workflow volume or business-unit expansion.",
        "benchmarks": [
            "Enterprise governance tools often sell via annual contracts",
            "Pricing depends heavily on approval depth, audit trail needs, and integration surface",
        ],
        "packaging_notes": [
            "Pilot with one compliance workflow",
            "Expand by business unit, framework, or review volume",
            "Position ROI around analyst leverage and faster audit readiness",
        ],
    },
}

RISK_DATA = {
    "sales": {
        "risks": [
            "Crowded category and weak differentiation if product looks like generic note-taking",
            "Integration quality will make or break retention",
            "Users may resist another post-meeting workflow unless value is immediate",
        ],
        "mitigations": [
            "Anchor product on action execution rather than summary generation",
            "Invest early in CRM and manager workflow depth",
        ],
    },
    "support": {
        "risks": [
            "Customer-facing mistakes can damage brand trust",
            "Merchant workflows vary significantly by catalog, policy, and tooling",
            "ROI claims can be weak if automation quality is inconsistent",
        ],
        "mitigations": [
            "Start in copilot mode with human approval for risky actions",
            "Use strong policy and order-context retrieval before suggesting actions",
        ],
    },
    "compliance": {
        "risks": [
            "Enterprise sales cycles and security reviews are long",
            "Regulated teams require explainability, approvals, and audit trails",
            "Model usage may be restricted depending on data sensitivity",
        ],
        "mitigations": [
            "Lead with human-reviewed workflows and strong auditability",
            "Target narrow, high-value compliance use cases first",
        ],
    },
}


def infer_market_theme(text: str) -> str:
    lowered = text.lower()
    if any(keyword in lowered for keyword in ["sales", "meeting", "revops", "crm"]):
        return "sales"
    if any(keyword in lowered for keyword in ["support", "merchant", "shopify", "ticket"]):
        return "support"
    if any(keyword in lowered for keyword in ["compliance", "regulated", "financial", "audit"]):
        return "compliance"
    return "sales"


def _compact_json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, indent=2)


@tool("market_dataset_lookup")
def market_dataset_lookup(query: str) -> str:
    """Look up mock market size, demand signals, and adoption barriers for the product brief."""
    theme = infer_market_theme(query)
    return _compact_json({"theme": theme, **MARKET_DATA[theme]})


@tool("competitor_landscape_lookup")
def competitor_landscape_lookup(query: str) -> str:
    """Look up mock competitor landscape, strengths, gaps, and whitespace opportunities."""
    theme = infer_market_theme(query)
    return _compact_json({"theme": theme, **COMPETITOR_DATA[theme]})


@tool("customer_signal_lookup")
def customer_signal_lookup(query: str) -> str:
    """Look up mock ICP, customer pain points, buying triggers, and buyer objections."""
    theme = infer_market_theme(query)
    return _compact_json({"theme": theme, **CUSTOMER_DATA[theme]})


@tool("pricing_benchmark_lookup")
def pricing_benchmark_lookup(query: str) -> str:
    """Look up mock pricing benchmarks, packaging patterns, and monetization guidance."""
    theme = infer_market_theme(query)
    return _compact_json({"theme": theme, **PRICING_DATA[theme]})


@tool("risk_signal_lookup")
def risk_signal_lookup(query: str) -> str:
    """Look up mock market, execution, and compliance risks plus mitigation ideas."""
    theme = infer_market_theme(query)
    return _compact_json({"theme": theme, **RISK_DATA[theme]})


def build_agents() -> dict[str, Agent]:
    llm = DEFAULT_MODEL
    shared_tools = [market_dataset_lookup, competitor_landscape_lookup, customer_signal_lookup, pricing_benchmark_lookup]
    return {
        "manager": Agent(
            role="Research Director",
            goal="Lead a market intelligence team, delegate work wisely, and produce an executive-ready recommendation.",
            backstory=(
                "You are a seasoned strategy leader who turns ambiguous market questions "
                "into clear research plans, coordinates specialist analysts, and validates "
                "the quality of each deliverable before presenting it to leadership."
            ),
            verbose=False,
            allow_delegation=True,
            llm=llm,
        ),
        "market": Agent(
            role="Market Analyst",
            goal="Estimate demand, identify trends, and explain why the target segment may or may not be attractive.",
            backstory=(
                "You study market behavior, buyer demand, and expansion opportunities in "
                "software categories, especially AI-enabled B2B workflows."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
            tools=[market_dataset_lookup],
        ),
        "competitor": Agent(
            role="Competitor Analyst",
            goal="Compare likely competitors, positioning patterns, and whitespace opportunities.",
            backstory=(
                "You specialize in competitor teardown work, product differentiation, "
                "feature comparison, and positioning strategy."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
            tools=[competitor_landscape_lookup, pricing_benchmark_lookup],
        ),
        "customer": Agent(
            role="Customer Insight Analyst",
            goal="Clarify ideal customer profile, pains, buying triggers, and likely objections.",
            backstory=(
                "You translate user behavior into actionable product and GTM insight, "
                "with strong intuition for jobs-to-be-done and adoption friction."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
            tools=[customer_signal_lookup, market_dataset_lookup],
        ),
        "pricing": Agent(
            role="Pricing Strategist",
            goal="Recommend packaging, monetization, and pricing guardrails that fit the market.",
            backstory=(
                "You design SaaS pricing and packaging strategies with an eye toward "
                "willingness to pay, buyer psychology, and land-and-expand motion."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
            tools=[pricing_benchmark_lookup, competitor_landscape_lookup],
        ),
        "risk": Agent(
            role="Risk Analyst",
            goal="Surface execution, compliance, adoption, and market-entry risks before launch.",
            backstory=(
                "You stress-test strategy plans, identify hidden assumptions, and make "
                "sure product teams do not ignore major delivery or regulatory risk."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
            tools=[risk_signal_lookup, market_dataset_lookup],
        ),
        "writer": Agent(
            role="Strategy Writer",
            goal="Turn specialist findings into a concise executive memo with practical recommendations.",
            backstory=(
                "You write for product and executive stakeholders and know how to convert "
                "messy research into a decision-ready memo."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
    }


def specialist_json_instruction(schema: str) -> str:
    return (
        "Use your assigned tool(s) before answering. Return valid JSON only with no markdown fence. "
        f"Required schema:\n{schema}"
    )


def build_tasks(brief: str, agents: dict[str, Agent], approval_mode: str) -> list[Task]:
    market_task = Task(
        description=(
            f"Market intelligence brief:\n{brief}\n\n"
            "Analyze the market opportunity and demand environment.\n"
            + specialist_json_instruction(
                """{
  "market_attractiveness": "short verdict",
  "market_size_summary": "1-2 sentence summary",
  "growth_signals": ["signal 1", "signal 2", "signal 3"],
  "adoption_barriers": ["barrier 1", "barrier 2"],
  "target_segment_angle": "best initial segment to target"
}"""
            )
        ),
        expected_output="A JSON object covering market attractiveness, demand signals, barriers, and target segment angle.",
        agent=agents["market"],
    )

    competitor_task = Task(
        description=(
            f"Market intelligence brief:\n{brief}\n\n"
            "Analyze the competitor landscape and identify differentiation options.\n"
            + specialist_json_instruction(
                """{
  "top_competitors": [{"name": "competitor", "strength": "strength", "gap": "gap"}],
  "category_pattern": "what the market generally looks like",
  "whitespace_opportunities": ["opportunity 1", "opportunity 2"],
  "positioning_warning": "main competitive trap to avoid"
}"""
            )
        ),
        expected_output="A JSON object with competitors, category pattern, whitespace, and positioning warning.",
        agent=agents["competitor"],
    )

    customer_task = Task(
        description=(
            f"Market intelligence brief:\n{brief}\n\n"
            "Analyze the customer profile and buyer behavior.\n"
            + specialist_json_instruction(
                """{
  "ideal_customer_profile": "single sentence ICP",
  "pain_points": ["pain 1", "pain 2", "pain 3"],
  "buying_triggers": ["trigger 1", "trigger 2"],
  "buyer_objections": ["objection 1", "objection 2"],
  "messaging_angle": "most compelling value angle"
}"""
            )
        ),
        expected_output="A JSON object with ICP, pain points, triggers, objections, and messaging angle.",
        agent=agents["customer"],
    )

    pricing_task = Task(
        description=(
            f"Market intelligence brief:\n{brief}\n\n"
            "Recommend pricing and packaging for the initial launch.\n"
            + specialist_json_instruction(
                """{
  "pricing_model": "recommended pricing model",
  "benchmark_notes": ["note 1", "note 2"],
  "initial_packaging": ["tier or package 1", "tier or package 2"],
  "pricing_risk": "main pricing risk",
  "monetization_recommendation": "short recommendation"
}"""
            )
        ),
        expected_output="A JSON object with pricing model, benchmark notes, packaging, and risks.",
        agent=agents["pricing"],
    )

    risk_task = Task(
        description=(
            f"Market intelligence brief:\n{brief}\n\n"
            "Assess launch and market-entry risks.\n"
            + specialist_json_instruction(
                """{
  "top_risks": ["risk 1", "risk 2", "risk 3"],
  "critical_assumptions": ["assumption 1", "assumption 2"],
  "mitigations": ["mitigation 1", "mitigation 2"],
  "overall_risk_level": "low/medium/high",
  "gating_issue": "biggest blocker if any"
}"""
            )
        ),
        expected_output="A JSON object with top risks, assumptions, mitigations, overall risk, and gating issue.",
        agent=agents["risk"],
    )

    memo_task = Task(
        description=(
            "Synthesize the specialist outputs into an executive market intelligence memo.\n"
            "Use the structured outputs from market, competitor, customer, pricing, and risk analysis.\n"
            "Return markdown with these sections:\n"
            "1. Executive Summary\n"
            "2. Target Segment Recommendation\n"
            "3. Competitive Positioning\n"
            "4. Pricing and Packaging\n"
            "5. Go / Pilot / No-Go Recommendation\n"
            "6. 30/60/90 Day Plan\n"
            "7. Top Risks\n"
            "8. Evidence Used from Specialist Outputs"
        ),
        expected_output="A polished executive memo in markdown.",
        agent=agents["writer"],
        context=[market_task, competitor_task, customer_task, pricing_task, risk_task],
    )

    approval_instructions = {
        "approve": (
            "Leadership approval mode is APPROVE. Return valid JSON only with keys "
            '`decision`, `reason`, `required_followups`, and `ship_readiness`.'
        ),
        "request_more_research": (
            "Leadership approval mode is REQUEST_MORE_RESEARCH. Return valid JSON only with keys "
            '`decision`, `reason`, `research_gaps`, `required_followups`, and `ship_readiness`.'
        ),
        "no_go": (
            "Leadership approval mode is NO_GO. Return valid JSON only with keys "
            '`decision`, `reason`, `blocking_issues`, `required_followups`, and `ship_readiness`.'
        ),
    }

    approval_task = Task(
        description=(
            f"Review the executive memo and all specialist outputs.\n"
            f"{approval_instructions.get(approval_mode, approval_instructions['approve'])}\n"
            "Base the final decision on the evidence, risks, and leadership posture."
        ),
        expected_output="A final approval decision in JSON.",
        agent=agents["manager"],
        context=[market_task, competitor_task, customer_task, pricing_task, risk_task, memo_task],
    )

    return [market_task, competitor_task, customer_task, pricing_task, risk_task, memo_task, approval_task]


def extract_json_payload(text: str) -> dict[str, Any] | None:
    if not text:
        return None
    text = text.strip()
    candidates = [text]
    fenced = re.findall(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.DOTALL)
    candidates.extend(fenced)
    brace_match = re.search(r"(\{.*\})", text, flags=re.DOTALL)
    if brace_match:
        candidates.append(brace_match.group(1))

    for candidate in candidates:
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue
    return None


def summarize_tooling(agents: dict[str, Agent]) -> dict[str, list[str]]:
    tool_summary: dict[str, list[str]] = {}
    for name, agent in agents.items():
        tool_summary[name] = [getattr(tool_obj, "name", str(tool_obj)) for tool_obj in getattr(agent, "tools", [])]
    return tool_summary


def run_market_intelligence_crew(brief: str, approval_mode: str = "approve") -> dict[str, object]:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "Missing OPENAI_API_KEY. Add it to your environment or a .env file before running this project."
        )

    agents = build_agents()
    tasks = build_tasks(brief, agents, approval_mode)
    manager = agents["manager"]
    specialist_agents = [agent for name, agent in agents.items() if name != "manager"]

    crew = Crew(
        agents=specialist_agents,
        tasks=tasks,
        manager_agent=manager,
        process=Process.hierarchical,
        planning=True,
        verbose=False,
    )

    start = time.time()
    final_output = crew.kickoff()
    total_time = time.time() - start

    task_outputs = []
    parsed_outputs: dict[str, Any] = {}
    for task in tasks:
        raw_output = getattr(task.output, "raw", None) if getattr(task, "output", None) else None
        title = task.agent.role if getattr(task, "agent", None) else task.description.splitlines()[0]
        parsed = extract_json_payload(raw_output or "")
        if parsed is not None:
            parsed_outputs[title] = parsed
        task_outputs.append(
            {
                "agent": title,
                "description": task.description,
                "output": raw_output or "No output captured.",
                "parsed_output": parsed,
            }
        )

    approval_decision = parsed_outputs.get(manager.role) or parsed_outputs.get("Research Director")

    return {
        "brief": brief,
        "final_output": str(final_output),
        "task_outputs": task_outputs,
        "structured_outputs": parsed_outputs,
        "approval_decision": approval_decision,
        "total_time": total_time,
        "model": DEFAULT_MODEL,
        "process": "hierarchical",
        "approval_mode": approval_mode,
        "manager_role": manager.role,
        "specialist_roles": [agent.role for agent in specialist_agents],
        "tool_summary": summarize_tooling(agents),
    }


def run_demo() -> None:
    print("=" * 78)
    print("P21 - CrewAI Hierarchical Market Intelligence Demo")
    print("=" * 78)
    print()
    brief = MARKET_SCENARIOS[0]
    print("Brief:")
    print(brief)
    print()
    result = run_market_intelligence_crew(brief, approval_mode="request_more_research")
    print("Executive Memo:")
    print(result["final_output"])
    print()
    print("Approval Decision:")
    print(json.dumps(result["approval_decision"], indent=2))
    print()
    print(f"Completed in {result['total_time']:.1f}s using {result['model']}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python market_intelligence.py demo")
