﻿# GenAI Learning Roadmap â€” Demo Projects Master Plan

> **Created:** April 2026
> **Infrastructure:** Azure VM (10.0.0.32) + OpenAI API
> **Stack:** Python 3.12, latest libraries, Streamlit UIs
> **Repo:** c:\work\docs\genai\genai-learning\projects\

---

## Architecture

```
Azure VM (10.0.0.32)
â”œâ”€â”€ /home/azureuser/genai-projects/
â”‚   â”œâ”€â”€ 01-rag-pdf-qa/          (Port 8501)
â”‚   â”œâ”€â”€ 02-function-calling/    (Port 8502)
â”‚   â”œâ”€â”€ 03-structured-output/   (Port 8503)
â”‚   â”œâ”€â”€ 04-guardrails/          (Port 8504)
â”‚   â”œâ”€â”€ 05-react-agent/         (Port 8505)
â”‚   â”œâ”€â”€ 06-agent-workflows/     (Port 8506)
â”‚   â”œâ”€â”€ 07-multi-agent/         (Port 8507)
â”‚   â”œâ”€â”€ 08-mcp-server/          (Port 8508)
â”‚   â”œâ”€â”€ 09-a2a-protocol/        (Port 8509)
â”‚   â”œâ”€â”€ 10-advanced-rag/        (Port 8510)
â”‚   â”œâ”€â”€ 11-graphrag/            (Port 8511)
â”‚   â”œâ”€â”€ 12-local-slm/           (Port 8512)
â”‚   â”œâ”€â”€ 13-multimodal/          (Port 8513)
â”‚   â”œâ”€â”€ 14-voice-ai/            (Port 8514)
â”‚   â”œâ”€â”€ 15-evaluation/          (Port 8515)
â”‚   â”œâ”€â”€ 16-llmops/              (Port 8516)
â”‚   â”œâ”€â”€ 17-quantization/        (Port 8517)
â”‚   â”œâ”€â”€ 18-ai-gateway/          (Port 8518)
â”‚   â”œâ”€â”€ 19-langgraph-realtime-ops/ (Port 8519)
â”‚   â””â”€â”€ 20-crewai-business-workflow/ (Port 8520)
```

---

## Phase 1: Core Application Patterns (Concepts 6-10)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P01 | `01-rag-pdf-qa` | RAG + Vector DB | Enterprise knowledge base â€” Q&A over company policies, product docs, research papers | LangChain, ChromaDB, OpenAI Embeddings | âœ… Done |
| P02 | `02-function-calling` | Function Calling / Tool Use | AI assistant with live weather, stock, math, and dictionary tools â€” full tool-call loop with parallel & sequential chains | OpenAI Functions API | âœ… Done |
| P03 | `03-structured-output` | Structured Output | Multi-domain data extraction â€” invoices (finance), resumes (HR), medical prescriptions (healthcare), bug reports (engineering) | OpenAI Structured Outputs, Pydantic v2, Instructor | âœ… Done |
| P04 | `04-guardrails` | Guardrails & Safety | Production chatbot safety â€” prompt injection defense, PII redaction, topic control, toxicity filtering | Guardrails AI, Presidio, custom validators | âœ… Done |

## Phase 2: Agents & Orchestration (Concepts 11-16)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P05 | `05-react-agent` | AI Agents + ReAct | Competitive intelligence agent â€” researches companies, gathers financials, writes analysis reports | LangGraph, Tavily Search | âœ… Done |
| P06 | `06-agent-workflows` | Agentic Patterns | DevOps incident response â€” router classifies severity, planner creates runbook, reflection reviews fix quality | LangGraph state machines | âœ… Done |
| P07 | `07-multi-agent` | Multi-Agent Systems | Software team simulation â€” PM writes specs, Developer codes, QA tests, Tech Lead reviews | CrewAI | âœ… Done |
| P08 | `08-mcp-server` | MCP Protocol | Custom MCP server â€” file manager + database query + web scraper tools, usable from any MCP client | FastMCP (Python SDK) | âœ… Done |
| P09 | `09-a2a-protocol` | A2A Protocol | Cross-team agent collaboration â€” Sales agent discovers CRM agent, delegates lead processing via A2A | Google A2A SDK | âœ… Done |

## Phase 3: Advanced Techniques (Concepts 17-25)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P10 | `10-advanced-rag` | Advanced RAG | Legal contract analyzer â€” HyDE, reranking, CRAG self-correction, agentic retrieval from multi-source corpus | LangGraph, Cohere Rerank | âœ… Done |
| P11 | `11-graphrag` | GraphRAG | Fraud investigation network â€” extract entities/relationships from case files, traverse connections | Microsoft GraphRAG, NetworkX | âœ… Done |
| P12 | `12-local-slm` | SLMs | Edge-deployed code review assistant â€” runs locally via Ollama, no API calls, compares quality vs cloud LLMs | Ollama, Qwen2 0.5B | âœ… Done |
| P13 | `13-multimodal` | Multimodal AI | Insurance claims processor â€” analyze damage photos, extract form data, read charts from reports | GPT-4o Vision | âœ… Done |
| P14 | `14-voice-ai` | Voice & Audio AI | Meeting assistant â€” transcribe audio, generate summary, action items, and follow-up email | Whisper, OpenAI TTS | âœ… Done |
| P15 | `15-evaluation` | Evaluation & Observability | RAG quality dashboard â€” evaluate P01 with Ragas metrics, trace latency, measure faithfulness/relevancy | Ragas, LangSmith/Langfuse | âœ… Done |

## Phase 4: Production (Concepts 26-28)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P16 | `16-llmops` | LLMOps | Prompt CI/CD â€” version prompts, automated eval in GitHub Actions, cost tracking dashboard | Promptfoo, MLflow | âœ… Done |
| P17 | `17-quantization` | Quantization & Optimization | Model compression lab â€” quantize Mistral 7B to GGUF 4-bit, benchmark speed/quality tradeoffs | llama.cpp, llama-cpp-python | âœ… Done |
| P18 | `18-ai-gateway` | AI Gateway & Routing | Multi-provider gateway â€” unified API, smart routing by complexity, fallback chains, semantic caching | LiteLLM Proxy | âœ… Done |
| P19 | `19-langgraph-realtime-ops` | LangGraph Real-Time Ops | Incident command center â€” classify alerts, enrich with telemetry, branch on severity, escalate to human review, and generate remediation plan | LangGraph, OpenAI Structured Outputs | âœ… Done |
| P20 | `20-crewai-business-workflow` | CrewAI Business Workflow | Revenue operations launch crew â€” strategy, operations, messaging, and risk review collaborate to ship a business initiative | CrewAI | âœ… Done |
| P21 | `21-crewai-hierarchical-market-intelligence` | CrewAI Hierarchical Process | Market intelligence director - a manager agent delegates research, competitor analysis, pricing, and risk review before producing an executive recommendation | CrewAI | Done |

---


## Per-Project Structure

```
<project>/
â”œâ”€â”€ STEPS.md             # Step-by-step guide: setup, run, understand
â”œâ”€â”€ requirements.txt     # Python dependencies
â”œâ”€â”€ .env                 # API keys (gitignored)
â”œâ”€â”€ *.py                 # Core implementation files
â”œâ”€â”€ app.py               # Streamlit UI (where applicable)
â””â”€â”€ sample_data/         # Test data (where applicable)
```

---

## Execution Log

| Date | Project | Action | Result |
|------|---------|--------|--------|
| 2026-04-07 | P01 | Deployed + tested CLI + Streamlit | âœ… 3 PDFs ingested, Q&A working |
| 2026-04-07 | P02 | Deployed + tested 5 demos + Streamlit | âœ… All tool patterns working |
| 2026-04-07 | P03 | Deployed + fixed schema/render bugs | âœ… All 4 extractors working |
| 2026-04-07 | P04â€“P18 | Batch generated, deployed, tested | âœ… All 15 projects running |
| 2026-04-15 | P19,P20 | Added true LangGraph and CrewAI examples with Streamlit UIs | âœ… Repo now includes 20 projects |
| 2026-04-07 | P05,P06,P07,P08,P10,P11 | Fixed button/validation + session state bugs | âœ… All interactive inputs working |
| 2026-04-07 | P12 | Installed Ollama, pulled phi3 + qwen2:0.5b | âœ… Local SLM running on CPU |
| 2026-04-08 | All | Final cleanup, README, architecture docs | âœ… Git-ready |
