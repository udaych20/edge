# P20 - CrewAI Software Release Review

## Concept
This project shows a true **CrewAI** implementation for a role-based software workflow:
- **Specialized agents** with distinct engineering responsibilities
- **Sequential task handoffs** from technical scoping to validation and release review
- **Shared context** between tasks
- **Engineering-ready outputs** instead of toy prompts

## Real-World Scenario
**Software Release Review Crew** - An engineering team needs to turn a feature request
into a production-ready release plan. A tech lead defines scope, a backend engineer
reviews system impact, QA creates validation coverage, SRE checks operational readiness,
and security performs a final release review.

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/20-crewai-business-workflow
python3 business_workflow.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8520
```

### Step 3: Try Different Release Requests
Use the sample scenarios or paste your own:
- OAuth login release
- Async invoice processing rollout
- Semantic search API launch

The crew will produce a technical scope brief, implementation review,
QA plan, SRE readiness review, and a final security decision.

## Key Takeaways
- CrewAI is a natural fit when the problem is best modeled as a **team**
  of specialized reviewers
- The task and context abstraction makes inter-agent handoffs easy to follow
- This pattern is especially useful for release reviews, change management,
  and engineering readiness workflows
