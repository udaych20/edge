"""
P20 - CrewAI Software Release Review
====================================
Role-based software release workflow using CrewAI.
"""

from __future__ import annotations

import os
import time

from crewai import Agent, Crew, Process, Task
from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


BUSINESS_SCENARIOS = [
    "Prepare a production release plan for adding OAuth login and audit logging to our SaaS platform. Include architecture impact, testing strategy, deployment risks, rollback plan, and security review.",
    "Review the release readiness for a new background job system that processes customer invoices asynchronously. Cover service dependencies, failure modes, observability, and go-live risks.",
    "Plan the launch of a semantic search API for internal documentation. Include technical scope, QA coverage, production monitoring, and security concerns before release.",
]


def build_agents() -> dict[str, Agent]:
    llm = DEFAULT_MODEL
    return {
        "lead": Agent(
            role="Tech Lead",
            goal="Turn a release request into a clear technical scope with practical success criteria.",
            backstory=(
                "You lead platform and product engineering projects and are skilled at "
                "turning vague feature ideas into shippable technical plans."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "backend": Agent(
            role="Backend Engineer",
            goal="Review implementation impact across APIs, services, data models, and failure paths.",
            backstory=(
                "You build backend systems and think carefully about integration points, "
                "performance, and operational failure modes."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "qa": Agent(
            role="QA Engineer",
            goal="Design a practical validation plan with regression coverage and edge cases.",
            backstory=(
                "You protect release quality by defining test strategy, reproducible checks, "
                "and realistic failure scenarios."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "sre": Agent(
            role="SRE Reviewer",
            goal="Evaluate deployment readiness, observability, rollback safety, and production risk.",
            backstory=(
                "You own production reliability and make sure releases are observable, "
                "recoverable, and safe to operate."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "security": Agent(
            role="Security Reviewer",
            goal="Review the release for auth, data protection, abuse, and compliance risks.",
            backstory=(
                "You review software launches for security posture, access control, "
                "sensitive data handling, and policy gaps."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
    }


def build_tasks(request: str, agents: dict[str, Agent]) -> list[Task]:
    scope_task = Task(
        description=(
            f"Release request:\n{request}\n\n"
            "Produce a technical release brief with:\n"
            "1. Feature scope and primary user impact\n"
            "2. Architecture or system components affected\n"
            "3. Success criteria and non-goals\n"
            "4. Key assumptions, dependencies, and open questions\n"
            "Keep it concrete and engineering-focused."
        ),
        expected_output="A release brief with scope, architecture impact, success criteria, and assumptions.",
        agent=agents["lead"],
    )

    implementation_task = Task(
        description=(
            "Using the release brief, create an implementation review with:\n"
            "1. Services, APIs, or data models affected\n"
            "2. Integration points and dependencies\n"
            "3. Likely failure modes or scaling concerns\n"
            "4. Recommended engineering checklist before release"
        ),
        expected_output="An implementation review with impacted systems, risks, and an engineering checklist.",
        agent=agents["backend"],
        context=[scope_task],
    )

    qa_task = Task(
        description=(
            "Using the release brief and implementation review, create a QA validation plan with:\n"
            "1. Core test scenarios\n"
            "2. Regression coverage areas\n"
            "3. Edge cases and negative tests\n"
            "4. Exit criteria for sign-off"
        ),
        expected_output="A QA plan with test scenarios, edge cases, and release exit criteria.",
        agent=agents["qa"],
        context=[scope_task, implementation_task],
    )

    sre_task = Task(
        description=(
            "Using the release brief, implementation review, and QA plan, produce an SRE readiness review with:\n"
            "1. Deployment strategy\n"
            "2. Monitoring, alerting, and logging requirements\n"
            "3. Rollback or mitigation plan\n"
            "4. Operational risks before release"
        ),
        expected_output="An SRE readiness review with deployment, observability, and rollback guidance.",
        agent=agents["sre"],
        context=[scope_task, implementation_task, qa_task],
    )

    security_task = Task(
        description=(
            "Review the complete release package and produce a final security and release decision with:\n"
            "1. Go / no-go recommendation\n"
            "2. Security concerns and mitigations\n"
            "3. Missing controls or approvals\n"
            "4. Final readiness summary for engineering leadership"
        ),
        expected_output="A final release decision with security findings, mitigations, and readiness summary.",
        agent=agents["security"],
        context=[scope_task, implementation_task, qa_task, sre_task],
    )

    return [scope_task, implementation_task, qa_task, sre_task, security_task]


def run_business_crew(request: str) -> dict[str, object]:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "Missing OPENAI_API_KEY. Add it to your environment or a .env file before running this project."
        )
    agents = build_agents()
    tasks = build_tasks(request, agents)
    crew = Crew(
        agents=list(agents.values()),
        tasks=tasks,
        process=Process.sequential,
        verbose=False,
    )

    start = time.time()
    final_output = crew.kickoff()
    total_time = time.time() - start

    task_outputs = []
    for task in tasks:
        raw_output = getattr(task.output, "raw", None) if getattr(task, "output", None) else None
        task_outputs.append(
            {
                "agent": task.agent.role,
                "description": task.description,
                "output": raw_output or "No output captured.",
            }
        )

    return {
        "request": request,
        "final_output": str(final_output),
        "task_outputs": task_outputs,
        "total_time": total_time,
        "model": DEFAULT_MODEL,
    }


def run_demo() -> None:
    print("=" * 72)
    print("P20 - CrewAI Software Release Review Demo")
    print("=" * 72)
    print()
    request = BUSINESS_SCENARIOS[0]
    print("Request:")
    print(request)
    print()
    result = run_business_crew(request)
    print("Final Output:")
    print(result["final_output"])
    print()
    print(f"Completed in {result['total_time']:.1f}s using {result['model']}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python business_workflow.py demo")
