"""
LangGraph Full Reference Guide
================================
Covers every major LangGraph concept with working examples:

  SECTION 1 - State & Reducers
  SECTION 2 - Nodes (all variants)
  SECTION 3 - Edges (all variants)
  SECTION 4 - Graph Types (StateGraph, MessageGraph, Subgraphs)
  SECTION 5 - Memory & Checkpointers (4 types)
  SECTION 6 - Human-in-the-Loop (interrupt_before / interrupt_after)
  SECTION 7 - Streaming (values, updates, events, debug)
  SECTION 8 - Parallel Fan-Out with the Send API
  SECTION 9 - Subgraphs (nested graphs)
  SECTION 10 - ToolNode (built-in tool execution)
  SECTION 11 - Full kitchen-sink demo
"""

from __future__ import annotations

import json
import operator
import sqlite3
import uuid
from typing import Annotated, Any, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.types import Command, Send

load_dotenv()

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — STATE & REDUCERS
# ─────────────────────────────────────────────────────────────────────────────
# State is a TypedDict that flows through every node.
# Each field can have a *reducer* via Annotated[type, reducer_fn].
# A reducer controls HOW incoming partial updates are merged into the state.

class BasicState(TypedDict):
    """Plain fields — each node OVERWRITES the previous value."""
    query: str
    result: str
    attempts: int


class ReducerState(TypedDict):
    """
    Fields with reducers — langgraph MERGES updates instead of overwriting.

    Annotated[list[str], operator.add]  → appends lists (never loses old items)
    Annotated[list[BaseMessage], add_messages] → appends and deduplicates messages
    """
    query: str
    steps: Annotated[list[str], operator.add]      # accumulator list
    messages: Annotated[list[BaseMessage], add_messages]  # message log
    score: int                                       # plain overwrite


# MessagesState is a built-in state with a single `messages` field using add_messages.
# Equivalent to: class MyState(TypedDict): messages: Annotated[list, add_messages]
# Use it as the base class instead of TypedDict when you mainly work with chat messages.

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — NODES
# ─────────────────────────────────────────────────────────────────────────────
# A node is ANY callable: plain function, lambda, class.__call__, async def.
# It receives the FULL state and returns a PARTIAL dict (only changed fields).

# --- 2a. Plain function node ---
def plain_node(state: BasicState) -> dict:
    return {"result": f"processed: {state['query']}"}


# --- 2b. Node that accumulates (uses reducer) ---
def step_node(state: ReducerState) -> dict:
    # returning a list here — operator.add will APPEND it to existing steps
    return {"steps": ["step_node ran"], "score": state["score"] + 1}


# --- 2c. Async node ---
async def async_node(state: BasicState) -> dict:
    # await any coroutine here (http calls, DB queries, …)
    return {"result": "async result"}


# --- 2d. Node that calls an LLM ---
def llm_node(state: ReducerState) -> dict:
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    response = llm.invoke(state["messages"])
    return {"messages": [response]}  # add_messages reducer appends it


# --- 2e. Node using Command (advanced: redirect flow from inside the node) ---
def command_node(state: BasicState) -> Command:
    # Command lets a node decide BOTH the state update AND where to go next.
    # This is an alternative to conditional edges when the node itself knows routing.
    if "error" in state["query"]:
        return Command(update={"result": "error path"}, goto="error_handler")
    return Command(update={"result": "ok"}, goto=END)


# --- 2f. Entry-point node (same as any other node — label is just convention) ---
def entry_node(state: BasicState) -> dict:
    return {"attempts": 0}


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — EDGES
# ─────────────────────────────────────────────────────────────────────────────

# There are 5 edge types:

# 1. add_edge(START, "node")         — graph entry point
# 2. add_edge("a", "b")              — unconditional next step
# 3. add_edge("z", END)              — unconditional termination
# 4. add_conditional_edges(...)      — router: one source → many possible targets
# 5. add_conditional_edges with Send — fan-out: one source → N parallel branches

def router(state: BasicState) -> Literal["node_a", "node_b", "end"]:
    """
    Conditional edge function — returns the NAME of the next node.
    Must return a value that matches one of the keys in the routing dict
    passed to add_conditional_edges, OR the actual node name directly.
    """
    if state["attempts"] > 3:
        return "end"
    elif "urgent" in state["query"]:
        return "node_a"
    else:
        return "node_b"


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 4 — GRAPH TYPES
# ─────────────────────────────────────────────────────────────────────────────

# ── 4a. StateGraph ───────────────────────────────────────────────────────────
# Most common. You define your own TypedDict state.
def build_state_graph_example():
    graph = StateGraph(BasicState)

    graph.add_node("start_node", entry_node)
    graph.add_node("process", plain_node)

    graph.add_edge(START, "start_node")
    graph.add_edge("start_node", "process")
    graph.add_edge("process", END)

    return graph.compile()


# ── 4b. MessagesState graph (chat-style) ─────────────────────────────────────
# Use when building chatbots. State is just {messages: list[BaseMessage]}.
def build_messages_graph_example():
    graph = StateGraph(MessagesState)

    def chat_node(state: MessagesState) -> dict:
        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        return {"messages": [llm.invoke(state["messages"])]}

    graph.add_node("chat", chat_node)
    graph.add_edge(START, "chat")
    graph.add_edge("chat", END)
    return graph.compile()


# ── 4c. Graph with input/output schema filtering ─────────────────────────────
# input_schema  — only these fields are accepted from the caller
# output_schema — only these fields are returned to the caller
class InputSchema(TypedDict):
    query: str

class OutputSchema(TypedDict):
    result: str

def build_schema_filtered_graph():
    graph = StateGraph(BasicState, input=InputSchema, output=OutputSchema)
    graph.add_node("process", plain_node)
    graph.add_edge(START, "process")
    graph.add_edge("process", END)
    return graph.compile()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 5 — MEMORY & CHECKPOINTERS (4 types)
# ─────────────────────────────────────────────────────────────────────────────
#
# A checkpointer saves EVERY graph state snapshot to persistent storage.
# This gives you:
#   • Thread memory  — resume interrupted runs (human-in-the-loop)
#   • Cross-session  — same thread_id brings back old messages
#   • Time-travel    — replay from any prior checkpoint
#   • Fault recovery — re-invoke after crashes without losing progress
#
# TYPE 1 — MemorySaver (in-process RAM, lost on restart, great for dev/tests)
# TYPE 2 — SqliteSaver (local SQLite file, persists across restarts)
# TYPE 3 — AsyncSqliteSaver (same but async-compatible)
# TYPE 4 — PostgresSaver (production; requires langgraph-checkpoint-postgres pkg)

def demo_memory_types():
    """Shows how to attach each checkpointer type to a graph."""

    def simple_node(state: BasicState) -> dict:
        return {"result": f"answered: {state['query']}", "attempts": state.get("attempts", 0) + 1}

    def make_graph(checkpointer):
        g = StateGraph(BasicState)
        g.add_node("node", simple_node)
        g.add_edge(START, "node")
        g.add_edge("node", END)
        return g.compile(checkpointer=checkpointer)

    # ── TYPE 1: MemorySaver ───────────────────────────────────────────────
    memory_saver = MemorySaver()
    graph_mem = make_graph(memory_saver)

    # thread_id makes each conversation independent
    cfg_a = {"configurable": {"thread_id": "user-alice"}}
    cfg_b = {"configurable": {"thread_id": "user-bob"}}

    graph_mem.invoke({"query": "hello", "result": "", "attempts": 0}, config=cfg_a)
    graph_mem.invoke({"query": "world", "result": "", "attempts": 0}, config=cfg_b)

    # Retrieve a saved state snapshot
    snapshot_a = graph_mem.get_state(cfg_a)
    print("[MemorySaver] Alice snapshot:", snapshot_a.values["result"])

    # List ALL checkpoints for a thread
    history = list(graph_mem.get_state_history(cfg_a))
    print(f"[MemorySaver] {len(history)} checkpoint(s) for Alice")

    # ── TYPE 2: SqliteSaver ───────────────────────────────────────────────
    conn = sqlite3.connect("checkpoints.db", check_same_thread=False)
    sqlite_saver = SqliteSaver(conn)
    graph_sql = make_graph(sqlite_saver)

    cfg_sql = {"configurable": {"thread_id": "persistent-thread"}}
    graph_sql.invoke({"query": "persisted query", "result": "", "attempts": 0}, config=cfg_sql)

    snapshot_sql = graph_sql.get_state(cfg_sql)
    print("[SqliteSaver] Persisted result:", snapshot_sql.values["result"])

    # ── TYPE 3 & 4 notes ─────────────────────────────────────────────────
    # TYPE 3 - AsyncSqliteSaver (for async workflows):
    #   from langgraph.checkpoint.aiosqlite import AsyncSqliteSaver
    #   async with AsyncSqliteSaver.from_conn_string("checkpoints.db") as saver:
    #       graph = make_graph(saver)
    #       await graph.ainvoke(...)

    # TYPE 4 - PostgresSaver (production scale):
    #   from langgraph.checkpoint.postgres import PostgresSaver
    #   saver = PostgresSaver.from_conn_string("postgresql://user:pw@host/db")
    #   graph = make_graph(saver)

    return graph_mem, cfg_a


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 6 — HUMAN-IN-THE-LOOP
# ─────────────────────────────────────────────────────────────────────────────
# interrupt_before / interrupt_after pause the graph at a node boundary.
# The caller gets back a snapshot; after review, call .invoke() again to resume.

def build_human_review_graph():
    memory = MemorySaver()
    graph = StateGraph(BasicState)

    def draft_answer(state: BasicState) -> dict:
        return {"result": f"Draft: {state['query']}"}

    def publish(state: BasicState) -> dict:
        return {"result": f"Published: {state['result']}"}

    graph.add_node("draft", draft_answer)
    graph.add_node("publish", publish)
    graph.add_edge(START, "draft")
    graph.add_edge("draft", "publish")
    graph.add_edge("publish", END)

    # Graph pauses BEFORE "publish" — human can inspect/edit state first
    return graph.compile(checkpointer=memory, interrupt_before=["publish"])


def demo_human_in_the_loop():
    graph = build_human_review_graph()
    cfg = {"configurable": {"thread_id": "review-thread"}}

    # First invoke — runs "draft", then PAUSES before "publish"
    state = graph.invoke({"query": "Write a blog post", "result": "", "attempts": 0}, config=cfg)
    print("[HITL] Paused. Draft result:", state["result"])

    # Human inspects; optionally edits the state
    graph.update_state(cfg, {"result": "Edited by human: " + state["result"]})

    # Resume — continues from the interrupt point (publish runs now)
    final = graph.invoke(None, config=cfg)
    print("[HITL] Final after human edit:", final["result"])


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 7 — STREAMING
# ─────────────────────────────────────────────────────────────────────────────
# Four streaming modes:
#   "values"  — full state after EACH node completes
#   "updates" — only the partial dict returned by each node
#   "events"  — low-level events (on_node_start, on_node_end, on_llm_token, …)
#   "debug"   — internal checkpointer events (verbose, for debugging)

def demo_streaming():
    graph = build_state_graph_example()
    initial = {"query": "streaming demo", "result": "", "attempts": 0}

    print("\n── stream mode: values ──")
    for chunk in graph.stream(initial, stream_mode="values"):
        print("  state:", chunk)

    print("\n── stream mode: updates ──")
    for node_name, update in graph.stream(initial, stream_mode="updates"):
        print(f"  {node_name} returned:", update)

    # For LLM token streaming use astream_events (async) or the events mode:
    # async for event in graph.astream_events(initial, version="v2"):
    #     if event["event"] == "on_chat_model_stream":
    #         print(event["data"]["chunk"].content, end="", flush=True)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 8 — PARALLEL FAN-OUT WITH Send API
# ─────────────────────────────────────────────────────────────────────────────
# Send lets you spawn N parallel branches with DIFFERENT state payloads.
# All branches run concurrently; their results are merged by the reducer.

class FanOutState(TypedDict):
    topics: list[str]
    summaries: Annotated[list[str], operator.add]  # reducer accumulates results


def generate_topics(state: FanOutState) -> list[Send]:
    """Fan-out: one Send per topic → each runs summarize_topic in parallel."""
    return [Send("summarize_topic", {"topic": t, "summaries": []}) for t in state["topics"]]


class TopicState(TypedDict):
    topic: str
    summaries: Annotated[list[str], operator.add]


def summarize_topic(state: TopicState) -> dict:
    return {"summaries": [f"Summary of {state['topic']}"]}


def build_fanout_graph():
    graph = StateGraph(FanOutState)
    graph.add_node("summarize_topic", summarize_topic)

    # Conditional edge with Send — returns list[Send] instead of a string
    graph.add_conditional_edges(START, generate_topics, ["summarize_topic"])
    graph.add_edge("summarize_topic", END)
    return graph.compile()


def demo_fanout():
    graph = build_fanout_graph()
    result = graph.invoke({"topics": ["AI", "Cloud", "Security"], "summaries": []})
    print("[Fan-out] Summaries:", result["summaries"])


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 9 — SUBGRAPHS (nested graphs)
# ─────────────────────────────────────────────────────────────────────────────
# A compiled graph can be used as a NODE inside another graph.
# State schemas don't need to match — only shared keys are passed through.

class SubState(TypedDict):
    query: str
    sub_result: str


def build_sub_graph():
    g = StateGraph(SubState)

    def sub_node(state: SubState) -> dict:
        return {"sub_result": f"sub processed: {state['query']}"}

    g.add_node("sub_node", sub_node)
    g.add_edge(START, "sub_node")
    g.add_edge("sub_node", END)
    return g.compile()


class ParentState(TypedDict):
    query: str
    sub_result: str
    final: str


def build_parent_graph():
    sub = build_sub_graph()  # compiled graph

    parent = StateGraph(ParentState)

    def pre_node(state: ParentState) -> dict:
        return {"query": state["query"].upper()}

    def post_node(state: ParentState) -> dict:
        return {"final": f"parent got: {state['sub_result']}"}

    parent.add_node("pre", pre_node)
    parent.add_node("sub_graph", sub)   # subgraph is just a node
    parent.add_node("post", post_node)

    parent.add_edge(START, "pre")
    parent.add_edge("pre", "sub_graph")
    parent.add_edge("sub_graph", "post")
    parent.add_edge("post", END)
    return parent.compile()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 10 — ToolNode (built-in tool execution)
# ─────────────────────────────────────────────────────────────────────────────
# ToolNode is a pre-built node that:
#   1. Reads tool_calls from the last AIMessage
#   2. Executes each tool
#   3. Appends ToolMessage results to state["messages"]
# tools_condition is a pre-built router: goes to tools if there are tool_calls,
# otherwise goes to END.

@tool
def get_weather(city: str) -> str:
    """Returns current weather for a city."""
    return f"Weather in {city}: 22°C, sunny."

@tool
def get_population(city: str) -> str:
    """Returns population of a city."""
    return f"Population of {city}: 3.9M"


def build_tool_graph():
    tools = [get_weather, get_population]
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0).bind_tools(tools)

    def call_llm(state: MessagesState) -> dict:
        return {"messages": [llm.invoke(state["messages"])]}

    graph = StateGraph(MessagesState)
    graph.add_node("llm", call_llm)
    graph.add_node("tools", ToolNode(tools))   # ToolNode handles all tool execution

    graph.add_edge(START, "llm")
    graph.add_conditional_edges("llm", tools_condition)  # → "tools" or END
    graph.add_edge("tools", "llm")             # loop back after tool execution
    return graph.compile()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 11 — ALL GRAPH METHODS QUICK REFERENCE
# ─────────────────────────────────────────────────────────────────────────────
#
# Building:
#   graph.add_node(name, fn)                           add a node
#   graph.add_edge(src, dst)                           unconditional edge
#   graph.add_conditional_edges(src, router_fn, map)   conditional edge
#   graph.set_entry_point(name)                        alias for add_edge(START, name)
#   graph.set_finish_point(name)                       alias for add_edge(name, END)
#   graph.compile(checkpointer, interrupt_before,      compile → runnable
#                 interrupt_after, debug)
#
# Running (synchronous):
#   graph.invoke(input, config)                        run to completion → final state
#   graph.stream(input, config, stream_mode)           generator of chunks
#   graph.get_state(config)                            current state snapshot
#   graph.get_state_history(config)                    all past checkpoints
#   graph.update_state(config, values, as_node)        manually patch state
#
# Running (async):
#   await graph.ainvoke(...)
#   async for chunk in graph.astream(...): ...
#   async for event in graph.astream_events(..., version="v2"): ...
#
# Introspection:
#   graph.get_graph()                                  returns Graph object
#   graph.get_graph().draw_mermaid()                   Mermaid diagram string
#   graph.get_graph().draw_mermaid_png()               PNG bytes
#
# config dict keys:
#   {"configurable": {
#       "thread_id":       "...",   required for checkpointing
#       "checkpoint_id":   "...",   time-travel: replay from specific checkpoint
#   }}
#
# ─────────────────────────────────────────────────────────────────────────────
# SECTION 12 — MEMORY TYPES DECISION GUIDE
# ─────────────────────────────────────────────────────────────────────────────
#
# ┌─────────────────────┬───────────────────────────────────────────────────┐
# │ Memory Type         │ When to Use                                       │
# ├─────────────────────┼───────────────────────────────────────────────────┤
# │ MemorySaver         │ Dev, tests, single-process apps, no restart need  │
# │ SqliteSaver         │ Local / single-server apps, persists across runs  │
# │ AsyncSqliteSaver    │ Same as above but with async graph execution      │
# │ PostgresSaver       │ Production multi-instance, horizontal scale       │
# └─────────────────────┴───────────────────────────────────────────────────┘
#
# WITHIN a thread, you get:
#   Short-term memory  → the messages / state accumulated in the current run
#   Long-term memory   → everything persisted by checkpointer across sessions
#                        (retrieved automatically when you re-invoke with same thread_id)
#
# For CROSS-USER long-term memory (facts about users stored separately):
#   Use a dedicated store: InMemoryStore or PostgresStore (langgraph-store)
#   graph.compile(store=my_store)     → nodes can call store.put / store.get


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 13 — KITCHEN-SINK DEMO  (runs all sections end-to-end)
# ─────────────────────────────────────────────────────────────────────────────

def run_full_demo():
    print("=" * 70)
    print("LangGraph Full Reference — Kitchen-Sink Demo")
    print("=" * 70)

    # Fan-out demo (no LLM needed)
    print("\n[1] Fan-out / parallel Send")
    demo_fanout()

    # Subgraph demo (no LLM needed)
    print("\n[2] Subgraph (nested graph)")
    parent = build_parent_graph()
    r = parent.invoke({"query": "hello subgraph", "sub_result": "", "final": ""})
    print("    Parent final:", r["final"])

    # Memory demo (no LLM needed)
    print("\n[3] MemorySaver — thread-isolated state")
    demo_memory_types()

    # HITL demo (no LLM needed)
    print("\n[4] Human-in-the-loop interrupt")
    demo_human_in_the_loop()

    # Streaming demo (no LLM needed)
    print("\n[5] Streaming modes")
    demo_streaming()

    print("\nDone. (LLM-powered demos — ToolNode, chat graph — skipped to avoid API costs.)")
    print("Call build_tool_graph() or build_messages_graph_example() with a valid OPENAI_API_KEY.")


if __name__ == "__main__":
    run_full_demo()
