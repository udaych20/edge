"""
Real-World Pattern 2 — Supervisor Multi-Agent System
=====================================================
Used by: Enterprise AI platforms, AutoGPT-style products, internal copilots,
         LangChain's own AgentExecutor replacement, CrewAI-equivalent in LangGraph

Features used:
  [OK] Supervisor node         — LLM decides which specialist to call next
  [OK] Specialist subgraphs    — each agent has its own tools + prompt
  [OK] Conditional edges       — supervisor routing after each agent finishes
  [OK] MemorySaver             — shared context across all agents in one session
  [OK] MessagesState           — all agents share one message thread

Flow:
  User task
      -> Supervisor LLM decides: researcher | coder | writer | FINISH
      -> Chosen agent does its work, appends to messages
      -> Back to supervisor (loop)
      -> Supervisor says FINISH -> final answer

This is the #1 multi-agent pattern in production LangGraph deployments.
"""

from __future__ import annotations

from typing import Literal

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition

load_dotenv()

LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# --- Specialist tools ---------------------------------------------------------

@tool
def web_search(query: str) -> str:
    """Search the web for current information on a topic."""
    # In production: Tavily, SerpAPI, Bing Search
    return f"[Search results for '{query}']: Found 3 recent articles. Key facts: topic is growing 40% YoY, main players are A, B, C."

@tool
def run_python(code: str) -> str:
    """Execute Python code and return the output. Use for data analysis and calculations."""
    # In production: use a sandboxed executor (e2b, modal, docker)
    try:
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            exec(code, {"__builtins__": {"print": print, "range": range, "len": len, "sum": sum}})  # noqa: S102
        return buf.getvalue() or "(no output)"
    except Exception as e:
        return f"Error: {e}"

@tool
def write_document(title: str, content: str) -> str:
    """Save a document with a title and content. Returns document ID."""
    doc_id = f"DOC-{abs(hash(title)) % 9999:04d}"
    print(f"    [write_document] Saved '{title}' as {doc_id}")
    return f"Document saved: {doc_id}"


# --- Specialist agents --------------------------------------------------------

RESEARCHER_TOOLS = [web_search]
CODER_TOOLS      = [run_python]
WRITER_TOOLS     = [write_document]


def make_agent_node(system_prompt: str, tools: list):
    """Factory: returns a node function that runs an agent with given tools."""
    agent_llm = LLM.bind_tools(tools) if tools else LLM
    tool_node  = ToolNode(tools) if tools else None

    def agent_node(state: MessagesState) -> dict:
        messages = [SystemMessage(content=system_prompt)] + state["messages"]
        response = agent_llm.invoke(messages)
        updates = {"messages": [response]}

        # If LLM called a tool, execute it immediately inside this node
        if tool_node and getattr(response, "tool_calls", None):
            tool_state = {"messages": state["messages"] + [response]}
            tool_result = tool_node.invoke(tool_state)
            updates["messages"] = [response] + tool_result["messages"]

        return updates

    return agent_node


researcher_node = make_agent_node(
    "You are a research specialist. Search for factual information using web_search. "
    "Be thorough. End your response with 'RESEARCH COMPLETE'.",
    RESEARCHER_TOOLS,
)

coder_node = make_agent_node(
    "You are a Python coding specialist. Write and run Python code to perform calculations "
    "or data analysis using run_python. End your response with 'CODE COMPLETE'.",
    CODER_TOOLS,
)

writer_node = make_agent_node(
    "You are a writing specialist. Synthesize information into clear documents using write_document. "
    "Write professional, structured content. End your response with 'WRITING COMPLETE'.",
    WRITER_TOOLS,
)


# --- Supervisor ---------------------------------------------------------------
# The supervisor reads all messages and decides who should act next.
# It returns a structured response with a `next` field.

SUPERVISOR_SYSTEM = """You are a supervisor managing a team of AI specialists:
- researcher: finds information using web search
- coder: writes and runs Python for calculations/analysis
- writer: creates polished documents from research

Given the conversation, decide who should act next.
Respond with JSON: {"next": "researcher"|"coder"|"writer"|"FINISH"}
Say FINISH only when the task is fully complete.
"""

def supervisor_node(state: MessagesState) -> dict:
    from langchain_core.messages import AIMessage
    messages = [SystemMessage(content=SUPERVISOR_SYSTEM)] + state["messages"]
    response = LLM.invoke(messages)

    # Parse the next agent from the response
    content = response.content.lower()
    if "researcher" in content:
        next_agent = "researcher"
    elif "coder" in content:
        next_agent = "coder"
    elif "writer" in content:
        next_agent = "writer"
    else:
        next_agent = "FINISH"

    print(f"  [supervisor] -> {next_agent}")
    return {"messages": [AIMessage(content=f"Routing to: {next_agent}")]}


def route_supervisor(state: MessagesState) -> Literal["researcher", "coder", "writer", "__end__"]:
    """Read the last supervisor message to decide routing."""
    last = state["messages"][-1]
    content = last.content.lower() if hasattr(last, "content") else ""
    if "researcher" in content:
        return "researcher"
    elif "coder" in content:
        return "coder"
    elif "writer" in content:
        return "writer"
    return "__end__"


# --- Graph --------------------------------------------------------------------

def build_supervisor_graph():
    memory = MemorySaver()
    g = StateGraph(MessagesState)

    g.add_node("supervisor",  supervisor_node)
    g.add_node("researcher",  researcher_node)
    g.add_node("coder",       coder_node)
    g.add_node("writer",      writer_node)

    # Supervisor is the hub — all specialists report back to it
    g.add_edge(START, "supervisor")
    g.add_conditional_edges("supervisor", route_supervisor,
                            {"researcher": "researcher", "coder": "coder",
                             "writer": "writer", "__end__": END})

    # Every specialist returns to supervisor for next decision
    g.add_edge("researcher", "supervisor")
    g.add_edge("coder",      "supervisor")
    g.add_edge("writer",     "supervisor")

    return g.compile(checkpointer=memory)


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55
    print(f"\n{sep}")
    print("Supervisor Multi-Agent — market research task")
    print(sep)

    try:
        graph = build_supervisor_graph()
        cfg = {"configurable": {"thread_id": "research-session-1"}}

        result = graph.invoke({
            "messages": [HumanMessage(content=(
                "Research the current state of the LangGraph market, "
                "calculate how many companies are using it (assume 500 GitHub stars = 1 company), "
                "and write a short executive summary document."
            ))]
        }, config=cfg)

        print(f"\n  Total messages exchanged: {len(result['messages'])}")
        # Show the final written content
        for msg in reversed(result["messages"]):
            if hasattr(msg, "content") and "WRITING COMPLETE" in str(msg.content):
                print(f"\n  Final output:\n{msg.content[:500]}")
                break
    except Exception as e:
        print(f"  Skipped (needs API key): {e}")


if __name__ == "__main__":
    run()
