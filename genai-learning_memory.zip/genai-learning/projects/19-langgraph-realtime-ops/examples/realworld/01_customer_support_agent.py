"""
Real-World Pattern 1 — Customer Support Agent
===============================================
Used by: Intercom, Zendesk AI, Salesforce Einstein, internal helpdesks

Features used:
  [OK] ToolNode + tool loop   — agent looks up orders, policies, account info
  [OK] MemorySaver            — multi-turn conversation per session/ticket
  [OK] Conditional routing    — escalate to human when confidence is low
  [OK] interrupt_before       — human agent reviews before sending refund

Flow:
  User message
      -> classify intent (billing / order / technical / escalate)
      -> route to specialist handler
      -> handler uses tools (lookup order, check policy, process refund)
      -> if refund: PAUSE for human approval
      -> send final reply
"""

from __future__ import annotations

import operator
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.types import Command

load_dotenv()

# --- Tools the agent can call -------------------------------------------------

@tool
def lookup_order(order_id: str) -> str:
    """Look up the status of a customer order by order ID."""
    orders = {
        "ORD-001": "Delivered on 2024-01-15. Carrier: FedEx. No issues logged.",
        "ORD-002": "In transit. Expected delivery: tomorrow. Carrier: UPS.",
        "ORD-003": "Delayed. New ETA: 5 business days. Reason: weather.",
    }
    return orders.get(order_id, f"Order {order_id} not found in system.")


@tool
def check_refund_policy(product_category: str) -> str:
    """Check the refund policy for a product category."""
    policies = {
        "electronics": "30-day return window. Must be unopened. Restocking fee: 15%.",
        "clothing": "60-day return window. Must have tags attached. Free returns.",
        "software": "No refunds after activation. Contact support for exceptions.",
        "default": "30-day return window. Original packaging required.",
    }
    return policies.get(product_category.lower(), policies["default"])


@tool
def get_account_info(customer_id: str) -> str:
    """Retrieve customer account standing and tier."""
    accounts = {
        "C-100": "Gold member since 2021. Lifetime value: $4,200. No open disputes.",
        "C-200": "New customer (2024). First purchase. VIP flag: No.",
        "C-300": "Platinum member. Lifetime value: $18,500. Dedicated CSM assigned.",
    }
    return accounts.get(customer_id, "Customer not found.")


@tool
def process_refund(order_id: str, amount: float, reason: str) -> str:
    """Process a refund for an order. Requires human approval for amounts > $100."""
    return f"Refund of ${amount:.2f} queued for {order_id}. Reason: {reason}. Ref: REF-{hash(order_id) % 9999:04d}"


# --- State --------------------------------------------------------------------

class SupportState(TypedDict):
    messages: Annotated[list[BaseMessage], operator.add]
    customer_id: str
    intent: str                        # billing | order | technical | escalate
    refund_amount: float
    requires_human_approval: bool
    ticket_id: str


# --- Nodes --------------------------------------------------------------------

TOOLS = [lookup_order, check_refund_policy, get_account_info, process_refund]
LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)
AGENT_LLM = LLM.bind_tools(TOOLS)

SYSTEM_PROMPT = """You are a helpful customer support agent.
Use tools to look up real information before answering.
When a refund > $100 is needed, call process_refund and note it needs approval.
Be concise and professional."""


def classify_intent(state: SupportState) -> dict:
    """Quick classification — no tools, just routing."""
    last_msg = state["messages"][-1].content.lower()
    if any(w in last_msg for w in ["refund", "charge", "billing", "payment"]):
        intent = "billing"
    elif any(w in last_msg for w in ["order", "delivery", "shipping", "track"]):
        intent = "order"
    elif any(w in last_msg for w in ["bug", "error", "crash", "not working"]):
        intent = "technical"
    else:
        intent = "general"
    print(f"  [classify] intent='{intent}'")
    return {"intent": intent}


def route_by_intent(state: SupportState) -> Literal["billing_agent", "order_agent", "general_agent"]:
    mapping = {
        "billing":   "billing_agent",
        "order":     "order_agent",
        "technical": "general_agent",
        "general":   "general_agent",
    }
    return mapping.get(state["intent"], "general_agent")


def billing_agent(state: SupportState) -> dict:
    print("  [billing_agent] processing billing query")
    sys = SystemMessage(content=SYSTEM_PROMPT + "\nFocus on billing and refund issues.")
    response = AGENT_LLM.invoke([sys] + state["messages"])
    # Check if a large refund was requested
    needs_approval = False
    if hasattr(response, "tool_calls"):
        for tc in response.tool_calls:
            if tc["name"] == "process_refund" and tc["args"].get("amount", 0) > 100:
                needs_approval = True
    return {
        "messages": [response],
        "requires_human_approval": needs_approval,
        "refund_amount": 150.0 if needs_approval else 0.0,
    }


def order_agent(state: SupportState) -> dict:
    print("  [order_agent] processing order query")
    sys = SystemMessage(content=SYSTEM_PROMPT + "\nFocus on order tracking and delivery.")
    response = AGENT_LLM.invoke([sys] + state["messages"])
    return {"messages": [response]}


def general_agent(state: SupportState) -> dict:
    print("  [general_agent] processing general query")
    sys = SystemMessage(content=SYSTEM_PROMPT)
    response = AGENT_LLM.invoke([sys] + state["messages"])
    return {"messages": [response]}


def human_approval_gate(state: SupportState) -> dict:
    """This node is interrupt_before'd — human reviews before it runs."""
    print(f"  [human_approval] Approving refund of ${state['refund_amount']:.2f}")
    return {"messages": [AIMessage(content=f"Refund of ${state['refund_amount']:.2f} approved by supervisor.")]}


def tool_executor(state: SupportState) -> dict:
    tool_node = ToolNode(TOOLS)
    result = tool_node.invoke(state)
    return result


def finalize_response(state: SupportState) -> dict:
    """Generate the final clean message to send to the customer."""
    last_ai = next((m for m in reversed(state["messages"]) if isinstance(m, AIMessage) and m.content), None)
    if last_ai:
        print(f"  [finalize] Final: {last_ai.content[:80]}...")
    return {}


def check_tools_or_done(state: SupportState) -> str:
    last = state["messages"][-1]
    if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
        return "tools"
    if state.get("requires_human_approval"):
        return "human_approval"
    return "finalize"


# --- Graph --------------------------------------------------------------------

def build_support_graph():
    memory = MemorySaver()
    g = StateGraph(SupportState)

    g.add_node("classify",        classify_intent)
    g.add_node("billing_agent",   billing_agent)
    g.add_node("order_agent",     order_agent)
    g.add_node("general_agent",   general_agent)
    g.add_node("tools",           ToolNode(TOOLS))
    g.add_node("human_approval",  human_approval_gate)
    g.add_node("finalize",        finalize_response)

    g.add_edge(START, "classify")
    g.add_conditional_edges("classify", route_by_intent)

    # Each agent loops through tools until done
    for agent in ["billing_agent", "order_agent", "general_agent"]:
        g.add_conditional_edges(agent, check_tools_or_done,
                                {"tools": "tools", "human_approval": "human_approval", "finalize": "finalize"})

    g.add_edge("tools", "billing_agent")   # tools always return to caller agent
    g.add_edge("human_approval", "finalize")
    g.add_edge("finalize", END)

    # Pause before sending any refund > $100 — supervisor must approve
    return g.compile(checkpointer=memory, interrupt_before=["human_approval"])


# --- Demo ---------------------------------------------------------------------

def run():
    graph = build_support_graph()

    sep = "-" * 55
    print(f"\n{sep}")
    print("Scenario 1 — Order tracking query (no approval needed)")
    print(sep)
    cfg1 = {"configurable": {"thread_id": "ticket-001"}}
    try:
        result = graph.invoke({
            "messages": [HumanMessage(content="Where is my order ORD-002?")],
            "customer_id": "C-100",
            "intent": "",
            "refund_amount": 0.0,
            "requires_human_approval": False,
            "ticket_id": "TK-001",
        }, config=cfg1)
        last = next((m for m in reversed(result["messages"]) if isinstance(m, AIMessage) and m.content), None)
        print(f"  Agent reply: {last.content if last else '(no reply)'}")
    except Exception as e:
        print(f"  Skipped (needs API key): {e}")
        return

    print(f"\n{sep}")
    print("Scenario 2 — Refund request (pauses for human approval)")
    print(sep)
    cfg2 = {"configurable": {"thread_id": "ticket-002"}}
    try:
        result = graph.invoke({
            "messages": [HumanMessage(content="I need a refund for ORD-001, it was $150 and never arrived.")],
            "customer_id": "C-100",
            "intent": "",
            "refund_amount": 0.0,
            "requires_human_approval": False,
            "ticket_id": "TK-002",
        }, config=cfg2)
        snap = graph.get_state(cfg2)
        if snap.next:
            print(f"  Paused at: {snap.next} — supervisor reviewing refund")
            # Supervisor approves -> resume
            final = graph.invoke(None, config=cfg2)
            last = next((m for m in reversed(final["messages"]) if isinstance(m, AIMessage) and m.content), None)
            print(f"  After approval: {last.content if last else '(no reply)'}")
    except Exception as e:
        print(f"  Error: {e}")


if __name__ == "__main__":
    run()
