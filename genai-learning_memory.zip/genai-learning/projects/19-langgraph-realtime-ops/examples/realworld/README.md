# Real-World LangGraph Patterns

| # | Pattern | Industry | Key Features |
|---|---|---|---|
| 01 | Customer Support Agent | SaaS, e-commerce | ToolNode, HITL for refund approval, session memory |
| 02 | Supervisor Multi-Agent | Enterprise AI platforms | Supervisor hub, specialist agents, shared message thread |
| 03 | RAG with Citations | Legal tech, enterprise search | Fan-out retrieval, relevance grading, hallucination guard |
| 04 | AI Code Review | DevOps, CI/CD | Parallel reviewers, HITL for critical issues, scoring |
| 05 | Document Processing | Legal, finance, insurance | Fan-out + subgraphs, structured extraction, batch jobs |
| 06 | Plan-and-Execute Agent | Coding assistants, task automation | Two-phase planner+executor, re-planning, tool loop |

## Feature → Real-World Value Map

| Feature | Why it matters in production |
|---|---|
| **ToolNode loop** | Any agent that needs to call APIs, DBs, or services |
| **MemorySaver / SqliteSaver** | Multi-turn chat — users expect context across messages |
| **interrupt_before (HITL)** | Compliance, finance, medical — humans must approve high-stakes actions |
| **Fan-out with Send** | Batch processing — don't process 1000 docs sequentially |
| **Subgraphs** | Team-scale codebases — each team owns their subgraph |
| **Supervisor pattern** | When one LLM can't do everything — delegate to specialists |
| **Conditional edges** | Business rules — route by intent, priority, document type |
| **Structured output (Pydantic)** | Extract data reliably — invoices, contracts, forms |
| **Streaming** | UI responsiveness — users abandon apps that feel slow |
| **Re-planning** | Production reliability — handle failures gracefully |

## Run any example

```bash
cd projects/19-langgraph-realtime-ops/examples/realworld
python 01_customer_support_agent.py
```

Requires `OPENAI_API_KEY` in `.env` for LLM-powered examples.
Non-LLM parts (routing, fan-out, memory) run without any API key.
