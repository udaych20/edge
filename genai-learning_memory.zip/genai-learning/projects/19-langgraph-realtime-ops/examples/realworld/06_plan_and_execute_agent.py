"""
Real-World Pattern 6 — Plan-and-Execute Agent
==============================================
Used by: Devin (AI software engineer), OpenAI o1-style agents,
         GitHub Copilot Workspace, internal task automation

Features used:
  [OK] Two-phase graph        — planner generates steps, executor runs them
  [OK] ToolNode loop          — executor uses tools to complete each step
  [OK] Reducer                — accumulate completed steps
  [OK] Conditional edge       — re-plan if execution fails
  [OK] MemorySaver            — track plan state across re-planning cycles

Why this beats a simple ReAct loop:
  • Planner uses a REASONING model (o1/Sonnet) once -> slower but smarter
  • Executor uses a FAST model (gpt-4o-mini) per step -> cheaper
  • Steps can be run in parallel (future: fan-out per step)
  • Re-planning: if a step fails, re-plan the remaining steps

Flow:
  Task
      -> planner: break into ordered steps
      -> executor loop:
          pick next unfinished step
          -> use tools to complete it
          -> mark done, continue
      -> if step fails N times -> re-plan
      -> all steps done -> final summary
"""

from __future__ import annotations

import operator
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition
from pydantic import BaseModel

load_dotenv()

PLANNER_LLM  = ChatOpenAI(model="gpt-4o-mini", temperature=0)
EXECUTOR_LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# --- Pydantic plan schema -----------------------------------------------------

class Step(BaseModel):
    step_id: int
    description: str
    tool_hint: str      # which tool to use


class Plan(BaseModel):
    goal: str
    steps: list[Step]


# --- Tools the executor can use -----------------------------------------------

@tool
def search_knowledge_base(query: str) -> str:
    """Search internal knowledge base for information."""
    kb = {
        "deployment process": "1. Run tests. 2. Build Docker image. 3. Push to ECR. 4. Update ECS task.",
        "api rate limits":    "Public API: 100 req/min. Internal: 1000 req/min. Burst: 2x for 30s.",
        "database backup":    "Automated daily at 02:00 UTC via pg_dump -> S3. Retention: 30 days.",
    }
    for k, v in kb.items():
        if any(w in query.lower() for w in k.split()):
            return v
    return "No relevant information found."


@tool
def write_file(filename: str, content: str) -> str:
    """Write content to a file. Returns confirmation."""
    print(f"    [write_file] Writing {filename} ({len(content)} chars)")
    return f"File '{filename}' written successfully ({len(content)} chars)."


@tool
def run_command(command: str) -> str:
    """Simulate running a shell command. Returns mocked output."""
    mock = {
        "pytest": "...........\n14 passed in 2.3s",
        "docker build": "Successfully built abc123",
        "git status": "nothing to commit, working tree clean",
    }
    for k, v in mock.items():
        if k in command:
            return v
    return f"Command '{command}' completed with exit code 0."


@tool
def notify_slack(channel: str, message: str) -> str:
    """Send a notification to a Slack channel."""
    return f"Notification sent to #{channel}: '{message}'"


# --- State --------------------------------------------------------------------

class PlanState(TypedDict):
    task: str
    plan: list[dict]                               # list of Step dicts
    current_step_index: int
    completed_steps: Annotated[list[str], operator.add]
    failed_steps: Annotated[list[str], operator.add]
    replan_count: int
    final_summary: str
    executor_messages: list                        # tool loop messages


# --- Planner ------------------------------------------------------------------

def planner_node(state: PlanState) -> dict:
    replan = state.get("replan_count", 0)
    if replan > 0:
        context = f"Previous steps completed: {state['completed_steps']}\nFailed steps: {state['failed_steps']}\nRe-plan remaining work."
    else:
        context = ""

    print(f"  [planner] {'Re-planning' if replan else 'Planning'} task: '{state['task']}'")
    prompt = f"Task: {state['task']}\n{context}\n\nCreate a step-by-step plan. Each step should use one tool."

    try:
        result = PLANNER_LLM.with_structured_output(Plan).invoke(
            [SystemMessage(content="You are a task planner. Break tasks into clear executable steps."),
             HumanMessage(content=prompt)]
        )
        plan = [s.model_dump() for s in result.steps]
        print(f"  [planner] Created {len(plan)} step(s): {[s['description'][:30] for s in plan]}")
        return {"plan": plan, "current_step_index": 0}
    except Exception as e:
        print(f"  [planner] Error: {e}. Using fallback plan.")
        return {
            "plan": [
                {"step_id": 1, "description": "Search for relevant information", "tool_hint": "search_knowledge_base"},
                {"step_id": 2, "description": "Write output file", "tool_hint": "write_file"},
                {"step_id": 3, "description": "Notify team", "tool_hint": "notify_slack"},
            ],
            "current_step_index": 0,
        }


# --- Executor -----------------------------------------------------------------

TOOLS = [search_knowledge_base, write_file, run_command, notify_slack]
EXECUTOR_AGENT = EXECUTOR_LLM.bind_tools(TOOLS)


def executor_node(state: PlanState) -> dict:
    plan = state["plan"]
    idx = state["current_step_index"]

    if idx >= len(plan):
        return {}

    step = plan[idx]
    print(f"  [executor] Step {idx+1}/{len(plan)}: '{step['description']}'")

    # Give executor a fresh message window per step
    messages = [
        SystemMessage(content=f"Complete this step using tools: {step['description']}\nHint: use {step['tool_hint']}"),
        HumanMessage(content=f"Execute step {step['step_id']}: {step['description']}"),
    ]
    response = EXECUTOR_AGENT.invoke(messages)
    updated_messages = messages + [response]

    # Execute tool calls immediately
    if getattr(response, "tool_calls", None):
        tool_node = ToolNode(TOOLS)
        tool_result = tool_node.invoke({"messages": updated_messages})
        updated_messages += tool_result["messages"]

    return {
        "completed_steps": [f"Step {step['step_id']}: {step['description']}"],
        "current_step_index": idx + 1,
        "executor_messages": updated_messages,
    }


# --- Routing ------------------------------------------------------------------

def route_after_execution(state: PlanState) -> Literal["executor", "summarize", "replan"]:
    plan = state["plan"]
    idx = state["current_step_index"]

    if idx < len(plan):
        return "executor"     # more steps to execute

    failed = len(state.get("failed_steps", []))
    if failed > 0 and state.get("replan_count", 0) < 2:
        return "replan"       # some steps failed -> re-plan

    return "summarize"        # all done


def summarize_node(state: PlanState) -> dict:
    completed = state["completed_steps"]
    summary = (
        f"Task completed: '{state['task']}'\n"
        f"Steps executed: {len(completed)}\n"
        + "\n".join(f"  [OK] {s}" for s in completed)
    )
    print(f"  [summarize] All {len(completed)} steps done")
    return {"final_summary": summary}


# --- Graph --------------------------------------------------------------------

def build_plan_execute_graph():
    memory = MemorySaver()
    g = StateGraph(PlanState)

    g.add_node("planner",   planner_node)
    g.add_node("executor",  executor_node)
    g.add_node("summarize", summarize_node)

    g.add_edge(START, "planner")
    g.add_edge("planner", "executor")
    g.add_conditional_edges("executor", route_after_execution,
                            {"executor": "executor", "summarize": "summarize", "replan": "planner"})
    g.add_edge("summarize", END)

    return g.compile(checkpointer=memory)


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55
    graph = build_plan_execute_graph()
    cfg = {"configurable": {"thread_id": "task-001"}}

    task = (
        "Set up deployment documentation: "
        "search for our deployment process, write it to deploy_guide.md, "
        "run tests to verify, and notify #engineering on Slack."
    )

    print(f"\n{sep}")
    print("Plan-and-Execute Agent")
    print(sep)
    print(f"  Task: {task}")
    print(sep)

    try:
        result = graph.invoke({
            "task": task,
            "plan": [],
            "current_step_index": 0,
            "completed_steps": [],
            "failed_steps": [],
            "replan_count": 0,
            "final_summary": "",
            "executor_messages": [],
        }, config=cfg)

        print(f"\n  {result['final_summary']}")
    except Exception as e:
        print(f"  Skipped (needs API key): {e}")


if __name__ == "__main__":
    run()
