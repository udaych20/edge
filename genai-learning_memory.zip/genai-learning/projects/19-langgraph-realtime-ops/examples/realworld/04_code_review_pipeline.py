"""
Real-World Pattern 4 — AI Code Review Pipeline
================================================
Used by: GitHub Copilot PR review, CodeRabbit, Codacy AI, internal CI/CD bots

Features used:
  [OK] Fan-out (Send)       — parallel review by security / style / logic analyzers
  [OK] Reducer              — merge all findings from parallel reviewers
  [OK] Human-in-the-loop    — block merge if critical issues found
  [OK] MemorySaver + thread — one review session per PR
  [OK] Conditional edges    — auto-approve vs request changes vs block

Flow:
  PR diff submitted
      -> parallel analysis: security + style + logic + test coverage
      -> aggregate all findings
      -> score: APPROVE | REQUEST_CHANGES | BLOCK
      -> if BLOCK: pause for senior engineer
      -> post review comment
"""

from __future__ import annotations

import operator
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send

load_dotenv()

LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# --- State --------------------------------------------------------------------

class Finding(TypedDict):
    category: str
    severity: Literal["info", "warning", "critical"]
    message: str
    line: int


class ReviewState(TypedDict):
    pr_id: str
    diff: str
    author: str
    findings: Annotated[list[Finding], operator.add]   # reducer merges parallel results
    overall_score: str                                  # APPROVE | REQUEST_CHANGES | BLOCK
    review_comment: str
    senior_override: bool


class AnalysisState(TypedDict):
    diff: str
    analyzer: str
    findings: Annotated[list[Finding], operator.add]


# --- Fanout: spawn 4 reviewers in parallel ------------------------------------

def spawn_reviewers(state: ReviewState) -> list[Send]:
    analyzers = ["security", "style", "logic", "tests"]
    print(f"  [spawn] Running {len(analyzers)} parallel reviewers for PR {state['pr_id']}")
    return [
        Send("analyze", {"diff": state["diff"], "analyzer": a, "findings": []})
        for a in analyzers
    ]


# --- Single analysis node (runs 4× in parallel) -------------------------------

ANALYZER_PROMPTS = {
    "security": (
        "You are a security code reviewer. Check for: SQL injection, hardcoded secrets, "
        "insecure dependencies, missing input validation, XSS, SSRF. "
        "Return a JSON list of findings: [{category, severity, message, line}]. "
        "severity is 'info', 'warning', or 'critical'. Return [] if no issues."
    ),
    "style": (
        "You are a code style reviewer. Check for: naming conventions, dead code, "
        "overly complex functions, missing docstrings on public APIs, inconsistent formatting. "
        "Return a JSON list: [{category, severity, message, line}]. Return [] if clean."
    ),
    "logic": (
        "You are a logic reviewer. Check for: off-by-one errors, null pointer risks, "
        "incorrect business logic, missing edge cases, race conditions. "
        "Return a JSON list: [{category, severity, message, line}]. Return [] if no issues."
    ),
    "tests": (
        "You are a test coverage reviewer. Check for: missing unit tests, untested edge cases, "
        "tests with no assertions, test code in production paths. "
        "Return a JSON list: [{category, severity, message, line}]. Return [] if coverage is good."
    ),
}


def analyze(state: AnalysisState) -> dict:
    import json
    analyzer = state["analyzer"]
    print(f"    [analyze:{analyzer}] reviewing diff...")

    system = ANALYZER_PROMPTS[analyzer]
    prompt = f"Review this diff:\n\n{state['diff']}\n\nReturn JSON array of findings only."

    try:
        response = LLM.invoke([SystemMessage(content=system), HumanMessage(content=prompt)])
        raw = response.content.strip()
        # Strip markdown code blocks if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        found = json.loads(raw)
        findings = [Finding(category=analyzer, severity=f.get("severity","info"),
                            message=f.get("message",""), line=f.get("line", 0))
                    for f in found if isinstance(f, dict)]
        print(f"    [analyze:{analyzer}] {len(findings)} finding(s)")
        return {"findings": findings}
    except Exception as e:
        print(f"    [analyze:{analyzer}] parse error: {e}")
        return {"findings": []}


# --- Aggregate & score --------------------------------------------------------

def aggregate_findings(state: ReviewState) -> dict:
    findings = state["findings"]
    critical = [f for f in findings if f["severity"] == "critical"]
    warnings  = [f for f in findings if f["severity"] == "warning"]

    if critical:
        score = "BLOCK"
    elif len(warnings) > 3:
        score = "REQUEST_CHANGES"
    else:
        score = "APPROVE"

    print(f"  [aggregate] {len(critical)} critical, {len(warnings)} warnings -> {score}")
    return {"overall_score": score}


def route_review(state: ReviewState) -> Literal["senior_review", "post_comment"]:
    return "senior_review" if state["overall_score"] == "BLOCK" else "post_comment"


def senior_review(state: ReviewState) -> dict:
    """interrupt_before this — senior engineer sees critical findings and decides."""
    print(f"  [senior_review] Senior approved override for PR {state['pr_id']}")
    return {"senior_override": True, "overall_score": "REQUEST_CHANGES"}


def post_comment(state: ReviewState) -> dict:
    critical = [f for f in state["findings"] if f["severity"] == "critical"]
    warnings  = [f for f in state["findings"] if f["severity"] == "warning"]
    infos     = [f for f in state["findings"] if f["severity"] == "info"]

    lines = [f"## AI Code Review — PR {state['pr_id']}", f"**Decision: {state['overall_score']}**", ""]

    if critical:
        lines.append("### Critical Issues (must fix)")
        for f in critical:
            lines.append(f"- [{f['category']}] L{f['line']}: {f['message']}")
        lines.append("")

    if warnings:
        lines.append("### Warnings")
        for f in warnings:
            lines.append(f"- [{f['category']}] L{f['line']}: {f['message']}")
        lines.append("")

    if infos:
        lines.append("### Style Notes")
        for f in infos:
            lines.append(f"- [{f['category']}] {f['message']}")

    if state.get("senior_override"):
        lines.append("\n*Override approved by senior engineer.*")

    comment = "\n".join(lines)
    print(f"  [post_comment] Posting review comment ({len(comment)} chars)")
    return {"review_comment": comment}


# --- Graph --------------------------------------------------------------------

def build_review_graph():
    memory = MemorySaver()
    g = StateGraph(ReviewState)

    g.add_node("analyze",            analyze)
    g.add_node("aggregate_findings", aggregate_findings)
    g.add_node("senior_review",      senior_review)
    g.add_node("post_comment",       post_comment)

    g.add_conditional_edges(START, spawn_reviewers, ["analyze"])   # parallel fan-out
    g.add_edge("analyze", "aggregate_findings")                     # fan-in
    g.add_conditional_edges("aggregate_findings", route_review,
                            {"senior_review": "senior_review", "post_comment": "post_comment"})
    g.add_edge("senior_review", "post_comment")
    g.add_edge("post_comment", END)

    return g.compile(checkpointer=memory, interrupt_before=["senior_review"])


# --- Demo ---------------------------------------------------------------------

SAMPLE_DIFF = """
diff --git a/api/auth.py b/api/auth.py
+++ b/api/auth.py
@@ -10,6 +10,15 @@
+def login(username, password):
+    query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
+    result = db.execute(query)
+    return result
+
+SECRET_KEY = "hardcoded_secret_12345"
+
+def get_user_data(user_id):
+    # TODO: add input validation
+    return db.query(f"SELECT * FROM users WHERE id={user_id}")
"""

CLEAN_DIFF = """
diff --git a/utils/formatter.py b/utils/formatter.py
+++ b/utils/formatter.py
@@ -1,3 +1,8 @@
+def format_date(date_str: str) -> str:
+    \"\"\"Format ISO date string to human readable.\"\"\"
+    from datetime import datetime
+    dt = datetime.fromisoformat(date_str)
+    return dt.strftime("%B %d, %Y")
"""


def run():
    sep = "-" * 55
    graph = build_review_graph()

    print(f"\n{sep}")
    print("PR 1 — Dangerous code (SQL injection + hardcoded secret)")
    print(sep)
    try:
        cfg1 = {"configurable": {"thread_id": "pr-001"}}
        result = graph.invoke({
            "pr_id": "PR-001", "diff": SAMPLE_DIFF, "author": "junior-dev",
            "findings": [], "overall_score": "", "review_comment": "", "senior_override": False,
        }, config=cfg1)

        snap = graph.get_state(cfg1)
        if snap.next:
            print(f"\n  !! Blocked. Waiting for senior review (next={snap.next})")
            print(f"  Critical findings:")
            for f in [x for x in snap.values["findings"] if x["severity"] == "critical"]:
                print(f"    - {f['message']}")
            # Senior approves override
            final = graph.invoke(None, config=cfg1)
            print(f"\n  Review comment:\n{final['review_comment']}")
        else:
            print(f"\n  Review comment:\n{result['review_comment']}")

    except Exception as e:
        print(f"  Skipped (needs API key): {e}")
        return

    print(f"\n{sep}")
    print("PR 2 — Clean code (should auto-approve)")
    print(sep)
    try:
        cfg2 = {"configurable": {"thread_id": "pr-002"}}
        result2 = graph.invoke({
            "pr_id": "PR-002", "diff": CLEAN_DIFF, "author": "senior-dev",
            "findings": [], "overall_score": "", "review_comment": "", "senior_override": False,
        }, config=cfg2)
        print(f"  Decision: {result2['overall_score']}")
        print(f"  Comment:\n{result2['review_comment']}")
    except Exception as e:
        print(f"  Error: {e}")


if __name__ == "__main__":
    run()
