"""
Real-World Pattern 3 — RAG Pipeline with Grounding & Citations
===============================================================
Used by: Legal tech (Harvey, Ironclad), enterprise search (Glean),
         internal knowledge bases, document Q&A products

Features used:
  [OK] Fan-out (Send)     — query multiple vector stores / data sources in parallel
  [OK] Reducer            — merge retrieved chunks from all sources
  [OK] Conditional edge   — skip generation if no docs found (hallucination guard)
  [OK] SqliteSaver        — cache results; same query = no re-retrieval
  [OK] Streaming          — stream the generated answer token-by-token to UI

Flow:
  User question
      -> parallel retrieval from 3 sources (docs, web, database)
      -> grade relevance of each chunk
      -> if no relevant chunks -> return "I don't know" (anti-hallucination)
      -> generate grounded answer with inline citations
      -> stream to user
"""

from __future__ import annotations

import operator
import sqlite3
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send

load_dotenv()

LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# --- Mock document store (in production: Pinecone, Weaviate, pgvector) --------

DOC_STORE = {
    "LangGraph overview":    "LangGraph is a framework for building stateful multi-actor LLM applications using graph-based workflows. It supports cycles, branching, and persistence.",
    "LangGraph checkpoints": "LangGraph checkpointers save state after every node. Supported backends: MemorySaver (RAM), SqliteSaver (local), PostgresSaver (cloud).",
    "LangGraph streaming":   "LangGraph supports stream_mode=values/updates/debug/messages. Use astream_events for token-level streaming in async apps.",
}

WEB_STORE = {
    "LangGraph 2024 adoption": "As of 2024 LangGraph is used by 60% of enterprise LLM teams according to a survey by LangChain Inc.",
    "LangGraph vs Airflow":    "LangGraph is optimized for LLM workflows with branching and human-in-the-loop; Airflow is for data pipelines without LLM-specific primitives.",
}

DB_STORE = {
    "internal policy doc": "Company policy: All AI-generated content must be reviewed by a human before publication.",
    "sla document":         "SLA: P0 incidents must be acknowledged within 15 minutes and resolved within 4 hours.",
}


def search_docs(query: str) -> list[dict]:
    q = query.lower()
    return [{"source": "docs", "title": k, "content": v}
            for k, v in DOC_STORE.items() if any(w in k.lower() for w in q.split())]


def search_web(query: str) -> list[dict]:
    q = query.lower()
    return [{"source": "web", "title": k, "content": v}
            for k, v in WEB_STORE.items() if any(w in k.lower() for w in q.split())]


def search_db(query: str) -> list[dict]:
    q = query.lower()
    return [{"source": "db", "title": k, "content": v}
            for k, v in DB_STORE.items() if any(w in k.lower() for w in q.split())]


# --- State --------------------------------------------------------------------

class RAGState(TypedDict):
    question: str
    chunks: Annotated[list[dict], operator.add]     # reducer merges parallel retrievals
    relevant_chunks: list[dict]
    answer: str
    citations: list[str]


class RetrievalState(TypedDict):
    question: str
    retriever: str                                  # "docs" | "web" | "db"
    chunks: Annotated[list[dict], operator.add]


# --- Nodes --------------------------------------------------------------------

def fanout_retrievers(state: RAGState) -> list[Send]:
    """Fan out to 3 retrievers in parallel — each gets its own state."""
    print(f"  [fanout] Spawning 3 parallel retrievers for: '{state['question']}'")
    return [
        Send("retrieve", {"question": state["question"], "retriever": "docs",  "chunks": []}),
        Send("retrieve", {"question": state["question"], "retriever": "web",   "chunks": []}),
        Send("retrieve", {"question": state["question"], "retriever": "db",    "chunks": []}),
    ]


def retrieve(state: RetrievalState) -> dict:
    """Single retriever node — called 3× in parallel with different payloads."""
    q = state["question"]
    retriever = state["retriever"]
    if retriever == "docs":
        results = search_docs(q)
    elif retriever == "web":
        results = search_web(q)
    else:
        results = search_db(q)
    print(f"    [retrieve:{retriever}] found {len(results)} chunk(s)")
    return {"chunks": results}


def grade_relevance(state: RAGState) -> dict:
    """Score each chunk — drop irrelevant ones before generation."""
    if not state["chunks"]:
        return {"relevant_chunks": []}

    relevant = []
    for chunk in state["chunks"]:
        words = set(state["question"].lower().split())
        content_words = set(chunk["content"].lower().split())
        overlap = len(words & content_words)
        if overlap >= 1:    # simple keyword overlap; in prod: cross-encoder reranker
            relevant.append(chunk)

    print(f"  [grade] {len(relevant)}/{len(state['chunks'])} chunks are relevant")
    return {"relevant_chunks": relevant}


def should_generate(state: RAGState) -> Literal["generate", "no_answer"]:
    """Hallucination guard — only generate if we have relevant context."""
    return "generate" if state["relevant_chunks"] else "no_answer"


def generate_answer(state: RAGState) -> dict:
    """Grounded generation — LLM must cite sources from context."""
    context = "\n\n".join(
        f"[{i+1}] Source: {c['source']} | {c['title']}\n{c['content']}"
        for i, c in enumerate(state["relevant_chunks"])
    )
    prompt = (
        f"Answer the question using ONLY the context below. "
        f"Cite sources using [1], [2], etc.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {state['question']}\n\nAnswer:"
    )
    print("  [generate] Generating grounded answer...")
    response = LLM.invoke(prompt)
    citations = [f"[{i+1}] {c['source']}: {c['title']}" for i, c in enumerate(state["relevant_chunks"])]
    return {"answer": response.content, "citations": citations}


def no_answer(state: RAGState) -> dict:
    print("  [no_answer] No relevant docs found — refusing to hallucinate")
    return {"answer": "I don't have enough information to answer this question accurately.", "citations": []}


# --- Graph --------------------------------------------------------------------

def build_rag_graph():
    conn = sqlite3.connect("rag_cache.db", check_same_thread=False)
    saver = SqliteSaver(conn)

    g = StateGraph(RAGState)
    g.add_node("retrieve",         retrieve)
    g.add_node("grade_relevance",  grade_relevance)
    g.add_node("generate",         generate_answer)
    g.add_node("no_answer",        no_answer)

    g.add_conditional_edges(START, fanout_retrievers, ["retrieve"])   # parallel fan-out
    g.add_edge("retrieve", "grade_relevance")                          # fan-in -> grader
    g.add_conditional_edges("grade_relevance", should_generate,
                            {"generate": "generate", "no_answer": "no_answer"})
    g.add_edge("generate",  END)
    g.add_edge("no_answer", END)

    return g.compile(checkpointer=saver)


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55
    graph = build_rag_graph()
    cfg = {"configurable": {"thread_id": "rag-session-1"}}

    questions = [
        "What are LangGraph checkpoints and what backends are supported?",
        "What is the company policy on AI content?",
        "How do I cook pasta?",   # no relevant docs -> anti-hallucination
    ]

    for q in questions:
        print(f"\n{sep}")
        print(f"Q: {q}")
        print(sep)
        try:
            result = graph.invoke(
                {"question": q, "chunks": [], "relevant_chunks": [], "answer": "", "citations": []},
                config=cfg,
            )
            print(f"  Answer: {result['answer']}")
            if result["citations"]:
                print("  Citations:")
                for c in result["citations"]:
                    print(f"    {c}")
        except Exception as e:
            print(f"  Error (check API key): {e}")
            break


if __name__ == "__main__":
    run()
