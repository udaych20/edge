"""
Real-World Pattern 5 — Document Processing Pipeline
=====================================================
Used by: DocuSign AI, Ironclad (contracts), insurance claim processing,
         invoice extraction, medical records processing

Features used:
  [OK] Fan-out (Send)       — process N documents in parallel
  [OK] Subgraph             — each document runs through its own mini-pipeline
  [OK] Reducer              — collect all extracted records back to parent
  [OK] Conditional edge     — route by document type (invoice / contract / form)
  [OK] SqliteSaver          — resume interrupted batch jobs
  [OK] update_state (HITL)  — human corrects low-confidence extractions

Flow:
  Batch of documents
      -> fan-out: each doc processed in parallel
         -> classify doc type
         -> extract fields (LLM structured output)
         -> validate extracted fields
         -> flag low-confidence for human review
      -> fan-in: collect all records
      -> generate batch summary report
"""

from __future__ import annotations

import operator
import sqlite3
from typing import Annotated, Literal, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Send
from pydantic import BaseModel, Field

load_dotenv()

LLM = ChatOpenAI(model="gpt-4o-mini", temperature=0)

# --- Pydantic models for structured extraction --------------------------------

class InvoiceData(BaseModel):
    vendor: str = Field(description="Vendor/supplier name")
    invoice_number: str
    amount: float
    currency: str = "USD"
    due_date: str
    line_items: list[str]
    confidence: float = Field(ge=0, le=1, description="Extraction confidence 0-1")


class ContractData(BaseModel):
    parties: list[str]
    effective_date: str
    expiry_date: str
    key_obligations: list[str]
    governing_law: str
    confidence: float = Field(ge=0, le=1)


class FormData(BaseModel):
    form_type: str
    submitter: str
    fields: dict[str, str]
    confidence: float = Field(ge=0, le=1)


# --- State --------------------------------------------------------------------

class ExtractedRecord(TypedDict):
    doc_id: str
    doc_type: str
    data: dict
    confidence: float
    needs_review: bool


class BatchState(TypedDict):
    documents: list[dict]                                        # raw input docs
    records: Annotated[list[ExtractedRecord], operator.add]      # reducer collects results
    low_confidence: list[ExtractedRecord]
    report: str


class DocState(TypedDict):
    doc_id: str
    content: str
    doc_type: str
    records: Annotated[list[ExtractedRecord], operator.add]


# --- Document subgraph --------------------------------------------------------

def classify_doc(state: DocState) -> dict:
    content_lower = state["content"].lower()
    if any(w in content_lower for w in ["invoice", "bill", "amount due", "vendor"]):
        doc_type = "invoice"
    elif any(w in content_lower for w in ["agreement", "contract", "party", "obligation"]):
        doc_type = "contract"
    else:
        doc_type = "form"
    print(f"    [classify:{state['doc_id']}] -> {doc_type}")
    return {"doc_type": doc_type}


def route_by_type(state: DocState) -> Literal["extract_invoice", "extract_contract", "extract_form"]:
    return f"extract_{state['doc_type']}"


def extract_invoice(state: DocState) -> dict:
    print(f"    [extract_invoice:{state['doc_id']}]")
    try:
        result = LLM.with_structured_output(InvoiceData).invoke(
            [SystemMessage(content="Extract invoice fields from this document."),
             HumanMessage(content=state["content"])]
        )
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="invoice",
                                 data=result.model_dump(), confidence=result.confidence,
                                 needs_review=result.confidence < 0.8)
    except Exception:
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="invoice",
                                 data={}, confidence=0.0, needs_review=True)
    return {"records": [record]}


def extract_contract(state: DocState) -> dict:
    print(f"    [extract_contract:{state['doc_id']}]")
    try:
        result = LLM.with_structured_output(ContractData).invoke(
            [SystemMessage(content="Extract contract fields from this document."),
             HumanMessage(content=state["content"])]
        )
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="contract",
                                 data=result.model_dump(), confidence=result.confidence,
                                 needs_review=result.confidence < 0.8)
    except Exception:
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="contract",
                                 data={}, confidence=0.0, needs_review=True)
    return {"records": [record]}


def extract_form(state: DocState) -> dict:
    print(f"    [extract_form:{state['doc_id']}]")
    try:
        result = LLM.with_structured_output(FormData).invoke(
            [SystemMessage(content="Extract form fields from this document."),
             HumanMessage(content=state["content"])]
        )
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="form",
                                 data=result.model_dump(), confidence=result.confidence,
                                 needs_review=result.confidence < 0.8)
    except Exception:
        record = ExtractedRecord(doc_id=state["doc_id"], doc_type="form",
                                 data={}, confidence=0.0, needs_review=True)
    return {"records": [record]}


def build_doc_subgraph():
    g = StateGraph(DocState)
    g.add_node("classify",          classify_doc)
    g.add_node("extract_invoice",   extract_invoice)
    g.add_node("extract_contract",  extract_contract)
    g.add_node("extract_form",      extract_form)

    g.add_edge(START, "classify")
    g.add_conditional_edges("classify", route_by_type)
    g.add_edge("extract_invoice",  END)
    g.add_edge("extract_contract", END)
    g.add_edge("extract_form",     END)
    return g.compile()


# --- Parent batch graph -------------------------------------------------------

def fanout_documents(state: BatchState) -> list[Send]:
    print(f"  [fanout] Processing {len(state['documents'])} documents in parallel")
    return [
        Send("process_doc", {
            "doc_id": doc["id"],
            "content": doc["content"],
            "doc_type": "",
            "records": [],
        })
        for doc in state["documents"]
    ]


def flag_low_confidence(state: BatchState) -> dict:
    low = [r for r in state["records"] if r["needs_review"]]
    print(f"  [flag] {len(low)} records need human review")
    return {"low_confidence": low}


def generate_report(state: BatchState) -> dict:
    total = len(state["records"])
    types = {}
    for r in state["records"]:
        types[r["doc_type"]] = types.get(r["doc_type"], 0) + 1

    avg_conf = (sum(r["confidence"] for r in state["records"]) / total) if total else 0
    needs_review = len(state["low_confidence"])

    report = (
        f"Batch Processing Report\n"
        f"{'-'*40}\n"
        f"Total documents: {total}\n"
        f"By type: {types}\n"
        f"Average confidence: {avg_conf:.0%}\n"
        f"Need human review: {needs_review}\n"
    )
    if state["low_confidence"]:
        report += "\nLow confidence records:\n"
        for r in state["low_confidence"]:
            report += f"  - {r['doc_id']} ({r['doc_type']}) conf={r['confidence']:.0%}\n"

    print(f"  [report] Generated batch summary")
    return {"report": report}


def build_batch_graph():
    doc_sub = build_doc_subgraph()
    conn = sqlite3.connect("batch_jobs.db", check_same_thread=False)
    saver = SqliteSaver(conn)

    g = StateGraph(BatchState)
    g.add_node("process_doc",        doc_sub)          # subgraph as node
    g.add_node("flag_low_confidence", flag_low_confidence)
    g.add_node("generate_report",     generate_report)

    g.add_conditional_edges(START, fanout_documents, ["process_doc"])
    g.add_edge("process_doc",         "flag_low_confidence")
    g.add_edge("flag_low_confidence", "generate_report")
    g.add_edge("generate_report",     END)

    return g.compile(checkpointer=saver)


# --- Sample documents ---------------------------------------------------------

SAMPLE_DOCUMENTS = [
    {
        "id": "DOC-001",
        "content": """
        INVOICE
        Vendor: Acme Corp
        Invoice Number: INV-2024-0042
        Amount Due: $4,250.00 USD
        Due Date: 2024-02-15
        Line Items:
          - Software License Q1: $3,500.00
          - Support Package: $750.00
        """,
    },
    {
        "id": "DOC-002",
        "content": """
        SERVICE AGREEMENT
        This agreement is between TechCorp Inc ("Client") and DevShop LLC ("Provider").
        Effective Date: January 1, 2024
        Expiry Date: December 31, 2024
        Key Obligations:
          - Provider shall deliver monthly reports
          - Client shall pay within 30 days of invoice
        Governing Law: State of California
        """,
    },
    {
        "id": "DOC-003",
        "content": """
        EXPENSE REIMBURSEMENT FORM
        Employee: Jane Smith
        Department: Engineering
        Travel Date: 2024-01-20
        Hotel: $320
        Meals: $85
        Transport: $45
        Total: $450
        """,
    },
]


def run():
    sep = "-" * 55
    print(f"\n{sep}")
    print("Batch Document Processing (3 docs in parallel)")
    print(sep)

    try:
        graph = build_batch_graph()
        cfg = {"configurable": {"thread_id": "batch-job-001"}}

        result = graph.invoke({
            "documents": SAMPLE_DOCUMENTS,
            "records": [],
            "low_confidence": [],
            "report": "",
        }, config=cfg)

        print(f"\n{result['report']}")

        if result["records"]:
            print("Extracted data sample (first record):")
            r = result["records"][0]
            print(f"  doc_id={r['doc_id']}, type={r['doc_type']}, conf={r['confidence']:.0%}")
            for k, v in list(r["data"].items())[:4]:
                print(f"  {k}: {v}")

    except Exception as e:
        print(f"  Skipped (needs API key): {e}")


if __name__ == "__main__":
    run()
