"""
Example 03 — Memory & All 4 Checkpointer Types
================================================
Covers:
  • MemorySaver         — in-RAM, dev/tests
  • SqliteSaver         — local file, survives restarts
  • AsyncSqliteSaver    — async-compatible SQLite
  • PostgresSaver       — production (shown as commented reference)
  • Thread isolation    — separate thread_id = separate conversation
  • Cross-session memory — same thread_id resumes history
  • Time-travel         — replay from any checkpoint_id
  • get_state / get_state_history / update_state
"""

from __future__ import annotations

import asyncio
import operator
import sqlite3
from typing import Annotated, TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

# --- State --------------------------------------------------------------------

class ConvState(TypedDict):
    user: str
    messages: Annotated[list[str], operator.add]   # accumulates across turns
    turn: int


# --- Nodes --------------------------------------------------------------------

def respond(state: ConvState) -> dict:
    last = state["messages"][-1] if state["messages"] else "(none)"
    reply = f"[turn {state['turn']+1}] Echo from {state['user']}: '{last}'"
    return {"messages": [reply], "turn": state["turn"] + 1}


# --- Graph factory ------------------------------------------------------------

def make_graph(checkpointer):
    g = StateGraph(ConvState)
    g.add_node("respond", respond)
    g.add_edge(START, "respond")
    g.add_edge("respond", END)
    return g.compile(checkpointer=checkpointer)


# --- TYPE 1: MemorySaver ------------------------------------------------------
# Lives in Python process memory. Lost when process exits.
# Perfect for: unit tests, local demos, single-process apps.

def demo_memory_saver():
    saver = MemorySaver()
    graph = make_graph(saver)

    # Two separate users -> two completely isolated threads
    cfg_alice = {"configurable": {"thread_id": "alice"}}
    cfg_bob   = {"configurable": {"thread_id": "bob"}}

    # Turn 1 — Alice
    graph.invoke({"user": "Alice", "messages": ["Hello!"], "turn": 0}, config=cfg_alice)
    # Turn 2 — Alice (same thread_id -> state is restored and continued)
    graph.invoke({"user": "Alice", "messages": ["How are you?"], "turn": 0}, config=cfg_alice)
    # Turn 1 — Bob (different thread_id -> starts fresh)
    graph.invoke({"user": "Bob", "messages": ["Hi there"], "turn": 0}, config=cfg_bob)

    # Read current state for Alice
    snap = graph.get_state(cfg_alice)
    print(f"  Alice messages ({len(snap.values['messages'])} total):")
    for m in snap.values["messages"]:
        print(f"    {m}")

    # Read current state for Bob
    snap_bob = graph.get_state(cfg_bob)
    print(f"  Bob messages: {snap_bob.values['messages']}")

    # List ALL checkpoints for Alice (one per invoke)
    history = list(graph.get_state_history(cfg_alice))
    print(f"  Alice has {len(history)} checkpoint(s)")

    # Time-travel: re-run from first checkpoint
    first_cp = history[-1]   # oldest is last in the list
    print(f"  Oldest checkpoint id: {first_cp.config['configurable']['checkpoint_id'][:16]}...")

    return graph, cfg_alice


# --- TYPE 2: SqliteSaver ------------------------------------------------------
# Writes to a local SQLite file. Survives process restarts.
# Perfect for: local scripts, CLI tools, single-server apps.

def demo_sqlite_saver():
    db_path = "memory_demo.db"
    conn = sqlite3.connect(db_path, check_same_thread=False)
    saver = SqliteSaver(conn)
    graph = make_graph(saver)

    cfg = {"configurable": {"thread_id": "sqlite-session"}}

    graph.invoke({"user": "Dev", "messages": ["First message"], "turn": 0}, config=cfg)
    graph.invoke({"user": "Dev", "messages": ["Second message"], "turn": 0}, config=cfg)

    snap = graph.get_state(cfg)
    print(f"  SQLite session messages: {snap.values['messages']}")
    print(f"  Persisted to: {db_path}")

    # Manually edit state (simulate human correction)
    graph.update_state(cfg, {"messages": ["[EDITED by human]"]})
    snap_after = graph.get_state(cfg)
    print(f"  After update_state: {snap_after.values['messages'][-1]}")

    conn.close()


# --- TYPE 3: AsyncSqliteSaver ------------------------------------------------
# Same as SqliteSaver but works with async graphs (ainvoke / astream).

async def demo_async_sqlite_saver():
    from langgraph.checkpoint.aiosqlite import AsyncSqliteSaver

    async with AsyncSqliteSaver.from_conn_string("async_memory_demo.db") as saver:
        graph = make_graph(saver)
        cfg = {"configurable": {"thread_id": "async-session"}}

        await graph.ainvoke({"user": "AsyncUser", "messages": ["async hello"], "turn": 0}, config=cfg)
        await graph.ainvoke({"user": "AsyncUser", "messages": ["async world"], "turn": 0}, config=cfg)

        snap = await graph.aget_state(cfg)
        print(f"  Async SQLite messages: {snap.values['messages']}")


# --- TYPE 4: PostgresSaver (reference — requires extra package) ---------------
# For production: multi-instance, horizontally scalable.
# Install: pip install langgraph-checkpoint-postgres
#
# Usage:
#   from langgraph.checkpoint.postgres import PostgresSaver
#   saver = PostgresSaver.from_conn_string("postgresql://user:pw@host/db")
#   saver.setup()     # creates tables on first use
#   graph = make_graph(saver)


# --- Time-travel demo ---------------------------------------------------------
# Every checkpoint has a checkpoint_id. Pass it in config to replay from there.

def demo_time_travel():
    saver = MemorySaver()
    graph = make_graph(saver)
    cfg = {"configurable": {"thread_id": "time-travel"}}

    # Build up 3 turns of history
    for msg in ["Turn A", "Turn B", "Turn C"]:
        graph.invoke({"user": "Traveller", "messages": [msg], "turn": 0}, config=cfg)

    history = list(graph.get_state_history(cfg))
    print(f"  Total checkpoints: {len(history)}")
    for i, h in enumerate(history):
        cp_id = h.config["configurable"]["checkpoint_id"][:12]
        print(f"    [{i}] checkpoint={cp_id}... messages={len(h.values['messages'])}")

    # Replay from checkpoint index 1 (second-most-recent)
    target_cfg = history[1].config
    snap = graph.get_state(target_cfg)
    print(f"  Replayed from checkpoint[1]: messages={snap.values['messages']}")


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55

    print(f"\n{sep}")
    print("TYPE 1 — MemorySaver (in-RAM)")
    print(sep)
    demo_memory_saver()

    print(f"\n{sep}")
    print("TYPE 2 — SqliteSaver (local file)")
    print(sep)
    demo_sqlite_saver()

    print(f"\n{sep}")
    print("TYPE 3 — AsyncSqliteSaver")
    print(sep)
    try:
        asyncio.run(demo_async_sqlite_saver())
    except ImportError:
        print("  Install aiosqlite: pip install aiosqlite")

    print(f"\n{sep}")
    print("Time-travel across checkpoints")
    print(sep)
    demo_time_travel()

    print(f"\n{sep}")
    print("TYPE 4 — PostgresSaver  (see comments in source)")
    print(sep)
    print("  pip install langgraph-checkpoint-postgres")
    print("  from langgraph.checkpoint.postgres import PostgresSaver")
    print("  saver = PostgresSaver.from_conn_string('postgresql://...')")


if __name__ == "__main__":
    run()
