"""
Run all LangGraph examples.

Usage (from the project root):
    python examples/run_all.py        # all 4 examples
    python examples/run_all.py 02     # single example by number
"""

import importlib
import sys
import os

THIS_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, THIS_DIR)

EXAMPLES = [
    ("01", "01 - State & All Node Variants",    "01_state_and_nodes"),
    ("02", "02 - All Edge Types & Routing",      "02_edges_and_routing"),
    ("03", "03 - Memory & 4 Checkpointer Types", "03_memory_checkpointers"),
    ("04", "04 - Human-in-the-Loop",             "04_human_in_the_loop"),
]


def run_example(title, module_name):
    print(f"\n{'=' * 62}")
    print(f"  {title}")
    print(f"{'=' * 62}")
    try:
        mod = importlib.import_module(module_name)
        mod.run()
    except ModuleNotFoundError as e:
        print(f"  MISSING PACKAGE: {e}")
        print("  Run:  pip install -r requirements.txt")
    except Exception as e:
        print(f"  ERROR: {type(e).__name__}: {e}")


def main():
    arg = sys.argv[1].lower() if len(sys.argv) > 1 else "all"

    if arg == "all":
        examples = EXAMPLES
    else:
        examples = [(k, t, m) for k, t, m in EXAMPLES if k == arg or m.startswith(arg)]
        if not examples:
            print(f"No example matching '{arg}'.")
            print("Available keys:", [k for k, _, _ in EXAMPLES])
            sys.exit(1)

    for _, title, module in examples:
        run_example(title, module)

    print(f"\n{'=' * 62}")
    print(f"  Done -- ran {len(examples)} example(s)")
    print(f"{'=' * 62}\n")


if __name__ == "__main__":
    main()
