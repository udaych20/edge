import asyncio
import operator
from pathlib import Path
from typing import Annotated, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import END, START, MessagesState, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import Command

load_dotenv(Path(__file__).parent / ".env")


# Plain state: each node overwrites the fields it returns
class PlainState(TypedDict):
    text: str
    count: int


# Reducer state: `log` accumulates across nodes instead of being overwritten
class ReducerState(TypedDict):
    query: str
    log: Annotated[list[str], operator.add]
    messages: Annotated[list[BaseMessage], add_messages]
    score: int


# --- nodes ---

def plain_node(state: PlainState) -> dict:
    print(f"  [plain_node] got: '{state['text']}'")
    return {"text": state["text"].upper(), "count": state["count"] + 1}


def log_node_a(state: ReducerState) -> dict:
    print("  [log_node_a] running")
    return {"log": ["node_a ran"], "score": 10}


def log_node_b(state: ReducerState) -> dict:
    print("  [log_node_b] running")
    return {"log": ["node_b ran"], "score": state["score"] + 5}


async def async_node(state: PlainState) -> dict:
    print("  [async_node] doing async work")
    await asyncio.sleep(0)
    return {"text": f"async({state['text']})", "count": state["count"] + 1}


def llm_node(state: MessagesState) -> dict:
    print("  [llm_node] calling LLM")
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
    response = llm.invoke(state["messages"])
    return {"messages": [response]}


def command_node(state: PlainState) -> Command:
    print(f"  [command_node] routing based on: '{state['text']}'")
    if "error" in state["text"]:
        return Command(update={"text": "ERROR HANDLED", "count": 99}, goto=END)
    return Command(update={"text": "ok", "count": state["count"] + 1}, goto="done")


def done_node(state: PlainState) -> dict:
    print(f"  [done_node] finished, count={state['count']}")
    return {}


# --- graphs ---

def build_plain_graph():
    g = StateGraph(PlainState)
    g.add_node("plain", plain_node)
    g.add_edge(START, "plain")
    g.add_edge("plain", END)
    return g.compile()


def build_reducer_graph():
    g = StateGraph(ReducerState)
    g.add_node("a", log_node_a)
    g.add_node("b", log_node_b)
    g.add_edge(START, "a")
    g.add_edge("a", "b")
    g.add_edge("b", END)
    return g.compile()


def build_async_graph():
    g = StateGraph(PlainState)
    g.add_node("async_step", async_node)
    g.add_edge(START, "async_step")
    g.add_edge("async_step", END)
    return g.compile()


def build_llm_graph():
    g = StateGraph(MessagesState)
    g.add_node("llm", llm_node)
    g.add_edge(START, "llm")
    g.add_edge("llm", END)
    return g.compile()


def build_command_graph():
    g = StateGraph(PlainState)
    g.add_node("router", command_node)
    g.add_node("done", done_node)
    g.add_edge(START, "router")
    g.add_edge("done", END)
    return g.compile()


# --- demo ---

def run():
    sep = "-" * 55

    print(f"\n{sep}")
    print("Variant 1 — Plain node (overwrite)")
    print(sep)
    result = build_plain_graph().invoke({"text": "hello", "count": 0})
    print(f"  text='{result['text']}', count={result['count']}")

    print(f"\n{sep}")
    print("Variant 2 — Reducer node (accumulate)")
    print(sep)
    result = build_reducer_graph().invoke({"query": "test", "log": [], "messages": [], "score": 0})
    print(f"  log={result['log']}, score={result['score']}")

    print(f"\n{sep}")
    print("Variant 3 — Async node")
    print(sep)
    result = asyncio.run(build_async_graph().ainvoke({"text": "world", "count": 0}))
    print(f"  text='{result['text']}'")

    print(f"\n{sep}")
    print("Variant 4 — LLM node")
    print(sep)
    try:
        result = build_llm_graph().invoke({"messages": [HumanMessage(content="Say hi in one word.")]})
        print(f"  LLM reply: {result['messages'][-1].content}")
    except Exception as e:
        print(f"  Skipped: {e}")

    print(f"\n{sep}")
    print("Variant 5 — Command node (node controls routing)")
    print(sep)
    r_ok = build_command_graph().invoke({"text": "all good", "count": 0})
    print(f"  Normal path: text='{r_ok['text']}', count={r_ok['count']}")
    r_err = build_command_graph().invoke({"text": "error occurred", "count": 0})
    print(f"  Error path:  text='{r_err['text']}', count={r_err['count']}")


if __name__ == "__main__":
    run()
