"""
Example 04 — Human-in-the-Loop (HITL)
========================================
Covers:
  • interrupt_before  — pause BEFORE a node runs (most common)
  • interrupt_after   — pause AFTER a node runs
  • Inspecting state at the breakpoint
  • Resuming after human approval  (invoke with None)
  • Editing state before resume    (update_state)
  • Rejecting / rerouting          (update_state with as_node)
  • Multi-step approval pipeline
"""

from __future__ import annotations

from typing import Literal, TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

# --- State --------------------------------------------------------------------

class ArticleState(TypedDict):
    title: str
    draft: str
    reviewed_draft: str
    published: bool
    rejection_reason: str


# --- Nodes --------------------------------------------------------------------

def write_draft(state: ArticleState) -> dict:
    print(f"  [write_draft] Writing draft for: '{state['title']}'")
    draft = f"Draft content about {state['title']}. This needs review."
    return {"draft": draft}


def legal_review(state: ArticleState) -> dict:
    print(f"  [legal_review] Auto-checking legal compliance...")
    return {"reviewed_draft": state["draft"] + " [legally cleared]"}


def publish(state: ArticleState) -> dict:
    print(f"  [publish] Publishing: '{state['reviewed_draft']}'")
    return {"published": True}


def reject(state: ArticleState) -> dict:
    print(f"  [reject] Rejected: {state['rejection_reason']}")
    return {"published": False}


# --- Example A: interrupt_before ---------------------------------------------
# Graph pauses BEFORE the named node — human sees what's ABOUT to happen.
# Most common pattern for "approve before action".

def build_interrupt_before_graph():
    memory = MemorySaver()
    #A graph whose nodes communicate by reading and writing to a shared state.
    g = StateGraph(ArticleState)

    g.add_node("write_draft", write_draft)
    g.add_node("legal_review", legal_review)
    g.add_node("publish", publish)

    g.add_edge(START, "write_draft")
    g.add_edge("write_draft", "legal_review")
    g.add_edge("legal_review", "publish")
    g.add_edge("publish", END)

    # Pauses BEFORE "publish" — human approves after legal review
    return g.compile(checkpointer=memory, interrupt_before=["publish"])


# --- Example B: interrupt_after ----------------------------------------------
# Graph pauses AFTER the named node — human sees the output before continuing.
# Useful for "review what was produced then decide".

def build_interrupt_after_graph():
    memory = MemorySaver()
    g = StateGraph(ArticleState)

    g.add_node("write_draft", write_draft)
    g.add_node("legal_review", legal_review)
    g.add_node("publish", publish)

    g.add_edge(START, "write_draft")
    g.add_edge("write_draft", "legal_review")
    g.add_edge("legal_review", "publish")
    g.add_edge("publish", END)

    # Pauses AFTER "write_draft" — human reads the draft before legal review
    return g.compile(checkpointer=memory, interrupt_after=["write_draft"])


# --- Example C: Edit state before resume -------------------------------------
# Human changes the draft content before the graph continues.

def demo_edit_then_resume():
    print("\n  Scenario: human edits the draft before publishing")

    graph = build_interrupt_before_graph()
    cfg = {"configurable": {"thread_id": "edit-demo"}}
    init = {"title": "AI Safety", "draft": "", "reviewed_draft": "", "published": False, "rejection_reason": ""}

    # Run to breakpoint (pauses before "publish")
    graph.invoke(init, config=cfg)
    snap = graph.get_state(cfg)
    print(f"  Paused at: {snap.next}")
    print(f"  Draft before edit: '{snap.values['reviewed_draft']}'")

    # Human edits the reviewed draft
    graph.update_state(cfg, {"reviewed_draft": "Completely rewritten by human editor."})
    snap2 = graph.get_state(cfg)
    print(f"  Draft after edit:  '{snap2.values['reviewed_draft']}'")

    # Resume — publish runs with the edited content
    final = graph.invoke(None, config=cfg)
    print(f"  Published: {final['published']}")


# --- Example D: Reject and reroute using update_state(as_node=...) -----------
# Human rejects — update_state pretends a different node ran so routing changes.

def demo_reject_and_reroute():
    print("\n  Scenario: human rejects the draft, reroutes to reject node")

    memory = MemorySaver()
    g = StateGraph(ArticleState)

    def router(state: ArticleState) -> Literal["publish", "reject"]:
        return "reject" if state["rejection_reason"] else "publish"

    g.add_node("write_draft", write_draft)
    g.add_node("legal_review", legal_review)
    g.add_node("publish", publish)
    g.add_node("reject", reject)

    g.add_edge(START, "write_draft")
    g.add_edge("write_draft", "legal_review")
    g.add_conditional_edges("legal_review", router)
    g.add_edge("publish", END)
    g.add_edge("reject", END)

    graph = g.compile(checkpointer=memory, interrupt_before=["publish", "reject"])
    cfg = {"configurable": {"thread_id": "reject-demo"}}
    init = {"title": "Risky Article", "draft": "", "reviewed_draft": "", "published": False, "rejection_reason": ""}

    graph.invoke(init, config=cfg)
    snap = graph.get_state(cfg)
    print(f"  Paused before: {snap.next}")

    # Human injects a rejection reason — update_state as if "legal_review" ran
    # This re-triggers the router with rejection_reason set
    graph.update_state(
        cfg,
        {"rejection_reason": "Contains unverified claims."},
        as_node="legal_review",    # pretend legal_review is setting this
    )

    final = graph.invoke(None, config=cfg)
    print(f"  Published: {final['published']}, Reason: {final['rejection_reason']}")


# --- Example E: Multi-step approval (two interrupt points) -------------------

def demo_multi_step_approval():
    print("\n  Scenario: two approval gates (legal + executive)")

    memory = MemorySaver()
    g = StateGraph(ArticleState)

    def exec_approval(state: ArticleState) -> dict:
        print("  [exec_approval] Executive pre-approval node")
        return {}

    g.add_node("write_draft", write_draft)
    g.add_node("legal_review", legal_review)
    g.add_node("exec_approval", exec_approval)
    g.add_node("publish", publish)

    g.add_edge(START, "write_draft")
    g.add_edge("write_draft", "legal_review")
    g.add_edge("legal_review", "exec_approval")
    g.add_edge("exec_approval", "publish")
    g.add_edge("publish", END)

    # Two interrupt points
    graph = g.compile(
        checkpointer=memory,
        interrupt_before=["legal_review", "publish"],
    )
    cfg = {"configurable": {"thread_id": "multi-approval"}}
    init = {"title": "Board Report", "draft": "", "reviewed_draft": "", "published": False, "rejection_reason": ""}

    # -- Gate 1: before legal_review
    graph.invoke(init, config=cfg)
    snap = graph.get_state(cfg)
    print(f"  Gate 1 paused at: {snap.next}  -> human approves legal review")
    graph.invoke(None, config=cfg)   # resume through legal_review

    # -- Gate 2: before publish
    snap2 = graph.get_state(cfg)
    print(f"  Gate 2 paused at: {snap2.next}  -> human approves publish")
    final = graph.invoke(None, config=cfg)
    print(f"  Final published: {final['published']}")


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55

    print(f"\n{sep}")
    print("A — interrupt_before: approve then resume")
    print(sep)
    graph = build_interrupt_before_graph()
    cfg = {"configurable": {"thread_id": "before-demo"}}
    init = {"title": "Tech News", "draft": "", "reviewed_draft": "", "published": False, "rejection_reason": ""}
    graph.invoke(init, config=cfg)
    snap = graph.get_state(cfg)
    print(f"  Paused, next node: {snap.next}")
    final = graph.invoke(None, config=cfg)      # None = resume
    print(f"  Resumed. Published: {final['published']}")

    print(f"\n{sep}")
    print("B — interrupt_after: inspect output then continue")
    print(sep)
    graph2 = build_interrupt_after_graph()
    cfg2 = {"configurable": {"thread_id": "after-demo"}}
    graph2.invoke(init, config=cfg2)
    snap2 = graph2.get_state(cfg2)
    print(f"  Paused after write_draft. Draft: '{snap2.values['draft']}'")
    final2 = graph2.invoke(None, config=cfg2)
    print(f"  Resumed. Published: {final2['published']}")

    print(f"\n{sep}")
    print("C — Edit state before resume")
    print(sep)
    demo_edit_then_resume()

    print(f"\n{sep}")
    print("D — Reject and reroute via update_state(as_node=...)")
    print(sep)
    demo_reject_and_reroute()

    print(f"\n{sep}")
    print("E — Multi-step approval (two interrupt points)")
    print(sep)
    demo_multi_step_approval()


if __name__ == "__main__":
    run()
