"""
Example 02 — All Edge Types
==============================
Covers:
  • add_edge(START, node)           — entry edge
  • add_edge(a, b)                  — unconditional edge
  • add_edge(z, END)                — terminal edge
  • add_conditional_edges(...)      — router: 1 source -> N possible targets
  • set_entry_point / set_finish_point  — convenience aliases
  • Dynamic conditional map (dict vs None)
"""

from __future__ import annotations

from typing import Literal, TypedDict

from langgraph.graph import END, START, StateGraph

# --- Shared state -------------------------------------------------------------

class RouteState(TypedDict):
    input: str
    path_taken: list[str]
    result: str


# --- Shared nodes -------------------------------------------------------------

def entry(state: RouteState) -> dict:
    return {"path_taken": state["path_taken"] + ["entry"]}

def fast_track(state: RouteState) -> dict:
    return {"path_taken": state["path_taken"] + ["fast_track"], "result": "fast"}

def normal_track(state: RouteState) -> dict:
    return {"path_taken": state["path_taken"] + ["normal_track"], "result": "normal"}

def premium_track(state: RouteState) -> dict:
    return {"path_taken": state["path_taken"] + ["premium_track"], "result": "premium"}

def finish(state: RouteState) -> dict:
    return {"path_taken": state["path_taken"] + ["finish"]}


# --- Edge Type 1 & 2 & 3: START -> node -> node -> END (unconditional) ----------

def build_linear_graph():
    """
    START --► entry --► finish --► END
    The simplest possible graph — three unconditional edges.
    """
    g = StateGraph(RouteState)
    g.add_node("entry", entry)
    g.add_node("finish", finish)

    g.add_edge(START, "entry")      # Edge type 1: entry
    g.add_edge("entry", "finish")   # Edge type 2: unconditional middle
    g.add_edge("finish", END)       # Edge type 3: terminal
    return g.compile()


# --- Edge Type 4a: Conditional edge with explicit routing dict ----------------
#
# add_conditional_edges(source, router_fn, path_map)
#   router_fn   -> returns a KEY (string/enum)
#   path_map    -> dict mapping keys -> actual node names
# Using a path_map decouples the router logic from node names.

def build_conditional_with_map():
    """
    entry --► router decides --► fast_track
                             --► normal_track
                             --► premium_track
    """
    def router(state: RouteState) -> Literal["fast", "normal", "premium"]:
        if "vip" in state["input"]:
            return "premium"
        elif "urgent" in state["input"]:
            return "fast"
        else:
            return "normal"

    g = StateGraph(RouteState)
    g.add_node("entry", entry)
    g.add_node("fast_track", fast_track)
    g.add_node("normal_track", normal_track)
    g.add_node("premium_track", premium_track)

    g.add_edge(START, "entry")
    g.add_conditional_edges(
        "entry",
        router,
        {                               # path_map: key -> node name
            "fast":    "fast_track",
            "normal":  "normal_track",
            "premium": "premium_track",
        },
    )
    g.add_edge("fast_track", END)
    g.add_edge("normal_track", END)
    g.add_edge("premium_track", END)
    return g.compile()


# --- Edge Type 4b: Conditional edge WITHOUT a path map -----------------------
# Router returns the ACTUAL node name directly — simpler but more coupled.

def build_conditional_no_map():
    """Router returns the node name directly, no path_map needed."""
    def router(state: RouteState) -> str:
        return "fast_track" if "urgent" in state["input"] else "normal_track"

    g = StateGraph(RouteState)
    g.add_node("entry", entry)
    g.add_node("fast_track", fast_track)
    g.add_node("normal_track", normal_track)

    g.add_edge(START, "entry")
    g.add_conditional_edges("entry", router)   # no path_map -> router returns node name
    g.add_edge("fast_track", END)
    g.add_edge("normal_track", END)
    return g.compile()


# --- Edge Type 5: set_entry_point / set_finish_point (aliases) ---------------
# These are convenience methods — identical to add_edge(START/END, ...).

def build_alias_graph():
    g = StateGraph(RouteState)
    g.add_node("entry", entry)
    g.add_node("finish", finish)

    g.set_entry_point("entry")        # same as add_edge(START, "entry")
    g.add_edge("entry", "finish")
    g.set_finish_point("finish")      # same as add_edge("finish", END)
    return g.compile()


# --- Edge Type 6: Looping back (retry/feedback loop) -------------------------

class LoopState(TypedDict):
    value: int
    attempts: int

def increment(state: LoopState) -> dict:
    return {"value": state["value"] + 1, "attempts": state["attempts"] + 1}

def build_loop_graph():
    """
    Loops the increment node up to 3 times, then exits.
    Pattern: node --► router --► same node (loop) or END (exit)
    """
    def loop_router(state: LoopState) -> Literal["loop", "done"]:
        return "loop" if state["attempts"] < 3 else "done"

    g = StateGraph(LoopState)
    g.add_node("increment", increment)

    g.add_edge(START, "increment")
    g.add_conditional_edges(
        "increment",
        loop_router,
        {"loop": "increment", "done": END},  # "loop" -> back to itself
    )
    return g.compile()


# --- Demo ---------------------------------------------------------------------

def run():
    sep = "-" * 55
    base = {"path_taken": [], "result": ""}

    print(f"\n{sep}")
    print("Linear graph (3 unconditional edges)")
    print(sep)
    r = build_linear_graph().invoke({**base, "input": "anything"})
    print(f"  Path: {' -> '.join(r['path_taken'])}")

    print(f"\n{sep}")
    print("Conditional edge WITH path_map")
    print(sep)
    for inp in ["buy now vip", "urgent request", "regular order"]:
        r = build_conditional_with_map().invoke({**base, "input": inp})
        print(f"  '{inp}' -> {r['result']}")

    print(f"\n{sep}")
    print("Conditional edge WITHOUT path_map")
    print(sep)
    for inp in ["urgent!", "normal"]:
        r = build_conditional_no_map().invoke({**base, "input": inp})
        print(f"  '{inp}' -> {r['result']}")

    print(f"\n{sep}")
    print("set_entry_point / set_finish_point aliases")
    print(sep)
    r = build_alias_graph().invoke({**base, "input": "test"})
    print(f"  Path: {' -> '.join(r['path_taken'])}")

    print(f"\n{sep}")
    print("Loop graph (3 retries then exit)")
    print(sep)
    r = build_loop_graph().invoke({"value": 0, "attempts": 0})
    print(f"  Final value={r['value']}, attempts={r['attempts']}")


if __name__ == "__main__":
    run()
