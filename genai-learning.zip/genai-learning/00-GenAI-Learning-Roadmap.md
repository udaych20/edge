# GenAI Concepts — Learning Roadmap

> **Last Updated:** April 2026  
> **Purpose:** A structured learning path covering all major Generative AI concepts, tools, and recent developments.

---

## Learning Path Overview

```
Foundations (1-5)           ✅ Completed
    → Core Patterns (6-10)
        → Single Agent (11-13)
            → Multi-Agent & Protocols (14-16)
                → Advanced Techniques (17-25)
                    → Production (26-28)
```

---

## 1. Foundations ✅ (Completed)

| # | Concept | Use Case | Top Learning Resources |
|---|---------|----------|----------------------|
| 1 | **LLMs (Large Language Models)** | Text generation, summarization, translation | Andrej Karpathy's "Intro to LLMs" (YouTube), DeepLearning.AI "GenAI with LLMs" (Coursera), Hugging Face NLP Course |
| 2 | **Tokenization & Embeddings** | Semantic search, text similarity, clustering | OpenAI Embeddings Guide, Jay Alammar's "The Illustrated Word2Vec", Hugging Face `sentence-transformers` docs |
| 3 | **Prompt Engineering** | Getting precise outputs, few-shot learning, chain-of-thought | OpenAI Prompt Engineering Guide, DAIR.AI Prompt Engineering Guide (GitHub), LearnPrompting.org |
| 4 | **Fine-Tuning** | Domain-specific models, style adaptation, task specialization | Hugging Face PEFT/LoRA docs, DeepLearning.AI "Fine-Tuning LLMs", Axolotl (GitHub) |
| 5 | **Transformer Architecture** | Understanding how LLMs work internally | Jay Alammar's "The Illustrated Transformer", 3Blue1Brown "Attention in Transformers" (YouTube), "Attention Is All You Need" paper |

---

## 2. Core Application Patterns

| # | Concept | Use Case | Top Learning Resources |
|---|---------|----------|----------------------|
| 6 | **RAG (Retrieval-Augmented Generation)** | Q&A over private documents, enterprise search, knowledge bases | LangChain RAG tutorial, DeepLearning.AI "Building RAG Agents", LlamaIndex docs |
| 7 | **Vector Databases** | Storing/querying embeddings for RAG, similarity search | Pinecone Learning Center, Weaviate Academy, ChromaDB getting-started guide |
| 8 | **Function Calling / Tool Use** | LLMs invoking APIs, executing code, querying databases | OpenAI Function Calling docs, Anthropic Tool Use docs, LangChain Tools guide |
| 9 | **Structured Output** | JSON generation, form filling, data extraction | OpenAI Structured Outputs guide, Instructor library (GitHub), Outlines (GitHub) |
| 10 | **Guardrails & Safety** | Content filtering, output validation, preventing prompt injection | NVIDIA NeMo Guardrails, Guardrails AI (GitHub), OWASP LLM Top 10 |

📄 Detailed: [01-Core-Application-Patterns.md](01-Core-Application-Patterns.md)

---

## 3. Agents & Orchestration

| # | Concept | Use Case | Top Learning Resources |
|---|---------|----------|----------------------|
| 11 | **AI Agents** | Autonomous task execution, research assistants, coding agents | DeepLearning.AI "AI Agents in LangGraph", OpenAI Agents SDK docs, Anthropic "Building Effective Agents" blog |
| 12 | **Agent Workflows (Agentic Patterns)** | Multi-step reasoning: reflection, planning, tool-use loops | Andrew Ng's Agentic Design Patterns, LangGraph docs, CrewAI docs |
| 13 | **ReAct (Reason + Act)** | Step-by-step reasoning with tool calls interleaved | Original ReAct paper, LangChain ReAct agent tutorial, Hugging Face Agents course |
| 14 | **Multi-Agent Systems** | Complex pipelines with specialized collaborating agents | CrewAI (GitHub), AutoGen by Microsoft (GitHub), LangGraph multi-agent tutorial |
| 15 | **Agent-to-Agent (A2A) Protocol** | Interoperability between agents across platforms/vendors | Google A2A Protocol spec (GitHub), Google Cloud A2A blog, A2A Python/JS SDK samples |
| 16 | **MCP (Model Context Protocol)** | Standardized tool/resource integration for LLMs | Anthropic MCP spec (modelcontextprotocol.io), MCP GitHub repos, VS Code + Copilot MCP docs |

📄 Detailed: [02-Agents-and-Orchestration.md](02-Agents-and-Orchestration.md)

---

## 4. Advanced & Recent Developments

| # | Concept | Use Case | Top Learning Resources |
|---|---------|----------|----------------------|
| 17 | **Advanced RAG** (HyDE, CRAG, Agentic RAG) | Improved retrieval accuracy, self-correcting retrieval | DeepLearning.AI "Agentic RAG with LlamaIndex", LangChain CRAG tutorial, arXiv surveys |
| 18 | **GraphRAG** | Entity-heavy domains, relationship-aware Q&A | Microsoft GraphRAG (GitHub), Neo4j GenAI docs, LangChain + Knowledge Graphs |
| 19 | **Mixture of Experts (MoE)** | Efficient large-scale models (Mixtral, GPT-4) | Hugging Face MoE explainer, "Outrageously Large Neural Networks" paper |
| 20 | **Small Language Models (SLMs)** | On-device/edge AI, privacy-preserving inference | Microsoft Phi-3 docs, Ollama, MLX by Apple (GitHub) |
| 21 | **Multimodal AI** | Vision + language, image/video understanding | OpenAI GPT-4o docs, Google Gemini API docs, Hugging Face Multimodal course |
| 22 | **Voice & Audio AI** | Transcription, TTS, real-time voice agents | OpenAI Whisper/TTS APIs, ElevenLabs docs, Deepgram SDK |
| 23 | **Code Generation & Copilots** | Coding assistants, automated testing, code review | GitHub Copilot docs, Cursor, Aider (GitHub) |
| 24 | **Evaluation & Observability** | Measuring quality, debugging agent behavior | Ragas (GitHub), LangSmith, Braintrust |
| 25 | **RLHF / DPO / Preference Tuning** | Aligning models with human preferences | DeepLearning.AI "RLHF" course, Hugging Face TRL library |

📄 Detailed: [03-Advanced-Developments.md](03-Advanced-Developments.md)

---

## 5. Deployment & Production

| # | Concept | Use Case | Top Learning Resources |
|---|---------|----------|----------------------|
| 26 | **LLMOps** | CI/CD for LLM apps, prompt versioning, cost management | MLflow LLM Tracking, Weights & Biases Prompts, PromptLayer |
| 27 | **Quantization & Optimization** | Reducing model size (GGUF, GPTQ, AWQ) | Hugging Face Quantization docs, llama.cpp (GitHub), vLLM docs |
| 28 | **AI Gateway & Routing** | Load balancing, fallback, rate limiting | LiteLLM (GitHub), Portkey AI, Azure AI Gateway |

📄 Detailed: [04-Deployment-and-Production.md](04-Deployment-and-Production.md)

---

> **Key Takeaway:** Start with RAG and Function Calling (highest practical impact), then progress to agents and multi-agent systems. MCP and A2A are the newest interoperability standards — learn them after understanding single-agent patterns.
