# Advanced & Recent Developments — Detailed Guide

> **Prerequisites:** Core Application Patterns, Agents & Orchestration  
> **Goal:** Master cutting-edge techniques in RAG, multimodal AI, model efficiency, evaluation, and alignment.

---

## Table of Contents

1. [Advanced RAG (HyDE, CRAG, Agentic RAG)](#1-advanced-rag)
2. [GraphRAG](#2-graphrag)
3. [Mixture of Experts (MoE)](#3-mixture-of-experts-moe)
4. [Small Language Models (SLMs)](#4-small-language-models-slms)
5. [Multimodal AI](#5-multimodal-ai)
6. [Voice & Audio AI](#6-voice--audio-ai)
7. [Code Generation & Copilots](#7-code-generation--copilots)
8. [Evaluation & Observability](#8-evaluation--observability)
9. [RLHF / DPO / Preference Tuning](#9-rlhf--dpo--preference-tuning)

---

## 1. Advanced RAG

### Why Basic RAG Isn't Enough

Basic RAG (embed → retrieve → generate) suffers from:

- **Lost in the middle** — LLMs struggle with relevant info buried in the middle of context
- **Wrong chunks retrieved** — Query-document mismatch
- **No verification** — Blindly trusts whatever is retrieved
- **Single-hop only** — Can't answer questions requiring information synthesis from multiple documents

### Advanced RAG Techniques

```
BASIC RAG                      ADVANCED RAG
                                
Query → Retrieve → Generate    Query → Rewrite → Retrieve → Rerank → 
                                Verify → Generate → Self-Check
```

#### Pre-Retrieval Optimization

| Technique | What It Does | How |
|-----------|-------------|-----|
| **Query Rewriting** | Reformulates query for better retrieval | LLM rewrites user query: "How to fix X?" → "Troubleshooting steps for X in Python 3.12" |
| **HyDE (Hypothetical Document Embeddings)** | Generates a hypothetical answer, embeds *that* for retrieval | Embed a fake answer → search for real documents similar to it |
| **Query Decomposition** | Splits complex query into sub-queries | "Compare X vs Y" → ["What is X?", "What is Y?", "Key differences?"] |
| **Step-Back Prompting** | Asks a broader question first | "Why is my Flask app slow?" → "What are common Flask performance issues?" |

#### Retrieval Enhancement

| Technique | What It Does | How |
|-----------|-------------|-----|
| **Hybrid Search** | Combines semantic (vector) + lexical (BM25) search | Merge results from both, weighted scoring |
| **Reranking** | Second-pass scoring of retrieved chunks | Cross-encoder reranker (Cohere Rerank, BGE Reranker) |
| **Contextual Retrieval** | Adds document context to each chunk before embedding | Prepend "This chunk is from [doc title], section [X]..." |
| **Multi-index** | Uses different indexes for different types of content | Summary index for overview, chunk index for details |
| **Metadata Filtering** | Narrow search by date, source, category | "Only search documents from 2025" |

#### Post-Retrieval Optimization

| Technique | What It Does | How |
|-----------|-------------|-----|
| **Contextual Compression** | Extracts only relevant portions from retrieved chunks | LLM or model compresses each chunk to query-relevant parts |
| **Lost-in-the-Middle Mitigation** | Reorders chunks so most relevant are at start/end | Place best matches at beginning and end of context |
| **Citation/Grounding** | Forces LLM to cite sources in response | System prompt: "Cite [Source X] for each claim" |

#### Self-Correcting RAG

| Technique | What It Does | How |
|-----------|-------------|-----|
| **CRAG (Corrective RAG)** | Evaluates retrieval quality; falls back to web search if poor | Retrieval evaluator scores confidence → if low, search the web instead |
| **Self-RAG** | LLM decides whether to retrieve at all, and verifies its own output | Special tokens trigger retrieval; critique tokens evaluate relevance |
| **Agentic RAG** | Agent decides when/what/how to retrieve dynamically | Agent loop: think → decide if retrieval needed → retrieve → validate → answer |

### Agentic RAG Architecture

```
┌───────────────────────────────────────────────────────┐
│                    AGENTIC RAG                         │
│                                                        │
│  ┌──────────┐    ┌─────────────┐    ┌──────────────┐ │
│  │  Router   │───▶│  Retriever   │───▶│  Grader      │ │
│  │  (LLM)   │    │  (Vector DB) │    │  (Relevance) │ │
│  └──────────┘    └─────────────┘    └──────┬───────┘ │
│       │                                      │        │
│       │ (no retrieval needed)     ┌──────────┴──────┐ │
│       │                          │  Relevant?       │ │
│       ▼                          ├─── Yes ──▶ Generate│
│  ┌──────────┐                    └─── No  ──▶ Web    │ │
│  │ Direct    │                              Search   │ │
│  │ Answer    │                              ↓        │ │
│  └──────────┘                           Generate     │ │
│                                             │        │ │
│                                    ┌────────┴──────┐ │
│                                    │ Hallucination  │ │
│                                    │ Check          │ │
│                                    ├── Pass ──▶ ✅  │ │
│                                    └── Fail ──▶ 🔄  │ │
│                                       (retry)       │ │
└───────────────────────────────────────────────────────┘
```

### Learning Resources

1. **DeepLearning.AI "Agentic RAG with LlamaIndex"** — Build self-correcting RAG agents
2. **LangChain Corrective RAG Tutorial** — Implement CRAG with LangGraph
3. **"Retrieval-Augmented Generation for AI-Generated Content" Survey** (arXiv) — Comprehensive academic overview

---

## 2. GraphRAG

### What Is It?

GraphRAG combines **knowledge graphs** with RAG to enable **entity-relationship-aware** retrieval and generation. Instead of flat chunks, it builds a graph of entities and relationships from your documents, enabling the LLM to answer questions requiring understanding of connections.

### GraphRAG vs. Standard RAG

| Aspect | Standard RAG | GraphRAG |
|--------|-------------|----------|
| **Index structure** | Flat chunks in vector DB | Knowledge graph (entities + relationships) |
| **Retrieval** | Semantic similarity | Graph traversal + semantic similarity |
| **Strengths** | Factual questions | Relationship questions, summarization |
| **Weakness** | "What connects X and Y?" | More complex to set up |
| **Example query** | "What is product X?" | "How is person A connected to company B through project C?" |

### How It Works (Microsoft GraphRAG)

```
┌──────────┐     ┌──────────────┐     ┌───────────────┐
│ Documents │────▶│ Entity/Rel    │────▶│ Knowledge     │
│           │     │ Extraction    │     │ Graph         │
└──────────┘     │ (LLM-based)  │     └───────┬───────┘
                 └──────────────┘             │
                                              ▼
                                     ┌───────────────┐
                                     │ Community      │
                                     │ Detection      │
                                     └───────┬───────┘
                                              │
                                              ▼
                                     ┌───────────────┐
                                     │ Community      │
                                     │ Summaries      │
                                     └───────────────┘
```

1. **Extract** entities and relationships from documents using LLM
2. **Build** a knowledge graph
3. **Detect communities** (clusters of related entities)
4. **Summarize** each community
5. **Query** using graph traversal + community summaries

### Query Types

| Type | Description | Example |
|------|-------------|---------|
| **Local search** | Find specific entity facts | "What role does Alice play in Project X?" |
| **Global search** | Broad summarization across communities | "What are the main themes in this dataset?" |
| **Drift search** | Follow connections dynamically | "Starting from Alice, find related projects and risks" |

### Tools

| Tool | Description |
|------|-------------|
| **Microsoft GraphRAG** | Full pipeline: extraction → graph → communities → query |
| **Neo4j + LangChain** | Graph database + RAG integration |
| **LlamaIndex Knowledge Graph** | Knowledge graph index mode |
| **Amazon Neptune** | Managed graph DB for large-scale GraphRAG |

### Learning Resources

1. **Microsoft GraphRAG** (github.com/microsoft/graphrag) — Official implementation and docs
2. **Neo4j GenAI Documentation** — Knowledge graphs for RAG
3. **LangChain + Knowledge Graphs Tutorial** — Practical integration guide

---

## 3. Mixture of Experts (MoE)

### What Is It?

MoE is a **model architecture** where a large model is divided into multiple specialized **"expert" sub-networks**. A **router** selects only a subset of experts for each input, making the model efficient — it has many parameters but activates only a fraction per inference.

### Why It Matters

- Models like **Mixtral, GPT-4, DeepSeek V3** use MoE
- Gets **large model quality** with **small model compute cost**
- Enables models with trillions of parameters that are still fast

### How It Works

```
                      ┌───────────┐
                      │   Router   │
        Input ───────▶│  (Gating)  │
                      └─────┬─────┘
                     selects top-2
              ┌──────┬──────┬──────┐
              ▼      ▼      ▼      ▼
          ┌──────┐┌──────┐┌──────┐┌──────┐
          │Expert││Expert││Expert││Expert│
          │  1   ││  2   ││  3   ││  4   │
          │      ││ ✅   ││      ││ ✅   │
          └──────┘└──┬───┘└──────┘└──┬───┘
                     │               │
                     ▼               ▼
                  ┌─────────────────────┐
                  │  Weighted Combine    │
                  └─────────┬───────────┘
                            ▼
                         Output
```

### Key Models Using MoE

| Model | Total Params | Active Params | Experts | Notes |
|-------|-------------|---------------|---------|-------|
| **Mixtral 8x7B** | 46.7B | ~12.9B | 8 (top-2) | Open-source, strong performance |
| **Mixtral 8x22B** | 141B | ~39B | 8 (top-2) | Larger, more capable |
| **GPT-4** | ~1.8T (rumored) | ~280B | 16 (top-2) | Not confirmed but widely reported |
| **DeepSeek V3** | 671B | ~37B | 256 (top-8) | Ultra-efficient MoE |
| **Grok-1** | 314B | ~86B | 8 (top-2) | Open-source by xAI |

### Learning Resources

1. **Hugging Face MoE Explainer Blog** — Visual, accessible introduction
2. **"Outrageously Large Neural Networks: The Sparsely-Gated MoE Layer"** — Original paper
3. **Fireworks AI MoE Guide** — Practical deployment of MoE models

---

## 4. Small Language Models (SLMs)

### What Is It?

SLMs are language models with **fewer than ~10B parameters**, designed to run **on-device** (phones, laptops, edge devices) while still being useful. They represent the trend toward **efficient, private, local AI**.

### Why It Matters

- **Privacy** — Data never leaves the device
- **Latency** — No network round-trip; instant responses
- **Cost** — No API fees; run on consumer hardware
- **Offline** — Works without internet
- **Compliance** — Easier to meet data residency requirements

### Key SLMs

| Model | Params | By | Highlights |
|-------|--------|----|-----------|
| **Phi-3/Phi-4** | 3.8B–14B | Microsoft | Best-in-class for size; strong reasoning |
| **Gemma 2** | 2B–9B | Google | Open weights; optimized for edge |
| **Llama 3.2** | 1B–3B | Meta | Smallest Llama; mobile-optimized |
| **Qwen 2.5** | 0.5B–7B | Alibaba | Strong multilingual, coding |
| **Mistral 7B** | 7B | Mistral AI | Excellent general-purpose |
| **SmolLM2** | 135M–1.7B | Hugging Face | Ultra-small; on-device focus |

### Local Inference Tools

| Tool | Description |
|------|-------------|
| **Ollama** | One-command local LLM server (Mac/Linux/Windows) |
| **llama.cpp** | C++ inference engine; GGUF format; CPU + GPU |
| **MLX** | Apple Silicon optimized ML framework |
| **vLLM** | High-throughput serving engine |
| **LM Studio** | GUI app for running local models |

### Quick Start with Ollama

```bash
# Install Ollama, then:
ollama pull phi3
ollama run phi3 "Explain quantum computing in 3 sentences"

# Use as OpenAI-compatible API:
curl http://localhost:11434/v1/chat/completions \
  -d '{"model": "phi3", "messages": [{"role": "user", "content": "Hello!"}]}'
```

### Learning Resources

1. **Microsoft Phi-3 Documentation** — Technical report and usage guides
2. **Ollama** (ollama.com) — Easiest way to run local models
3. **Apple MLX Documentation** — Optimized for Apple Silicon

---

## 5. Multimodal AI

### What Is It?

Multimodal AI models process and generate **multiple types of data** — text, images, audio, video — in a unified model. Instead of separate models for each modality, one model handles it all.

### Capabilities

| Modality | Input | Output | Examples |
|----------|-------|--------|----------|
| **Vision + Text** | Image → Text | Image understanding, OCR, chart reading | GPT-4o, Gemini, Claude 3.5 |
| **Text → Image** | Text → Image | Image generation | DALL-E 3, Midjourney, Stable Diffusion 3 |
| **Text → Video** | Text → Video | Video generation | Sora (OpenAI), Runway Gen-3 |
| **Audio + Text** | Audio → Text, Text → Audio | Transcription, TTS, voice chat | GPT-4o audio, Gemini |
| **Any → Any** | Mixed input → Mixed output | Fully multimodal conversations | GPT-4o (omni), Gemini 2.0 |

### Vision Use Cases

| Use Case | Description | Example |
|----------|-------------|---------|
| **Document AI** | Extract info from documents, invoices, receipts | Upload invoice → get structured JSON |
| **Image analysis** | Describe, classify, detect objects | "What's in this image?" → detailed description |
| **Chart/graph reading** | Interpret visualizations | Upload chart → "Sales grew 15% in Q3" |
| **UI understanding** | Analyze screenshots, wireframes | "What are the UX issues in this screenshot?" |
| **Medical imaging** | Analyze X-rays, MRIs (with proper models) | Research and clinical decision support |

### Code Example: Vision with GPT-4o

```python
from openai import OpenAI
import base64

client = OpenAI()

# Encode image
with open("chart.png", "rb") as f:
    image_data = base64.b64encode(f.read()).decode()

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Analyze this chart and summarize the trends."},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{image_data}"},
                },
            ],
        }
    ],
)
print(response.choices[0].message.content)
```

### Learning Resources

1. **OpenAI GPT-4o Documentation** — Vision, audio, and multimodal capabilities
2. **Google Gemini API Docs** — Native multimodal model
3. **Hugging Face Multimodal Course** — Building multimodal applications

---

## 6. Voice & Audio AI

### What Is It?

Voice AI enables **speech-to-text (STT)**, **text-to-speech (TTS)**, and **real-time voice conversations** with LLMs. Recent models support native audio understanding — not just transcription, but tone, emotion, and multi-speaker recognition.

### Key Capabilities

| Capability | Description | Tools |
|------------|-------------|-------|
| **Speech-to-Text** | Transcribe audio/video to text | Whisper (OpenAI), Deepgram, AssemblyAI |
| **Text-to-Speech** | Generate natural-sounding speech | OpenAI TTS, ElevenLabs, Play.ht |
| **Voice Cloning** | Create custom voices from samples | ElevenLabs, Resemble.ai |
| **Real-time Voice Chat** | Live conversation with AI | GPT-4o Realtime API, Gemini Live |
| **Audio Understanding** | Analyze audio: tone, emotion, music | GPT-4o audio, Gemini audio |

### Real-Time Voice Agent Architecture

```
┌──────────┐     ┌──────────────┐     ┌──────────────┐
│ User      │────▶│ STT          │────▶│ LLM          │
│ (speaks)  │     │ (Whisper)    │     │ (Process)    │
└──────────┘     └──────────────┘     └──────┬───────┘
                                              │
┌──────────┐     ┌──────────────┐             │
│ User      │◀───│ TTS          │◀────────────┘
│ (hears)   │     │ (ElevenLabs) │
└──────────┘     └──────────────┘
```

### Tools

| Tool | Type | Highlights |
|------|------|-----------|
| **OpenAI Whisper** | STT | Open-source, 99 languages, highly accurate |
| **OpenAI TTS / Realtime API** | TTS + Voice Chat | Low-latency, natural voices, tool calling during voice |
| **ElevenLabs** | TTS + Voice Clone | Most natural-sounding voices, voice cloning |
| **Deepgram** | STT | Ultra-fast, real-time, enterprise-grade |
| **AssemblyAI** | STT + Analysis | Speaker diarization, sentiment, summarization |

### Learning Resources

1. **OpenAI Whisper / TTS API Documentation** — Official guides
2. **ElevenLabs Documentation** — Voice synthesis and cloning
3. **Deepgram SDK Docs** — Real-time speech recognition

---

## 7. Code Generation & Copilots

### What Is It?

AI-powered code generation tools that assist developers by **writing code, fixing bugs, explaining code, generating tests, and performing code review** — either inline (Copilot-style) or via chat/agent interfaces.

### Tool Landscape

| Tool | Type | Highlights |
|------|------|-----------|
| **GitHub Copilot** | IDE extension | Most widely used; inline completions + chat + agents |
| **Cursor** | AI-native IDE | VS Code fork with deep AI integration; multi-file editing |
| **Windsurf (Codeium)** | AI-native IDE | Flow-based agent; context-aware across codebase |
| **Aider** | CLI agent | Terminal-based; git-aware; works with any LLM |
| **Amazon Q Developer** | IDE extension + CLI | AWS integration; security scanning; code transformation |
| **Tabnine** | IDE extension | Enterprise-focused; runs on-premise; code privacy |
| **OpenAI Codex CLI** | CLI agent | Open-source; terminal-based code agent |

### Capabilities Beyond Completion

| Capability | Description |
|------------|-------------|
| **Multi-file editing** | Agent edits across multiple files in a codebase |
| **Codebase Q&A** | "How does authentication work in this project?" |
| **Test generation** | Generate unit/integration tests from source code |
| **Bug fixing** | Identify and fix bugs from error messages |
| **Code review** | Review PRs and suggest improvements |
| **Documentation** | Generate docstrings, READMEs, API docs |
| **Refactoring** | Modernize code, change patterns, migrate frameworks |

### Learning Resources

1. **GitHub Copilot Documentation** — Official guides for VS Code, JetBrains, CLI
2. **Cursor Documentation** — AI-native IDE features
3. **Aider** (aider.chat) — Open-source coding agent

---

## 8. Evaluation & Observability

### What Is It?

**Evaluation** measures the quality of LLM outputs (accuracy, relevance, toxicity). **Observability** is the ability to monitor, trace, and debug LLM applications in production — like APM (Application Performance Monitoring) but for AI.

### Why It's Critical

- LLM outputs are **non-deterministic** — you need to measure quality
- RAG pipelines have **multiple failure points** (retrieval, generation, grounding)
- Agents can go off-track — observability helps you **debug and improve**
- Required for **A/B testing** different prompts, models, and configurations

### RAG Evaluation Metrics

| Metric | What It Measures | How |
|--------|-----------------|-----|
| **Faithfulness** | Is the answer grounded in retrieved context? | Check if each claim is supported by context |
| **Answer Relevancy** | Does the answer address the question? | Semantic similarity between question and answer |
| **Context Precision** | Are the retrieved chunks relevant? | What % of retrieved chunks are actually useful |
| **Context Recall** | Did we retrieve all relevant information? | Compare retrieved chunks to ground truth |

### Evaluation Frameworks

| Tool | Type | Highlights |
|------|------|-----------|
| **Ragas** | Open-source | Gold standard for RAG evaluation; faithfulness, relevancy, context metrics |
| **DeepEval** | Open-source | 14+ metrics; RAG, agents, fine-tuning evaluation |
| **TruLens** | Open-source | Feedback functions for RAG quality |
| **Promptfoo** | Open-source | Prompt testing & comparison; CI/CD integration |

### Observability / Tracing Platforms

| Platform | Type | Highlights |
|----------|------|-----------|
| **LangSmith** | Managed | By LangChain; traces, evaluations, datasets, playground |
| **Braintrust** | Managed | Evals, logging, prompt playground, A/B testing |
| **Phoenix (Arize)** | Open-source | Traces, evals, embeddings visualization |
| **Langfuse** | Open-source | Tracing, analytics, prompt management |
| **Weights & Biases** | Managed | Experiment tracking, prompt versioning |

### What Tracing Looks Like

```
User Query: "What is our refund policy?"
│
├── [Embedding] 45ms — text-embedding-3-small
│   └── tokens: 8, cost: $0.000001
│
├── [Retrieval] 120ms — Pinecone query
│   └── returned 5 chunks, relevance: [0.92, 0.88, 0.85, 0.71, 0.65]
│
├── [Reranking] 80ms — Cohere Rerank
│   └── reordered to: [chunk3, chunk1, chunk2]
│
├── [Generation] 850ms — gpt-4o
│   └── tokens: 1,247 (prompt: 1,100 + completion: 147)
│   └── cost: $0.0089
│
└── [Evaluation]
    ├── Faithfulness: 0.95 ✅
    ├── Relevancy: 0.91 ✅
    └── Toxicity: 0.01 ✅
```

### Ragas Example

```python
from ragas import evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_precision
from datasets import Dataset

# Your RAG pipeline outputs
eval_data = Dataset.from_dict({
    "question": ["What is our return policy?"],
    "answer": ["You can return items within 30 days for a full refund."],
    "contexts": [["Our return policy allows returns within 30 days of purchase for a full refund. Items must be unused."]],
    "ground_truth": ["Items can be returned within 30 days for a full refund if unused."],
})

results = evaluate(
    dataset=eval_data,
    metrics=[faithfulness, answer_relevancy, context_precision],
)
print(results)
# {'faithfulness': 0.95, 'answer_relevancy': 0.92, 'context_precision': 1.0}
```

### Learning Resources

1. **Ragas Documentation** (docs.ragas.io) — RAG evaluation metrics and guides
2. **LangSmith Documentation** — Production tracing and evaluation
3. **Braintrust Documentation** — Evals, logging, and prompt management

---

## 9. RLHF / DPO / Preference Tuning

### What Is It?

Techniques for **aligning LLMs with human preferences** — making models more helpful, harmless, and honest. This is how raw pretrained models (which just predict next tokens) become useful assistants like ChatGPT or Claude.

### The Alignment Pipeline

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Pretraining   │────▶│ Supervised    │────▶│ Preference    │
│ (next-token   │     │ Fine-Tuning   │     │ Alignment     │
│  prediction)  │     │ (SFT)         │     │ (RLHF/DPO)   │
└──────────────┘     └──────────────┘     └──────────────┘
                                                  │
Raw model that       Learns to follow       Learns what humans
completes text       instructions            actually prefer
```

### RLHF (Reinforcement Learning from Human Feedback)

```
1. Collect human preferences:
   Prompt → [Response A, Response B] → Human picks better one

2. Train reward model:
   Learn to predict human preference scores

3. Optimize with RL (PPO):
   Fine-tune LLM to maximize reward model score
```

**Pros:** Powerful, proven (used by ChatGPT)  
**Cons:** Complex, unstable training, requires reward model

### DPO (Direct Preference Optimization)

```
1. Collect human preferences (same as RLHF)
   Prompt → [Chosen response, Rejected response]

2. Directly optimize LLM:
   No reward model needed — optimize preferences directly
```

**Pros:** Simpler, more stable, no RL needed  
**Cons:** Can overfit on preference data, less flexible

### Comparison

| Aspect | RLHF | DPO | ORPO |
|--------|------|-----|------|
| **Complexity** | High (reward model + RL) | Medium (direct optimization) | Low (single-stage) |
| **Stability** | Can be unstable | More stable | Most stable |
| **Data needed** | Pairwise preferences | Pairwise preferences | Pairwise preferences |
| **Components** | SFT + RM + PPO | SFT + DPO | Single combined stage |
| **Used by** | OpenAI (ChatGPT) | Meta (Llama 3), many others | Research frontier |

### Tools

| Tool | Description |
|------|-------------|
| **Hugging Face TRL** | Library for SFT, RLHF, DPO training |
| **Axolotl** | Easy fine-tuning including DPO/ORPO |
| **OpenRLHF** | Scalable RLHF framework |

### Learning Resources

1. **DeepLearning.AI "RLHF" Short Course** — Practical intro to alignment
2. **Hugging Face TRL Documentation** — SFT, DPO, PPO trainers
3. **"Direct Preference Optimization" Paper** — The DPO methodology

---

## Summary & Next Steps

| Concept | Impact | Difficulty |
|---------|--------|-----------|
| **Advanced RAG** | Very High — immediate production improvement | Medium |
| **GraphRAG** | High — for entity-rich domains | High |
| **MoE** | Understanding — explains modern model efficiency | Low (conceptual) |
| **SLMs** | High — enables local/private AI | Low |
| **Multimodal** | High — unlocks vision/audio use cases | Medium |
| **Voice AI** | Medium — for voice-enabled apps | Medium |
| **Code Gen** | Very High — immediate developer productivity | Low |
| **Evaluation** | Critical — required before production | Medium |
| **RLHF/DPO** | Deep — for model builders/researchers | High |

**Next:** [04-Deployment-and-Production.md](04-Deployment-and-Production.md) — LLMOps, Quantization, AI Gateways
