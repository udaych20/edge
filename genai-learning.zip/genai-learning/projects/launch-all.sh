#!/bin/bash
cd /home/azureuser/genai-projects

projects=(
    "04-guardrails 8504"
    "05-react-agent 8505"
    "06-agent-workflows 8506"
    "07-multi-agent 8507"
    "08-mcp-server 8508"
    "09-a2a-protocol 8509"
    "10-advanced-rag 8510"
    "11-graphrag 8511"
    "12-local-slm 8512"
    "13-multimodal 8513"
    "14-voice-ai 8514"
    "15-evaluation 8515"
    "16-llmops 8516"
    "17-quantization 8517"
    "18-ai-gateway 8518"
)

for entry in "${projects[@]}"; do
    dir=$(echo "$entry" | awk '{print $1}')
    port=$(echo "$entry" | awk '{print $2}')
    cd /home/azureuser/genai-projects/$dir
    nohup /home/azureuser/.local/bin/streamlit run app.py --server.address 0.0.0.0 --server.port $port --server.headless true > streamlit.log 2>&1 &
    echo "Launched $dir on port $port"
done

echo "All apps launched. Waiting 5 seconds..."
sleep 5
echo "--- Port check ---"
ss -tlnp | grep -E '850[4-9]|851[0-8]' | sort
