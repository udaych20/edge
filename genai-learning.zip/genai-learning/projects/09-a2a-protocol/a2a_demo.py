"""
A2A Protocol Demo — Agent-to-Agent Communication
==================================================
Simulates the A2A protocol locally:
  - Agent Cards for capability discovery
  - Task-based delegation between agents
  - Sales Agent ↔ CRM Agent ↔ Email Agent collaboration
"""

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
client = OpenAI()


# ─── A2A Protocol Models ─────────────────────────────────────────────────────

class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class AgentCard:
    """A2A Agent Card — describes an agent's capabilities."""
    name: str
    description: str
    version: str
    capabilities: list[dict]  # {name, description, input_schema, output_schema}
    endpoint: str
    auth_type: str = "bearer"


@dataclass
class A2ATask:
    """A2A Task — unit of work delegated between agents."""
    task_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    capability: str = ""
    input_data: dict = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[dict] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    completed_at: Optional[str] = None
    error: Optional[str] = None


# ─── Agent Definitions ───────────────────────────────────────────────────────

CRM_AGENT_CARD = AgentCard(
    name="CRM Agent",
    description="Manages customer relationships, lead enrichment, and scoring. Can enrich leads with company data, score lead quality, and update CRM records.",
    version="1.0.0",
    endpoint="http://crm-agent.internal:8081",
    capabilities=[
        {
            "name": "enrich_lead",
            "description": "Enrich a sales lead with company information, social profiles, and firmographic data.",
            "input_schema": {"company_name": "str", "contact_email": "str", "contact_name": "str"},
            "output_schema": {"company_size": "str", "industry": "str", "revenue_range": "str", "tech_stack": "list", "linkedin_url": "str"},
        },
        {
            "name": "score_lead",
            "description": "Score a lead 1-100 based on fit, intent, and engagement signals.",
            "input_schema": {"company_data": "dict", "interactions": "list"},
            "output_schema": {"score": "int", "tier": "str", "reasoning": "str", "recommended_action": "str"},
        },
    ],
)

EMAIL_AGENT_CARD = AgentCard(
    name="Email Agent",
    description="Drafts and sends personalized outreach emails based on lead data and context.",
    version="1.0.0",
    endpoint="http://email-agent.internal:8082",
    capabilities=[
        {
            "name": "draft_outreach",
            "description": "Draft a personalized sales outreach email based on lead data.",
            "input_schema": {"lead_data": "dict", "lead_score": "dict", "product": "str"},
            "output_schema": {"subject": "str", "body": "str", "cta": "str"},
        },
    ],
)

ANALYTICS_AGENT_CARD = AgentCard(
    name="Analytics Agent",
    description="Provides pipeline analytics, conversion metrics, and forecasting.",
    version="1.0.0",
    endpoint="http://analytics-agent.internal:8083",
    capabilities=[
        {
            "name": "pipeline_summary",
            "description": "Get current sales pipeline summary with stage breakdown.",
            "input_schema": {},
            "output_schema": {"total_pipeline": "float", "stages": "dict", "conversion_rate": "float"},
        },
    ],
)

ALL_AGENTS = {
    "crm": CRM_AGENT_CARD,
    "email": EMAIL_AGENT_CARD,
    "analytics": ANALYTICS_AGENT_CARD,
}


# ─── Simulated Agent Backends ────────────────────────────────────────────────

def crm_enrich_lead(input_data: dict) -> dict:
    """Simulate CRM lead enrichment using LLM."""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a CRM system's lead enrichment engine. Given basic lead info, "
                    "generate realistic enrichment data. Respond with ONLY a JSON object."
                ),
            },
            {
                "role": "user",
                "content": f"Enrich this lead: {json.dumps(input_data)}\n\n"
                "Return JSON with: company_size, industry, revenue_range, tech_stack (list), "
                "linkedin_url, founded_year, headquarters, recent_news",
            },
        ],
        temperature=0.3,
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content)


def crm_score_lead(input_data: dict) -> dict:
    """Simulate lead scoring using LLM."""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a lead scoring engine. Score the lead 1-100 based on company fit, "
                    "budget signals, and buying intent. Respond with ONLY a JSON object."
                ),
            },
            {
                "role": "user",
                "content": f"Score this lead: {json.dumps(input_data)}\n\n"
                "Return JSON with: score (1-100), tier (Hot/Warm/Cold), reasoning, recommended_action",
            },
        ],
        temperature=0.2,
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content)


def email_draft_outreach(input_data: dict) -> dict:
    """Simulate email drafting using LLM."""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a sales email specialist. Draft a personalized, concise outreach "
                    "email. Be professional but conversational. No spam tactics. "
                    "Respond with ONLY a JSON object."
                ),
            },
            {
                "role": "user",
                "content": f"Draft outreach for: {json.dumps(input_data)}\n\n"
                "Return JSON with: subject, body, cta (call to action)",
            },
        ],
        temperature=0.4,
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content)


def analytics_pipeline_summary(input_data: dict) -> dict:
    """Return simulated pipeline analytics."""
    return {
        "total_pipeline_value": "$2.4M",
        "total_leads": 142,
        "stages": {
            "prospecting": {"count": 45, "value": "$450K"},
            "qualification": {"count": 38, "value": "$620K"},
            "proposal": {"count": 22, "value": "$580K"},
            "negotiation": {"count": 15, "value": "$490K"},
            "closed_won": {"count": 12, "value": "$260K"},
        },
        "conversion_rate": "8.5%",
        "avg_deal_size": "$21.7K",
        "avg_cycle_days": 34,
    }


CAPABILITY_DISPATCH = {
    ("crm", "enrich_lead"): crm_enrich_lead,
    ("crm", "score_lead"): crm_score_lead,
    ("email", "draft_outreach"): email_draft_outreach,
    ("analytics", "pipeline_summary"): analytics_pipeline_summary,
}


# ─── A2A Protocol Simulation ─────────────────────────────────────────────────

def discover_agent(agent_key: str) -> AgentCard:
    """Simulate A2A agent discovery (GET /agent-card)."""
    return ALL_AGENTS[agent_key]


def submit_task(agent_key: str, capability: str, input_data: dict) -> A2ATask:
    """Simulate A2A task submission (POST /tasks)."""
    task = A2ATask(capability=capability, input_data=input_data)
    task.status = TaskStatus.IN_PROGRESS

    # Execute
    dispatch_key = (agent_key, capability)
    if dispatch_key in CAPABILITY_DISPATCH:
        try:
            result = CAPABILITY_DISPATCH[dispatch_key](input_data)
            task.result = result
            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.now().isoformat()
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
    else:
        task.status = TaskStatus.FAILED
        task.error = f"Unknown capability: {agent_key}/{capability}"

    return task


# ─── Sales Agent Orchestrator ─────────────────────────────────────────────────

@dataclass
class SalesWorkflowResult:
    lead_input: dict
    discovery_log: list[dict] = field(default_factory=list)
    tasks: list[A2ATask] = field(default_factory=list)
    final_summary: str = ""
    total_time: float = 0.0


def run_sales_workflow(lead: dict, verbose: bool = True) -> SalesWorkflowResult:
    """Sales Agent orchestrates a multi-agent workflow via A2A protocol."""
    start = time.time()
    result = SalesWorkflowResult(lead_input=lead)

    # Step 1: Discover available agents
    if verbose:
        print("🔍 [Discovery] Sales Agent discovering peer agents...")
    for key, card in ALL_AGENTS.items():
        result.discovery_log.append({
            "agent": card.name,
            "capabilities": [c["name"] for c in card.capabilities],
            "endpoint": card.endpoint,
        })
        if verbose:
            caps = ", ".join(c["name"] for c in card.capabilities)
            print(f"   Found: {card.name} — [{caps}]")

    # Step 2: Enrich lead via CRM Agent
    if verbose:
        print(f"\n📋 [Task 1] Delegating lead enrichment to CRM Agent...")
    enrich_task = submit_task("crm", "enrich_lead", lead)
    result.tasks.append(enrich_task)
    if verbose:
        print(f"   Task {enrich_task.task_id}: {enrich_task.status.value}")

    # Step 3: Score lead via CRM Agent
    if verbose:
        print(f"\n📊 [Task 2] Delegating lead scoring to CRM Agent...")
    score_input = {"lead": lead, "enrichment": enrich_task.result}
    score_task = submit_task("crm", "score_lead", score_input)
    result.tasks.append(score_task)
    if verbose:
        print(f"   Task {score_task.task_id}: {score_task.status.value}")
        if score_task.result:
            print(f"   Score: {score_task.result.get('score', 'N/A')}, Tier: {score_task.result.get('tier', 'N/A')}")

    # Step 4: Draft outreach via Email Agent
    if verbose:
        print(f"\n✉️ [Task 3] Delegating email draft to Email Agent...")
    email_input = {
        "lead_data": {**lead, **( enrich_task.result or {})},
        "lead_score": score_task.result,
        "product": "Enterprise AI Platform",
    }
    email_task = submit_task("email", "draft_outreach", email_input)
    result.tasks.append(email_task)
    if verbose:
        print(f"   Task {email_task.task_id}: {email_task.status.value}")

    # Step 5: Get pipeline summary
    if verbose:
        print(f"\n📈 [Task 4] Getting pipeline summary from Analytics Agent...")
    pipeline_task = submit_task("analytics", "pipeline_summary", {})
    result.tasks.append(pipeline_task)
    if verbose:
        print(f"   Task {pipeline_task.task_id}: {pipeline_task.status.value}")

    result.total_time = time.time() - start

    # Generate summary
    result.final_summary = _generate_summary(result)
    return result


def _generate_summary(result: SalesWorkflowResult) -> str:
    lines = ["# Sales Lead Processing Summary\n"]
    lines.append(f"**Lead:** {result.lead_input.get('contact_name', 'Unknown')} @ {result.lead_input.get('company_name', 'Unknown')}")
    lines.append(f"**Agents Involved:** {len(result.discovery_log)}")
    lines.append(f"**Tasks Completed:** {sum(1 for t in result.tasks if t.status == TaskStatus.COMPLETED)}/{len(result.tasks)}")
    lines.append(f"**Total Time:** {result.total_time:.1f}s\n")

    for task in result.tasks:
        status_icon = "✅" if task.status == TaskStatus.COMPLETED else "❌"
        lines.append(f"{status_icon} **{task.capability}** (Task: {task.task_id})")

    return "\n".join(lines)


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_LEADS = [
    {
        "contact_name": "Priya Patel",
        "contact_email": "priya.patel@techcorp.io",
        "company_name": "TechCorp Solutions",
        "source": "Webinar registration",
        "notes": "Attended our AI in Enterprise webinar, asked about pricing for 500+ seats",
    },
    {
        "contact_name": "James Morrison",
        "contact_email": "j.morrison@globalbank.com",
        "company_name": "GlobalBank International",
        "source": "Inbound demo request",
        "notes": "Evaluating AI platforms for fraud detection, budget approved for Q2",
    },
]


def run_demo():
    print("=" * 70)
    print("  A2A Protocol — Sales & CRM Agent Collaboration Demo")
    print("=" * 70)

    lead = DEMO_LEADS[0]
    print(f"\n📌 New Lead: {lead['contact_name']} @ {lead['company_name']}")
    print(f"   Source: {lead['source']}")
    print(f"   Notes: {lead['notes']}\n")

    result = run_sales_workflow(lead, verbose=True)

    print(f"\n{'=' * 70}")
    print("  RESULTS")
    print(f"{'=' * 70}")

    for task in result.tasks:
        print(f"\n─── {task.capability} (Task {task.task_id}) ───")
        if task.result:
            print(json.dumps(task.result, indent=2, default=str)[:400])

    print(f"\n{'=' * 70}")
    print(f"  Workflow completed in {result.total_time:.1f}s")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python a2a_demo.py demo")
