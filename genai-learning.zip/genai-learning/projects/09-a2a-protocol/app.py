"""
P09 – A2A Protocol: Streamlit UI
==================================
"""
import json
import streamlit as st
from a2a_demo import ALL_AGENTS, DEMO_LEADS, run_sales_workflow, TaskStatus

st.set_page_config(page_title="P09 – A2A Protocol", page_icon="🤝", layout="wide")
st.title("🤝 P09 – A2A Protocol: Agent Collaboration")
st.caption("Sales Agent discovers and delegates to CRM, Email, and Analytics agents")

with st.sidebar:
    st.header("🌐 Agent Registry")
    for key, card in ALL_AGENTS.items():
        with st.expander(f"{card.name} v{card.version}"):
            st.markdown(card.description)
            for cap in card.capabilities:
                st.markdown(f"- **{cap['name']}**: {cap['description']}")

col1, col2 = st.columns([1, 1])
with col1:
    st.subheader("📌 Lead Input")
    lead_idx = st.selectbox("Select demo lead:", range(len(DEMO_LEADS)),
        format_func=lambda i: f"{DEMO_LEADS[i]['contact_name']} @ {DEMO_LEADS[i]['company_name']}")
    lead = DEMO_LEADS[lead_idx]

    contact_name = st.text_input("Contact Name", value=lead["contact_name"])
    company_name = st.text_input("Company", value=lead["company_name"])
    email = st.text_input("Email", value=lead["contact_email"])
    notes = st.text_area("Notes", value=lead["notes"])

with col2:
    st.subheader("📊 Results")
    if st.button("🚀 Process Lead via A2A", type="primary", use_container_width=True):
        lead_data = {
            "contact_name": contact_name,
            "contact_email": email,
            "company_name": company_name,
            "notes": notes,
        }
        with st.spinner("Sales Agent orchestrating..."):
            result = run_sales_workflow(lead_data, verbose=False)

        st.success(f"Completed in {result.total_time:.1f}s — {len(result.tasks)} tasks")

        for task in result.tasks:
            icon = "✅" if task.status == TaskStatus.COMPLETED else "❌"
            with st.expander(f"{icon} {task.capability} (Task {task.task_id})"):
                if task.result:
                    st.json(task.result)
                if task.error:
                    st.error(task.error)
