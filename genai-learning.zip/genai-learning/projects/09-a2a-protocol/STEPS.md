# P09 – A2A Protocol: Agent-to-Agent Communication

## Concept
**Agent-to-Agent (A2A)** protocol enables independent AI agents to discover
each other's capabilities, delegate tasks, and collaborate across organizational
boundaries using a standard protocol.

## Real-World Scenario
**Sales & CRM Agent Collaboration** — A Sales Agent receives a lead and needs
to process it. It discovers a CRM Agent's capabilities via an Agent Card,
delegates lead enrichment and scoring, and receives structured results.

## Architecture
```
Sales Agent                          CRM Agent
    │                                    │
    │  1. GET /agent-card               │
    │──────────────────────────────────▶│
    │  ← Agent Card (capabilities)      │
    │◀──────────────────────────────────│
    │                                    │
    │  2. POST /tasks (enrich lead)     │
    │──────────────────────────────────▶│
    │  ← Task ID + status              │
    │◀──────────────────────────────────│
    │                                    │
    │  3. GET /tasks/{id}               │
    │──────────────────────────────────▶│
    │  ← Enriched lead data            │
    │◀──────────────────────────────────│
```

## Steps

### Step 1: Run the Demo
```bash
cd /home/azureuser/genai-projects/09-a2a-protocol
python3 a2a_demo.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8509
```

## Key Takeaways
- Agent Cards define capabilities, inputs/outputs, and endpoint URLs
- Tasks are the unit of work — create, poll, and receive results
- Agents are loosely coupled — they discover capabilities at runtime
- Protocol enables cross-team and cross-org agent collaboration
