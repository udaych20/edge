"""
P10 – Advanced RAG: Streamlit UI
==================================
Compare 4 RAG approaches side by side on legal contracts.
"""

import streamlit as st
from advanced_rag import (
    CONTRACTS, DEMO_QUERIES, basic_rag, crag, hyde_rag, reranked_rag, setup_vectorstore,
)

st.set_page_config(page_title="P10 – Advanced RAG", page_icon="⚖️", layout="wide")
st.title("⚖️ P10 – Advanced RAG: Legal Contract Analyzer")
st.caption("Compare Basic RAG vs HyDE vs Reranking vs CRAG on legal documents")

@st.cache_resource
def init_vectorstore():
    return setup_vectorstore()

collection = init_vectorstore()

with st.sidebar:
    st.header("📚 Contracts Loaded")
    for c in CONTRACTS:
        st.markdown(f"- **{c['title']}** ({len(c['chunks'])} chunks)")
    st.divider()
    approach = st.multiselect(
        "Select RAG approaches to compare:",
        ["Basic RAG", "HyDE RAG", "Reranked RAG", "CRAG"],
        default=["Basic RAG", "HyDE RAG"],
    )
    top_k = st.slider("Top K results", 2, 6, 3)

st.header("Example Queries")
for i, q in enumerate(DEMO_QUERIES):
    if st.button(q[:60], key=f"dq_{i}"):
        st.session_state["rag_query"] = q

default_q = st.session_state.get("rag_query", "")
query = st.text_input("Enter your legal question:", value=default_q)

APPROACH_MAP = {
    "Basic RAG": basic_rag,
    "HyDE RAG": hyde_rag,
    "Reranked RAG": reranked_rag,
    "CRAG": crag,
}

if st.button("🚀 Run Analysis", type="primary", use_container_width=True):
    if not query.strip():
        st.warning("⚠️ Please enter a legal question or select an example above.")
    elif not approach:
        st.warning("⚠️ Please select at least one RAG approach from the sidebar.")
    else:
        cols = st.columns(len(approach))
        for i, ap_name in enumerate(approach):
            with cols[i]:
                st.subheader(ap_name)
                with st.spinner(f"Running {ap_name}..."):
                    result = APPROACH_MAP[ap_name](query, collection, top_k=top_k)
                st.metric("Time", f"{result.time_seconds:.1f}s")
                st.markdown(result.answer)
                with st.expander("Retrieved Chunks"):
                    for j, chunk in enumerate(result.retrieved_chunks):
                        st.markdown(f"**Chunk {j+1}** ({chunk['metadata']['contract_title']})")
                        st.caption(chunk["text"][:200])
                if result.details:
                    with st.expander("Details"):
                        st.json(result.details)
