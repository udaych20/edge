"""
Advanced RAG — Legal Contract Analyzer
========================================
Demonstrates 4 advanced RAG techniques:
  1. Basic RAG (baseline)
  2. HyDE — Hypothetical Document Embeddings
  3. Reranked RAG — LLM-based cross-encoder reranking
  4. CRAG — Corrective RAG with self-grading retrieval
"""

import json
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import chromadb
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
client = OpenAI()

# ─── Sample Legal Contracts ──────────────────────────────────────────────────

CONTRACTS = [
    {
        "id": "contract-001",
        "title": "SaaS License Agreement — CloudScale ↔ Meridian Financial",
        "chunks": [
            "TERM AND RENEWAL: This Agreement shall commence on January 1, 2026 and continue for an initial period of 36 months ('Initial Term'). Upon expiration of the Initial Term, this Agreement shall automatically renew for successive 12-month periods unless either party provides written notice of non-renewal at least 90 days prior to the end of the then-current term.",
            "FEES AND PAYMENT: Client shall pay Licensor an annual subscription fee of $240,000 USD, payable in quarterly installments of $60,000 due on the first business day of each calendar quarter. Late payments shall accrue interest at 1.5% per month. Licensor reserves the right to suspend access if payment is more than 30 days overdue.",
            "DATA PROTECTION: Licensor shall implement and maintain appropriate technical and organizational measures to protect Client Data in accordance with ISO 27001, SOC 2 Type II, and applicable data protection laws including GDPR and CCPA. Licensor shall notify Client of any data breach within 72 hours of discovery.",
            "LIMITATION OF LIABILITY: In no event shall either party's aggregate liability exceed the total fees paid or payable in the 12-month period preceding the claim. Neither party shall be liable for indirect, incidental, consequential, or punitive damages, including lost profits or lost data, except in cases of gross negligence or willful misconduct.",
            "INTELLECTUAL PROPERTY: All intellectual property rights in the Service, including source code, algorithms, and documentation, shall remain the exclusive property of Licensor. Client retains all rights to Client Data. Licensor grants Client a non-exclusive, non-transferable license to use the Service during the Term.",
            "TERMINATION FOR CAUSE: Either party may terminate this Agreement immediately upon written notice if the other party: (a) materially breaches the Agreement and fails to cure within 30 days of notice, (b) becomes insolvent or files for bankruptcy, or (c) is acquired by a direct competitor of the non-terminating party.",
        ],
    },
    {
        "id": "contract-002",
        "title": "Employment Agreement — TechCorp ↔ Senior Engineer",
        "chunks": [
            "COMPENSATION: Base salary of $185,000 USD per annum, paid bi-weekly. Employee is eligible for an annual performance bonus of up to 20% of base salary, subject to individual and company performance targets. Equity grant of 10,000 stock options vesting over 4 years with a 1-year cliff.",
            "NON-COMPETE: For a period of 12 months following termination, Employee shall not directly or indirectly engage in, or be employed by, any business that competes with the Company's core AI/ML platform products within the United States. This restriction shall not apply if Employee is terminated without cause.",
            "CONFIDENTIALITY: Employee shall not disclose any Confidential Information during or after employment. Confidential Information includes trade secrets, customer lists, pricing strategies, unreleased product plans, and proprietary algorithms. This obligation survives termination indefinitely for trade secrets and for 5 years for other confidential information.",
            "INVENTION ASSIGNMENT: All inventions, discoveries, and works of authorship created by Employee during employment, or using Company resources, shall be the sole property of the Company. Employee agrees to execute all documents necessary to perfect the Company's ownership rights, including patent applications.",
            "TERMINATION: Company may terminate employment at-will with 2 weeks' written notice or pay in lieu. Upon termination without cause, Employee shall receive: (a) 3 months' base salary as severance, (b) continuation of health benefits for 6 months, and (c) acceleration of vesting for options scheduled to vest within the next 6 months.",
        ],
    },
    {
        "id": "contract-003",
        "title": "Master Services Agreement — DataFlow ↔ HealthCare Inc.",
        "chunks": [
            "SCOPE OF SERVICES: DataFlow shall provide data analytics platform implementation, including: (a) data pipeline design and deployment, (b) machine learning model development for patient readmission prediction, (c) dashboard creation for clinical outcomes monitoring, and (d) staff training for 50 designated users.",
            "HIPAA COMPLIANCE: DataFlow acknowledges that it will have access to Protected Health Information (PHI) and agrees to comply with all requirements of HIPAA, HITECH Act, and applicable state health privacy laws. DataFlow shall execute a Business Associate Agreement (BAA) prior to accessing any PHI. All PHI shall be encrypted at rest (AES-256) and in transit (TLS 1.3).",
            "SERVICE LEVELS: DataFlow guarantees 99.9% uptime for the production analytics platform, measured monthly. For each 0.1% below the SLA, Client shall receive a credit of 5% of monthly fees, up to a maximum of 30% of monthly fees. Scheduled maintenance windows (max 4 hours/month) are excluded from uptime calculations.",
            "INDEMNIFICATION: DataFlow shall indemnify and hold harmless Client against all claims, damages, and expenses arising from: (a) DataFlow's breach of HIPAA obligations, (b) infringement of third-party intellectual property rights by the Service, or (c) DataFlow's gross negligence or willful misconduct. Client shall indemnify DataFlow against claims arising from Client's misuse of the Service.",
            "DISPUTE RESOLUTION: Any dispute arising from this Agreement shall first be submitted to good-faith mediation. If mediation fails within 60 days, disputes shall be resolved by binding arbitration under the rules of the American Arbitration Association in New York, NY. Each party bears its own attorney fees unless the arbitrator determines otherwise.",
        ],
    },
]


# ─── Vector Store Setup ──────────────────────────────────────────────────────

def get_embedding(text: str) -> list[float]:
    """Get OpenAI embedding for text."""
    response = client.embeddings.create(model="text-embedding-3-small", input=text)
    return response.data[0].embedding


def setup_vectorstore():
    """Build ChromaDB collection from contract chunks."""
    chroma_client = chromadb.Client()

    # Delete if exists
    try:
        chroma_client.delete_collection("legal_contracts")
    except Exception:
        pass

    collection = chroma_client.create_collection(
        name="legal_contracts",
        metadata={"hnsw:space": "cosine"},
    )

    all_docs = []
    all_ids = []
    all_metadata = []

    for contract in CONTRACTS:
        for i, chunk in enumerate(contract["chunks"]):
            doc_id = f"{contract['id']}-chunk-{i}"
            all_docs.append(chunk)
            all_ids.append(doc_id)
            all_metadata.append({
                "contract_id": contract["id"],
                "contract_title": contract["title"],
                "chunk_index": i,
            })

    # Get embeddings
    embeddings = []
    for doc in all_docs:
        embeddings.append(get_embedding(doc))

    collection.add(
        documents=all_docs,
        embeddings=embeddings,
        ids=all_ids,
        metadatas=all_metadata,
    )

    return collection


# ─── RAG Approaches ──────────────────────────────────────────────────────────

@dataclass
class RAGResult:
    approach: str
    query: str
    retrieved_chunks: list[dict] = field(default_factory=list)
    answer: str = ""
    time_seconds: float = 0.0
    details: dict = field(default_factory=dict)


def basic_rag(query: str, collection, top_k: int = 3) -> RAGResult:
    """Standard RAG: embed query → retrieve → generate."""
    start = time.time()

    query_emb = get_embedding(query)
    results = collection.query(query_embeddings=[query_emb], n_results=top_k)

    chunks = []
    for i in range(len(results["documents"][0])):
        chunks.append({
            "text": results["documents"][0][i],
            "metadata": results["metadatas"][0][i],
            "distance": results["distances"][0][i],
        })

    context = "\n\n---\n\n".join(c["text"] for c in chunks)
    answer = _generate_answer(query, context)

    return RAGResult(
        approach="Basic RAG",
        query=query,
        retrieved_chunks=chunks,
        answer=answer,
        time_seconds=time.time() - start,
    )


def hyde_rag(query: str, collection, top_k: int = 3) -> RAGResult:
    """HyDE RAG: generate hypothetical answer → embed that → retrieve."""
    start = time.time()

    # Generate hypothetical document
    hyp_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": "You are a legal expert. Write a detailed passage that would answer the following question about contracts. Write as if quoting from an actual contract clause.",
            },
            {"role": "user", "content": query},
        ],
        temperature=0.3,
        max_tokens=300,
    )
    hypothetical_doc = hyp_response.choices[0].message.content

    # Embed hypothetical doc and retrieve
    hyde_emb = get_embedding(hypothetical_doc)
    results = collection.query(query_embeddings=[hyde_emb], n_results=top_k)

    chunks = []
    for i in range(len(results["documents"][0])):
        chunks.append({
            "text": results["documents"][0][i],
            "metadata": results["metadatas"][0][i],
            "distance": results["distances"][0][i],
        })

    context = "\n\n---\n\n".join(c["text"] for c in chunks)
    answer = _generate_answer(query, context)

    return RAGResult(
        approach="HyDE RAG",
        query=query,
        retrieved_chunks=chunks,
        answer=answer,
        time_seconds=time.time() - start,
        details={"hypothetical_document": hypothetical_doc},
    )


def reranked_rag(query: str, collection, top_k: int = 3, initial_k: int = 8) -> RAGResult:
    """Reranked RAG: retrieve more → LLM rerank → use top results."""
    start = time.time()

    # Retrieve more candidates
    query_emb = get_embedding(query)
    results = collection.query(query_embeddings=[query_emb], n_results=initial_k)

    candidates = []
    for i in range(len(results["documents"][0])):
        candidates.append({
            "text": results["documents"][0][i],
            "metadata": results["metadatas"][0][i],
            "distance": results["distances"][0][i],
        })

    # LLM-based reranking
    rerank_prompt = f"Query: {query}\n\nRank these document chunks by relevance to the query. Return a JSON array of indices (0-based) in order from most to least relevant.\n\n"
    for i, c in enumerate(candidates):
        rerank_prompt += f"[{i}] {c['text'][:200]}\n\n"

    rerank_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a relevance ranking system. Return ONLY a JSON array of indices."},
            {"role": "user", "content": rerank_prompt},
        ],
        temperature=0.0,
        response_format={"type": "json_object"},
    )

    try:
        ranking_data = json.loads(rerank_response.choices[0].message.content)
        # Handle various possible JSON structures
        if isinstance(ranking_data, dict):
            ranked_indices = ranking_data.get("indices", ranking_data.get("ranking", list(range(len(candidates)))))
        else:
            ranked_indices = ranking_data
        reranked = [candidates[i] for i in ranked_indices[:top_k] if i < len(candidates)]
    except Exception:
        reranked = candidates[:top_k]

    context = "\n\n---\n\n".join(c["text"] for c in reranked)
    answer = _generate_answer(query, context)

    return RAGResult(
        approach="Reranked RAG",
        query=query,
        retrieved_chunks=reranked,
        answer=answer,
        time_seconds=time.time() - start,
        details={"initial_candidates": len(candidates), "reranked_to": len(reranked)},
    )


def crag(query: str, collection, top_k: int = 3) -> RAGResult:
    """Corrective RAG: retrieve → grade quality → regenerate if needed."""
    start = time.time()

    query_emb = get_embedding(query)
    results = collection.query(query_embeddings=[query_emb], n_results=top_k)

    chunks = []
    for i in range(len(results["documents"][0])):
        chunks.append({
            "text": results["documents"][0][i],
            "metadata": results["metadatas"][0][i],
            "distance": results["distances"][0][i],
        })

    context = "\n\n---\n\n".join(c["text"] for c in chunks)

    # Self-grade retrieval quality
    grade_response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": "You are a retrieval quality grader. Given a query and retrieved documents, rate the retrieval quality as 'good', 'fair', or 'poor'. Respond with ONLY a JSON object with 'grade' and 'reasoning'.",
            },
            {"role": "user", "content": f"Query: {query}\n\nRetrieved:\n{context[:1500]}"},
        ],
        temperature=0.0,
        response_format={"type": "json_object"},
    )
    grade_data = json.loads(grade_response.choices[0].message.content)
    grade = grade_data.get("grade", "good")

    correction_applied = False
    if grade == "poor":
        # Knowledge refinement: ask LLM to generate the answer from its knowledge
        correction_applied = True
        context += "\n\n---\n\n[LLM KNOWLEDGE SUPPLEMENT]: Based on general legal knowledge, "
        supplement = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "Provide relevant legal contract information to supplement retrieval."},
                {"role": "user", "content": query},
            ],
            temperature=0.2,
            max_tokens=300,
        )
        context += supplement.choices[0].message.content

    answer = _generate_answer(query, context)

    return RAGResult(
        approach="CRAG (Corrective RAG)",
        query=query,
        retrieved_chunks=chunks,
        answer=answer,
        time_seconds=time.time() - start,
        details={
            "retrieval_grade": grade,
            "grade_reasoning": grade_data.get("reasoning", ""),
            "correction_applied": correction_applied,
        },
    )


def _generate_answer(query: str, context: str) -> str:
    """Generate answer from context."""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a legal analyst. Answer the question based on the contract excerpts provided. "
                    "Cite specific clauses. If the information is not in the excerpts, say so clearly. "
                    "Be precise and reference specific terms, amounts, and conditions."
                ),
            },
            {
                "role": "user",
                "content": f"Contract excerpts:\n{context}\n\nQuestion: {query}",
            },
        ],
        temperature=0.1,
        max_tokens=500,
    )
    return response.choices[0].message.content


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_QUERIES = [
    "What are the payment terms and late payment penalties across all contracts?",
    "Compare the termination clauses — how can each contract be ended?",
    "What data protection and compliance requirements are specified?",
    "What are the liability limits and indemnification terms?",
]

def run_demo():
    print("=" * 70)
    print("  Advanced RAG — Legal Contract Analyzer Demo")
    print("=" * 70)

    print("\n📚 Loading contracts and building vector store...")
    collection = setup_vectorstore()
    print(f"   Indexed {collection.count()} chunks from {len(CONTRACTS)} contracts")

    query = DEMO_QUERIES[0]
    print(f"\n📋 Query: {query}\n")

    approaches = [
        ("Basic RAG", basic_rag),
        ("HyDE RAG", hyde_rag),
        ("Reranked RAG", reranked_rag),
        ("CRAG", crag),
    ]

    for name, func in approaches:
        print(f"\n{'─' * 70}")
        print(f"  {name}")
        print(f"{'─' * 70}")
        result = func(query, collection)
        print(f"  Time: {result.time_seconds:.1f}s")
        print(f"  Chunks retrieved: {len(result.retrieved_chunks)}")
        if result.details:
            for k, v in result.details.items():
                print(f"  {k}: {v}" if not isinstance(v, str) else f"  {k}: {v[:100]}")
        print(f"\n  Answer: {result.answer[:200]}...")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python advanced_rag.py demo")
