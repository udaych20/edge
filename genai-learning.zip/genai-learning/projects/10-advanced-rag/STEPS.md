# P10 – Advanced RAG: Legal Contract Analyzer

## Concept
Advanced RAG techniques beyond basic retrieve-and-generate:
- **HyDE** (Hypothetical Document Embeddings) — Generate a hypothetical answer first, embed that for retrieval
- **Reranking** — Cross-encoder reranking of retrieved chunks
- **CRAG** (Corrective RAG) — Self-grading retrieval quality, web fallback
- **Contextual Compression** — Compress retrieved chunks to only relevant parts

## Real-World Scenario
**Legal Contract Analysis** — Law firm needs to query across hundreds of contracts:
analyze clauses, compare terms, identify risks, and answer questions with
precise citations.

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/10-advanced-rag
python3 advanced_rag.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8510
```

### Step 3: Compare RAG Approaches
The UI lets you toggle between:
- Basic RAG (standard retrieval)
- HyDE RAG (hypothetical document embeddings)
- Reranked RAG (cross-encoder reranking)
- CRAG (self-correcting retrieval)

## Key Takeaways
- HyDE improves retrieval for questions with different vocabulary than source docs
- Reranking dramatically improves precision by cross-encoding query+chunk pairs
- CRAG adds self-assessment: if retrieval quality is low, it tries to correct
- Combining these techniques yields production-grade RAG quality
