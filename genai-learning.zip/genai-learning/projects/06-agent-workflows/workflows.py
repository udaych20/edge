"""
Agent Workflows — DevOps Incident Response System
===================================================
Demonstrates four agentic patterns:
  1. Router   — Classify severity & route to workflow
  2. Planner  — Generate investigation runbook
  3. Executor — Execute runbook steps (simulated)
  4. Reflector — Review & rate the response quality
"""

import json
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel, Field

load_dotenv()
client = OpenAI()


# ─── Data Models ──────────────────────────────────────────────────────────────

class Severity(str, Enum):
    P0 = "P0 - Critical (Revenue Impact)"
    P1 = "P1 - High (User-Facing Degradation)"
    P2 = "P2 - Medium (Internal / Partial Impact)"
    P3 = "P3 - Low (Cosmetic / Non-Urgent)"


class IncidentCategory(str, Enum):
    DATABASE = "Database"
    NETWORKING = "Networking"
    APPLICATION = "Application"
    INFRASTRUCTURE = "Infrastructure"
    SECURITY = "Security"
    CERTIFICATE = "Certificate/TLS"
    MEMORY = "Memory/Resource"
    DEPLOYMENT = "Deployment"


class RouterOutput(BaseModel):
    severity: Severity
    category: IncidentCategory
    summary: str = Field(description="One-line incident summary")
    affected_services: list[str] = Field(description="List of affected services/components")
    requires_immediate_action: bool


class RunbookStep(BaseModel):
    step_number: int
    action: str = Field(description="What to do")
    command: Optional[str] = Field(default=None, description="CLI command to run, if applicable")
    expected_outcome: str
    rollback: Optional[str] = Field(default=None, description="Rollback action if step fails")


class Runbook(BaseModel):
    title: str
    steps: list[RunbookStep]
    estimated_resolution_time: str
    escalation_path: str


class ReflectionResult(BaseModel):
    quality_score: int = Field(ge=1, le=10, description="1-10 score for response quality")
    strengths: list[str]
    improvements: list[str]
    missing_steps: list[str] = Field(default_factory=list)
    overall_assessment: str


@dataclass
class WorkflowResult:
    incident_text: str
    router_output: Optional[RouterOutput] = None
    runbook: Optional[Runbook] = None
    execution_log: list[dict] = field(default_factory=list)
    reflection: Optional[ReflectionResult] = None
    total_time: float = 0.0


# ─── Pattern 1: Router ───────────────────────────────────────────────────────

def route_incident(incident_text: str) -> RouterOutput:
    """Classify the incident severity, category, and affected services."""
    completion = client.beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a senior SRE incident commander. Classify the incoming "
                    "incident by severity, category, and affected services. Be precise "
                    "about severity — P0 means revenue or data loss, P1 means user-facing "
                    "degradation, P2 means partial/internal impact, P3 means cosmetic."
                ),
            },
            {"role": "user", "content": f"Classify this incident:\n\n{incident_text}"},
        ],
        response_format=RouterOutput,
        temperature=0.0,
    )
    return completion.choices[0].message.parsed


# ─── Pattern 2: Planner ──────────────────────────────────────────────────────

def plan_response(incident_text: str, router_output: RouterOutput) -> Runbook:
    """Generate an investigation and remediation runbook."""
    context = f"""Incident: {router_output.summary}
Severity: {router_output.severity.value}
Category: {router_output.category.value}
Affected Services: {', '.join(router_output.affected_services)}
Immediate Action Required: {router_output.requires_immediate_action}

Full incident report:
{incident_text}"""

    completion = client.beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a DevOps automation expert. Generate a detailed runbook "
                    "for investigating and resolving this incident. Include specific "
                    "CLI commands where applicable (kubectl, docker, psql, curl, etc.). "
                    "Each step should have a rollback action. Be practical and specific."
                ),
            },
            {"role": "user", "content": context},
        ],
        response_format=Runbook,
        temperature=0.1,
    )
    return completion.choices[0].message.parsed


# ─── Pattern 3: Executor (Simulated) ─────────────────────────────────────────

SIMULATED_OUTPUTS = {
    "kubectl": "NAME                          READY   STATUS    RESTARTS   AGE\nuser-service-7d8f6c4b5-x2j9k   1/1     Running   3 (5m ago)   4h",
    "docker": "CONTAINER ID   IMAGE          STATUS       PORTS\na1b2c3d4e5f6   user-svc:v2.1  Up 4 hours   :8080->8080/tcp",
    "psql": "active_connections | max_connections | connection_usage_pct\n        148           |       150       |       98.7%",
    "curl": "HTTP/1.1 200 OK\nContent-Type: application/json\n{\"status\": \"healthy\", \"latency_ms\": 45}",
    "openssl": "Certificate:\n    Validity\n        Not After : Apr 5 2026 00:00:00 GMT\n    *** EXPIRED ***",
    "top": "PID   USER    RES     %MEM    %CPU    COMMAND\n12345 app     4.2G    52.5    2.1     java -jar user-service.jar",
    "default": "Command executed successfully.",
}


def execute_step(step: RunbookStep) -> dict:
    """Simulate executing a runbook step."""
    output = SIMULATED_OUTPUTS.get("default")
    if step.command:
        for key in SIMULATED_OUTPUTS:
            if key in step.command.lower():
                output = SIMULATED_OUTPUTS[key]
                break

    return {
        "step_number": step.step_number,
        "action": step.action,
        "command": step.command,
        "output": output,
        "status": "completed",
    }


# ─── Pattern 4: Reflection ───────────────────────────────────────────────────

def reflect_on_response(
    incident_text: str,
    router_output: RouterOutput,
    runbook: Runbook,
    execution_log: list[dict],
) -> ReflectionResult:
    """Review the quality of the incident response."""
    context = f"""Original Incident: {incident_text}

Classification:
- Severity: {router_output.severity.value}
- Category: {router_output.category.value}

Runbook: {runbook.title}
Steps executed: {len(execution_log)}
Estimated resolution: {runbook.estimated_resolution_time}

Execution results:
{json.dumps(execution_log, indent=2, default=str)[:2000]}"""

    completion = client.beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a senior SRE reviewing an incident response. Rate the "
                    "quality of the classification, runbook, and execution. Be critical "
                    "but fair. Identify strengths, areas for improvement, and any "
                    "missing investigation steps. Score 1-10."
                ),
            },
            {"role": "user", "content": context},
        ],
        response_format=ReflectionResult,
        temperature=0.2,
    )
    return completion.choices[0].message.parsed


# ─── Full Pipeline ────────────────────────────────────────────────────────────

def run_incident_workflow(incident_text: str, verbose: bool = True) -> WorkflowResult:
    """Run the complete incident response workflow."""
    start = time.time()
    result = WorkflowResult(incident_text=incident_text)

    # Step 1: Route
    if verbose:
        print("🔀 [Router] Classifying incident...")
    result.router_output = route_incident(incident_text)
    if verbose:
        print(f"   Severity: {result.router_output.severity.value}")
        print(f"   Category: {result.router_output.category.value}")
        print(f"   Summary: {result.router_output.summary}")

    # Step 2: Plan
    if verbose:
        print("\n📋 [Planner] Generating runbook...")
    result.runbook = plan_response(incident_text, result.router_output)
    if verbose:
        print(f"   Runbook: {result.runbook.title}")
        print(f"   Steps: {len(result.runbook.steps)}")
        print(f"   ETA: {result.runbook.estimated_resolution_time}")

    # Step 3: Execute
    if verbose:
        print("\n⚡ [Executor] Running runbook steps...")
    for step in result.runbook.steps:
        log = execute_step(step)
        result.execution_log.append(log)
        if verbose:
            cmd = step.command or "(manual)"
            print(f"   Step {step.step_number}: {step.action[:50]}... [{cmd[:40]}]")

    # Step 4: Reflect
    if verbose:
        print("\n🪞 [Reflector] Reviewing response quality...")
    result.reflection = reflect_on_response(
        incident_text, result.router_output, result.runbook, result.execution_log
    )
    if verbose:
        print(f"   Quality Score: {result.reflection.quality_score}/10")
        print(f"   Assessment: {result.reflection.overall_assessment[:100]}...")

    result.total_time = time.time() - start
    return result


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_INCIDENTS = [
    "ALERT: Database connection pool exhausted on orders-db-primary. "
    "Active connections: 148/150. Queries timing out after 30s. "
    "500 errors on /api/orders endpoint. Customer checkout failing. "
    "Started 15 minutes ago after v2.3.1 deployment.",

    "ALERT: SSL certificate expired on payment-gateway.prod.example.com. "
    "All HTTPS requests returning ERR_CERT_DATE_INVALID. "
    "Stripe webhook deliveries failing. Payment processing down for EU customers.",

    "ALERT: Memory leak detected in user-service pods. "
    "Memory usage growing 100MB/hour, OOM kills every 4 hours. "
    "Pod restarts: 6 in last 24h. Heap dump shows HashMap growing unbounded "
    "in SessionCache. Started after v3.1.0 deployment 2 days ago.",
]


def run_demo():
    print("=" * 70)
    print("  Agent Workflows — DevOps Incident Response Demo")
    print("=" * 70)

    incident = DEMO_INCIDENTS[0]
    print(f"\n📟 Incident Alert:\n{incident}\n")

    result = run_incident_workflow(incident, verbose=True)

    print(f"\n{'=' * 70}")
    print(f"  WORKFLOW COMPLETE — {result.total_time:.1f}s total")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python workflows.py demo")
