# P06 – Agent Workflows: DevOps Incident Response

## Concept
Agentic workflow patterns: **Router**, **Planner**, **Reflection**, and **Pipeline**.
Instead of a single agent loop, these patterns compose specialized steps into a
deterministic workflow with LLM-powered decision nodes.

## Real-World Scenario
**DevOps Incident Response System** — When a production alert fires:
1. **Router** classifies severity (P0-P3) and routes to appropriate workflow
2. **Planner** generates an investigation runbook
3. **Executor** runs each runbook step
4. **Reflection** reviews the fix quality and suggests improvements

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/06-agent-workflows
python3 workflows.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8506
```

### Step 3: Try Incident Scenarios
1. "Database connection pool exhausted, 500 errors on /api/orders"
2. "SSL certificate expired on payment-gateway.prod.example.com"
3. "Memory leak in user-service pod, OOM kills every 4 hours"

## Key Takeaways
- Router pattern: LLM classifies input → deterministic dispatch
- Planner pattern: LLM generates structured action plan
- Reflection pattern: LLM evaluates its own output quality
- These patterns are more predictable than free-form agent loops
