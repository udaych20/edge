"""
P06 – Agent Workflows: Streamlit UI
=====================================
DevOps incident response with Router → Planner → Executor → Reflector pipeline.
"""

import streamlit as st
from workflows import DEMO_INCIDENTS, run_incident_workflow

st.set_page_config(page_title="P06 – Agent Workflows", page_icon="🔀", layout="wide")

st.title("🔀 P06 – Agent Workflows: Incident Response")
st.caption("Router → Planner → Executor → Reflector pipeline for DevOps incidents")

with st.sidebar:
    st.header("Sample Incidents")
    labels = ["DB Connection Pool", "SSL Certificate Expired", "Memory Leak"]
    for i, (label, inc) in enumerate(zip(labels, DEMO_INCIDENTS)):
        if st.button(f"🔔 {label}", key=f"inc_{i}", use_container_width=True):
            st.session_state["incident_input"] = inc

default_inc = st.session_state.get("incident_input", "")
incident = st.text_area("📟 Paste incident alert:", value=default_inc, height=120)

if st.button("🚀 Run Incident Workflow", type="primary", use_container_width=True):
    if not incident.strip():
        st.warning("⚠️ Please paste an incident alert or select a sample from the sidebar.")
    else:
        with st.status("Processing incident...", expanded=True) as status:
            result = run_incident_workflow(incident, verbose=False)
            status.update(label=f"Workflow complete in {result.total_time:.1f}s", state="complete")

        # ── Router Output ──
        st.markdown("### 🔀 Step 1: Router — Incident Classification")
        r = result.router_output
        c1, c2, c3 = st.columns(3)
        c1.metric("Severity", r.severity.value.split(" - ")[0])
        c2.metric("Category", r.category.value)
        c3.metric("Immediate?", "Yes" if r.requires_immediate_action else "No")
        st.info(f"**Summary:** {r.summary}")
        st.markdown(f"**Affected Services:** {', '.join(r.affected_services)}")

        # ── Runbook ──
        st.markdown("### 📋 Step 2: Planner — Investigation Runbook")
        rb = result.runbook
        st.markdown(f"**{rb.title}** | ETA: {rb.estimated_resolution_time} | Escalation: {rb.escalation_path}")
        for step in rb.steps:
            with st.expander(f"Step {step.step_number}: {step.action[:60]}"):
                if step.command:
                    st.code(step.command, language="bash")
                st.markdown(f"**Expected:** {step.expected_outcome}")
                if step.rollback:
                    st.markdown(f"**Rollback:** {step.rollback}")

        # ── Execution Log ──
        st.markdown("### ⚡ Step 3: Executor — Runbook Execution")
        for log in result.execution_log:
            with st.expander(f"Step {log['step_number']}: {log['action'][:50]}..."):
                if log["command"]:
                    st.code(log["command"], language="bash")
                st.code(log["output"], language="text")

        # ── Reflection ──
        st.markdown("### 🪞 Step 4: Reflector — Quality Review")
        ref = result.reflection
        st.metric("Quality Score", f"{ref.quality_score}/10")
        st.markdown(f"**Assessment:** {ref.overall_assessment}")

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**✅ Strengths:**")
            for s in ref.strengths:
                st.markdown(f"- {s}")
        with col2:
            st.markdown("**🔧 Improvements:**")
            for imp in ref.improvements:
                st.markdown(f"- {imp}")
        if ref.missing_steps:
            st.warning("**Missing Steps:** " + "; ".join(ref.missing_steps))
