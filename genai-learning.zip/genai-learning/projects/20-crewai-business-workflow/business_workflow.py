"""
P20 - CrewAI Business Workflow
==============================
Role-based business execution workflow using CrewAI.
"""

from __future__ import annotations

import os
import time

from crewai import Agent, Crew, Process, Task
from dotenv import load_dotenv

load_dotenv()

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


BUSINESS_SCENARIOS = [
    "Launch a same-day shipping upsell campaign for premium customers in the US. We need the target segment, operating plan, customer message, risks, and success metrics.",
    "Design a customer retention playbook for users who have not logged in for 21 days. Include interventions, operations changes, and the email sequence.",
    "Prepare a rollout plan for an AI invoice assistant for SMB finance teams. Cover positioning, launch plan, support readiness, and compliance risks.",
]


def build_agents() -> dict[str, Agent]:
    llm = DEFAULT_MODEL
    return {
        "strategist": Agent(
            role="Growth Strategist",
            goal="Turn a business request into a focused market strategy with clear outcomes.",
            backstory=(
                "You lead growth initiatives for a SaaS company and specialize in "
                "turning fuzzy requests into clear go-to-market plans."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "operations": Agent(
            role="Revenue Operations Manager",
            goal="Translate strategy into an executable operating plan with owners and dependencies.",
            backstory=(
                "You coordinate lifecycle, CRM, enablement, and analytics teams to "
                "ship business programs on time."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "copywriter": Agent(
            role="Lifecycle Marketing Lead",
            goal="Write concise customer-facing messaging aligned to the strategy and offer.",
            backstory=(
                "You write lifecycle campaigns that balance clarity, persuasion, and trust."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
        "risk": Agent(
            role="Risk and Compliance Reviewer",
            goal="Review the plan for operational, legal, and customer-trust risks before launch.",
            backstory=(
                "You review product launches and campaigns for policy, privacy, and "
                "execution risk."
            ),
            verbose=False,
            allow_delegation=False,
            llm=llm,
        ),
    }


def build_tasks(request: str, agents: dict[str, Agent]) -> list[Task]:
    strategy_task = Task(
        description=(
            f"Business request:\n{request}\n\n"
            "Produce a structured strategy brief with:\n"
            "1. Goal and target audience\n"
            "2. Key value proposition\n"
            "3. Success metrics\n"
            "4. Constraints and assumptions\n"
            "Keep it practical and specific."
        ),
        expected_output="A strategy brief with audience, value proposition, metrics, and assumptions.",
        agent=agents["strategist"],
    )

    operations_task = Task(
        description=(
            "Using the strategy brief, create a launch execution plan with:\n"
            "1. Workstreams and owners\n"
            "2. Dependencies and risks\n"
            "3. A one-week launch timeline\n"
            "4. Required dashboards or reporting"
        ),
        expected_output="An execution plan with owners, dependencies, and a short launch timeline.",
        agent=agents["operations"],
        context=[strategy_task],
    )

    messaging_task = Task(
        description=(
            "Using the strategy brief and operations plan, write customer-facing messaging:\n"
            "1. Launch announcement headline\n"
            "2. One email draft\n"
            "3. In-app message copy\n"
            "Tone should be clear, credible, and business-ready."
        ),
        expected_output="Customer messaging assets including headline, email, and in-app copy.",
        agent=agents["copywriter"],
        context=[strategy_task, operations_task],
    )

    risk_task = Task(
        description=(
            "Review the complete plan and produce a final launch review with:\n"
            "1. Approval decision\n"
            "2. Key risks and mitigations\n"
            "3. Missing items before launch\n"
            "4. Final recommendation"
        ),
        expected_output="A launch review with approval status, top risks, and mitigations.",
        agent=agents["risk"],
        context=[strategy_task, operations_task, messaging_task],
    )

    return [strategy_task, operations_task, messaging_task, risk_task]


def run_business_crew(request: str) -> dict[str, object]:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "Missing OPENAI_API_KEY. Add it to your environment or a .env file before running this project."
        )
    agents = build_agents()
    tasks = build_tasks(request, agents)
    crew = Crew(
        agents=list(agents.values()),
        tasks=tasks,
        process=Process.sequential,
        verbose=False,
    )

    start = time.time()
    final_output = crew.kickoff()
    total_time = time.time() - start

    task_outputs = []
    for task in tasks:
        raw_output = getattr(task.output, "raw", None) if getattr(task, "output", None) else None
        task_outputs.append(
            {
                "agent": task.agent.role,
                "description": task.description,
                "output": raw_output or "No output captured.",
            }
        )

    return {
        "request": request,
        "final_output": str(final_output),
        "task_outputs": task_outputs,
        "total_time": total_time,
        "model": DEFAULT_MODEL,
    }


def run_demo() -> None:
    print("=" * 72)
    print("P20 - CrewAI Business Workflow Demo")
    print("=" * 72)
    print()
    request = BUSINESS_SCENARIOS[0]
    print("Request:")
    print(request)
    print()
    result = run_business_crew(request)
    print("Final Output:")
    print(result["final_output"])
    print()
    print(f"Completed in {result['total_time']:.1f}s using {result['model']}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python business_workflow.py demo")
