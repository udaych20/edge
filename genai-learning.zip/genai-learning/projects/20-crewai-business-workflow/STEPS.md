# P20 - CrewAI Business Workflow

## Concept
This project shows a true **CrewAI** implementation for a role-based business workflow:
- **Specialized agents** with distinct goals and backstories
- **Sequential task handoffs** from strategy to execution to review
- **Shared context** between tasks
- **Business-ready outputs** instead of toy prompts

## Real-World Scenario
**Revenue Operations Launch Crew** - A business team needs to turn a new initiative
into a launch-ready plan. A strategist defines the approach, operations converts it
into execution steps, marketing writes the customer messaging, and a risk reviewer
checks the plan before launch.

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/20-crewai-business-workflow
python3 business_workflow.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8520
```

### Step 3: Try Different Business Requests
Use the sample scenarios or paste your own:
- Upsell campaign launch
- Customer retention program
- New AI feature rollout

The crew will produce a strategy brief, operating plan, customer messaging,
and a final risk review.

## Key Takeaways
- CrewAI is a natural fit when the problem is best modeled as a **team**
  of role-based collaborators
- The task and context abstraction makes inter-agent handoffs easy to follow
- This pattern is especially useful for launch planning, research teams,
  and internal business workflows
