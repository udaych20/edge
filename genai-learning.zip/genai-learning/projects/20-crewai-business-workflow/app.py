"""
P20 - CrewAI Business Workflow: Streamlit UI
"""

import streamlit as st

from business_workflow import BUSINESS_SCENARIOS, run_business_crew

st.set_page_config(page_title="P20 - CrewAI Business Workflow", page_icon="TEAM", layout="wide")
st.title("P20 - CrewAI Business Workflow")
st.caption("Role-based business execution with CrewAI agents and sequential task handoffs")

with st.sidebar:
    st.header("Sample Requests")
    for i, scenario in enumerate(BUSINESS_SCENARIOS):
        if st.button(scenario[:55] + "...", key=f"scenario_{i}", use_container_width=True):
            st.session_state["business_request"] = scenario

default_request = st.session_state.get("business_request", "")
request = st.text_area("Business request", value=default_request, height=140)

if st.button("Run CrewAI Workflow", type="primary", use_container_width=True):
    if not request.strip():
        st.warning("Please enter a business request or choose a sample from the sidebar.")
    else:
        try:
            with st.status("Crew is working...", expanded=True) as status:
                result = run_business_crew(request)
                status.update(label=f"Done in {result['total_time']:.1f}s", state="complete")
        except Exception as exc:
            st.error(str(exc))
            st.info("Set OPENAI_API_KEY in your shell or add it to a .env file in this project folder, then rerun.")
            st.stop()

        st.subheader("Final Output")
        st.markdown(result["final_output"])

        st.subheader("Per-Agent Deliverables")
        for item in result["task_outputs"]:
            with st.expander(item["agent"], expanded=True):
                st.caption(item["description"])
                st.markdown(item["output"])

        st.info(f"Model: {result['model']}")
