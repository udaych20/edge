# P03: Structured Output — Step-by-Step Guide

## Concept Covered
- **Concept 9:** Structured Output

## Real-World Scenarios (4 Domains)

| Domain | Scenario | What It Extracts |
|--------|----------|-----------------|
| **Finance** | Invoice/receipt processing | Vendor, line items, totals, tax, payment terms |
| **Healthcare** | Medical prescription parsing | Patient, medications, dosage, frequency, doctor |
| **Software Engineering** | Bug report classification | Severity, component, reproduction steps, environment |
| **HR / Recruiting** | Resume/CV parsing | Contact info, skills, experience, education, certifications |

## Tech Stack
- **OpenAI Structured Outputs** — Native JSON Schema enforcement (guaranteed schema compliance)
- **Pydantic v2** — Python data models with validation
- **Instructor** — Provider-agnostic structured extraction with auto-retry on validation failures

## Architecture
```
Unstructured Text → Pydantic Schema Definition → OpenAI Structured Output API
    → Guaranteed JSON conforming to schema → Type-safe Python object
    → Downstream processing (DB insert, API call, report)
```

## Files
| File | Purpose |
|------|---------|
| `schemas.py` | Pydantic v2 models for all 4 domains (Invoice, Prescription, BugReport, Resume) |
| `extractors.py` | Core extraction engine: OpenAI native + Instructor approaches; batch processing |
| `sample_data.py` | Realistic sample texts for all 4 domains |
| `app.py` | Streamlit UI with domain selector, text input, and structured result display |
| `.env` | OpenAI API key |

## Steps to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run All Domain Demos (CLI)
```bash
python3 extractors.py demo
# Runs extraction on all 4 domains, shows structured output
```

### 3. Run Single Domain
```bash
python3 extractors.py extract invoice
python3 extractors.py extract prescription
python3 extractors.py extract bugreport
python3 extractors.py extract resume
```

### 4. Run Streamlit UI
```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8503
# Open http://<server-ip>:8503
```

## Key Learning Points
1. **Pydantic v2 Models** — Type-safe schemas with enums, optional fields, nested objects, validators
2. **OpenAI Structured Outputs** — `response_format` with Pydantic model guarantees schema compliance
3. **Instructor Library** — Provider-agnostic alternative with auto-retry on validation failures
4. **Enum Constraints** — Force classification into predefined categories (severity, department)
5. **Nested Objects** — Complex schemas: Invoice → list[LineItem], Resume → list[Experience]
6. **Field Descriptions** — Guide the LLM on what each field means for better extraction
7. **Batch Processing** — Process multiple documents efficiently

## What to Experiment With
- Add custom Pydantic validators (e.g., `total = sum(line_items)` check)
- Try with messy, real-world text (handwritten notes, informal emails)
- Compare `gpt-4o-mini` vs `gpt-4o` extraction accuracy
- Add a new domain schema (e.g., real estate listing, legal contract)
