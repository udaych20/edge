"""
P03 – Structured Output Extraction: Streamlit UI
==================================================
Four real-world domains | Two extraction approaches | JSON + Table view
"""

import json
import streamlit as st
from extractors import DOMAINS, extract_instructor, extract_native
from schemas import Invoice, Prescription, BugReport, Resume
from sample_data import INVOICE_TEXT, PRESCRIPTION_TEXT, BUG_REPORT_TEXT, RESUME_TEXT

st.set_page_config(
    page_title="P03 – Structured Output Extraction",
    page_icon="🏗️",
    layout="wide",
)

st.title("🏗️ P03 – Structured Output Extraction")
st.caption("Extract structured data from messy real-world documents using LLM + Pydantic schemas")

# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("Configuration")

    domain = st.selectbox(
        "Domain",
        options=list(DOMAINS.keys()),
        format_func=lambda x: {
            "invoice": "💰 Invoice (Finance)",
            "prescription": "💊 Prescription (Healthcare)",
            "bug_report": "🐛 Bug Report (Software)",
            "resume": "📄 Resume (HR)",
        }[x],
    )

    approach = st.radio(
        "Extraction Approach",
        options=["native", "instructor"],
        format_func=lambda x: {
            "native": "OpenAI Native (beta.parse)",
            "instructor": "Instructor Library",
        }[x],
    )

    model = st.selectbox(
        "Model",
        options=["gpt-4o-mini", "gpt-4o"],
        index=0,
    )

    use_custom_text = st.toggle("Use custom text input", value=False)

    st.divider()
    st.markdown(
        "**Approach Comparison**\n\n"
        "- **Native**: OpenAI's built-in structured output. Zero-shot schema compliance.\n"
        "- **Instructor**: Adds retry logic, validation feedback, and provider flexibility."
    )

# ─── Pretty Renderers ────────────────────────────────────────────────────────

def _render_pretty(domain: str, result):
    if domain == "invoice":
        r: Invoice = result
        st.markdown(f"**Invoice:** `{r.invoice_number}`")
        st.markdown(f"**Vendor:** {r.vendor_name}")
        st.markdown(f"**Customer:** {r.customer_name}")
        st.markdown(f"**Date:** {r.invoice_date} | **Due:** {r.due_date}")
        st.markdown(f"**Payment Terms:** {r.payment_terms.value if r.payment_terms else 'N/A'}")
        st.divider()
        for i, item in enumerate(r.line_items, 1):
            st.markdown(f"{i}. **{item.description}** — Qty: {item.quantity} × ${item.unit_price} = **${item.amount}**")
        st.divider()
        st.markdown(f"### Total: ${r.total_amount} {r.currency.value if r.currency else ''}")

    elif domain == "prescription":
        r: Prescription = result
        st.markdown(f"**Patient:** {r.patient_name} (DOB: {r.patient_dob})")
        st.markdown(f"**Doctor:** {r.prescriber_name} | License: {r.prescriber_license}")
        st.markdown(f"**Date:** {r.prescription_date}")
        st.markdown(f"**Diagnosis:** {r.diagnosis}")
        if r.allergies_noted:
            st.warning(f"⚠️ Allergies: {', '.join(r.allergies_noted)}")
        st.divider()
        for med in r.medications:
            st.markdown(
                f"**💊 {med.drug_name}** {med.dosage}\n\n"
                f"- Route: {med.route.value if med.route else 'N/A'}\n"
                f"- Frequency: {med.frequency.value if med.frequency else 'N/A'}\n"
                f"- Duration: {med.duration or 'N/A'}\n"
                f"- Instructions: {med.special_instructions or 'None'}"
            )

    elif domain == "bug_report":
        r: BugReport = result
        severity_color = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}.get(
            r.severity.value if r.severity else "", "⚪"
        )
        st.markdown(f"### {severity_color} {r.title}")
        st.markdown(f"**Severity:** {r.severity.value if r.severity else 'N/A'} | "
                     f"**Priority:** {r.priority.value if r.priority else 'N/A'} | "
                     f"**Category:** {r.category.value if r.category else 'N/A'}")
        st.markdown(f"**Reporter:** {r.affected_users or 'N/A'} | **Version:** {r.environment.app_version or 'N/A'}")
        st.divider()
        st.markdown("**Steps to Reproduce:**")
        for step in r.reproduction_steps:
            st.markdown(f"  {step.step_number}. {step.action}")
            if step.expected_result:
                st.markdown(f"     *Expected:* {step.expected_result}")
            if step.actual_result:
                st.markdown(f"     *Actual:* {step.actual_result}")
        if r.error_message:
            st.code(r.error_message, language="text")
        if r.workaround:
            st.info(f"**Workaround:** {r.workaround}")

    elif domain == "resume":
        r: Resume = result
        st.markdown(f"### {r.full_name}")
        st.markdown(f"{r.email} | {r.phone or ''} | {r.location or ''}")
        if r.summary:
            st.markdown(f"*{r.summary}*")
        st.divider()
        st.markdown("**Skills:**")
        for s in r.skills:
            level = s.level.value if s.level else "unknown"
            st.markdown(f"- {s.name} ({s.years or '?'}y) — *{level}*")
        st.divider()
        st.markdown("**Experience:**")
        for exp in r.work_experience:
            st.markdown(f"**{exp.title}** @ {exp.company} ({exp.start_date} – {exp.end_date or 'Present'})")
            for resp in (exp.responsibilities or []):
                st.markdown(f"  - {resp}")


def _render_table(domain: str, result):
    import pandas as pd

    if domain == "invoice":
        r: Invoice = result
        data = [
            {
                "Description": li.description,
                "Quantity": li.quantity,
                "Unit Price": li.unit_price,
                "Total": li.amount,
            }
            for li in r.line_items
        ]
        st.dataframe(pd.DataFrame(data), use_container_width=True)

    elif domain == "prescription":
        r: Prescription = result
        data = [
            {
                "Medication": m.drug_name,
                "Dosage": m.dosage,
                "Route": m.route.value if m.route else "",
                "Frequency": m.frequency.value if m.frequency else "",
                "Duration": m.duration or "",
            }
            for m in r.medications
        ]
        st.dataframe(pd.DataFrame(data), use_container_width=True)

    elif domain == "bug_report":
        r: BugReport = result
        data = [
            {"#": s.step_number, "Step": s.action}
            for s in r.reproduction_steps
        ]
        st.dataframe(pd.DataFrame(data), use_container_width=True)

    elif domain == "resume":
        r: Resume = result
        data = [
            {"Skill": s.name, "Years": s.years, "Level": s.level.value if s.level else ""}
            for s in r.skills
        ]
        st.dataframe(pd.DataFrame(data), use_container_width=True)


# ─── Main Area ────────────────────────────────────────────────────────────────
config = DOMAINS[domain]

col_input, col_output = st.columns([1, 1])

with col_input:
    st.subheader("📥 Input Document")

    if use_custom_text:
        input_text = st.text_area(
            "Paste your document text:",
            height=400,
            placeholder=f"Paste a {domain.replace('_', ' ')} document here...",
        )
    else:
        input_text = config["sample_text"]
        st.text_area(
            "Sample document (read-only):",
            value=input_text,
            height=400,
            disabled=True,
        )

    # Show the Pydantic schema
    with st.expander("📋 View Pydantic Schema"):
        schema_json = config["model_class"].model_json_schema()
        st.json(schema_json)

with col_output:
    st.subheader("📤 Extracted Output")

    if st.button("🚀 Extract Structured Data", type="primary", use_container_width=True):
        if not input_text or not input_text.strip():
            st.warning("Please provide input text.")
        else:
            with st.spinner(f"Extracting via {approach}..."):
                try:
                    extract_fn = extract_native if approach == "native" else extract_instructor
                    result = extract_fn(
                        text=input_text,
                        model_class=config["model_class"],
                        system_prompt=config["system_prompt"],
                        model=model,
                    )
                    st.session_state["last_result"] = result
                    st.session_state["last_domain"] = domain
                    st.success(f"Extraction complete via {approach}!")
                except Exception as e:
                    st.error(f"Extraction failed: {e}")

    # Display results
    if "last_result" in st.session_state and st.session_state.get("last_domain") == domain:
        result = st.session_state["last_result"]

        tab_pretty, tab_json, tab_table = st.tabs(["Pretty View", "Raw JSON", "Key Fields"])

        with tab_pretty:
            _render_pretty(domain, result)

        with tab_json:
            result_dict = result.model_dump(mode="json")
            st.json(result_dict)

            st.download_button(
                "💾 Download JSON",
                data=json.dumps(result_dict, indent=2, default=str),
                file_name=f"{domain}_extracted.json",
                mime="application/json",
            )

        with tab_table:
            _render_table(domain, result)
