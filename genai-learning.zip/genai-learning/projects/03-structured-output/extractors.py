"""
Structured Output Extraction Engine
====================================
Demonstrates two approaches:
  1. OpenAI native Structured Outputs (beta.chat.completions.parse)
  2. Instructor library (provider-agnostic, retry logic, validation)

Real-world domains: Invoice, Prescription, Bug Report, Resume
"""

import json
import os
import time
from typing import Type, TypeVar

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel

from schemas import (
    BugReport,
    Invoice,
    Prescription,
    Resume,
)
from sample_data import (
    BUG_REPORT_TEXT,
    INVOICE_TEXT,
    PRESCRIPTION_TEXT,
    RESUME_TEXT,
)

load_dotenv()

T = TypeVar("T", bound=BaseModel)

client = OpenAI()

# ─── Domain config ───────────────────────────────────────────────────────────

DOMAINS = {
    "invoice": {
        "model_class": Invoice,
        "sample_text": INVOICE_TEXT,
        "system_prompt": (
            "You are a financial document parser. Extract all invoice details "
            "precisely from the provided text. For line items, capture each "
            "service/product separately with exact amounts. Use ISO date format "
            "(YYYY-MM-DD). Currency amounts should be numbers without symbols."
        ),
    },
    "prescription": {
        "model_class": Prescription,
        "sample_text": PRESCRIPTION_TEXT,
        "system_prompt": (
            "You are a medical document parser. Extract prescription details "
            "with extreme accuracy — medication names, dosages, and frequencies "
            "must be exact. Map to the provided enum values where applicable. "
            "Patient safety depends on precision."
        ),
    },
    "bug_report": {
        "model_class": BugReport,
        "sample_text": BUG_REPORT_TEXT,
        "system_prompt": (
            "You are a software engineering assistant that triages bug reports. "
            "Extract structured information from the bug report text. Identify "
            "severity, category, reproduction steps, error messages, and any "
            "workarounds mentioned. Be thorough with technical details."
        ),
    },
    "resume": {
        "model_class": Resume,
        "sample_text": RESUME_TEXT,
        "system_prompt": (
            "You are an HR tech parser. Extract structured resume data from the "
            "provided text. Capture all skills with proficiency levels, work "
            "experiences with quantified achievements, and education details. "
            "Dates should use ISO format where possible."
        ),
    },
}


# ─── Approach 1: OpenAI Native Structured Outputs ────────────────────────────


def extract_native(
    text: str,
    model_class: Type[T],
    system_prompt: str,
    model: str = "gpt-4o-mini",
) -> T:
    """
    Use OpenAI's native Structured Outputs via beta.chat.completions.parse().
    The API guarantees the response matches the Pydantic schema exactly.
    """
    completion = client.beta.chat.completions.parse(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Extract structured data from:\n\n{text}"},
        ],
        response_format=model_class,
        temperature=0.0,
    )
    parsed = completion.choices[0].message.parsed
    if parsed is None:
        refusal = completion.choices[0].message.refusal
        raise ValueError(f"Model refused to parse: {refusal}")
    return parsed


# ─── Approach 2: Instructor Library ──────────────────────────────────────────


def extract_instructor(
    text: str,
    model_class: Type[T],
    system_prompt: str,
    model: str = "gpt-4o-mini",
    max_retries: int = 2,
) -> T:
    """
    Use Instructor library for structured extraction.
    Adds automatic retry with validation feedback on failure.
    """
    import instructor

    instructor_client = instructor.from_openai(OpenAI())
    return instructor_client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Extract structured data from:\n\n{text}"},
        ],
        response_model=model_class,
        temperature=0.0,
        max_retries=max_retries,
    )


# ─── Batch Processing ────────────────────────────────────────────────────────


def extract_all_domains(approach: str = "native") -> dict:
    """Run extraction across all 4 domains, return results dict."""
    extract_fn = extract_native if approach == "native" else extract_instructor
    results = {}

    for domain_name, config in DOMAINS.items():
        print(f"\n{'='*60}")
        print(f"  Extracting: {domain_name.upper()} ({approach})")
        print(f"{'='*60}")

        start = time.time()
        try:
            result = extract_fn(
                text=config["sample_text"],
                model_class=config["model_class"],
                system_prompt=config["system_prompt"],
            )
            elapsed = time.time() - start

            results[domain_name] = {
                "status": "success",
                "data": result,
                "time_seconds": round(elapsed, 2),
            }

            # Print key fields as quick verification
            print(f"  ✓ Extracted in {elapsed:.2f}s")
            _print_summary(domain_name, result)

        except Exception as e:
            elapsed = time.time() - start
            results[domain_name] = {
                "status": "error",
                "error": str(e),
                "time_seconds": round(elapsed, 2),
            }
            print(f"  ✗ Failed in {elapsed:.2f}s: {e}")

    return results


def _print_summary(domain: str, result: BaseModel) -> None:
    """Print a brief summary of extracted data for verification."""
    if domain == "invoice":
        r: Invoice = result
        print(f"    Invoice#: {r.invoice_number}")
        print(f"    Vendor: {r.vendor_name}")
        print(f"    Total: {r.total_amount} {r.currency.value if r.currency else 'N/A'}")
        print(f"    Line items: {len(r.line_items)}")
    elif domain == "prescription":
        r: Prescription = result
        print(f"    Patient: {r.patient_name}")
        print(f"    Doctor: {r.prescriber_name}")
        print(f"    Medications: {len(r.medications)}")
        for med in r.medications:
            print(f"      - {med.drug_name} {med.dosage}")
    elif domain == "bug_report":
        r: BugReport = result
        print(f"    Title: {r.title[:60]}...")
        print(f"    Severity: {r.severity.value if r.severity else 'N/A'}")
        print(f"    Priority: {r.priority.value if r.priority else 'N/A'}")
        print(f"    Steps to reproduce: {len(r.reproduction_steps)}")
    elif domain == "resume":
        r: Resume = result
        print(f"    Name: {r.full_name}")
        print(f"    Skills: {len(r.skills)}")
        print(f"    Experience entries: {len(r.work_experience)}")
        print(f"    Education entries: {len(r.education)}")


# ─── CLI Demo ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        # Quick demo: run a single domain
        domain = sys.argv[2] if len(sys.argv) > 2 else "invoice"
        approach = sys.argv[3] if len(sys.argv) > 3 else "native"

        if domain not in DOMAINS:
            print(f"Unknown domain: {domain}. Choose from: {list(DOMAINS.keys())}")
            sys.exit(1)

        config = DOMAINS[domain]
        print(f"Extracting {domain} via {approach}...")
        extract_fn = extract_native if approach == "native" else extract_instructor
        result = extract_fn(
            text=config["sample_text"],
            model_class=config["model_class"],
            system_prompt=config["system_prompt"],
        )
        print(json.dumps(result.model_dump(mode="json"), indent=2, default=str))

    elif len(sys.argv) > 1 and sys.argv[1] == "all":
        approach = sys.argv[2] if len(sys.argv) > 2 else "native"
        results = extract_all_domains(approach=approach)
        print(f"\n{'='*60}")
        print("  SUMMARY")
        print(f"{'='*60}")
        for domain, res in results.items():
            status = "✓" if res["status"] == "success" else "✗"
            print(f"  {status} {domain}: {res['status']} ({res['time_seconds']}s)")

    else:
        print("Usage:")
        print("  python extractors.py demo [domain] [approach]")
        print("  python extractors.py all [approach]")
        print()
        print("  domain:   invoice | prescription | bug_report | resume")
        print("  approach: native | instructor")
