"""
Realistic sample data for structured extraction demos.
These simulate messy, real-world documents — not clean templates.
"""

INVOICE_TEXT = """
INVOICE

CloudScale Solutions Pvt. Ltd.
42 Tech Park Road, Whitefield
Bangalore, Karnataka 560066, India
GST: 29AABCC1234F1ZP

Bill To:
Meridian Financial Services
Attn: Accounts Payable
100 Wall Street, Suite 2400
New York, NY 10005, USA

Invoice Number: CS-INV-2026-0847
Invoice Date: March 15, 2026
Due Date: April 14, 2026
Payment Terms: Net 30

Description of Services:

1. Cloud Infrastructure Migration (AWS to Azure)
   Phase 1: Assessment & Planning
   Quantity: 120 hours @ $150/hour
   Total: $18,000.00

2. Kubernetes Cluster Setup & Configuration
   3 production clusters, 2 staging
   Quantity: 80 hours @ $175/hour
   Total: $14,000.00

3. CI/CD Pipeline Implementation (GitHub Actions)
   Quantity: 40 hours @ $150/hour
   Total: $6,000.00

4. 24/7 Monitoring Setup (Datadog + PagerDuty)
   Quantity: 1 setup (fixed price)
   Total: $4,500.00

5. Staff Training & Knowledge Transfer
   Quantity: 3 sessions @ $2,000/session
   Total: $6,000.00

                         Subtotal: $48,500.00
                    Tax (0% - Export): $0.00
                    TOTAL DUE (USD): $48,500.00

Payment Instructions:
Wire transfer to HDFC Bank, Account: 50200012345678
SWIFT: HDFCINBB
Reference: CS-INV-2026-0847

Notes: This invoice covers Phase 1 of the 3-phase migration project.
Remaining phases will be billed upon milestone completion per SOW dated Jan 10, 2026.
"""


PRESCRIPTION_TEXT = """
Dr. Priya Sharma, MD, FACP
Internal Medicine & Pulmonology
Apollo Hospitals, Jubilee Hills
Hyderabad, Telangana 500033
License No: TS-MCI-28456 | NPI: 1234567890

Date: April 3, 2026

Patient: Rajesh Kumar Mehta
DOB: 15-Aug-1978 (Age: 47)
MRN: APL-HYD-2024-88432
Allergies: Penicillin, Sulfa drugs

Diagnosis: Community-Acquired Pneumonia (CAP), Moderate Severity
Secondary: Type 2 Diabetes Mellitus (controlled)

Rx:

1. Tab. Azithromycin 500mg
   Take 1 tablet orally, once daily for 5 days
   Quantity: 5 tablets
   Take on empty stomach, 1 hour before meals

2. Tab. Montelukast 10mg
   Take 1 tablet orally at bedtime
   Duration: 14 days
   Quantity: 14 tablets

3. Syp. Ambroxol 30mg/5ml
   Take 10ml (2 teaspoons) three times daily after meals
   Duration: 7 days
   Quantity: 1 bottle (100ml)

4. Inh. Salbutamol 100mcg MDI
   2 puffs via inhalation, every 6 hours as needed for wheezing
   Quantity: 1 inhaler (200 puffs)
   Refills: 2

5. Tab. Paracetamol 650mg
   Take 1 tablet orally every 6 hours as needed for fever above 100.4°F
   Max 4 tablets per day
   Quantity: 20 tablets

Continue existing medications:
- Metformin 500mg twice daily (ongoing for diabetes)

Follow-up: Return in 7 days for chest X-ray review.
If symptoms worsen (increased breathlessness, high fever >103°F, or blood in sputum),
visit ER immediately.

                                        Dr. Priya Sharma
                                        (Digital Signature)
"""


BUG_REPORT_TEXT = """
Subject: URGENT - Payment processing completely broken in EU region since last deployment

Hey team,

We've got a critical issue that started right after yesterday's deployment (v4.12.0-rc3) to production.
Multiple customers in the EU region are reporting that payment processing is failing silently. 
No error messages shown to users, the checkout page just spins forever and then times out after 2 minutes.

We're getting hammered on Zendesk — over 200 tickets in the last 6 hours. Rough estimate is this affects
ALL users trying to pay with European credit cards (Visa/Mastercard) through our Stripe integration.
US and APAC seem fine.

To reproduce:
1. Log into the app using any EU-based account (or set billing country to Germany/France/UK)
2. Add any item to cart and go to checkout
3. Enter a valid EU credit card number
4. Click "Pay Now"
5. Expected: Payment processes and order confirmation shows
   Actually: Spinner shows indefinitely, console shows 504 Gateway Timeout after ~120 seconds

From the server logs I can see this error:
```
2026-04-06 14:23:18 ERROR [PaymentService] Stripe API call failed: 
  stripe.error.APIConnectionError: Unable to connect to eu-west-1.stripe.com
  Timeout after 30000ms. Region: eu-west-1, Gateway: payment-gw-eu-02
  Traceback: ...PaymentService.process_payment() -> StripeClient.charge() -> HTTPClient.request()
```

It looks like the EU payment gateway endpoint was changed in the last deployment but the new
endpoint URL has a typo — `eu-wesst-1` instead of `eu-west-1` in the config. 

Workaround: We can temporarily route EU traffic through the US gateway by setting 
STRIPE_EU_GATEWAY=us-east-1 in the environment config, but this will increase latency
by ~800ms for EU users.

The config change was in PR #4521 merged by @david.chen yesterday. 
Related ticket: PAY-1847, PAY-1852

This is a P0 — we're losing revenue every minute. Can someone hotfix the config ASAP?

-- Sarah (SRE Team Lead)
Platform: Production (AWS EKS, Kubernetes 1.29)
Browser: Affects all browsers, server-side issue
App version: v4.12.0-rc3
"""


RESUME_TEXT = """
ANANYA KRISHNAN
Senior Full-Stack Engineer & Cloud Architect

📧 ananya.krishnan@protonmail.com | 📱 +91-9876543210
📍 Bangalore, India | 🔗 linkedin.com/in/ananyakrishnan

PROFESSIONAL SUMMARY
Versatile full-stack engineer with 9+ years building scalable distributed systems and leading engineering
teams. Expertise in cloud-native architecture (AWS/Azure), AI/ML integration, and DevOps practices.
Led migration of monolithic banking platform to microservices serving 12M+ users. Passionate about
GenAI applications and building developer productivity tools.

SKILLS
• Python (9 years, Expert) • TypeScript/Node.js (7 years, Advanced) • Go (3 years, Intermediate)
• React/Next.js (6 years, Advanced) • PostgreSQL (8 years, Expert) • MongoDB (5 years, Advanced)
• AWS (7 years, Expert) • Azure (4 years, Advanced) • Kubernetes/Docker (6 years, Expert)
• Terraform (4 years, Advanced) • LangChain/LlamaIndex (2 years, Intermediate)
• System Design (Expert) • Team Leadership (Advanced)

EXPERIENCE

Senior Software Engineer | Flipkart (Walmart) | Bangalore, India
Aug 2022 – Present
• Architected real-time recommendation engine using LangChain + Redis, reducing product discovery 
  time by 35% for 50M+ monthly active users
• Led team of 8 engineers building the seller analytics platform processing 2TB+ daily event data
• Migrated payment service from monolith to event-driven microservices (Kafka + K8s), achieving 
  99.99% uptime
• Built internal AI code review tool using GPT-4 that reduced PR review time by 40%
• Technologies: Python, Go, TypeScript, React, PostgreSQL, Redis, Kafka, Kubernetes, AWS, Terraform

Software Engineer II | Infosys (Client: HSBC) | Hyderabad, India
Jun 2019 – Jul 2022
• Developed core banking middleware serving 12M+ customers across 6 countries
• Built real-time fraud detection system using scikit-learn + Kafka Streams, catching 94% of fraudulent
  transactions with <500ms latency
• Implemented CI/CD pipeline reducing deployment time from 4 hours to 15 minutes
• Mentored 5 junior developers and conducted technical interviews
• Technologies: Java, Spring Boot, Python, Angular, Oracle DB, AWS, Docker, Jenkins

Software Engineer | TCS Digital | Chennai, India
Jul 2017 – May 2019
• Built customer-facing REST APIs for telecom billing platform handling 5M+ daily transactions
• Designed NoSQL data model in MongoDB reducing query latency by 60%
• Developed automated testing framework achieving 85% code coverage
• Technologies: Node.js, Express, MongoDB, React, Docker, Azure

EDUCATION

B.Tech in Computer Science & Engineering
Indian Institute of Technology (IIT) Madras | 2013 – 2017
CGPA: 8.9/10 | Dean's List (2015, 2016)

CERTIFICATIONS
• AWS Solutions Architect – Professional (2024)
• Certified Kubernetes Administrator (CKA) (2023)  
• Google Cloud Professional Machine Learning Engineer (2025)
• HashiCorp Terraform Associate (2023)

LANGUAGES
English (Fluent), Hindi (Native), Tamil (Native), Telugu (Conversational)
"""
