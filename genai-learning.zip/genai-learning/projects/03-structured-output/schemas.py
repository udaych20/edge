"""
Pydantic v2 Schemas for structured extraction across 4 real-world domains.
Each model demonstrates different Pydantic features:
  - Enums for classification constraints
  - Nested objects (list of line items, experiences)
  - Optional fields with defaults
  - Field descriptions to guide LLM extraction
  - Custom validators
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


# ============================================================================
# Domain 1: FINANCE — Invoice / Receipt Processing
# ============================================================================

class LineItem(BaseModel):
    """A single line item on an invoice."""
    description: str = Field(description="Product or service description")
    quantity: float = Field(description="Number of units")
    unit_price: float = Field(description="Price per unit in the invoice currency")
    amount: float = Field(description="Total for this line item (quantity × unit_price)")


class PaymentTerms(str, Enum):
    NET_15 = "Net 15"
    NET_30 = "Net 30"
    NET_45 = "Net 45"
    NET_60 = "Net 60"
    DUE_ON_RECEIPT = "Due on Receipt"
    PREPAID = "Prepaid"
    OTHER = "Other"


class Currency(str, Enum):
    USD = "USD"
    EUR = "EUR"
    GBP = "GBP"
    INR = "INR"
    JPY = "JPY"
    OTHER = "Other"


class Invoice(BaseModel):
    """Structured representation of an invoice or receipt."""
    invoice_number: str = Field(description="Unique invoice identifier (e.g., INV-2024-001)")
    vendor_name: str = Field(description="Name of the company issuing the invoice")
    vendor_address: Optional[str] = Field(default=None, description="Vendor's full address")
    customer_name: str = Field(description="Name of the customer being billed")
    invoice_date: str = Field(description="Date the invoice was issued (YYYY-MM-DD)")
    due_date: Optional[str] = Field(default=None, description="Payment due date (YYYY-MM-DD)")
    currency: Currency = Field(description="Currency of the invoice")
    line_items: list[LineItem] = Field(description="List of products/services billed")
    subtotal: float = Field(description="Sum of all line items before tax")
    tax_rate: Optional[float] = Field(default=None, description="Tax rate as percentage (e.g., 18.0 for 18%)")
    tax_amount: Optional[float] = Field(default=None, description="Total tax amount")
    total_amount: float = Field(description="Final amount due including tax")
    payment_terms: PaymentTerms = Field(description="Payment terms")
    notes: Optional[str] = Field(default=None, description="Any additional notes or special instructions")


# ============================================================================
# Domain 2: HEALTHCARE — Medical Prescription Parsing
# ============================================================================

class DosageFrequency(str, Enum):
    ONCE_DAILY = "Once daily"
    TWICE_DAILY = "Twice daily"
    THREE_TIMES_DAILY = "Three times daily"
    FOUR_TIMES_DAILY = "Four times daily"
    EVERY_4_HOURS = "Every 4 hours"
    EVERY_6_HOURS = "Every 6 hours"
    EVERY_8_HOURS = "Every 8 hours"
    EVERY_12_HOURS = "Every 12 hours"
    AS_NEEDED = "As needed (PRN)"
    WEEKLY = "Weekly"
    BEFORE_MEALS = "Before meals"
    AFTER_MEALS = "After meals"
    AT_BEDTIME = "At bedtime"
    OTHER = "Other"


class RouteOfAdministration(str, Enum):
    ORAL = "Oral"
    TOPICAL = "Topical"
    INTRAVENOUS = "Intravenous (IV)"
    INTRAMUSCULAR = "Intramuscular (IM)"
    SUBCUTANEOUS = "Subcutaneous"
    INHALATION = "Inhalation"
    SUBLINGUAL = "Sublingual"
    RECTAL = "Rectal"
    OPHTHALMIC = "Ophthalmic (Eye)"
    OTIC = "Otic (Ear)"
    OTHER = "Other"


class Medication(BaseModel):
    """A single prescribed medication."""
    drug_name: str = Field(description="Generic or brand name of the medication")
    dosage: str = Field(description="Dosage strength (e.g., '500mg', '10mg/5ml')")
    route: RouteOfAdministration = Field(description="How the medication is administered")
    frequency: DosageFrequency = Field(description="How often the medication should be taken")
    duration: Optional[str] = Field(default=None, description="Duration of treatment (e.g., '7 days', '2 weeks')")
    quantity: Optional[str] = Field(default=None, description="Total quantity prescribed (e.g., '30 tablets')")
    refills: Optional[int] = Field(default=0, description="Number of refills authorized")
    special_instructions: Optional[str] = Field(default=None, description="Special instructions (e.g., 'Take with food')")


class Prescription(BaseModel):
    """Structured representation of a medical prescription."""
    patient_name: str = Field(description="Full name of the patient")
    patient_dob: Optional[str] = Field(default=None, description="Patient date of birth (YYYY-MM-DD)")
    patient_id: Optional[str] = Field(default=None, description="Patient ID or medical record number")
    prescriber_name: str = Field(description="Full name of the prescribing doctor")
    prescriber_license: Optional[str] = Field(default=None, description="Doctor's license/NPI number")
    prescriber_specialty: Optional[str] = Field(default=None, description="Doctor's medical specialty")
    prescription_date: str = Field(description="Date the prescription was written (YYYY-MM-DD)")
    diagnosis: Optional[str] = Field(default=None, description="Primary diagnosis or reason for prescription")
    medications: list[Medication] = Field(description="List of prescribed medications")
    allergies_noted: Optional[list[str]] = Field(default=None, description="Patient allergies noted on the prescription")
    follow_up: Optional[str] = Field(default=None, description="Follow-up instructions")


# ============================================================================
# Domain 3: SOFTWARE ENGINEERING — Bug Report Classification
# ============================================================================

class BugSeverity(str, Enum):
    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class BugPriority(str, Enum):
    P0 = "P0 - Blocker"
    P1 = "P1 - Critical"
    P2 = "P2 - Major"
    P3 = "P3 - Minor"
    P4 = "P4 - Trivial"


class BugCategory(str, Enum):
    FUNCTIONAL = "Functional"
    PERFORMANCE = "Performance"
    SECURITY = "Security"
    UI_UX = "UI/UX"
    DATA_INTEGRITY = "Data Integrity"
    COMPATIBILITY = "Compatibility"
    CRASH = "Crash/Hang"
    MEMORY_LEAK = "Memory Leak"
    REGRESSION = "Regression"
    OTHER = "Other"


class Environment(BaseModel):
    """Runtime environment details."""
    os: Optional[str] = Field(default=None, description="Operating system (e.g., 'Windows 11', 'Ubuntu 22.04')")
    browser: Optional[str] = Field(default=None, description="Browser and version if web app")
    app_version: Optional[str] = Field(default=None, description="Application version")
    runtime: Optional[str] = Field(default=None, description="Runtime environment (e.g., 'Python 3.12', 'Node 20')")


class ReproductionStep(BaseModel):
    """A single step to reproduce the bug."""
    step_number: int = Field(description="Step sequence number")
    action: str = Field(description="What the user does in this step")
    expected_result: Optional[str] = Field(default=None, description="What should happen")
    actual_result: Optional[str] = Field(default=None, description="What actually happens")


class BugReport(BaseModel):
    """Structured bug report extracted from unstructured user report."""
    title: str = Field(description="Concise bug title (max 100 chars)")
    summary: str = Field(description="One-paragraph description of the bug")
    severity: BugSeverity = Field(description="Impact severity level")
    priority: BugPriority = Field(description="Fix priority")
    category: BugCategory = Field(description="Type of bug")
    component: str = Field(description="Affected system component or module")
    environment: Environment = Field(description="Environment where bug occurs")
    reproduction_steps: list[ReproductionStep] = Field(description="Steps to reproduce the bug")
    error_message: Optional[str] = Field(default=None, description="Exact error message or stack trace excerpt")
    workaround: Optional[str] = Field(default=None, description="Known workaround, if any")
    affected_users: Optional[str] = Field(default=None, description="Estimated scope (e.g., 'All users', '10% of EU users')")
    related_tickets: Optional[list[str]] = Field(default=None, description="Related JIRA/GitHub issue IDs")


# ============================================================================
# Domain 4: HR / RECRUITING — Resume Parsing
# ============================================================================

class SkillLevel(str, Enum):
    EXPERT = "Expert"
    ADVANCED = "Advanced"
    INTERMEDIATE = "Intermediate"
    BEGINNER = "Beginner"


class Skill(BaseModel):
    """A professional skill with proficiency level."""
    name: str = Field(description="Skill name (e.g., 'Python', 'Kubernetes', 'Project Management')")
    level: SkillLevel = Field(description="Proficiency level")
    years: Optional[float] = Field(default=None, description="Years of experience with this skill")


class WorkExperience(BaseModel):
    """A single job/role in the candidate's career history."""
    company: str = Field(description="Company name")
    title: str = Field(description="Job title")
    location: Optional[str] = Field(default=None, description="City, Country")
    start_date: str = Field(description="Start date (YYYY-MM or YYYY)")
    end_date: Optional[str] = Field(default=None, description="End date (YYYY-MM or 'Present')")
    responsibilities: list[str] = Field(description="Key responsibilities and achievements (3-5 bullet points)")
    technologies: Optional[list[str]] = Field(default=None, description="Technologies used in this role")


class Education(BaseModel):
    """An educational qualification."""
    institution: str = Field(description="University or school name")
    degree: str = Field(description="Degree type (e.g., 'B.Tech', 'M.S.', 'MBA')")
    field_of_study: str = Field(description="Major or field (e.g., 'Computer Science')")
    graduation_year: Optional[str] = Field(default=None, description="Year of graduation")
    gpa: Optional[str] = Field(default=None, description="GPA or percentage if mentioned")


class Resume(BaseModel):
    """Structured representation of a resume/CV."""
    full_name: str = Field(description="Candidate's full name")
    email: Optional[str] = Field(default=None, description="Email address")
    phone: Optional[str] = Field(default=None, description="Phone number")
    location: Optional[str] = Field(default=None, description="Current city/country")
    linkedin: Optional[str] = Field(default=None, description="LinkedIn profile URL")
    summary: str = Field(description="Professional summary (2-3 sentences)")
    total_experience_years: Optional[float] = Field(default=None, description="Total years of professional experience")
    skills: list[Skill] = Field(description="Technical and professional skills with proficiency levels")
    work_experience: list[WorkExperience] = Field(description="Work history, most recent first")
    education: list[Education] = Field(description="Educational qualifications")
    certifications: Optional[list[str]] = Field(default=None, description="Professional certifications")
    languages: Optional[list[str]] = Field(default=None, description="Languages spoken")
