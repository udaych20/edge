# Project 17: Model Quantization & Optimization — Compressing LLMs for Faster Inference

## What You'll Learn
- **Quantization Basics**: What quantization is and why it matters for LLM deployment
- **Precision Formats**: FP32, FP16, INT8, INT4 — how each affects model quality and speed
- **GGUF Format**: The standard format for quantized models (used by llama.cpp, Ollama, LM Studio)
- **Tradeoff Analysis**: How to choose the right quantization level for your use case
- **Cloud vs Local**: When to use API-based models vs local quantized models

## Quantization Concepts

### What Is Quantization?
Quantization reduces the numerical precision of model weights:
```
FP32 (32-bit float) → FP16 (16-bit float) → INT8 (8-bit integer) → INT4 (4-bit integer)
```
Each step roughly **halves** the model size and memory footprint while trading off some quality.

### Why Quantize?
- **Memory**: A 7B parameter model at FP32 = ~28 GB. At Q4_K_M = ~4.1 GB
- **Speed**: Smaller models → faster inference, especially on CPU
- **Cost**: Run models on consumer hardware instead of expensive GPUs
- **Privacy**: Keep data on-device instead of sending to cloud APIs

### Precision Formats Explained
| Format | Bits/Weight | Description |
|--------|-----------|-------------|
| FP32 | 32 | Full precision — training standard, maximum quality |
| FP16 | 16 | Half precision — minimal quality loss, 2× smaller |
| Q8_0 | 8 | 8-bit quantization — near-lossless, good starting point |
| Q5_1 | ~5.5 | 5-bit with extra precision bits — great quality/size balance |
| Q4_K_M | ~4.5 | 4-bit k-quant medium — the sweet spot for most use cases |
| Q3_K_S | ~3.5 | 3-bit k-quant small — noticeable quality loss, very compact |
| Q2_K | ~2.5 | 2-bit k-quant — aggressive compression, significant quality loss |

### GGUF Format
GGUF (GPT-Generated Unified Format) is the standard for quantized models:
```
Original Model (PyTorch/Safetensors)
        ↓  convert
GGUF FP16 (baseline)
        ↓  quantize
GGUF Q4_K_M (compressed)
```
- Used by **llama.cpp**, **Ollama**, **LM Studio**, **GPT4All**
- Self-contained: weights + tokenizer + metadata in one file
- Supports CPU inference (no GPU required)

### llama.cpp Pipeline
```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│  HuggingFace │     │   convert    │     │   quantize   │
│    Model     │ ──→ │  to GGUF     │ ──→ │  to Q4_K_M   │
│  (FP16/32)   │     │  (FP16)      │     │  (~4.1 GB)   │
└──────────────┘     └──────────────┘     └──────────────┘
                                                  │
                                                  ▼
                                          ┌──────────────┐
                                          │  llama.cpp   │
                                          │   server     │
                                          │  (OpenAI API │
                                          │  compatible) │
                                          └──────────────┘
```

### K-Quants
The "K" in Q4_K_M stands for "k-quant" — a method that uses different bit widths for different layers:
- **Attention layers**: Keep higher precision (more important for quality)
- **Feed-forward layers**: Use lower precision (more compressible)
- **_S / _M / _L**: Small / Medium / Large variants (more bits in important layers)

## Architecture
```
┌──────────────────────────────────────────┐
│          Streamlit UI (:8517)            │
│  ┌──────────┬───────────┬─────────────┐  │
│  │  Quant   │ Benchmark │ Cloud vs    │  │
│  │Explorer  │  Charts   │  Local      │  │
│  └────┬─────┴─────┬─────┴──────┬──────┘  │
│       │           │            │          │
│  ┌────┴───────────┴────────────┴───────┐  │
│  │       quantization_demo.py          │  │
│  │  (Simulated benchmarks + OpenAI)    │  │
│  └─────────────────────────────────────┘  │
└──────────────────────────────────────────┘
```

## Files
| File | Purpose |
|------|---------|
| `quantization_demo.py` | Core logic — benchmark data, calculators, cloud API comparison |
| `app.py` | Streamlit dashboard on port 8517 |
| `requirements.txt` | Python dependencies |
| `.env` | OpenAI API key |

## How to Run

### Local Development
```bash
cd projects/17-quantization
pip install -r requirements.txt
# CLI demo
python quantization_demo.py demo
# Streamlit UI
streamlit run app.py --server.port 8517
```

### Deploy to Azure VM
```bash
# Copy files
scp -i ~/.ssh/key.pem -r . azureuser@10.0.0.32:~/genai-projects/17-quantization/

# SSH and run
ssh -i ~/.ssh/key.pem azureuser@10.0.0.32
cd ~/genai-projects/17-quantization
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8517 --server.headless true
```

Access at: `http://10.0.0.32:8517`

## Key Takeaways
1. **Q4_K_M is the sweet spot** — ~4× compression with minimal quality loss for most tasks
2. **Quantization enables local deployment** — Run 7B models on laptops, 70B on workstations
3. **Cloud APIs still win for quality-critical tasks** — GPT-4o quality > any quantized open model
4. **The right choice depends on your constraints** — privacy, cost, latency, quality requirements

## Note
This project uses **simulated benchmark data** based on real-world measurements since the VM
may not have GPU hardware or llama.cpp installed. The benchmark numbers are representative of
actual performance measured on standard hardware (Apple M2, RTX 3090, etc.).
