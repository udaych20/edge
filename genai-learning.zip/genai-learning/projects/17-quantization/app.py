"""
Quantization & Optimization Dashboard — Streamlit UI.
Port: 8517
"""

import streamlit as st

from quantization_demo import (
    QUANT_LEVELS_7B,
    QUANTIZATION_EXPLAINERS,
    CLOUD_PRICING,
    LOCAL_COST_PER_HOUR,
    get_quant_data,
    get_recommendation,
    estimate_cloud_cost,
    estimate_local_cost,
    measure_cloud_latency,
)

# --------------------------------------------------------------------------- #
#  Page config
# --------------------------------------------------------------------------- #
st.set_page_config(page_title="Quantization Lab", page_icon="🗜️", layout="wide")

# --------------------------------------------------------------------------- #
#  Header
# --------------------------------------------------------------------------- #
st.title("🗜️ Model Quantization & Optimization Lab")
st.caption(
    "Explore how quantization compresses LLMs — compare precision levels, "
    "benchmark speed/quality tradeoffs, and calculate cloud vs local costs"
)

tab1, tab2, tab3, tab4 = st.tabs([
    "📊 Benchmark Explorer",
    "💰 Cloud vs Local",
    "🎯 Recommendation Engine",
    "📖 Learn Quantization",
])

# =========================================================================== #
#  Tab 1 — Benchmark Explorer
# =========================================================================== #
with tab1:
    st.header("Quantization Benchmark Explorer")

    col_model, _ = st.columns([1, 2])
    with col_model:
        model_size = st.selectbox(
            "Model size (parameters)",
            ["1B", "3B", "7B", "13B", "34B", "70B"],
            index=2,
            key="bench_model",
        )

    quant_data = get_quant_data(model_size)

    # --- Overview table ---
    st.subheader(f"Benchmark Table — {model_size} Model")
    table_rows = []
    for q in quant_data:
        star = " ⭐" if q.name == "Q4_K_M" else ""
        table_rows.append({
            "Quant Level": f"{q.name}{star}",
            "Bits/Weight": q.bits_per_weight,
            "Size (GB)": q.model_size_gb,
            "RAM (GB)": q.ram_required_gb,
            "CPU (tok/s)": q.speed_tps_cpu,
            "GPU (tok/s)": q.speed_tps_gpu,
            "Perplexity": q.perplexity,
            "Quality %": q.quality_pct,
        })
    st.dataframe(table_rows, use_container_width=True, hide_index=True)

    # --- Charts ---
    st.subheader("Visual Comparison")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Model Size on Disk (GB)**")
        size_data = {q.name: q.model_size_gb for q in quant_data}
        st.bar_chart(size_data, horizontal=True, color="#4A90D9")

    with col2:
        st.markdown("**Inference Speed — CPU (tokens/sec)**")
        speed_data = {q.name: q.speed_tps_cpu for q in quant_data}
        st.bar_chart(speed_data, horizontal=True, color="#50C878")

    col3, col4 = st.columns(2)

    with col3:
        st.markdown("**Perplexity (lower = better)**")
        ppl_data = {q.name: q.perplexity for q in quant_data}
        st.bar_chart(ppl_data, horizontal=True, color="#FF6B6B")

    with col4:
        st.markdown("**Quality vs FP16 Baseline (%)**")
        qual_data = {q.name: q.quality_pct for q in quant_data}
        st.bar_chart(qual_data, horizontal=True, color="#FFD700")

    # --- Compression ratio ---
    st.subheader("Compression Ratios")
    fp32_size = quant_data[0].model_size_gb
    comp_cols = st.columns(len(quant_data) - 1)
    for i, q in enumerate(quant_data[1:]):
        ratio = fp32_size / q.model_size_gb
        savings = (1 - q.model_size_gb / fp32_size) * 100
        with comp_cols[i]:
            st.metric(q.name, f"{ratio:.1f}×", f"-{savings:.0f}% size")

# =========================================================================== #
#  Tab 2 — Cloud vs Local Cost Calculator
# =========================================================================== #
with tab2:
    st.header("Cloud vs Local Cost Calculator")

    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("📋 Usage Parameters")
        requests_per_day = st.slider("Requests per day", 10, 10000, 1000, 10, key="cost_rpd")
        avg_input_tokens = st.slider("Avg input tokens per request", 50, 2000, 500, 50, key="cost_in")
        avg_output_tokens = st.slider("Avg output tokens per request", 50, 1000, 200, 50, key="cost_out")

    with col_right:
        st.subheader("⚙️ Configuration")
        cloud_model = st.selectbox(
            "Cloud model",
            list(CLOUD_PRICING.keys()),
            format_func=lambda m: CLOUD_PRICING[m]["label"],
            key="cost_cloud",
        )
        local_hw = st.selectbox(
            "Local hardware",
            list(LOCAL_COST_PER_HOUR.keys()),
            format_func=lambda h: h.replace("_", " ").title(),
            key="cost_hw",
        )
        local_quant = st.selectbox(
            "Local quantization",
            [q.name for q in QUANT_LEVELS_7B],
            index=4,  # Q4_K_M
            key="cost_quant",
        )

    # Calculate
    cloud_est = estimate_cloud_cost(cloud_model, avg_input_tokens, avg_output_tokens, requests_per_day)
    local_q = next(q for q in QUANT_LEVELS_7B if q.name == local_quant)
    tps = local_q.speed_tps_gpu if "gpu" in local_hw else local_q.speed_tps_cpu
    local_est = estimate_local_cost(local_hw, tps, avg_output_tokens, requests_per_day)

    st.divider()

    st.subheader("💰 Cost Comparison")
    c1, c2, c3 = st.columns(3)

    with c1:
        st.markdown("**☁️ Cloud API**")
        st.metric("Monthly Cost", f"${cloud_est['monthly_cost']:.2f}")
        st.metric("Annual Cost", f"${cloud_est['annual_cost']:.2f}")
        st.caption(f"Model: {cloud_est['model']}")

    with c2:
        st.markdown("**🖥️ Local Inference**")
        st.metric("Monthly Cost", f"${local_est['monthly_cost']:.4f}")
        st.metric("Annual Cost", f"${local_est['annual_cost']:.2f}")
        st.caption(f"Electricity only — {local_hw.replace('_', ' ').title()}")

    with c3:
        st.markdown("**📊 Comparison**")
        if local_est["monthly_cost"] > 0:
            ratio = cloud_est["monthly_cost"] / local_est["monthly_cost"]
            st.metric("Cloud / Local", f"{ratio:.0f}×", "more expensive (cloud)")
        else:
            st.metric("Cloud / Local", "∞", "Local is essentially free")

        latency_note = (f"Local: {local_est['seconds_per_request']}s/req "
                        f"({tps:.0f} tok/s)")
        st.caption(latency_note)

    # Fine print
    st.info(
        "💡 **Note**: Local cost is electricity only. Real TCO includes hardware purchase, "
        "maintenance, and your time. Cloud APIs also give you the latest models without setup. "
        "The right choice depends on your volume, privacy needs, and quality requirements."
    )

    # --- Live latency test ---
    st.divider()
    st.subheader("🌐 Live Cloud Latency Test")

    test_prompt = st.text_input(
        "Test prompt",
        "Explain model quantization in two sentences.",
        key="latency_prompt",
    )

    if st.button("⚡ Measure Latency", key="btn_latency"):
        with st.spinner("Calling OpenAI API..."):
            result = measure_cloud_latency(test_prompt, cloud_model)

        if "error" in result:
            st.error(result["error"])
        else:
            m1, m2, m3 = st.columns(3)
            m1.metric("Latency", f"{result['latency_sec']}s")
            m2.metric("Output Tokens", result["output_tokens"])
            m3.metric("Speed", f"{result['tokens_per_sec']} tok/s")
            st.markdown(f"**Response:** {result['response']}")

# =========================================================================== #
#  Tab 3 — Recommendation Engine
# =========================================================================== #
with tab3:
    st.header("Quantization Recommendation Engine")
    st.write("Select your use case and constraints to get a personalized recommendation.")

    col_uc, col_hw = st.columns(2)

    with col_uc:
        use_case = st.selectbox(
            "Primary use case",
            [
                "general_chat",
                "code_generation",
                "summarization",
                "reasoning_math",
                "embedding_search",
                "mobile_edge",
            ],
            format_func=lambda x: x.replace("_", " ").title(),
            key="rec_uc",
        )

    with col_hw:
        available_ram = st.selectbox(
            "Available RAM (GB)",
            [4, 6, 8, 16, 32, 64],
            index=2,
            key="rec_ram",
        )

    rec = get_recommendation(use_case)

    st.divider()

    # Main recommendation
    st.subheader(f"✅ Recommended: {rec['recommended']}")
    st.write(rec["reason"])

    # Details for recommended quant
    rec_q = next((q for q in QUANT_LEVELS_7B if q.name == rec["recommended"]), None)
    if rec_q:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Size (7B)", f"{rec_q.model_size_gb} GB")
        c2.metric("RAM Needed", f"{rec_q.ram_required_gb} GB")
        c3.metric("CPU Speed", f"{rec_q.speed_tps_cpu} tok/s")
        c4.metric("Quality", f"{rec_q.quality_pct}%")

        # RAM check
        if rec_q.ram_required_gb > available_ram:
            st.warning(
                f"⚠️ {rec['recommended']} needs {rec_q.ram_required_gb} GB RAM "
                f"but you have {available_ram} GB. Consider a more aggressive quant level."
            )

    # Alternatives
    st.subheader("🔄 Alternatives")
    for alt in rec["alternatives"]:
        st.write(f"- {alt}")

    # Model size helper
    st.divider()
    st.subheader("📐 What Model Fits Your RAM?")

    ram_check = available_ram
    st.write(f"With **{ram_check} GB RAM**, you can run:")
    for q in QUANT_LEVELS_7B:
        fits = "✅" if q.ram_required_gb <= ram_check else "❌"
        st.write(f"  {fits} 7B {q.name} ({q.ram_required_gb} GB)")

# =========================================================================== #
#  Tab 4 — Learn Quantization
# =========================================================================== #
with tab4:
    st.header("📖 Understanding Quantization")

    # Overview
    st.subheader("What Is Quantization?")
    st.markdown("""
    **Quantization** reduces the numerical precision of neural network weights to make
    models smaller and faster. Think of it like audio compression:

    | Analogy | Audio | LLMs |
    |---------|-------|------|
    | Uncompressed | WAV (lossless) | FP32 (full precision) |
    | Light compression | FLAC (lossless) | FP16 / Q8_0 |
    | Standard compression | MP3 320kbps | Q5_1 / Q4_K_M |
    | Heavy compression | MP3 128kbps | Q3_K_S / Q2_K |
    | Extreme compression | MP3 64kbps | Q2_K (very lossy) |

    Just as most people can't tell the difference between a 320kbps MP3 and a WAV file,
    most users can't distinguish Q4_K_M outputs from FP16 outputs.
    """)

    st.divider()

    # Per-level explainers
    st.subheader("Quantization Levels Explained")

    for level_name, info in QUANTIZATION_EXPLAINERS.items():
        with st.expander(info["title"], expanded=(level_name == "Q4_K_M")):
            st.markdown(info["detail"])

            # Show benchmark for this level
            q_data = next((q for q in QUANT_LEVELS_7B if q.name == level_name), None)
            if q_data:
                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Size (7B)", f"{q_data.model_size_gb} GB")
                m2.metric("CPU Speed", f"{q_data.speed_tps_cpu} tok/s")
                m3.metric("Perplexity", f"{q_data.perplexity}")
                m4.metric("Quality", f"{q_data.quality_pct}%")

    st.divider()

    # K-Quant explanation
    st.subheader("K-Quants: Smart Layer-Aware Quantization")
    st.markdown("""
    The **K-quant** system (introduced in llama.cpp) treats different layers differently:

    ```
    ┌─────────────────────────────────────────┐
    │           Transformer Block              │
    │  ┌─────────────────────────────────┐    │
    │  │   Attention (Q, K, V, O)        │    │
    │  │   → Higher precision (Q5_K/Q6_K)│    │
    │  │   (Critical for coherence)      │    │
    │  └─────────────────────────────────┘    │
    │  ┌─────────────────────────────────┐    │
    │  │   Feed-Forward Network          │    │
    │  │   → Lower precision (Q4_K/Q3_K) │    │
    │  │   (More redundant, compressible)│    │
    │  └─────────────────────────────────┘    │
    └─────────────────────────────────────────┘
    ```

    **Variants:**
    - **_S** (Small): Minimize size — use lowest bits everywhere
    - **_M** (Medium): Balance quality and size — recommended default
    - **_L** (Large): Maximize quality — more bits in important layers
    """)

    st.divider()

    # GGUF format
    st.subheader("GGUF: The Universal Quantized Format")
    st.markdown("""
    **GGUF** (GPT-Generated Unified Format) is the standard file format for quantized models:

    ```
    ┌──────────────────────────────┐
    │        GGUF File             │
    │  ┌────────────────────────┐  │
    │  │  Metadata              │  │
    │  │  - Model architecture  │  │
    │  │  - Tokenizer config    │  │
    │  │  - Quant type          │  │
    │  └────────────────────────┘  │
    │  ┌────────────────────────┐  │
    │  │  Tokenizer Data        │  │
    │  │  - Vocabulary          │  │
    │  │  - Merge rules         │  │
    │  └────────────────────────┘  │
    │  ┌────────────────────────┐  │
    │  │  Quantized Weights     │  │
    │  │  (The big part)        │  │
    │  └────────────────────────┘  │
    └──────────────────────────────┘
    ```

    **Used by:** llama.cpp · Ollama · LM Studio · GPT4All · text-generation-webui

    **Key advantage:** Single self-contained file — no separate tokenizer files, no config.json,
    just one `.gguf` file you can download and run.
    """)

# --------------------------------------------------------------------------- #
#  Footer
# --------------------------------------------------------------------------- #
st.divider()
st.caption(
    "📌 Benchmark data is simulated based on published llama.cpp measurements. "
    "Cloud API calls are live. | Project 17 of GenAI Learning Roadmap"
)
