"""
Model Quantization & Optimization — Core Implementation.

Conceptual demo: simulated benchmark data based on real-world measurements,
plus live OpenAI API calls for cloud-vs-local comparison.

Benchmark data sourced from published llama.cpp benchmarks on:
- Apple M2 Pro (CPU, 32 GB)
- NVIDIA RTX 3090 (GPU, 24 GB)
"""

import os
import sys
import time
import json
from dataclasses import dataclass, field, asdict
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

# --------------------------------------------------------------------------- #
#  Data models
# --------------------------------------------------------------------------- #

@dataclass
class QuantLevel:
    """Represents a single quantization level with benchmark data."""
    name: str
    bits_per_weight: float
    description: str
    # --- 7B model benchmarks (Llama-2-7B reference) ---
    model_size_gb: float          # File size on disk
    ram_required_gb: float        # Runtime memory (model + context)
    # --- Speed (tokens/sec, Apple M2 Pro CPU, 2048 ctx) ---
    speed_tps_cpu: float          # Tokens per second — CPU
    speed_tps_gpu: float          # Tokens per second — RTX 3090
    # --- Quality ---
    perplexity: float             # Wiki2 perplexity (lower = better)
    quality_pct: float            # Relative quality vs FP16 baseline (%)


@dataclass
class ModelProfile:
    """A model at a given parameter count with all quant level data."""
    name: str
    params_b: float               # Billion parameters
    base_size_gb: float           # FP32 size
    quant_levels: list[QuantLevel] = field(default_factory=list)


# --------------------------------------------------------------------------- #
#  Benchmark data — based on published llama.cpp & HuggingFace benchmarks
# --------------------------------------------------------------------------- #

QUANT_LEVELS_7B: list[QuantLevel] = [
    QuantLevel(
        name="FP32",
        bits_per_weight=32.0,
        description="Full 32-bit floating point — maximum precision, training standard",
        model_size_gb=26.8,
        ram_required_gb=28.5,
        speed_tps_cpu=2.1,
        speed_tps_gpu=45.0,
        perplexity=5.67,
        quality_pct=100.1,
    ),
    QuantLevel(
        name="FP16",
        bits_per_weight=16.0,
        description="Half precision — baseline for quantization comparison",
        model_size_gb=13.4,
        ram_required_gb=15.0,
        speed_tps_cpu=4.8,
        speed_tps_gpu=95.0,
        perplexity=5.68,
        quality_pct=100.0,
    ),
    QuantLevel(
        name="Q8_0",
        bits_per_weight=8.0,
        description="8-bit quantization — near-lossless, good for quality-sensitive tasks",
        model_size_gb=7.16,
        ram_required_gb=9.0,
        speed_tps_cpu=9.5,
        speed_tps_gpu=120.0,
        perplexity=5.69,
        quality_pct=99.8,
    ),
    QuantLevel(
        name="Q5_1",
        bits_per_weight=5.5,
        description="5-bit with extra precision — excellent quality-to-size ratio",
        model_size_gb=5.65,
        ram_required_gb=7.5,
        speed_tps_cpu=12.3,
        speed_tps_gpu=135.0,
        perplexity=5.72,
        quality_pct=99.3,
    ),
    QuantLevel(
        name="Q4_K_M",
        bits_per_weight=4.5,
        description="4-bit k-quant medium — the sweet spot for most use cases",
        model_size_gb=4.08,
        ram_required_gb=6.0,
        speed_tps_cpu=15.8,
        speed_tps_gpu=155.0,
        perplexity=5.79,
        quality_pct=98.1,
    ),
    QuantLevel(
        name="Q3_K_S",
        bits_per_weight=3.5,
        description="3-bit k-quant small — compact but quality starts degrading",
        model_size_gb=3.16,
        ram_required_gb=5.0,
        speed_tps_cpu=18.5,
        speed_tps_gpu=170.0,
        perplexity=6.14,
        quality_pct=93.5,
    ),
    QuantLevel(
        name="Q2_K",
        bits_per_weight=2.5,
        description="2-bit k-quant — aggressive compression, noticeable quality loss",
        model_size_gb=2.67,
        ram_required_gb=4.5,
        speed_tps_cpu=21.0,
        speed_tps_gpu=185.0,
        perplexity=6.79,
        quality_pct=86.2,
    ),
]

# Scale factors for other model sizes (relative to 7B)
MODEL_SCALE_FACTORS = {
    "1B":  {"params": 1.0,  "size_scale": 0.14,  "speed_scale": 5.0,  "ppl_offset": 2.5},
    "3B":  {"params": 3.0,  "size_scale": 0.43,  "speed_scale": 2.3,  "ppl_offset": 0.8},
    "7B":  {"params": 7.0,  "size_scale": 1.0,   "speed_scale": 1.0,  "ppl_offset": 0.0},
    "13B": {"params": 13.0, "size_scale": 1.86,  "speed_scale": 0.55, "ppl_offset": -0.4},
    "34B": {"params": 34.0, "size_scale": 4.86,  "speed_scale": 0.22, "ppl_offset": -0.9},
    "70B": {"params": 70.0, "size_scale": 10.0,  "speed_scale": 0.10, "ppl_offset": -1.3},
}


def get_quant_data(model_size: str = "7B") -> list[QuantLevel]:
    """Return quantization benchmark data scaled for the given model size."""
    if model_size == "7B":
        return QUANT_LEVELS_7B

    factors = MODEL_SCALE_FACTORS.get(model_size)
    if not factors:
        return QUANT_LEVELS_7B

    scaled = []
    for q in QUANT_LEVELS_7B:
        scaled.append(QuantLevel(
            name=q.name,
            bits_per_weight=q.bits_per_weight,
            description=q.description,
            model_size_gb=round(q.model_size_gb * factors["size_scale"], 2),
            ram_required_gb=round(q.ram_required_gb * factors["size_scale"], 2),
            speed_tps_cpu=round(q.speed_tps_cpu * factors["speed_scale"], 1),
            speed_tps_gpu=round(q.speed_tps_gpu * factors["speed_scale"], 1),
            perplexity=round(q.perplexity + factors["ppl_offset"], 2),
            quality_pct=q.quality_pct,
        ))
    return scaled


# --------------------------------------------------------------------------- #
#  Cloud vs Local comparison
# --------------------------------------------------------------------------- #

# OpenAI pricing per 1M tokens (as of 2024-2025)
CLOUD_PRICING = {
    "gpt-4o-mini": {"input": 0.15, "output": 0.60, "label": "GPT-4o Mini"},
    "gpt-4o":      {"input": 2.50, "output": 10.00, "label": "GPT-4o"},
    "gpt-4.1-nano": {"input": 0.10, "output": 0.40, "label": "GPT-4.1 Nano"},
}

# Local running costs (electricity only, approximate)
LOCAL_COST_PER_HOUR = {
    "cpu_laptop": 0.01,     # ~10W extra for inference
    "cpu_desktop": 0.03,    # ~30W extra
    "gpu_3090": 0.10,       # ~350W TDP
    "gpu_4090": 0.12,       # ~450W TDP
}


def estimate_cloud_cost(
    model: str, input_tokens: int, output_tokens: int, requests_per_day: int,
) -> dict:
    """Estimate monthly cloud API cost."""
    pricing = CLOUD_PRICING.get(model, CLOUD_PRICING["gpt-4o-mini"])
    daily_input = input_tokens * requests_per_day
    daily_output = output_tokens * requests_per_day
    daily_cost = (daily_input / 1_000_000 * pricing["input"]
                  + daily_output / 1_000_000 * pricing["output"])
    return {
        "model": pricing["label"],
        "daily_cost": round(daily_cost, 4),
        "monthly_cost": round(daily_cost * 30, 2),
        "annual_cost": round(daily_cost * 365, 2),
        "input_cost_per_1k": round(pricing["input"] / 1000, 6),
        "output_cost_per_1k": round(pricing["output"] / 1000, 6),
    }


def estimate_local_cost(
    hardware: str, tokens_per_sec: float, output_tokens: int, requests_per_day: int,
) -> dict:
    """Estimate monthly local inference cost (electricity only)."""
    cost_per_hour = LOCAL_COST_PER_HOUR.get(hardware, 0.03)
    seconds_per_request = output_tokens / max(tokens_per_sec, 1)
    hours_per_day = (seconds_per_request * requests_per_day) / 3600
    daily_cost = hours_per_day * cost_per_hour
    return {
        "hardware": hardware,
        "daily_cost": round(daily_cost, 4),
        "monthly_cost": round(daily_cost * 30, 4),
        "annual_cost": round(daily_cost * 365, 2),
        "seconds_per_request": round(seconds_per_request, 2),
        "hours_per_day": round(hours_per_day, 3),
    }


# --------------------------------------------------------------------------- #
#  Live cloud latency measurement
# --------------------------------------------------------------------------- #

def measure_cloud_latency(prompt: str = "Explain quantization in one sentence.",
                          model: str = "gpt-4o-mini") -> dict:
    """Call OpenAI API and measure real latency + token usage."""
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        return {"error": "OPENAI_API_KEY not set"}

    client = OpenAI(api_key=api_key)

    start = time.perf_counter()
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150,
        temperature=0.7,
    )
    elapsed = time.perf_counter() - start

    usage = response.usage
    output_text = response.choices[0].message.content or ""

    tokens_generated = usage.completion_tokens if usage else len(output_text.split())
    tps = tokens_generated / elapsed if elapsed > 0 else 0

    return {
        "model": model,
        "prompt": prompt,
        "response": output_text,
        "latency_sec": round(elapsed, 3),
        "input_tokens": usage.prompt_tokens if usage else 0,
        "output_tokens": usage.completion_tokens if usage else 0,
        "tokens_per_sec": round(tps, 1),
    }


# --------------------------------------------------------------------------- #
#  Educational content
# --------------------------------------------------------------------------- #

QUANTIZATION_EXPLAINERS = {
    "FP32": {
        "title": "FP32 — Full Precision (32-bit Float)",
        "detail": (
            "Each weight stored as a 32-bit IEEE 754 floating point number.\n"
            "- **1 sign bit** + **8 exponent bits** + **23 mantissa bits**\n"
            "- Range: ±3.4 × 10³⁸ with ~7 decimal digits precision\n"
            "- This is the standard training format — maximum quality\n"
            "- Rarely used for inference due to size and speed penalties"
        ),
    },
    "FP16": {
        "title": "FP16 — Half Precision (16-bit Float)",
        "detail": (
            "Each weight stored as a 16-bit floating point number.\n"
            "- **1 sign bit** + **5 exponent bits** + **10 mantissa bits**\n"
            "- Range: ±65,504 with ~3 decimal digits precision\n"
            "- Baseline for quantization — almost no quality loss vs FP32\n"
            "- 2× smaller than FP32, 2× faster on GPUs with tensor cores"
        ),
    },
    "Q8_0": {
        "title": "Q8_0 — 8-bit Quantization",
        "detail": (
            "Weights mapped to 8-bit integers with a per-block scale factor.\n"
            "- 256 possible values per weight (vs ~4 billion for FP32)\n"
            "- Block size: 32 weights share one FP16 scale factor\n"
            "- Near-lossless: perplexity within 0.01 of FP16\n"
            "- Good for quality-critical applications where 4-bit is too lossy"
        ),
    },
    "Q5_1": {
        "title": "Q5_1 — 5-bit with Minimum Value",
        "detail": (
            "5 bits per weight with per-block scale and minimum.\n"
            "- 32 possible values per weight\n"
            "- Block stores: scale (FP16) + min (FP16) + 5-bit weights\n"
            "- Effective bits/weight ≈ 5.5 due to metadata overhead\n"
            "- Excellent balance — barely noticeable quality loss"
        ),
    },
    "Q4_K_M": {
        "title": "Q4_K_M — 4-bit K-Quant Medium (⭐ Recommended)",
        "detail": (
            "K-quant uses **different precision for different layers**.\n"
            "- Attention layers: higher precision (Q5_K or Q6_K)\n"
            "- Feed-forward layers: lower precision (Q4_K)\n"
            "- The 'M' = medium — balances quality vs compression\n"
            "- **Best default choice** for most use cases\n"
            "- Only ~2% quality loss vs FP16 with 3× compression"
        ),
    },
    "Q3_K_S": {
        "title": "Q3_K_S — 3-bit K-Quant Small",
        "detail": (
            "3-bit quantization with minimal metadata per block.\n"
            "- Only 8 possible values per weight position\n"
            "- Noticeable quality degradation (~6.5% loss vs FP16)\n"
            "- Good for: memory-constrained devices, draft generation\n"
            "- Not recommended for: reasoning, code, math tasks"
        ),
    },
    "Q2_K": {
        "title": "Q2_K — 2-bit K-Quant (Aggressive)",
        "detail": (
            "Extreme 2-bit compression with block-level quantization.\n"
            "- Only 4 possible values per weight position\n"
            "- Significant quality loss (~14% vs FP16)\n"
            "- Useful for: experimentation, quick drafts, simple chat\n"
            "- Avoid for: factual accuracy, complex reasoning, code gen\n"
            "- Impressive that models work at all with such compression!"
        ),
    },
}


def get_recommendation(use_case: str) -> dict:
    """Recommend quantization level based on use case."""
    recommendations = {
        "general_chat": {
            "recommended": "Q4_K_M",
            "reason": "Best balance of quality and speed for conversational AI",
            "alternatives": ["Q5_1 (if quality matters more)", "Q3_K_S (if memory is tight)"],
        },
        "code_generation": {
            "recommended": "Q5_1",
            "reason": "Code tasks are sensitive to precision — use higher quality quant",
            "alternatives": ["Q8_0 (best local quality)", "Cloud API (if accuracy is critical)"],
        },
        "summarization": {
            "recommended": "Q4_K_M",
            "reason": "Summarization is fairly robust to quantization",
            "alternatives": ["Q3_K_S (for high throughput)", "Q2_K (for quick drafts)"],
        },
        "reasoning_math": {
            "recommended": "Q8_0",
            "reason": "Math and reasoning degrade significantly at low precision",
            "alternatives": ["FP16 (if possible)", "Cloud API (GPT-4o for best results)"],
        },
        "embedding_search": {
            "recommended": "Q8_0",
            "reason": "Embedding quality drops faster than generation quality",
            "alternatives": ["FP16 (for production search)", "Cloud API (for best recall)"],
        },
        "mobile_edge": {
            "recommended": "Q3_K_S",
            "reason": "Minimal memory and fast inference for edge devices",
            "alternatives": ["Q2_K (for very small devices)", "Q4_K_M (if 6GB RAM available)"],
        },
    }
    return recommendations.get(use_case, recommendations["general_chat"])


# --------------------------------------------------------------------------- #
#  CLI demo
# --------------------------------------------------------------------------- #

def _cli_demo() -> None:
    """Run an interactive CLI demo."""
    print("=" * 70)
    print("  Model Quantization & Optimization — Interactive Demo")
    print("=" * 70)

    # 1. Show benchmark table
    print("\n📊 Benchmark Data — Llama-2 7B (Apple M2 Pro CPU / RTX 3090 GPU)")
    print("-" * 70)
    print(f"{'Quant':<10} {'Size':>8} {'RAM':>8} {'CPU t/s':>8} {'GPU t/s':>8} "
          f"{'PPL':>7} {'Quality':>8}")
    print("-" * 70)
    for q in QUANT_LEVELS_7B:
        marker = " ⭐" if q.name == "Q4_K_M" else ""
        print(f"{q.name:<10} {q.model_size_gb:>7.1f}G {q.ram_required_gb:>7.1f}G "
              f"{q.speed_tps_cpu:>7.1f} {q.speed_tps_gpu:>7.1f} "
              f"{q.perplexity:>7.2f} {q.quality_pct:>7.1f}%{marker}")

    # 2. Compression ratios
    print("\n📦 Compression vs FP32:")
    fp32_size = QUANT_LEVELS_7B[0].model_size_gb
    for q in QUANT_LEVELS_7B[1:]:
        ratio = fp32_size / q.model_size_gb
        savings = (1 - q.model_size_gb / fp32_size) * 100
        print(f"  {q.name:<10} → {ratio:.1f}× smaller ({savings:.0f}% reduction)")

    # 3. Cost comparison
    print("\n💰 Cost Comparison — 1000 requests/day, 500 input + 200 output tokens each:")
    cloud = estimate_cloud_cost("gpt-4o-mini", 500, 200, 1000)
    local = estimate_local_cost("cpu_laptop", 15.8, 200, 1000)
    print(f"  Cloud (GPT-4o Mini): ${cloud['monthly_cost']}/month")
    print(f"  Local (Q4_K_M CPU):  ${local['monthly_cost']}/month (electricity only)")
    print(f"  Savings:             {cloud['monthly_cost'] / max(local['monthly_cost'], 0.01):.0f}× cheaper locally")

    # 4. Live API call
    print("\n🌐 Live Cloud API Latency Test...")
    result = measure_cloud_latency()
    if "error" in result:
        print(f"  ⚠️  {result['error']}")
    else:
        print(f"  Model:    {result['model']}")
        print(f"  Latency:  {result['latency_sec']}s")
        print(f"  Tokens:   {result['output_tokens']} output tokens")
        print(f"  Speed:    {result['tokens_per_sec']} tokens/sec")
        print(f"  Response: {result['response'][:100]}...")

    # 5. Recommendation
    print("\n🎯 Recommendations by Use Case:")
    for uc in ["general_chat", "code_generation", "reasoning_math", "mobile_edge"]:
        rec = get_recommendation(uc)
        label = uc.replace("_", " ").title()
        print(f"  {label:<20} → {rec['recommended']} — {rec['reason']}")

    print("\n" + "=" * 70)
    print("  ✅ Demo complete! Run the Streamlit app for interactive exploration.")
    print("     streamlit run app.py --server.port 8517")
    print("=" * 70)


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        _cli_demo()
    else:
        print("Usage: python quantization_demo.py demo")
        print("  Or run the Streamlit app: streamlit run app.py --server.port 8517")
