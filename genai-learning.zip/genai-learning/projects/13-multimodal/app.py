"""
Streamlit UI for Multimodal AI — Insurance Claims Processor
Analyze images with GPT-4o Vision: describe, extract, chart analysis, comparison.
Run: streamlit run app.py --server.port 8513
"""

import io
import tempfile
from pathlib import Path

import streamlit as st
from PIL import Image

from multimodal import (
    analyze_chart,
    compare_images,
    describe_image,
    extract_document,
    freeform_vision,
    generate_bar_chart_image,
    generate_damage_photo,
    generate_damage_photo_after,
    generate_receipt_image,
    encode_pil_image,
)

st.set_page_config(page_title="P13 — Multimodal AI", page_icon="🖼️", layout="wide")

st.title("🖼️ Multimodal AI — Insurance Claims Processor")
st.caption("GPT-4o Vision • Image Description • Document Extraction • Chart Analysis • Comparison")

# ---------------------------------------------------------------------------
# Sidebar — mode selection & options
# ---------------------------------------------------------------------------
st.sidebar.header("Analysis Mode")
mode = st.sidebar.radio(
    "Select mode:",
    ["📷 Describe Image", "📄 Extract Document", "📊 Analyze Chart",
     "🔀 Compare Images", "✏️ Custom Prompt"],
    index=0,
)

st.sidebar.markdown("---")
st.sidebar.header("Options")
detail = st.sidebar.selectbox("Detail level", ["high", "low"], index=0,
                               help="'high' = better quality but more tokens/cost")
use_sample = st.sidebar.checkbox("Use sample images (Pillow-generated)", value=True)

st.sidebar.markdown("---")
st.sidebar.markdown(
    "**About:** This demo uses GPT-4o's vision capability to analyze images. "
    "Upload your own images or use the built-in Pillow-generated samples."
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def save_pil_to_tempfile(img: Image.Image) -> str:
    """Save a PIL image to a temp file and return the path."""
    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    img.save(tmp, format="PNG")
    tmp.close()
    return tmp.name


def save_uploaded_to_tempfile(uploaded) -> str:
    """Save an uploaded Streamlit file to a temp file and return the path."""
    tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
    tmp.write(uploaded.getvalue())
    tmp.close()
    return tmp.name


def get_image_source(label="Upload an image", key="img_upload"):
    """Handle image input — upload, URL, or sample. Returns (path, pil_image)."""
    if use_sample:
        sample_choice = st.selectbox(
            "Select sample image:",
            ["Damage Photo (Before)", "Insurance Receipt", "Claims Bar Chart", "Damage Photo (After)"],
            key=f"sample_{key}",
        )
        generators = {
            "Damage Photo (Before)": generate_damage_photo,
            "Insurance Receipt": generate_receipt_image,
            "Claims Bar Chart": generate_bar_chart_image,
            "Damage Photo (After)": generate_damage_photo_after,
        }
        img = generators[sample_choice]()
        path = save_pil_to_tempfile(img)
        return path, img

    tab_upload, tab_url = st.tabs(["📁 Upload File", "🔗 Image URL"])

    with tab_upload:
        uploaded = st.file_uploader(label, type=["png", "jpg", "jpeg", "webp", "gif"], key=key)
        if uploaded:
            img = Image.open(uploaded)
            path = save_uploaded_to_tempfile(uploaded)
            return path, img

    with tab_url:
        url = st.text_input("Image URL:", key=f"url_{key}",
                            placeholder="https://example.com/image.png")
        if url:
            return url, None  # URL-based, no local PIL image

    return None, None


# ---------------------------------------------------------------------------
# Mode: Describe Image
# ---------------------------------------------------------------------------
if mode == "📷 Describe Image":
    st.header("📷 Image Description")
    st.markdown("Upload an image to get a detailed structured description.")

    col1, col2 = st.columns([1, 1])
    with col1:
        path, img = get_image_source("Upload image to describe")
        if img is not None:
            st.image(img, caption="Input Image", use_container_width=True)
        extra = st.text_input("Additional context (optional):",
                              placeholder="e.g., This is a water damage claim photo")

    with col2:
        if path and st.button("🔍 Describe Image", type="primary", use_container_width=True):
            with st.spinner("Analyzing image with GPT-4o..."):
                result = describe_image(path, extra)
            st.success("Analysis complete!")
            st.markdown(f"**Summary:** {result.summary}")
            st.markdown(f"**Scene Type:** {result.scene_type}")
            st.markdown(f"**Objects:** {', '.join(result.objects)}")
            st.markdown(f"**Colors:** {', '.join(result.colors)}")
            st.markdown("---")
            st.markdown(f"**Details:** {result.details}")

            with st.expander("Raw JSON"):
                st.json(result.model_dump())

# ---------------------------------------------------------------------------
# Mode: Extract Document
# ---------------------------------------------------------------------------
elif mode == "📄 Extract Document":
    st.header("📄 Document Data Extraction")
    st.markdown("Upload a document image (receipt, ID, form) to extract structured data.")

    col1, col2 = st.columns([1, 1])
    with col1:
        path, img = get_image_source("Upload document image")
        if img is not None:
            st.image(img, caption="Document Image", use_container_width=True)
        extra = st.text_input("Additional context (optional):",
                              placeholder="e.g., This is an insurance claim receipt")

    with col2:
        if path and st.button("📄 Extract Data", type="primary", use_container_width=True):
            with st.spinner("Extracting document data with GPT-4o..."):
                result = extract_document(path, extra)
            st.success("Extraction complete!")
            st.markdown(f"**Document Type:** {result.document_type}")
            st.markdown("**Extracted Fields:**")
            for k, v in result.fields.items():
                st.markdown(f"- **{k}:** {v}")
            st.markdown("---")
            st.markdown(f"**Confidence Notes:** {result.confidence_notes}")

            with st.expander("Raw Text"):
                st.text(result.raw_text)
            with st.expander("Raw JSON"):
                st.json(result.model_dump())

# ---------------------------------------------------------------------------
# Mode: Analyze Chart
# ---------------------------------------------------------------------------
elif mode == "📊 Analyze Chart":
    st.header("📊 Chart & Graph Analysis")
    st.markdown("Upload a chart or graph image for data interpretation.")

    col1, col2 = st.columns([1, 1])
    with col1:
        path, img = get_image_source("Upload chart image")
        if img is not None:
            st.image(img, caption="Chart Image", use_container_width=True)
        extra = st.text_input("Additional context (optional):",
                              placeholder="e.g., This chart is from the Q3 claims report")

    with col2:
        if path and st.button("📊 Analyze Chart", type="primary", use_container_width=True):
            with st.spinner("Analyzing chart with GPT-4o..."):
                result = analyze_chart(path, extra)
            st.success("Analysis complete!")
            st.markdown(f"**Chart Type:** {result.chart_type}")
            st.markdown(f"**Title:** {result.title}")
            st.markdown(f"**X-Axis:** {result.x_axis}")
            st.markdown(f"**Y-Axis:** {result.y_axis}")
            st.markdown("**Key Data Points:**")
            for dp in result.data_points:
                st.markdown(f"- {dp}")
            st.markdown(f"**Trends:** {result.trends}")
            st.markdown("---")
            st.markdown(f"**Summary:** {result.summary}")

            with st.expander("Raw JSON"):
                st.json(result.model_dump())

# ---------------------------------------------------------------------------
# Mode: Compare Images
# ---------------------------------------------------------------------------
elif mode == "🔀 Compare Images":
    st.header("🔀 Image Comparison")
    st.markdown("Compare two images side by side (e.g., before/after damage photos).")

    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Image 1 (Before)")
        if use_sample:
            img1 = generate_damage_photo()
            path1 = save_pil_to_tempfile(img1)
            st.image(img1, caption="Before — Damage Photo", use_container_width=True)
        else:
            uploaded1 = st.file_uploader("Upload first image", type=["png", "jpg", "jpeg", "webp"],
                                         key="cmp1")
            path1, img1 = None, None
            if uploaded1:
                img1 = Image.open(uploaded1)
                path1 = save_uploaded_to_tempfile(uploaded1)
                st.image(img1, caption="Image 1", use_container_width=True)

    with col2:
        st.subheader("Image 2 (After)")
        if use_sample:
            img2 = generate_damage_photo_after()
            path2 = save_pil_to_tempfile(img2)
            st.image(img2, caption="After — Repaired", use_container_width=True)
        else:
            uploaded2 = st.file_uploader("Upload second image", type=["png", "jpg", "jpeg", "webp"],
                                         key="cmp2")
            path2, img2 = None, None
            if uploaded2:
                img2 = Image.open(uploaded2)
                path2 = save_uploaded_to_tempfile(uploaded2)
                st.image(img2, caption="Image 2", use_container_width=True)

    extra = st.text_input("Additional context (optional):",
                          placeholder="e.g., Compare before and after water damage repair")

    if use_sample:
        can_compare = True
    else:
        can_compare = path1 is not None and path2 is not None

    if can_compare and st.button("🔀 Compare Images", type="primary", use_container_width=True):
        with st.spinner("Comparing images with GPT-4o..."):
            result = compare_images(path1, path2, extra)
        st.success("Comparison complete!")

        col_sim, col_diff = st.columns(2)
        with col_sim:
            st.markdown("### ✅ Similarities")
            for s in result.similarities:
                st.markdown(f"- {s}")
        with col_diff:
            st.markdown("### ❌ Differences")
            for d in result.differences:
                st.markdown(f"- {d}")

        st.markdown("---")
        st.markdown(f"**Summary:** {result.summary}")

        with st.expander("Raw JSON"):
            st.json(result.model_dump())

# ---------------------------------------------------------------------------
# Mode: Custom Prompt
# ---------------------------------------------------------------------------
elif mode == "✏️ Custom Prompt":
    st.header("✏️ Custom Vision Prompt")
    st.markdown("Send any prompt with an image to GPT-4o Vision.")

    col1, col2 = st.columns([1, 1])
    with col1:
        path, img = get_image_source("Upload image", key="custom_img")
        if img is not None:
            st.image(img, caption="Input Image", use_container_width=True)

    with col2:
        prompt = st.text_area(
            "Your prompt:",
            height=150,
            placeholder="e.g., List all visible damage in this photo and estimate repair cost ranges.",
        )
        if path and prompt and st.button("🚀 Send to GPT-4o", type="primary", use_container_width=True):
            with st.spinner("Processing with GPT-4o Vision..."):
                result = freeform_vision(path, prompt)
            st.success("Done!")
            st.markdown(result)

# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------
st.markdown("---")
st.caption("Project 13 — GenAI Learning Roadmap • Multimodal AI with GPT-4o Vision • Port 8513")
