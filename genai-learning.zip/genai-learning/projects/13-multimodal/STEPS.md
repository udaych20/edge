# Project 13: Multimodal AI — Image + Text Processing with GPT-4o Vision

## Concept: Multimodal AI (Concept #21)

### What is Multimodal AI?
Multimodal AI processes **multiple types of input** — text, images, audio, video — in a single model. Unlike traditional AI that handles one modality at a time, multimodal models understand the *relationships* between different data types.

**GPT-4o** is OpenAI's flagship multimodal model. It natively accepts images alongside text prompts and can:
- Describe image contents in detail
- Extract text from documents (OCR-like capability)
- Interpret charts and graphs
- Compare multiple images
- Answer questions about visual content

### How the Vision API Works

```
┌──────────────┐     ┌─────────────────────────────────────┐
│  User Input  │     │  API Message Structure               │
│              │     │                                       │
│  Image       │────▶│  { role: "user",                     │
│  (file/URL)  │     │    content: [                        │
│              │     │      { type: "text", text: "..." },  │
│  + Prompt    │────▶│      { type: "image_url",            │
│  (text)      │     │        image_url: {                  │
│              │     │          url: "data:image/png;base64, │
└──────────────┘     │               ..." } } ] }           │
                     └──────────────┬──────────────────────┘
                                    │
                                    ▼
                     ┌─────────────────────────────────────┐
                     │         GPT-4o Vision Model          │
                     │                                       │
                     │  • Understands spatial layout          │
                     │  • Reads text in images (OCR)          │
                     │  • Interprets charts/graphs            │
                     │  • Detects objects and scenes           │
                     └──────────────┬──────────────────────┘
                                    │
                                    ▼
                     ┌─────────────────────────────────────┐
                     │  Structured Response                  │
                     │  (text, JSON, Pydantic model)         │
                     └─────────────────────────────────────┘
```

### Image Encoding Methods

1. **Base64 encoding** — Convert local files to base64 strings, embed in API request
   - Pro: Works with any local file, no hosting needed
   - Con: Increases request payload size

2. **URL reference** — Pass a publicly accessible image URL
   - Pro: Smaller payload, faster requests
   - Con: Image must be publicly accessible

### Real-World Scenario: Insurance Claims Processor

This project simulates an insurance claims processing system that:
- **Analyzes damage photos** — describe visible damage, estimate severity
- **Extracts form data** — read text from ID cards, receipts, claim forms
- **Reads charts** — interpret charts from adjuster reports
- **Compares images** — before/after damage comparison

### Analysis Modes

| Mode | Use Case | Output |
|------|----------|--------|
| **Describe** | General image description | Detailed text description |
| **Extract** | Document/receipt/ID OCR | Structured key-value data |
| **Chart** | Chart/graph interpretation | Data points, trends, summary |
| **Compare** | Side-by-side comparison | Differences and similarities |

## Project Structure

```
13-multimodal/
├── .env                # OpenAI API key
├── requirements.txt    # Dependencies
├── multimodal.py       # Core vision analysis engine
├── app.py              # Streamlit UI
└── STEPS.md            # This file
```

## Setup & Run

### 1. Install dependencies
```bash
cd 13-multimodal
pip install -r requirements.txt
```

### 2. Set environment variable
```bash
# .env file should contain:
OPENAI_API_KEY=sk-proj-...
```

### 3. Run CLI demo
```bash
python multimodal.py demo
```
This generates sample images using Pillow (no external files needed) and runs all analysis modes.

### 4. Run Streamlit app
```bash
streamlit run app.py --server.port 8513 --server.address 0.0.0.0
```

### 5. Deploy on Azure VM
```bash
# Copy files to VM
scp -r 13-multimodal/ azureuser@<VM_IP>:~/genai-projects/

# SSH and run
ssh azureuser@<VM_IP>
cd ~/genai-projects/13-multimodal
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8513 --server.headless true
```

Access at: `http://<VM_IP>:8513`

## Key Concepts Demonstrated

1. **Base64 image encoding** — Converting images for API consumption
2. **Multi-image messages** — Sending multiple images in one request (comparison mode)
3. **Prompt engineering for vision** — Crafting effective prompts for image analysis
4. **Structured extraction** — Parsing vision outputs into Pydantic models
5. **Synthetic test data** — Generating sample images with Pillow for self-contained demos
6. **Detail control** — Using `detail: "high"` vs `"low"` for cost/quality tradeoff

## API Cost Notes

- GPT-4o vision pricing depends on image size and `detail` setting
- `detail: "low"` — fixed cost, 512×512 thumbnailed
- `detail: "high"` — variable cost based on image tiles (512×512 each)
- Keep images reasonably sized to control costs
