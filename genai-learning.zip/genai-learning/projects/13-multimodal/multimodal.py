"""
Multimodal AI — Image + Text Analysis with GPT-4o Vision

Real-world scenario: Insurance Claims Processor
Analyzes damage photos, extracts form data, reads charts from reports.

Usage:
    python multimodal.py demo          # Generate sample images & run all analyses
    python multimodal.py describe <path>  # Describe an image
    python multimodal.py extract <path>   # Extract text/data from document image
    python multimodal.py chart <path>     # Analyze a chart/graph image
"""

import base64
import io
import json
import os
import sys
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI
from PIL import Image, ImageDraw, ImageFont
from pydantic import BaseModel, Field

load_dotenv()

client = OpenAI()
MODEL = "gpt-4o"

# ---------------------------------------------------------------------------
# Pydantic models for structured output
# ---------------------------------------------------------------------------

class ImageDescription(BaseModel):
    """Structured image description."""
    summary: str = Field(description="One-sentence summary of the image")
    objects: list[str] = Field(description="Key objects/elements visible")
    scene_type: str = Field(description="Type of scene (indoor, outdoor, document, chart, etc.)")
    colors: list[str] = Field(description="Dominant colors")
    details: str = Field(description="Detailed description")


class ExtractedDocument(BaseModel):
    """Structured data extracted from a document image."""
    document_type: str = Field(description="Type of document (receipt, ID, form, etc.)")
    fields: dict[str, str] = Field(description="Extracted key-value pairs")
    raw_text: str = Field(description="All visible text concatenated")
    confidence_notes: str = Field(description="Notes on extraction confidence or ambiguity")


class ChartAnalysis(BaseModel):
    """Structured chart/graph analysis."""
    chart_type: str = Field(description="Type of chart (bar, line, pie, scatter, etc.)")
    title: str = Field(description="Chart title if visible")
    x_axis: str = Field(description="X-axis label or description")
    y_axis: str = Field(description="Y-axis label or description")
    data_points: list[str] = Field(description="Key data points or values")
    trends: str = Field(description="Observed trends or patterns")
    summary: str = Field(description="Plain-English summary of what the chart shows")


class ComparisonResult(BaseModel):
    """Structured comparison of two images."""
    similarities: list[str] = Field(description="Things that are similar between the images")
    differences: list[str] = Field(description="Things that differ between the images")
    summary: str = Field(description="Overall comparison summary")


# ---------------------------------------------------------------------------
# Image encoding utilities
# ---------------------------------------------------------------------------

def encode_image_to_base64(image_path: str) -> str:
    """Read an image file and return its base64 encoding."""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def encode_pil_image(img: Image.Image, fmt: str = "PNG") -> str:
    """Encode a PIL Image object to base64."""
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


def make_image_content(source: str, detail: str = "high") -> dict:
    """
    Build the image_url content block for the API.
    `source` can be a file path or an HTTP(S) URL.
    """
    if source.startswith(("http://", "https://")):
        url = source
    else:
        ext = Path(source).suffix.lower().lstrip(".")
        mime = {"jpg": "jpeg", "jpeg": "jpeg", "png": "png",
                "gif": "gif", "webp": "webp"}.get(ext, "png")
        b64 = encode_image_to_base64(source)
        url = f"data:image/{mime};base64,{b64}"
    return {"type": "image_url", "image_url": {"url": url, "detail": detail}}


def make_pil_image_content(img: Image.Image, detail: str = "high") -> dict:
    """Build image_url content block from a PIL Image."""
    b64 = encode_pil_image(img)
    url = f"data:image/png;base64,{b64}"
    return {"type": "image_url", "image_url": {"url": url, "detail": detail}}


# ---------------------------------------------------------------------------
# Core analysis functions
# ---------------------------------------------------------------------------

def analyze_image(
    source: str,
    prompt: str,
    detail: str = "high",
    max_tokens: int = 1024,
) -> str:
    """Send an image + text prompt to GPT-4o and return the text response."""
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                make_image_content(source, detail=detail),
            ],
        }
    ]
    resp = client.chat.completions.create(
        model=MODEL, messages=messages, max_tokens=max_tokens
    )
    return resp.choices[0].message.content


def describe_image(source: str, extra_context: str = "") -> ImageDescription:
    """Describe an image and return structured output."""
    prompt = (
        "Analyze this image in detail. Respond with valid JSON matching this schema:\n"
        '{"summary": "...", "objects": ["..."], "scene_type": "...", '
        '"colors": ["..."], "details": "..."}\n'
    )
    if extra_context:
        prompt += f"\nAdditional context: {extra_context}"
    raw = analyze_image(source, prompt)
    return _parse_json_response(raw, ImageDescription)


def extract_document(source: str, extra_context: str = "") -> ExtractedDocument:
    """Extract text and structured data from a document image."""
    prompt = (
        "You are an OCR and document analysis expert. Extract all text and data "
        "from this document image. Identify the document type and pull out key fields.\n"
        "Respond with valid JSON matching this schema:\n"
        '{"document_type": "...", "fields": {"key": "value", ...}, '
        '"raw_text": "...", "confidence_notes": "..."}\n'
    )
    if extra_context:
        prompt += f"\nAdditional context: {extra_context}"
    raw = analyze_image(source, prompt)
    return _parse_json_response(raw, ExtractedDocument)


def analyze_chart(source: str, extra_context: str = "") -> ChartAnalysis:
    """Analyze a chart or graph image."""
    prompt = (
        "You are a data visualization expert. Analyze this chart/graph image.\n"
        "Identify the chart type, axes, data points, and trends.\n"
        "Respond with valid JSON matching this schema:\n"
        '{"chart_type": "...", "title": "...", "x_axis": "...", "y_axis": "...", '
        '"data_points": ["..."], "trends": "...", "summary": "..."}\n'
    )
    if extra_context:
        prompt += f"\nAdditional context: {extra_context}"
    raw = analyze_image(source, prompt)
    return _parse_json_response(raw, ChartAnalysis)


def compare_images(
    source1: str, source2: str, extra_context: str = ""
) -> ComparisonResult:
    """Compare two images side by side."""
    prompt = (
        "Compare these two images carefully. Identify similarities and differences.\n"
        "Respond with valid JSON matching this schema:\n"
        '{"similarities": ["..."], "differences": ["..."], "summary": "..."}\n'
    )
    if extra_context:
        prompt += f"\nAdditional context: {extra_context}"

    content = [
        {"type": "text", "text": prompt},
        make_image_content(source1),
        make_image_content(source2),
    ]
    messages = [{"role": "user", "content": content}]
    resp = client.chat.completions.create(
        model=MODEL, messages=messages, max_tokens=1024
    )
    raw = resp.choices[0].message.content
    return _parse_json_response(raw, ComparisonResult)


def freeform_vision(source: str, prompt: str) -> str:
    """Send any custom prompt with an image. Returns raw text."""
    return analyze_image(source, prompt)


# ---------------------------------------------------------------------------
# JSON parsing helper
# ---------------------------------------------------------------------------

def _parse_json_response(raw: str, model_cls):
    """Extract JSON from a GPT response (handles markdown fences) and validate."""
    text = raw.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        data = json.loads(text)
        return model_cls(**data)
    except (json.JSONDecodeError, Exception):
        # Fallback: try to find JSON object in the text
        start = text.find("{")
        end = text.rfind("}") + 1
        if start != -1 and end > start:
            try:
                data = json.loads(text[start:end])
                return model_cls(**data)
            except Exception:
                pass
        # Last resort: return a minimal valid model
        return model_cls.model_construct(
            **{f.alias or name: f"[Parse error] {raw[:200]}"
               for name, f in model_cls.model_fields.items()}
        )


# ---------------------------------------------------------------------------
# Sample image generators (Pillow) — self-contained demo data
# ---------------------------------------------------------------------------

def _get_font(size: int = 14):
    """Get a font, falling back to default if no TTF available."""
    try:
        return ImageFont.truetype("arial.ttf", size)
    except (OSError, IOError):
        try:
            return ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", size)
        except (OSError, IOError):
            return ImageFont.load_default()


def generate_bar_chart_image() -> Image.Image:
    """Generate a simple bar chart image using Pillow."""
    width, height = 500, 400
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)
    font = _get_font(14)
    title_font = _get_font(18)

    # Title
    draw.text((120, 15), "Insurance Claims by Category", fill="black", font=title_font)

    # Data
    categories = ["Auto", "Home", "Health", "Life", "Travel"]
    values = [450, 320, 280, 150, 90]
    colors = ["#4472C4", "#ED7D31", "#A5A5A5", "#FFC000", "#5B9BD5"]
    max_val = max(values)

    # Axes
    left, bottom, right, top = 80, 340, 460, 60
    draw.line([(left, top), (left, bottom)], fill="black", width=2)
    draw.line([(left, bottom), (right, bottom)], fill="black", width=2)

    # Y-axis labels
    for i in range(5):
        y = bottom - (i / 4) * (bottom - top)
        val = int(max_val * i / 4)
        draw.text((30, y - 8), str(val), fill="black", font=font)
        draw.line([(left, y), (right, y)], fill="#DDDDDD", width=1)

    # Bars
    bar_width = 50
    gap = 25
    for i, (cat, val, color) in enumerate(zip(categories, values, colors)):
        x = left + 20 + i * (bar_width + gap)
        bar_height = (val / max_val) * (bottom - top)
        y_top = bottom - bar_height
        draw.rectangle([x, y_top, x + bar_width, bottom], fill=color)
        draw.text((x + 5, bottom + 8), cat, fill="black", font=font)
        draw.text((x + 10, y_top - 18), str(val), fill="black", font=font)

    # Y-axis label
    draw.text((10, 180), "Count", fill="black", font=font)

    return img


def generate_receipt_image() -> Image.Image:
    """Generate a simple receipt-like document image using Pillow."""
    width, height = 350, 500
    img = Image.new("RGB", (width, height), "#FFFFF0")
    draw = ImageDraw.Draw(img)
    font = _get_font(14)
    title_font = _get_font(18)
    small_font = _get_font(12)

    y = 20
    draw.text((100, y), "ACME INSURANCE", fill="black", font=title_font); y += 30
    draw.text((110, y), "Claims Receipt", fill="gray", font=font); y += 25
    draw.line([(20, y), (330, y)], fill="black", width=1); y += 15

    lines = [
        ("Claim #:", "CLM-2024-08542"),
        ("Date:", "2024-11-15"),
        ("Policy Holder:", "John A. Smith"),
        ("Policy #:", "POL-HM-992841"),
        ("Type:", "Homeowner"),
        ("Category:", "Water Damage"),
    ]
    for label, value in lines:
        draw.text((30, y), label, fill="black", font=font)
        draw.text((170, y), value, fill="black", font=font)
        y += 25

    draw.line([(20, y), (330, y)], fill="black", width=1); y += 15
    draw.text((30, y), "DAMAGE ASSESSMENT", fill="black", font=title_font); y += 30

    items = [
        ("Kitchen flooding", "$4,500.00"),
        ("Cabinet replacement", "$2,200.00"),
        ("Floor repair", "$3,100.00"),
        ("Mold remediation", "$1,800.00"),
    ]
    for desc, amt in items:
        draw.text((30, y), desc, fill="black", font=font)
        draw.text((250, y), amt, fill="black", font=font)
        y += 22

    draw.line([(20, y + 5), (330, y + 5)], fill="black", width=2); y += 15
    draw.text((30, y), "TOTAL ESTIMATE:", fill="black", font=title_font)
    draw.text((230, y), "$11,600.00", fill="black", font=title_font); y += 35

    draw.text((30, y), "Status: PENDING REVIEW", fill="red", font=font); y += 25
    draw.text((30, y), "Adjuster: Maria Garcia", fill="gray", font=small_font); y += 20
    draw.text((30, y), "Office: 555-0142", fill="gray", font=small_font)

    # Border
    draw.rectangle([5, 5, width - 5, height - 5], outline="black", width=2)

    return img


def generate_damage_photo() -> Image.Image:
    """Generate a simple colored image simulating a 'damage scene' with annotations."""
    width, height = 500, 400
    img = Image.new("RGB", (width, height), "#8B7355")
    draw = ImageDraw.Draw(img)
    font = _get_font(14)
    title_font = _get_font(16)

    # Simulate a room with water damage
    # Floor
    draw.rectangle([0, 250, 500, 400], fill="#6B4226")
    # Wall
    draw.rectangle([0, 0, 500, 250], fill="#D2B48C")
    # Water stain on wall
    draw.ellipse([100, 120, 280, 240], fill="#7BA3B0", outline="#5A8A9A")
    draw.ellipse([130, 150, 250, 230], fill="#8AB5C2")
    # Window
    draw.rectangle([320, 40, 440, 160], outline="white", width=3)
    draw.line([(380, 40), (380, 160)], fill="white", width=2)
    draw.line([(320, 100), (440, 100)], fill="white", width=2)
    draw.rectangle([322, 42, 378, 98], fill="#87CEEB")
    draw.rectangle([382, 42, 438, 98], fill="#87CEEB")
    draw.rectangle([322, 102, 378, 158], fill="#87CEEB")
    draw.rectangle([382, 102, 438, 158], fill="#87CEEB")
    # Water on floor
    draw.ellipse([50, 270, 300, 370], fill="#5A8A9A", outline="#4A7A8A")
    # Baseboard
    draw.rectangle([0, 245, 500, 255], fill="#8B6914")
    # Damaged baseboard section
    draw.rectangle([80, 245, 260, 255], fill="#5A4A0A")

    # Annotations
    draw.text((110, 100), "Water stain", fill="red", font=title_font)
    draw.text((100, 280), "Standing water", fill="yellow", font=title_font)
    draw.text((80, 230), "Damaged baseboard", fill="red", font=font)

    # Label
    draw.rectangle([0, 0, 500, 30], fill="black")
    draw.text((10, 5), "CLAIM CLM-2024-08542 — Kitchen Water Damage", fill="white", font=title_font)

    return img


def generate_damage_photo_after() -> Image.Image:
    """Generate an 'after repair' version of the damage photo for comparison."""
    width, height = 500, 400
    img = Image.new("RGB", (width, height), "#8B7355")
    draw = ImageDraw.Draw(img)
    font = _get_font(14)
    title_font = _get_font(16)

    # Same room, repaired
    # Floor (clean)
    draw.rectangle([0, 250, 500, 400], fill="#8B6B4A")
    # Wall (repainted)
    draw.rectangle([0, 0, 500, 250], fill="#E8DCC8")
    # No water stain — clean wall
    # Window
    draw.rectangle([320, 40, 440, 160], outline="white", width=3)
    draw.line([(380, 40), (380, 160)], fill="white", width=2)
    draw.line([(320, 100), (440, 100)], fill="white", width=2)
    draw.rectangle([322, 42, 378, 98], fill="#87CEEB")
    draw.rectangle([382, 42, 438, 98], fill="#87CEEB")
    draw.rectangle([322, 102, 378, 158], fill="#87CEEB")
    draw.rectangle([382, 102, 438, 158], fill="#87CEEB")
    # New baseboard
    draw.rectangle([0, 245, 500, 255], fill="#C4A454")
    # Clean floor
    draw.rectangle([50, 290, 300, 295], fill="#9B7B5A")

    # Annotations
    draw.text((110, 140), "Wall repainted", fill="green", font=title_font)
    draw.text((100, 310), "Floor dried & cleaned", fill="green", font=title_font)
    draw.text((80, 230), "New baseboard installed", fill="green", font=font)

    # Label
    draw.rectangle([0, 0, 500, 30], fill="black")
    draw.text((10, 5), "CLAIM CLM-2024-08542 — After Repair", fill="white", font=title_font)

    return img


# ---------------------------------------------------------------------------
# CLI demo
# ---------------------------------------------------------------------------

def run_demo():
    """Generate sample images and run all analysis modes."""
    output_dir = Path(__file__).parent / "sample_output"
    output_dir.mkdir(exist_ok=True)

    print("=" * 60)
    print("  Multimodal AI Demo — Insurance Claims Processor")
    print("=" * 60)

    # 1. Generate sample images
    print("\n[1/5] Generating sample images with Pillow...")
    chart_img = generate_bar_chart_image()
    receipt_img = generate_receipt_image()
    damage_img = generate_damage_photo()
    after_img = generate_damage_photo_after()

    chart_path = output_dir / "bar_chart.png"
    receipt_path = output_dir / "receipt.png"
    damage_path = output_dir / "damage_before.png"
    after_path = output_dir / "damage_after.png"

    chart_img.save(chart_path)
    receipt_img.save(receipt_path)
    damage_img.save(damage_path)
    after_img.save(after_path)
    print(f"   Saved to {output_dir}/")

    # 2. Image Description
    print("\n[2/5] Analyzing damage photo (Describe mode)...")
    desc = describe_image(str(damage_path), "This is a photo from an insurance claim for water damage.")
    print(f"   Summary: {desc.summary}")
    print(f"   Scene type: {desc.scene_type}")
    print(f"   Objects: {', '.join(desc.objects)}")
    print(f"   Details: {desc.details[:200]}...")

    # 3. Document Extraction
    print("\n[3/5] Extracting data from receipt (Extract mode)...")
    doc = extract_document(str(receipt_path), "This is an insurance claim receipt.")
    print(f"   Document type: {doc.document_type}")
    print(f"   Fields extracted:")
    for k, v in doc.fields.items():
        print(f"     {k}: {v}")

    # 4. Chart Analysis
    print("\n[4/5] Analyzing bar chart (Chart mode)...")
    chart = analyze_chart(str(chart_path), "This chart is from an insurance company's annual report.")
    print(f"   Chart type: {chart.chart_type}")
    print(f"   Title: {chart.title}")
    print(f"   Summary: {chart.summary}")
    print(f"   Trends: {chart.trends}")

    # 5. Comparison
    print("\n[5/5] Comparing before/after photos (Compare mode)...")
    comp = compare_images(str(damage_path), str(after_path),
                          "Compare these before and after photos from an insurance water damage claim.")
    print(f"   Summary: {comp.summary}")
    print(f"   Similarities: {', '.join(comp.similarities[:3])}")
    print(f"   Differences: {', '.join(comp.differences[:3])}")

    print("\n" + "=" * 60)
    print("  Demo complete! All analysis modes demonstrated.")
    print("=" * 60)


def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python multimodal.py demo                # Run full demo")
        print("  python multimodal.py describe <image>     # Describe an image")
        print("  python multimodal.py extract <image>      # Extract document data")
        print("  python multimodal.py chart <image>        # Analyze a chart")
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "demo":
        run_demo()
    elif cmd == "describe" and len(sys.argv) >= 3:
        result = describe_image(sys.argv[2])
        print(result.model_dump_json(indent=2))
    elif cmd == "extract" and len(sys.argv) >= 3:
        result = extract_document(sys.argv[2])
        print(result.model_dump_json(indent=2))
    elif cmd == "chart" and len(sys.argv) >= 3:
        result = analyze_chart(sys.argv[2])
        print(result.model_dump_json(indent=2))
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    main()
