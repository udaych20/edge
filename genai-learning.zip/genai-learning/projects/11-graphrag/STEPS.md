# P11 – GraphRAG: Fraud Investigation Network

## Concept

**GraphRAG** combines knowledge graphs with retrieval-augmented generation. Instead of
retrieving flat text chunks (standard RAG), we extract **entities** and **relationships**
from documents, build a **knowledge graph**, and use graph traversal to retrieve
structurally-connected context before generating an answer.

### Why GraphRAG?

| Standard RAG | GraphRAG |
|---|---|
| Chunks text, embeds, retrieves by similarity | Extracts entities/relationships, traverses graph |
| Good for factoid Q&A | Good for multi-hop reasoning, network analysis |
| Misses connections across documents | Finds hidden connections via graph paths |
| Context = top-K chunks | Context = subgraph (neighbors, paths, communities) |

### Real-World Scenario: Fraud Investigation

Financial investigators analyze case files looking for:
- Shell companies connected to the same beneficial owner
- Money trails across multiple accounts and jurisdictions
- Patterns of transactions that suggest layering or structuring
- Networks of related individuals and entities

GraphRAG excels here because fraud patterns are inherently **relational** — they
live in the connections between entities, not in any single document.

## Architecture

```
Case Files (text)
       │
       ▼
┌──────────────┐
│  Entity &    │  OpenAI extracts people, companies,
│  Relation    │  accounts, transactions + relationships
│  Extraction  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  NetworkX    │  Build directed graph:
│  Knowledge   │  nodes = entities
│  Graph       │  edges = relationships
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Graph       │  Given query → find relevant subgraph
│  Retrieval   │  (neighbors, shortest paths, communities)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  LLM Answer  │  Combine graph context + original text
│  Generation  │  → structured fraud analysis answer
└──────────────┘
```

## Key Patterns Demonstrated

1. **Entity Extraction** — Using OpenAI structured outputs to pull typed entities
   (Person, Company, Account, Transaction) from unstructured case narratives.

2. **Relationship Extraction** — Identifying and typing connections: `owns`,
   `transferred_to`, `works_at`, `related_to`, `received_from`.

3. **Knowledge Graph Construction** — Building a NetworkX directed graph with
   typed nodes and weighted, labeled edges.

4. **Graph Traversal for Retrieval** — Instead of vector similarity, we traverse
   the graph: neighbors, shortest paths, connected components.

5. **Community Detection** — Using Louvain-style algorithms to find clusters of
   tightly connected entities (potential fraud rings).

6. **Graph-Enhanced RAG** — Combining graph-structural context with source text
   to produce richer, more connected answers.

## Files

| File | Purpose |
|------|---------|
| `graph_rag.py` | Core: extraction, graph building, retrieval, answer generation |
| `app.py` | Streamlit UI with graph visualization and query interface |
| `requirements.txt` | Dependencies |
| `.env` | OpenAI API key |

## Setup & Run

### 1. Install Dependencies

```bash
cd 11-graphrag
pip install -r requirements.txt
```

### 2. Set API Key

```bash
cp .env.example .env
# Edit .env with your OpenAI API key
```

### 3. Run CLI Demo

```bash
python graph_rag.py demo
```

This runs the full pipeline end-to-end:
- Loads sample fraud case narratives
- Extracts entities and relationships via OpenAI
- Builds the knowledge graph
- Detects communities
- Runs sample queries with graph-enhanced answers

### 4. Run Streamlit UI

```bash
streamlit run app.py --server.port 8511 --server.headless true
```

Open `http://localhost:8511` in your browser.

### 5. Deploy on Azure VM

```bash
# SSH into VM
ssh azureuser@<VM_IP>

# Navigate to project
cd ~/genai-projects/11-graphrag

# Install deps
pip install -r requirements.txt

# Run in background
nohup streamlit run app.py --server.address 0.0.0.0 --server.port 8511 --server.headless true > streamlit.log 2>&1 &
```

## Sample Queries

- "Trace the money flow from Oceanic Trading Ltd"
- "Who is connected to Viktor Petrov?"
- "Find all shell companies in the network"
- "What fraud patterns exist in the Pacific Rim cluster?"
- "Show the relationship between Marcus Chen and Apex Holdings"

## How It Works — Step by Step

### Step 1: Entity Extraction

Given a case narrative like:

> "Viktor Petrov, CEO of Oceanic Trading Ltd, authorized wire transfers totaling
> $2.3M to Apex Holdings registered in the Cayman Islands..."

The system extracts:
- **Person**: Viktor Petrov (role: CEO)
- **Company**: Oceanic Trading Ltd, Apex Holdings
- **Transaction**: $2.3M wire transfer

### Step 2: Relationship Extraction

From the same text:
- Viktor Petrov → `works_at` → Oceanic Trading Ltd
- Oceanic Trading Ltd → `transferred_to` → Apex Holdings ($2.3M)

### Step 3: Graph Construction

All entities become **nodes** (with type and attributes).
All relationships become **directed edges** (with label and metadata).

### Step 4: Query Processing

For "Trace money from Oceanic Trading":
1. Find the "Oceanic Trading Ltd" node
2. Traverse outgoing `transferred_to` edges
3. Follow chains: Oceanic → Apex → next account → ...
4. Collect all connected entities within 2-3 hops
5. Format as graph context

### Step 5: Answer Generation

The LLM receives:
- Original query
- Graph context (entities, relationships, paths)
- Source case text
- Instruction to synthesize a fraud analysis

## Concepts Covered

- **Concept 18**: GraphRAG — Graph-enhanced retrieval augmented generation
- Entity/relationship extraction from unstructured text
- Knowledge graph construction and traversal
- Community detection and clustering
- Graph-aware context retrieval
- Multi-hop reasoning over connected data
