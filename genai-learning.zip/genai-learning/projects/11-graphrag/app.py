"""
P11 – GraphRAG: Fraud Investigation Network — Streamlit UI
============================================================
Interactive knowledge graph exploration and graph-enhanced Q&A.
"""

import streamlit as st

from graph_rag import (
    DEMO_QUERIES,
    FRAUD_CASES,
    FraudKnowledgeGraph,
    format_adjacency_matrix,
    query_graph_rag,
)

st.set_page_config(page_title="P11 – GraphRAG", page_icon="🕸️", layout="wide")

st.title("🕸️ P11 – GraphRAG: Fraud Investigation Network")
st.caption("Knowledge graph extraction + graph-enhanced RAG for fraud analysis")


# ---------------------------------------------------------------------------
# Session state: build graph once
# ---------------------------------------------------------------------------

def build_knowledge_graph() -> FraudKnowledgeGraph:
    """Build the knowledge graph from fraud cases (cached in session state)."""
    kg = FraudKnowledgeGraph()
    kg.build_from_cases(FRAUD_CASES, verbose=False)
    return kg


if "kg" not in st.session_state:
    with st.spinner("🔨 Building knowledge graph from case files... (this calls OpenAI for extraction)"):
        st.session_state["kg"] = build_knowledge_graph()
    st.session_state["communities"] = st.session_state["kg"].detect_communities()

kg: FraudKnowledgeGraph = st.session_state["kg"]
communities: list[list[str]] = st.session_state["communities"]


# ---------------------------------------------------------------------------
# Sidebar: Graph overview & sample queries
# ---------------------------------------------------------------------------

with st.sidebar:
    st.header("📊 Graph Statistics")
    summary = kg.get_graph_summary()
    st.metric("Total Entities", summary["total_nodes"])
    st.metric("Total Relationships", summary["total_edges"])
    st.metric("Connected Components", summary["connected_components"])

    st.divider()
    st.subheader("Entity Types")
    for etype, count in sorted(summary["entity_types"].items()):
        st.write(f"**{etype}**: {count}")

    st.divider()
    st.subheader("Relationship Types")
    for rtype, count in sorted(summary["relationship_types"].items()):
        st.write(f"**{rtype}**: {count}")

    st.divider()
    st.header("💡 Example Queries")
    for i, q in enumerate(DEMO_QUERIES):
        if st.button(q[:55] + ("..." if len(q) > 55 else ""), key=f"demo_{i}", use_container_width=True):
            st.session_state["query_input"] = q


# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------

tab_query, tab_graph, tab_communities, tab_cases = st.tabs([
    "🔍 Query", "🕸️ Knowledge Graph", "👥 Communities", "📁 Case Files"
])


# ---------------------------------------------------------------------------
# Tab 1: Query Interface
# ---------------------------------------------------------------------------

with tab_query:
    default_q = st.session_state.get("query_input", "")
    query = st.text_area(
        "Enter your investigation query:",
        value=default_q,
        height=80,
        placeholder="e.g., Trace the money flow from Oceanic Trading Ltd",
    )

    if st.button("🚀 Investigate", type="primary", use_container_width=True):
        if not query.strip():
            st.warning("⚠️ Please enter an investigation query or select an example from the sidebar.")
        else:
            with st.spinner("🔍 Traversing knowledge graph and generating analysis..."):
                result = query_graph_rag(kg, query)

            # Metrics row
            c1, c2, c3 = st.columns(3)
            c1.metric("Entities in Context", result.entity_count)
            c2.metric("Relationships in Context", result.relationship_count)
            c3.metric("Paths Found", len(result.graph_context.paths))

            # Answer
            st.markdown("### 📝 Analysis")
            st.markdown(result.answer)

            # Graph context details
            with st.expander("📊 Graph Context Details", expanded=False):
                st.markdown("#### Relevant Entities")
                if result.graph_context.relevant_entities:
                    for entity in result.graph_context.relevant_entities:
                        etype = entity.get("entity_type", "unknown")
                        name = entity.get("name", "?")
                        icon = {"person": "👤", "company": "🏢", "account": "💳",
                                "transaction": "💰", "location": "📍"}.get(etype, "📌")
                        st.write(f"{icon} **{name}** ({etype})")
                else:
                    st.info("No specific entities matched the query. Full graph context was used.")

                st.markdown("#### Relevant Relationships")
                if result.graph_context.relevant_relationships:
                    for rel in result.graph_context.relevant_relationships:
                        st.write(
                            f"  {rel['source']} → **{rel.get('rel_type', '?')}** → {rel['target']}"
                        )

                if result.graph_context.paths:
                    st.markdown("#### Paths Discovered")
                    for path in result.graph_context.paths:
                        st.write(" → ".join(path))


# ---------------------------------------------------------------------------
# Tab 2: Knowledge Graph Visualization
# ---------------------------------------------------------------------------

with tab_graph:
    st.markdown("### Knowledge Graph Structure")
    st.markdown(
        "Explore the full knowledge graph. Each entity shows its outgoing and "
        "incoming relationships."
    )

    # Entity search
    search_entity = st.text_input(
        "🔎 Search for an entity:", placeholder="e.g., Viktor Petrov"
    )

    if search_entity:
        matches = kg.find_entity(search_entity)
        if matches:
            for match in matches:
                info = kg.get_entity_info(match)
                if info:
                    st.markdown(f"---\n#### 📌 {info['name']}")
                    attrs = info["attributes"]
                    etype = attrs.pop("entity_type", "unknown")
                    case = attrs.pop("source_case", "")
                    st.write(f"**Type**: {etype} | **Source**: {case}")
                    if attrs:
                        st.write(f"**Attributes**: {attrs}")

                    if info["outgoing_relationships"]:
                        st.markdown("**Outgoing →**")
                        for rel in info["outgoing_relationships"]:
                            target = rel.pop("target")
                            rtype = rel.pop("rel_type", "?")
                            st.write(f"  → **{rtype}** → {target}")

                    if info["incoming_relationships"]:
                        st.markdown("**← Incoming**")
                        for rel in info["incoming_relationships"]:
                            source = rel.pop("source")
                            rtype = rel.pop("rel_type", "?")
                            st.write(f"  ← **{rtype}** ← {source}")
        else:
            st.warning(f"No entities found matching '{search_entity}'")

    # Full adjacency view
    with st.expander("📋 Full Graph (Adjacency View)", expanded=not bool(search_entity)):
        adj_text = format_adjacency_matrix(kg)
        if adj_text:
            st.text(adj_text)
        else:
            st.info("Graph is empty.")

    # Edge list
    with st.expander("📑 All Relationships (Edge List)"):
        edge_data = []
        for u, v, data in kg.graph.edges(data=True):
            edge_data.append({
                "Source": u,
                "Relationship": data.get("rel_type", "?"),
                "Target": v,
                "Case": data.get("source_case", ""),
            })
        if edge_data:
            st.dataframe(edge_data, use_container_width=True)


# ---------------------------------------------------------------------------
# Tab 3: Community Detection
# ---------------------------------------------------------------------------

with tab_communities:
    st.markdown("### 👥 Community Clusters")
    st.markdown(
        "Communities are groups of tightly connected entities — potential fraud rings "
        "or related investigation targets."
    )

    if communities:
        for i, comm in enumerate(communities):
            with st.expander(f"Community {i + 1} ({len(comm)} members)", expanded=(i < 3)):
                # Categorize members
                people = []
                companies = []
                others = []
                for member in comm:
                    node_data = kg.graph.nodes.get(member, {})
                    etype = node_data.get("entity_type", "unknown")
                    if etype == "person":
                        people.append(member)
                    elif etype == "company":
                        companies.append(member)
                    else:
                        others.append(member)

                if people:
                    st.markdown("**👤 People:** " + ", ".join(people))
                if companies:
                    st.markdown("**🏢 Companies:** " + ", ".join(companies))
                if others:
                    st.markdown("**📌 Other:** " + ", ".join(others))

                # Internal edges
                internal_edges = [
                    (u, v, d) for u, v, d in kg.graph.edges(data=True)
                    if u in comm and v in comm
                ]
                if internal_edges:
                    st.markdown("**Internal connections:**")
                    for u, v, d in internal_edges:
                        st.write(f"  {u} → [{d.get('rel_type', '?')}] → {v}")
    else:
        st.info("No communities detected.")


# ---------------------------------------------------------------------------
# Tab 4: Source Case Files
# ---------------------------------------------------------------------------

with tab_cases:
    st.markdown("### 📁 Source Fraud Case Files")
    st.markdown("These are the raw case narratives used to build the knowledge graph.")

    for case in FRAUD_CASES:
        with st.expander(f"📄 {case['id']}: {case['title']}"):
            st.markdown(case["narrative"])

            # Show entities extracted from this case
            case_entities = [
                node for node, data in kg.graph.nodes(data=True)
                if data.get("source_case") == case["id"]
            ]
            if case_entities:
                st.markdown("**Extracted entities:** " + ", ".join(case_entities))

            case_edges = [
                (u, v, d) for u, v, d in kg.graph.edges(data=True)
                if d.get("source_case") == case["id"]
            ]
            if case_edges:
                st.markdown("**Extracted relationships:**")
                for u, v, d in case_edges:
                    st.write(f"  {u} → [{d.get('rel_type', '?')}] → {v}")
