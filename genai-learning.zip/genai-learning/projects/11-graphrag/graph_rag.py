"""
P11 – GraphRAG: Fraud Investigation Network
=============================================
Core implementation: entity/relationship extraction, knowledge graph
construction, graph-based retrieval, and LLM answer generation.

Run:  python graph_rag.py demo
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import networkx as nx
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI()
MODEL = "gpt-4o-mini"

# ---------------------------------------------------------------------------
# Domain Models
# ---------------------------------------------------------------------------

class EntityType(str, Enum):
    PERSON = "person"
    COMPANY = "company"
    ACCOUNT = "account"
    TRANSACTION = "transaction"
    LOCATION = "location"


class RelationshipType(str, Enum):
    OWNS = "owns"
    WORKS_AT = "works_at"
    TRANSFERRED_TO = "transferred_to"
    RECEIVED_FROM = "received_from"
    RELATED_TO = "related_to"
    REGISTERED_IN = "registered_in"
    DIRECTED_BY = "directed_by"


@dataclass
class Entity:
    """A typed entity extracted from case text."""
    name: str
    entity_type: EntityType
    attributes: dict[str, str] = field(default_factory=dict)
    source_case: str = ""

    @property
    def id(self) -> str:
        return f"{self.entity_type.value}:{self.name}"


@dataclass
class Relationship:
    """A directed relationship between two entities."""
    source: str
    target: str
    rel_type: RelationshipType
    attributes: dict[str, str] = field(default_factory=dict)
    source_case: str = ""


@dataclass
class GraphContext:
    """Retrieved graph context for a query."""
    relevant_entities: list[dict[str, Any]]
    relevant_relationships: list[dict[str, Any]]
    paths: list[list[str]]
    communities: list[list[str]]
    source_texts: list[str]


@dataclass
class GraphRAGResult:
    """Final result from a GraphRAG query."""
    query: str
    answer: str
    graph_context: GraphContext
    entity_count: int
    relationship_count: int


# ---------------------------------------------------------------------------
# Sample Fraud Case Data
# ---------------------------------------------------------------------------

FRAUD_CASES: list[dict[str, str]] = [
    {
        "id": "CASE-2024-001",
        "title": "Pacific Rim Shell Company Network",
        "narrative": (
            "Investigation into Oceanic Trading Ltd, a Hong Kong-registered import/export "
            "company. CEO Viktor Petrov authorized wire transfers totaling $2.3 million to "
            "Apex Holdings, a shell company registered in the Cayman Islands. Apex Holdings "
            "is directed by Elena Volkov, who also serves as a silent partner in Oceanic "
            "Trading Ltd. Forensic accounting revealed that Apex Holdings subsequently "
            "transferred $1.8 million to Pinnacle Ventures Ltd in Panama, which is owned "
            "by Marcus Chen. Marcus Chen is the brother-in-law of Viktor Petrov. Pinnacle "
            "Ventures maintains Account #CH-8820-4491 at Zurich Federal Bank. Additional "
            "analysis shows that Oceanic Trading Ltd received $3.1 million from Golden "
            "Dragon Imports, a company with no verifiable business operations, suggesting "
            "it may be a front company for laundering proceeds."
        ),
    },
    {
        "id": "CASE-2024-002",
        "title": "Real Estate Layering Scheme",
        "narrative": (
            "Federal investigators uncovered a real estate layering scheme orchestrated by "
            "Sofia Ramirez through her company, Emerald Property Group. Emerald Property "
            "Group purchased three commercial properties in Miami valued at $4.7 million "
            "using funds wired from Crescent Finance LLC, a Delaware-registered entity. "
            "Crescent Finance LLC is owned by James O'Sullivan, a known associate of Sofia "
            "Ramirez. Bank records show Crescent Finance received funds from Account "
            "#BZ-3301-7742 at Belize National Bank, which is held by Luca Moretti. Moretti "
            "operates Adriatic Consulting Group in Montenegro. The properties were quickly "
            "resold to Pacific Coast Realty, owned by David Park, at a 15% markup within "
            "60 days — a hallmark of layering. David Park previously worked at Emerald "
            "Property Group as VP of Acquisitions."
        ),
    },
    {
        "id": "CASE-2024-003",
        "title": "Cryptocurrency Structuring Operation",
        "narrative": (
            "Law enforcement identified a cryptocurrency structuring ring led by Yuki Tanaka. "
            "Tanaka operates NovaCrypt Exchange, an unlicensed virtual asset service provider "
            "based in Singapore. NovaCrypt Exchange processed over $5.2 million in Bitcoin "
            "transactions for clients including Viktor Petrov and Sofia Ramirez — both subjects "
            "of separate ongoing investigations. Funds were converted through NovaCrypt into "
            "stablecoins and routed to Atlas Digital Wallet, a platform controlled by Omar "
            "Hassan. Atlas Digital Wallet transferred $2.1 million USDT to Account #SG-6650-1123 "
            "at Pacific Union Bank, held by Pinnacle Ventures Ltd. This creates a direct link "
            "between the Pacific Rim case (CASE-2024-001) and the crypto structuring operation. "
            "Omar Hassan is also connected to Adriatic Consulting Group through a joint venture "
            "called Meridian Tech Solutions, linking this case to the real estate scheme "
            "(CASE-2024-002) as well."
        ),
    },
]


# ---------------------------------------------------------------------------
# Entity & Relationship Extraction
# ---------------------------------------------------------------------------

EXTRACTION_PROMPT = """\
You are a financial crime analyst AI. Given a fraud case narrative, extract all
entities and relationships.

**Entity types**: person, company, account, transaction, location
**Relationship types**: owns, works_at, transferred_to, received_from, related_to, registered_in, directed_by

Return a JSON object with this exact structure:
{
  "entities": [
    {"name": "...", "type": "person|company|account|transaction|location", "attributes": {"role": "...", ...}}
  ],
  "relationships": [
    {"source": "entity_name", "target": "entity_name", "type": "owns|works_at|transferred_to|received_from|related_to|registered_in|directed_by", "attributes": {"amount": "...", ...}}
  ]
}

Be thorough — extract every person, company, account, location, and significant
transaction mentioned. For transactions, create a node with the amount as the name
(e.g., "$2.3M wire transfer") and link it to source and destination entities.
Return ONLY valid JSON, no extra text.
"""


def extract_entities_and_relationships(
    case_narrative: str, case_id: str
) -> tuple[list[Entity], list[Relationship]]:
    """Extract entities and relationships from a case narrative using OpenAI."""
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": EXTRACTION_PROMPT},
            {"role": "user", "content": f"Case ID: {case_id}\n\nNarrative:\n{case_narrative}"},
        ],
        temperature=0.0,
        response_format={"type": "json_object"},
    )

    raw = json.loads(response.choices[0].message.content or "{}")

    entities: list[Entity] = []
    for e in raw.get("entities", []):
        try:
            entities.append(Entity(
                name=e["name"],
                entity_type=EntityType(e["type"].lower()),
                attributes=e.get("attributes", {}),
                source_case=case_id,
            ))
        except (ValueError, KeyError):
            continue

    relationships: list[Relationship] = []
    for r in raw.get("relationships", []):
        try:
            relationships.append(Relationship(
                source=r["source"],
                target=r["target"],
                rel_type=RelationshipType(r["type"].lower()),
                attributes=r.get("attributes", {}),
                source_case=case_id,
            ))
        except (ValueError, KeyError):
            continue

    return entities, relationships


# ---------------------------------------------------------------------------
# Knowledge Graph Construction
# ---------------------------------------------------------------------------

class FraudKnowledgeGraph:
    """NetworkX-based knowledge graph for fraud investigation."""

    def __init__(self) -> None:
        self.graph: nx.DiGraph = nx.DiGraph()
        self.case_texts: dict[str, str] = {}
        self.entity_registry: dict[str, Entity] = {}

    def add_case(self, case_id: str, narrative: str) -> None:
        """Store the case narrative for later retrieval."""
        self.case_texts[case_id] = narrative

    def add_entity(self, entity: Entity) -> None:
        """Add an entity as a graph node."""
        self.graph.add_node(
            entity.name,
            entity_type=entity.entity_type.value,
            source_case=entity.source_case,
            **entity.attributes,
        )
        self.entity_registry[entity.name] = entity

    def add_relationship(self, rel: Relationship) -> None:
        """Add a relationship as a directed edge."""
        # Ensure both endpoints exist as nodes
        if not self.graph.has_node(rel.source):
            self.graph.add_node(rel.source, entity_type="unknown", source_case=rel.source_case)
        if not self.graph.has_node(rel.target):
            self.graph.add_node(rel.target, entity_type="unknown", source_case=rel.source_case)

        self.graph.add_edge(
            rel.source,
            rel.target,
            rel_type=rel.rel_type.value,
            source_case=rel.source_case,
            **rel.attributes,
        )

    def build_from_cases(self, cases: list[dict[str, str]], verbose: bool = True) -> None:
        """Extract entities/relationships from all cases and build the graph."""
        for case in cases:
            case_id = case["id"]
            narrative = case["narrative"]
            self.add_case(case_id, narrative)

            if verbose:
                print(f"  Extracting from {case_id}: {case['title']}...")

            entities, relationships = extract_entities_and_relationships(narrative, case_id)

            if verbose:
                print(f"    → {len(entities)} entities, {len(relationships)} relationships")

            for entity in entities:
                self.add_entity(entity)
            for rel in relationships:
                self.add_relationship(rel)

        if verbose:
            print(f"\n  Graph totals: {self.graph.number_of_nodes()} nodes, "
                  f"{self.graph.number_of_edges()} edges")

    # -------------------------------------------------------------------
    # Graph Retrieval
    # -------------------------------------------------------------------

    def find_entity(self, query: str) -> list[str]:
        """Fuzzy-match entity names against query terms."""
        query_lower = query.lower()
        matches: list[str] = []
        for node in self.graph.nodes():
            if node.lower() in query_lower or query_lower in node.lower():
                matches.append(node)
        # Also check partial word overlap
        query_words = set(query_lower.split())
        for node in self.graph.nodes():
            node_words = set(node.lower().split())
            if query_words & node_words and node not in matches:
                matches.append(node)
        return matches

    def get_subgraph(self, entity_name: str, hops: int = 2) -> dict[str, Any]:
        """Get the neighborhood subgraph around an entity."""
        if entity_name not in self.graph:
            return {"nodes": [], "edges": []}

        # Collect nodes within N hops (undirected for discovery)
        undirected = self.graph.to_undirected()
        neighborhood = nx.ego_graph(undirected, entity_name, radius=hops)

        nodes = []
        for n in neighborhood.nodes():
            data = dict(self.graph.nodes[n])
            nodes.append({"name": n, **data})

        edges = []
        for u, v, data in self.graph.edges(data=True):
            if u in neighborhood.nodes() and v in neighborhood.nodes():
                edges.append({"source": u, "target": v, **data})

        return {"nodes": nodes, "edges": edges}

    def find_paths(self, source: str, target: str, max_length: int = 5) -> list[list[str]]:
        """Find all simple paths between two entities."""
        if source not in self.graph or target not in self.graph:
            return []
        undirected = self.graph.to_undirected()
        try:
            paths = list(nx.all_simple_paths(undirected, source, target, cutoff=max_length))
            return paths[:5]  # Limit to 5 paths
        except nx.NetworkXError:
            return []

    def detect_communities(self) -> list[list[str]]:
        """Detect communities using greedy modularity optimization."""
        undirected = self.graph.to_undirected()
        if len(undirected.nodes()) == 0:
            return []
        try:
            communities = nx.community.greedy_modularity_communities(undirected)
            return [sorted(list(c)) for c in communities]
        except Exception:
            # Fallback: connected components
            return [sorted(list(c)) for c in nx.connected_components(undirected)]

    def get_entity_info(self, entity_name: str) -> dict[str, Any] | None:
        """Get full info about an entity: attributes, neighbors, edges."""
        if entity_name not in self.graph:
            return None

        node_data = dict(self.graph.nodes[entity_name])
        outgoing = [
            {"target": v, **data}
            for _, v, data in self.graph.out_edges(entity_name, data=True)
        ]
        incoming = [
            {"source": u, **data}
            for u, _, data in self.graph.in_edges(entity_name, data=True)
        ]

        return {
            "name": entity_name,
            "attributes": node_data,
            "outgoing_relationships": outgoing,
            "incoming_relationships": incoming,
        }

    def get_graph_summary(self) -> dict[str, Any]:
        """Get high-level graph statistics."""
        type_counts: dict[str, int] = {}
        for _, data in self.graph.nodes(data=True):
            t = data.get("entity_type", "unknown")
            type_counts[t] = type_counts.get(t, 0) + 1

        rel_counts: dict[str, int] = {}
        for _, _, data in self.graph.edges(data=True):
            r = data.get("rel_type", "unknown")
            rel_counts[r] = rel_counts.get(r, 0) + 1

        return {
            "total_nodes": self.graph.number_of_nodes(),
            "total_edges": self.graph.number_of_edges(),
            "entity_types": type_counts,
            "relationship_types": rel_counts,
            "connected_components": nx.number_weakly_connected_components(self.graph),
        }


# ---------------------------------------------------------------------------
# Graph-Enhanced RAG: Context Building & Answer Generation
# ---------------------------------------------------------------------------

def build_graph_context(kg: FraudKnowledgeGraph, query: str) -> GraphContext:
    """Build rich graph context for a query by traversing the knowledge graph."""
    # 1. Find entities mentioned in query
    matched_entities = kg.find_entity(query)

    # 2. Collect subgraph around each matched entity
    all_nodes: list[dict[str, Any]] = []
    all_edges: list[dict[str, Any]] = []
    seen_nodes: set[str] = set()
    seen_edges: set[tuple[str, str]] = set()

    for entity_name in matched_entities:
        subgraph = kg.get_subgraph(entity_name, hops=2)
        for n in subgraph["nodes"]:
            if n["name"] not in seen_nodes:
                all_nodes.append(n)
                seen_nodes.add(n["name"])
        for e in subgraph["edges"]:
            edge_key = (e["source"], e["target"])
            if edge_key not in seen_edges:
                all_edges.append(e)
                seen_edges.add(edge_key)

    # 3. Find paths between pairs of matched entities
    paths: list[list[str]] = []
    for i, src in enumerate(matched_entities):
        for tgt in matched_entities[i + 1:]:
            paths.extend(kg.find_paths(src, tgt))

    # 4. Community detection
    communities = kg.detect_communities()

    # 5. Gather source texts for matched entities
    relevant_cases: set[str] = set()
    for node in all_nodes:
        case_id = node.get("source_case", "")
        if case_id and case_id in kg.case_texts:
            relevant_cases.add(case_id)
    source_texts = [kg.case_texts[cid] for cid in relevant_cases]

    # If no entities matched, fall back to all case texts
    if not all_nodes:
        source_texts = list(kg.case_texts.values())

    return GraphContext(
        relevant_entities=all_nodes,
        relevant_relationships=all_edges,
        paths=paths,
        communities=communities,
        source_texts=source_texts,
    )


ANSWER_PROMPT = """\
You are a senior financial crime analyst. You have access to a knowledge graph
built from fraud investigation case files. Use the graph context and source
documents below to answer the investigator's query.

**Graph Context:**
- Entities: {entities}
- Relationships: {relationships}
- Paths discovered: {paths}
- Communities/clusters: {communities}

**Source Case Texts:**
{source_texts}

**Instructions:**
1. Answer the query thoroughly, citing specific entities and relationships.
2. Trace connections step-by-step when relevant (A → B → C).
3. Identify potential fraud patterns (layering, structuring, shell networks).
4. Flag any cross-case connections.
5. Provide an overall risk assessment.

Answer in a structured format with clear sections.
"""


def generate_answer(query: str, context: GraphContext) -> str:
    """Generate a fraud analysis answer using graph context + LLM."""
    entities_str = json.dumps(context.relevant_entities[:30], indent=2, default=str)
    relationships_str = json.dumps(context.relevant_relationships[:30], indent=2, default=str)
    paths_str = json.dumps(context.paths[:10], default=str) if context.paths else "None found"
    communities_str = json.dumps(context.communities[:10], default=str) if context.communities else "None detected"
    source_texts = "\n\n---\n\n".join(context.source_texts[:5])

    prompt = ANSWER_PROMPT.format(
        entities=entities_str,
        relationships=relationships_str,
        paths=paths_str,
        communities=communities_str,
        source_texts=source_texts,
    )

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": prompt},
            {"role": "user", "content": query},
        ],
        temperature=0.2,
        max_tokens=2000,
    )

    return response.choices[0].message.content or "No answer generated."


def query_graph_rag(kg: FraudKnowledgeGraph, query: str) -> GraphRAGResult:
    """Full GraphRAG pipeline: query → graph context → LLM answer."""
    context = build_graph_context(kg, query)
    answer = generate_answer(query, context)

    return GraphRAGResult(
        query=query,
        answer=answer,
        graph_context=context,
        entity_count=len(context.relevant_entities),
        relationship_count=len(context.relevant_relationships),
    )


# ---------------------------------------------------------------------------
# Helper: Format graph as text for display
# ---------------------------------------------------------------------------

def format_graph_text(kg: FraudKnowledgeGraph) -> str:
    """Format the knowledge graph as readable text."""
    lines: list[str] = []
    lines.append("=" * 60)
    lines.append("KNOWLEDGE GRAPH")
    lines.append("=" * 60)

    # Group nodes by type
    by_type: dict[str, list[str]] = {}
    for node, data in kg.graph.nodes(data=True):
        t = data.get("entity_type", "unknown")
        by_type.setdefault(t, []).append(node)

    for entity_type, nodes in sorted(by_type.items()):
        lines.append(f"\n[{entity_type.upper()}] ({len(nodes)})")
        for n in sorted(nodes):
            lines.append(f"  • {n}")

    lines.append(f"\nRELATIONSHIPS ({kg.graph.number_of_edges()})")
    lines.append("-" * 40)
    for u, v, data in kg.graph.edges(data=True):
        rel = data.get("rel_type", "?")
        extra = ""
        if "amount" in data:
            extra = f" [{data['amount']}]"
        lines.append(f"  {u} --[{rel}]--> {v}{extra}")

    return "\n".join(lines)


def format_adjacency_matrix(kg: FraudKnowledgeGraph) -> str:
    """Format a simplified adjacency representation."""
    lines: list[str] = []
    for node in sorted(kg.graph.nodes()):
        out_edges = list(kg.graph.out_edges(node, data=True))
        in_edges = list(kg.graph.in_edges(node, data=True))
        if out_edges or in_edges:
            lines.append(f"\n📌 {node}")
            for _, target, data in out_edges:
                lines.append(f"   → [{data.get('rel_type', '?')}] → {target}")
            for source, _, data in in_edges:
                lines.append(f"   ← [{data.get('rel_type', '?')}] ← {source}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Demo Queries
# ---------------------------------------------------------------------------

DEMO_QUERIES: list[str] = [
    "Trace the money flow from Oceanic Trading Ltd",
    "Who is connected to Viktor Petrov and what are their roles?",
    "Find all shell companies in the network and their beneficial owners",
    "What links the Pacific Rim case to the cryptocurrency operation?",
    "Identify the fraud patterns involving Sofia Ramirez",
]


# ---------------------------------------------------------------------------
# CLI Demo
# ---------------------------------------------------------------------------

def run_demo() -> None:
    """Run the full GraphRAG demo end-to-end."""
    print("=" * 70)
    print("  P11 – GraphRAG: Fraud Investigation Network")
    print("=" * 70)

    # Step 1: Build knowledge graph
    print("\n📊 Step 1: Building knowledge graph from case files...\n")
    kg = FraudKnowledgeGraph()
    kg.build_from_cases(FRAUD_CASES, verbose=True)

    # Step 2: Show graph structure
    print("\n" + format_graph_text(kg))

    # Step 3: Community detection
    print("\n\n🔍 Step 2: Detecting communities...\n")
    communities = kg.detect_communities()
    for i, comm in enumerate(communities):
        print(f"  Community {i + 1}: {', '.join(comm[:8])}")
        if len(comm) > 8:
            print(f"    ... and {len(comm) - 8} more")

    # Step 4: Graph summary
    summary = kg.get_graph_summary()
    print(f"\n📈 Graph Summary:")
    print(f"  Nodes: {summary['total_nodes']}")
    print(f"  Edges: {summary['total_edges']}")
    print(f"  Connected components: {summary['connected_components']}")
    print(f"  Entity types: {summary['entity_types']}")
    print(f"  Relationship types: {summary['relationship_types']}")

    # Step 5: Run sample queries
    print("\n\n💬 Step 3: Running sample queries with GraphRAG...\n")
    for i, query in enumerate(DEMO_QUERIES[:2]):  # Run 2 queries in demo
        print(f"\n{'─' * 60}")
        print(f"  Query {i + 1}: {query}")
        print(f"{'─' * 60}")

        result = query_graph_rag(kg, query)

        print(f"\n  📊 Graph context: {result.entity_count} entities, "
              f"{result.relationship_count} relationships")
        if result.graph_context.paths:
            print(f"  🔗 Paths found: {len(result.graph_context.paths)}")

        print(f"\n  📝 Answer:\n")
        for line in result.answer.split("\n"):
            print(f"  {line}")

    print(f"\n\n{'=' * 70}")
    print("  Demo complete! Run the Streamlit app for interactive exploration:")
    print("  streamlit run app.py --server.port 8511")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python graph_rag.py demo")
        print("  Or run the Streamlit app: streamlit run app.py --server.port 8511")
