"""
Streamlit Dashboard — RAG Quality Evaluation.

Runs LLM-as-a-judge evaluation across test cases and displays
aggregate metrics, per-question breakdowns, and custom test input.
"""

import streamlit as st
import pandas as pd

from eval_engine import (
    TEST_DATASET,
    TestCase,
    evaluate_batch,
    evaluate_single,
    compute_summary,
)

st.set_page_config(page_title="RAG Eval Dashboard", page_icon="📊", layout="wide")

# ── Sidebar ─────────────────────────────────────────────────────────

st.sidebar.title("📊 RAG Eval Dashboard")
st.sidebar.markdown("Evaluate RAG quality with LLM-as-a-judge metrics.")
page = st.sidebar.radio("Navigate", ["Dashboard", "Add Custom Test Case"])

# ── State ───────────────────────────────────────────────────────────

if "results" not in st.session_state:
    st.session_state.results = None
if "custom_cases" not in st.session_state:
    st.session_state.custom_cases = []


def get_full_dataset() -> list[TestCase]:
    return TEST_DATASET + st.session_state.custom_cases


# ── Dashboard Page ──────────────────────────────────────────────────

if page == "Dashboard":
    st.title("📊 RAG Quality Evaluation Dashboard")

    dataset = get_full_dataset()
    st.info(f"**{len(dataset)}** test cases ({len(TEST_DATASET)} built-in + {len(st.session_state.custom_cases)} custom)")

    col_run, col_clear = st.columns([1, 1])
    with col_run:
        run_eval = st.button("🚀 Run Evaluation", type="primary", use_container_width=True)
    with col_clear:
        if st.button("🗑️ Clear Results", use_container_width=True):
            st.session_state.results = None
            st.rerun()

    if run_eval:
        progress_bar = st.progress(0, text="Starting evaluation...")

        def on_progress(i, total, tc_id):
            progress_bar.progress((i + 1) / total, text=f"Evaluating {tc_id} ({i+1}/{total})...")

        with st.spinner("Running LLM-as-a-judge evaluation..."):
            st.session_state.results = evaluate_batch(dataset, progress_callback=on_progress)

        progress_bar.progress(1.0, text="Evaluation complete!")

    results = st.session_state.results

    if results:
        summary = compute_summary(results)

        # ── Aggregate Metrics ───────────────────────────────────────
        st.header("📈 Aggregate Metrics")

        metric_cols = st.columns(5)
        metric_names = [
            ("Faithfulness", "faithfulness"),
            ("Answer Relevancy", "answer_relevancy"),
            ("Context Relevancy", "context_relevancy"),
            ("Completeness", "completeness"),
            ("Hallucination Rate", "hallucination_rate"),
        ]

        for col, (label, key) in zip(metric_cols, metric_names):
            with col:
                if key == "hallucination_rate":
                    rate = summary[key]["mean"]
                    detected = summary[key]["total_detected"]
                    total = summary[key]["total_cases"]
                    color = "🔴" if rate > 0.3 else ("🟡" if rate > 0.1 else "🟢")
                    st.metric(f"{color} {label}", f"{rate:.0%}", delta=f"{detected}/{total} detected", delta_color="inverse")
                else:
                    mean_val = summary[key]["mean"]
                    color = "🔴" if mean_val < 0.5 else ("🟡" if mean_val < 0.75 else "🟢")
                    st.metric(f"{color} {label}", f"{mean_val:.2f}", delta=f"min {summary[key]['min']:.2f}")

        # ── Bar Chart ───────────────────────────────────────────────
        st.subheader("Mean Scores by Metric")
        chart_data = pd.DataFrame({
            "Metric": ["Faithfulness", "Answer\nRelevancy", "Context\nRelevancy", "Completeness"],
            "Score": [
                summary["faithfulness"]["mean"],
                summary["answer_relevancy"]["mean"],
                summary["context_relevancy"]["mean"],
                summary["completeness"]["mean"],
            ],
        })
        st.bar_chart(chart_data, x="Metric", y="Score", height=350)

        # ── Per-Question Breakdown ──────────────────────────────────
        st.header("🔍 Per-Question Breakdown")

        for r in results:
            halluc_badge = "🔴 Hallucination" if r.hallucination else "🟢 Clean"
            avg_score = (r.faithfulness + r.answer_relevancy + r.context_relevancy + r.completeness) / 4
            status = "🔴" if avg_score < 0.5 else ("🟡" if avg_score < 0.75 else "🟢")

            with st.expander(f"{status} **{r.test_case_id}** — {r.question[:70]}  |  avg={avg_score:.2f}  |  {halluc_badge}"):
                score_cols = st.columns(5)
                labels = ["Faithfulness", "Answer Relevancy", "Context Relevancy", "Hallucination", "Completeness"]
                values = [r.faithfulness, r.answer_relevancy, r.context_relevancy, r.hallucination, r.completeness]

                for sc, lbl, val in zip(score_cols, labels, values):
                    with sc:
                        if lbl == "Hallucination":
                            display = "Yes 🔴" if val else "No 🟢"
                            st.metric(lbl, display)
                        else:
                            color_prefix = "🔴" if val < 0.5 else ("🟡" if val < 0.75 else "🟢")
                            st.metric(f"{color_prefix} {lbl}", f"{val:.2f}")

                st.markdown(f"**Category:** `{r.category}`")

                if r.details:
                    st.markdown("**Judge Reasoning:**")
                    for detail_key, detail_val in r.details.items():
                        nice_key = detail_key.replace("_", " ").title()
                        st.markdown(f"- **{nice_key}:** {detail_val}")

        # ── Results Table ───────────────────────────────────────────
        st.header("📋 Results Table")
        df = pd.DataFrame([
            {
                "ID": r.test_case_id,
                "Category": r.category,
                "Faithfulness": r.faithfulness,
                "Answer Relevancy": r.answer_relevancy,
                "Context Relevancy": r.context_relevancy,
                "Hallucination": "Yes" if r.hallucination else "No",
                "Completeness": r.completeness,
            }
            for r in results
        ])
        st.dataframe(df, use_container_width=True, hide_index=True)

    else:
        st.markdown("---")
        st.markdown("### 👆 Click **Run Evaluation** to start")
        st.markdown("The evaluation will run all 5 metrics across the test dataset using GPT-4o-mini as judge.")


# ── Add Custom Test Case Page ───────────────────────────────────────

elif page == "Add Custom Test Case":
    st.title("➕ Add Custom Test Case")
    st.markdown("Add your own QA pair to the evaluation dataset.")

    with st.form("custom_test_case"):
        question = st.text_input("Question", placeholder="What is the speed of light?")
        context = st.text_area("Context (retrieved passage)", placeholder="The speed of light in vacuum is approximately 299,792,458 meters per second...", height=120)
        answer = st.text_area("Answer (LLM response to evaluate)", placeholder="The speed of light is about 300,000 km/s...", height=100)
        ground_truth = st.text_area("Ground Truth (reference answer)", placeholder="~299,792,458 m/s or ~300,000 km/s", height=80)
        category = st.selectbox("Category", ["custom", "good_answer", "hallucinated", "incomplete", "irrelevant"])

        submitted = st.form_submit_button("Add Test Case", type="primary")

        if submitted:
            if not all([question, context, answer, ground_truth]):
                st.error("All fields are required.")
            else:
                new_id = f"custom-{len(st.session_state.custom_cases) + 1:02d}"
                tc = TestCase(
                    id=new_id,
                    question=question,
                    context=context,
                    answer=answer,
                    ground_truth=ground_truth,
                    category=category,
                )
                st.session_state.custom_cases.append(tc)
                st.success(f"Added test case **{new_id}**. Go to Dashboard to run evaluation.")

    if st.session_state.custom_cases:
        st.subheader("Custom Test Cases")
        for tc in st.session_state.custom_cases:
            with st.expander(f"{tc.id}: {tc.question[:60]}"):
                st.markdown(f"**Context:** {tc.context[:200]}...")
                st.markdown(f"**Answer:** {tc.answer}")
                st.markdown(f"**Ground Truth:** {tc.ground_truth}")
                st.markdown(f"**Category:** `{tc.category}`")

        if st.button("🗑️ Clear All Custom Cases"):
            st.session_state.custom_cases = []
            st.rerun()
