# Project 15: LLM Evaluation & Observability

## 🎯 What You'll Build
A **RAG Quality Dashboard** that evaluates retrieval and generation quality using LLM-as-a-judge — measuring faithfulness, relevancy, hallucination, and completeness across a test dataset.

## 📋 Key Concepts

### Why Evaluate LLM Outputs?
LLMs can hallucinate, miss context, or give irrelevant answers. Systematic evaluation catches these issues before users do. In production RAG systems, evaluation is critical for:
- Detecting **hallucinations** (answers not grounded in retrieved context)
- Measuring **retrieval quality** (are we fetching the right documents?)
- Tracking **answer quality** over time as prompts or models change

### LLM-as-a-Judge
Instead of relying on exact string matching or BLEU scores, we use a separate LLM call to **judge** the quality of each answer. GPT-4o-mini evaluates each response against structured rubrics and returns a score.

### Five Evaluation Metrics

| Metric | What It Measures | Scale |
|--------|-----------------|-------|
| **Faithfulness** | Is the answer grounded in the provided context? | 0.0 – 1.0 |
| **Answer Relevancy** | Does the answer actually address the question? | 0.0 – 1.0 |
| **Context Relevancy** | Are the retrieved contexts relevant to the question? | 0.0 – 1.0 |
| **Hallucination Detection** | Does the answer contain info NOT in the context? | 0 or 1 (binary) |
| **Answer Completeness** | Does the answer cover all aspects of the question? | 0.0 – 1.0 |

### Test Dataset Design
A good eval dataset includes a **mix** of scenarios:
- ✅ Good answers (faithful, complete, relevant)
- ❌ Hallucinated answers (contain fabricated info)
- ⚠️ Incomplete answers (miss key details)
- 🔀 Irrelevant answers (don't address the question)

## 🏗️ Architecture

```
Test Dataset (QA pairs with context)
        │
        ▼
┌─────────────────────────┐
│   Evaluation Engine     │
│                         │
│  For each test case:    │
│  ├─ Faithfulness Judge  │──► GPT-4o-mini
│  ├─ Relevancy Judge     │──► GPT-4o-mini
│  ├─ Context Judge       │──► GPT-4o-mini
│  ├─ Hallucination Judge │──► GPT-4o-mini
│  └─ Completeness Judge  │──► GPT-4o-mini
│                         │
│  Aggregate Statistics   │
└─────────────────────────┘
        │
        ▼
  Streamlit Dashboard
  (charts, per-question breakdown)
```

## 🚀 Setup & Run

### 1. Install Dependencies
```bash
cd projects/15-evaluation
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
# .env file should contain:
OPENAI_API_KEY=your-key-here
```

### 3. CLI Demo
```bash
python eval_engine.py demo
```

### 4. Launch Dashboard
```bash
streamlit run app.py --server.port 8515
```

## 📁 File Structure
```
15-evaluation/
├── STEPS.md           # This file
├── requirements.txt   # Dependencies
├── .env              # API key
├── eval_engine.py    # Core evaluation engine
└── app.py            # Streamlit dashboard
```

## 🔑 Key Takeaways
1. **LLM-as-a-judge** is practical and flexible — no need for labeled datasets
2. **Multiple metrics** give a complete picture; a single score hides problems
3. **Test dataset quality** matters — include edge cases and failure modes
4. **Structured output** from the judge ensures parseable, consistent scores
5. **Batch evaluation** enables tracking quality over time as you iterate
