"""
LLM Evaluation Engine — Custom LLM-as-a-judge framework.

Evaluates RAG quality across 5 metrics using GPT-4o-mini as judge:
  1. Faithfulness — Is the answer grounded in the context?
  2. Answer Relevancy — Does the answer address the question?
  3. Context Relevancy — Are the retrieved contexts relevant?
  4. Hallucination Detection — Info present NOT in context?
  5. Answer Completeness — Does the answer cover all aspects?
"""

import json
import os
import sys
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel, Field

load_dotenv()

client = OpenAI()
JUDGE_MODEL = "gpt-4o-mini"


# ── Pydantic Schemas ────────────────────────────────────────────────

class TestCase(BaseModel):
    """A single evaluation test case."""
    id: str
    question: str
    context: str
    answer: str
    ground_truth: str
    category: str = "general"


class MetricScore(BaseModel):
    """Score returned by a single evaluator."""
    score: float = Field(ge=0, le=1)
    reasoning: str


class HallucinationScore(BaseModel):
    """Binary hallucination detection result."""
    hallucination_detected: bool
    reasoning: str


class EvalResult(BaseModel):
    """Full evaluation result for one test case."""
    test_case_id: str
    question: str
    category: str
    faithfulness: float
    answer_relevancy: float
    context_relevancy: float
    hallucination: int  # 1 = hallucination detected, 0 = clean
    completeness: float
    details: dict = {}


# ── Test Dataset ────────────────────────────────────────────────────

TEST_DATASET: list[TestCase] = [
    TestCase(
        id="tc-01",
        question="What is the capital of France?",
        context="France is a country in Western Europe. Its capital city is Paris, which is also the largest city in France with a population of over 2 million in the city proper.",
        answer="The capital of France is Paris. It is the largest city in France with over 2 million residents.",
        ground_truth="Paris",
        category="good_answer",
    ),
    TestCase(
        id="tc-02",
        question="What are the symptoms of diabetes?",
        context="Type 2 diabetes symptoms include increased thirst, frequent urination, increased hunger, fatigue, and blurred vision. Some people may also experience slow-healing sores and frequent infections.",
        answer="Diabetes symptoms include increased thirst, frequent urination, hunger, fatigue, blurred vision, slow-healing sores, and frequent infections.",
        ground_truth="Increased thirst, frequent urination, increased hunger, fatigue, blurred vision, slow-healing sores, frequent infections.",
        category="good_answer",
    ),
    TestCase(
        id="tc-03",
        question="How does photosynthesis work?",
        context="Photosynthesis is the process by which green plants convert light energy into chemical energy. Plants absorb carbon dioxide from the air and water from the soil, using sunlight to convert these into glucose and oxygen.",
        answer="Photosynthesis converts light energy into chemical energy. Plants use CO2 and water with sunlight to produce glucose and oxygen. The process was discovered by Albert Einstein in 1905 and requires temperatures above 50°C.",
        ground_truth="Plants use sunlight to convert CO2 and water into glucose and oxygen.",
        category="hallucinated",
    ),
    TestCase(
        id="tc-04",
        question="What is machine learning?",
        context="Machine learning is a subset of artificial intelligence that enables systems to learn and improve from experience without being explicitly programmed. It focuses on developing algorithms that can access data and use it to learn for themselves.",
        answer="Machine learning is a type of AI where systems learn from data. It was invented by Elon Musk in 2015 and requires quantum computers to function properly.",
        ground_truth="ML is a subset of AI that enables systems to learn from experience without explicit programming.",
        category="hallucinated",
    ),
    TestCase(
        id="tc-05",
        question="Explain the water cycle in detail.",
        context="The water cycle consists of evaporation, condensation, precipitation, and collection. Water evaporates from oceans and lakes, forms clouds through condensation, falls as precipitation (rain, snow), and collects in bodies of water. Transpiration from plants also contributes to the cycle.",
        answer="Water evaporates from the ocean and then it rains.",
        ground_truth="Evaporation, condensation, precipitation, collection, and transpiration from plants.",
        category="incomplete",
    ),
    TestCase(
        id="tc-06",
        question="What are the benefits of exercise?",
        context="Regular physical exercise provides numerous health benefits including improved cardiovascular health, weight management, stronger muscles and bones, better mental health and mood, reduced risk of chronic diseases, improved sleep quality, and increased energy levels.",
        answer="Exercise is good for your heart.",
        ground_truth="Cardiovascular health, weight management, stronger muscles/bones, better mental health, reduced chronic disease risk, improved sleep, increased energy.",
        category="incomplete",
    ),
    TestCase(
        id="tc-07",
        question="What programming language is best for data science?",
        context="Python is widely considered the most popular language for data science due to its extensive libraries like NumPy, Pandas, and Scikit-learn. R is also popular for statistical analysis. Julia is gaining traction for numerical computing.",
        answer="The best recipe for chocolate cake requires 2 cups of flour, 1 cup of sugar, and 3 eggs. Preheat the oven to 350°F.",
        ground_truth="Python is most popular, R for statistics, Julia for numerical computing.",
        category="irrelevant",
    ),
    TestCase(
        id="tc-08",
        question="How do solar panels generate electricity?",
        context="Solar panels contain photovoltaic cells made of semiconductor materials like silicon. When sunlight hits these cells, photons knock electrons free from atoms, creating an electrical current. This direct current (DC) is then converted to alternating current (AC) by an inverter for home use.",
        answer="Solar panels use photovoltaic cells made of silicon. Sunlight knocks electrons free, creating DC electricity which an inverter converts to AC for home use.",
        ground_truth="Photovoltaic cells in silicon absorb sunlight, freeing electrons to create DC current, converted to AC by an inverter.",
        category="good_answer",
    ),
    TestCase(
        id="tc-09",
        question="What causes climate change?",
        context="Climate change is primarily driven by greenhouse gas emissions from burning fossil fuels, deforestation, and industrial processes. CO2, methane, and nitrous oxide trap heat in the atmosphere, causing global temperatures to rise.",
        answer="Climate change is caused by the Earth moving closer to the Sun every year, which increases temperatures globally.",
        ground_truth="Greenhouse gas emissions from fossil fuels, deforestation, and industry trap heat in the atmosphere.",
        category="hallucinated",
    ),
    TestCase(
        id="tc-10",
        question="What is blockchain technology?",
        context="Blockchain is a distributed ledger technology that records transactions across multiple computers. Each block contains a cryptographic hash of the previous block, a timestamp, and transaction data. This makes the data resistant to modification and creates a transparent, verifiable record.",
        answer="Blockchain is a distributed ledger recording transactions across many computers. Blocks contain hashes of previous blocks, timestamps, and transaction data, making records tamper-resistant and transparent.",
        ground_truth="Distributed ledger with blocks containing hashes, timestamps, and transaction data that is tamper-resistant.",
        category="good_answer",
    ),
]


# ── Evaluator Functions ─────────────────────────────────────────────

def _call_judge(system_prompt: str, user_prompt: str) -> str:
    """Call GPT-4o-mini as judge and return raw content."""
    response = client.chat.completions.create(
        model=JUDGE_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0,
        response_format={"type": "json_object"},
    )
    return response.choices[0].message.content


def evaluate_faithfulness(question: str, context: str, answer: str) -> MetricScore:
    """Evaluate whether the answer is grounded in the provided context."""
    system_prompt = (
        "You are an evaluation judge. Assess whether the answer is faithful to "
        "the provided context. A faithful answer only contains information that "
        "can be derived from the context.\n\n"
        "Return JSON: {\"score\": <0.0-1.0>, \"reasoning\": \"<explanation>\"}\n"
        "1.0 = fully faithful, 0.0 = completely unfaithful."
    )
    user_prompt = f"Context: {context}\n\nQuestion: {question}\n\nAnswer: {answer}"
    raw = _call_judge(system_prompt, user_prompt)
    data = json.loads(raw)
    return MetricScore(score=round(max(0, min(1, float(data["score"]))), 2), reasoning=data["reasoning"])


def evaluate_answer_relevancy(question: str, answer: str) -> MetricScore:
    """Evaluate whether the answer addresses the question."""
    system_prompt = (
        "You are an evaluation judge. Assess whether the answer is relevant to "
        "and addresses the question asked.\n\n"
        "Return JSON: {\"score\": <0.0-1.0>, \"reasoning\": \"<explanation>\"}\n"
        "1.0 = perfectly relevant, 0.0 = completely irrelevant."
    )
    user_prompt = f"Question: {question}\n\nAnswer: {answer}"
    raw = _call_judge(system_prompt, user_prompt)
    data = json.loads(raw)
    return MetricScore(score=round(max(0, min(1, float(data["score"]))), 2), reasoning=data["reasoning"])


def evaluate_context_relevancy(question: str, context: str) -> MetricScore:
    """Evaluate whether the retrieved context is relevant to the question."""
    system_prompt = (
        "You are an evaluation judge. Assess whether the provided context "
        "contains information relevant to answering the question.\n\n"
        "Return JSON: {\"score\": <0.0-1.0>, \"reasoning\": \"<explanation>\"}\n"
        "1.0 = highly relevant context, 0.0 = completely irrelevant context."
    )
    user_prompt = f"Question: {question}\n\nContext: {context}"
    raw = _call_judge(system_prompt, user_prompt)
    data = json.loads(raw)
    return MetricScore(score=round(max(0, min(1, float(data["score"]))), 2), reasoning=data["reasoning"])


def evaluate_hallucination(context: str, answer: str) -> HallucinationScore:
    """Detect whether the answer contains information not present in context."""
    system_prompt = (
        "You are a hallucination detector. Check if the answer contains any "
        "claims or facts that are NOT present in or cannot be inferred from the "
        "provided context.\n\n"
        "Return JSON: {\"hallucination_detected\": <true/false>, \"reasoning\": \"<explanation>\"}\n"
        "true = answer contains fabricated/unsupported information."
    )
    user_prompt = f"Context: {context}\n\nAnswer: {answer}"
    raw = _call_judge(system_prompt, user_prompt)
    data = json.loads(raw)
    return HallucinationScore(
        hallucination_detected=bool(data["hallucination_detected"]),
        reasoning=data["reasoning"],
    )


def evaluate_completeness(question: str, answer: str, ground_truth: str) -> MetricScore:
    """Evaluate whether the answer covers all aspects of the expected response."""
    system_prompt = (
        "You are an evaluation judge. Assess whether the answer covers all the "
        "key points present in the ground truth / reference answer.\n\n"
        "Return JSON: {\"score\": <0.0-1.0>, \"reasoning\": \"<explanation>\"}\n"
        "1.0 = covers everything, 0.0 = misses all key points."
    )
    user_prompt = (
        f"Question: {question}\n\n"
        f"Reference Answer: {ground_truth}\n\n"
        f"Actual Answer: {answer}"
    )
    raw = _call_judge(system_prompt, user_prompt)
    data = json.loads(raw)
    return MetricScore(score=round(max(0, min(1, float(data["score"]))), 2), reasoning=data["reasoning"])


# ── Batch Evaluation ────────────────────────────────────────────────

def evaluate_single(tc: TestCase) -> EvalResult:
    """Run all 5 metrics on a single test case."""
    faith = evaluate_faithfulness(tc.question, tc.context, tc.answer)
    relevancy = evaluate_answer_relevancy(tc.question, tc.answer)
    ctx_rel = evaluate_context_relevancy(tc.question, tc.context)
    halluc = evaluate_hallucination(tc.context, tc.answer)
    complete = evaluate_completeness(tc.question, tc.answer, tc.ground_truth)

    return EvalResult(
        test_case_id=tc.id,
        question=tc.question,
        category=tc.category,
        faithfulness=faith.score,
        answer_relevancy=relevancy.score,
        context_relevancy=ctx_rel.score,
        hallucination=1 if halluc.hallucination_detected else 0,
        completeness=complete.score,
        details={
            "faithfulness_reasoning": faith.reasoning,
            "relevancy_reasoning": relevancy.reasoning,
            "context_relevancy_reasoning": ctx_rel.reasoning,
            "hallucination_reasoning": halluc.reasoning,
            "completeness_reasoning": complete.reasoning,
        },
    )


def evaluate_batch(
    dataset: Optional[list[TestCase]] = None,
    progress_callback=None,
) -> list[EvalResult]:
    """Evaluate all test cases and return results."""
    dataset = dataset or TEST_DATASET
    results = []
    for i, tc in enumerate(dataset):
        if progress_callback:
            progress_callback(i, len(dataset), tc.id)
        result = evaluate_single(tc)
        results.append(result)
    return results


def compute_summary(results: list[EvalResult]) -> dict:
    """Compute aggregate statistics across all results."""
    if not results:
        return {}

    metrics = ["faithfulness", "answer_relevancy", "context_relevancy", "completeness"]
    summary = {}

    for metric in metrics:
        values = [getattr(r, metric) for r in results]
        summary[metric] = {
            "mean": round(sum(values) / len(values), 3),
            "min": round(min(values), 3),
            "max": round(max(values), 3),
        }

    halluc_values = [r.hallucination for r in results]
    summary["hallucination_rate"] = {
        "mean": round(sum(halluc_values) / len(halluc_values), 3),
        "total_detected": sum(halluc_values),
        "total_cases": len(halluc_values),
    }

    return summary


# ── CLI Demo ────────────────────────────────────────────────────────

def run_demo():
    """Run the evaluation demo from CLI."""
    print("=" * 60)
    print("  LLM Evaluation Engine — RAG Quality Assessment")
    print("=" * 60)
    print(f"\nDataset: {len(TEST_DATASET)} test cases")
    print(f"Judge model: {JUDGE_MODEL}")
    print(f"Metrics: Faithfulness, Answer Relevancy, Context Relevancy, Hallucination, Completeness")
    print("\n" + "-" * 60)

    def progress(i, total, tc_id):
        print(f"  [{i+1}/{total}] Evaluating {tc_id}...")

    results = evaluate_batch(progress_callback=progress)

    print("\n" + "=" * 60)
    print("  Per-Question Results")
    print("=" * 60)

    for r in results:
        halluc_icon = "🔴" if r.hallucination else "🟢"
        print(f"\n  {r.test_case_id} ({r.category})")
        print(f"    Q: {r.question[:60]}...")
        print(f"    Faithfulness:      {r.faithfulness:.2f}")
        print(f"    Answer Relevancy:  {r.answer_relevancy:.2f}")
        print(f"    Context Relevancy: {r.context_relevancy:.2f}")
        print(f"    Hallucination:     {halluc_icon} {'Yes' if r.hallucination else 'No'}")
        print(f"    Completeness:      {r.completeness:.2f}")

    summary = compute_summary(results)
    print("\n" + "=" * 60)
    print("  Aggregate Summary")
    print("=" * 60)

    for metric in ["faithfulness", "answer_relevancy", "context_relevancy", "completeness"]:
        s = summary[metric]
        print(f"  {metric:22s}  mean={s['mean']:.3f}  min={s['min']:.3f}  max={s['max']:.3f}")

    h = summary["hallucination_rate"]
    print(f"  {'hallucination_rate':22s}  rate={h['mean']:.3f}  detected={h['total_detected']}/{h['total_cases']}")

    print("\n✅ Evaluation complete.\n")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python eval_engine.py demo")
