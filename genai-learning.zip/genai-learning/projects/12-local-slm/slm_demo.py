"""
Project 12: Local SLM — Edge Code Review Assistant

Compares cloud LLM (GPT-4o-mini) vs local SLM (Ollama) for code review.
Includes fallback simulation when Ollama is not installed.
"""

import os
import sys
import time
import json
import argparse
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

# ---------------------------------------------------------------------------
# Code samples with real bugs / review opportunities
# ---------------------------------------------------------------------------

CODE_SAMPLES: dict[str, dict] = {
    "sql_injection": {
        "title": "SQL Injection Vulnerability",
        "language": "python",
        "code": '''
def get_user(username, password):
    """Authenticate user and return profile."""
    import sqlite3
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
    cursor.execute(query)
    user = cursor.fetchone()
    conn.close()
    return user

def search_products(search_term):
    """Search product catalog."""
    import sqlite3
    conn = sqlite3.connect("shop.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE name LIKE '%" + search_term + "%'")
    results = cursor.fetchall()
    conn.close()
    return results
''',
        "bugs": ["SQL injection via f-string interpolation", "SQL injection via string concatenation",
                 "Plaintext password comparison", "No connection context manager"],
    },
    "missing_validation": {
        "title": "Missing Input Validation",
        "language": "python",
        "code": '''
import os
import json

def process_upload(file_path, output_dir):
    """Process an uploaded file and save results."""
    with open(file_path, "r") as f:
        data = json.load(f)

    user_id = data["user_id"]
    filename = data["filename"]
    content = data["content"]

    save_path = os.path.join(output_dir, filename)
    with open(save_path, "w") as f:
        f.write(content)

    return {"status": "ok", "saved_to": save_path}

def calculate_discount(price, discount_percent):
    """Apply discount to price."""
    final = price - (price * discount_percent / 100)
    return final

def get_page(items, page_num, page_size):
    """Paginate a list of items."""
    start = (page_num - 1) * page_size
    return items[start:start + page_size]
''',
        "bugs": ["Path traversal via filename (e.g., ../../etc/passwd)", "No validation on price/discount ranges",
                 "No bounds checking on page_num/page_size", "No file-type validation on upload"],
    },
    "memory_leak": {
        "title": "Resource & Memory Leak",
        "language": "python",
        "code": '''
import threading

class CacheManager:
    """In-memory cache with no eviction policy."""

    def __init__(self):
        self._cache = {}
        self._lock = threading.Lock()
        self._stats = {"hits": 0, "misses": 0}

    def get(self, key):
        with self._lock:
            if key in self._cache:
                self._stats["hits"] += 1
                return self._cache[key]
            self._stats["misses"] += 1
            return None

    def set(self, key, value):
        with self._lock:
            self._cache[key] = value

    def get_all_versions(self, key):
        """Store every version of a value — never delete old ones."""
        with self._lock:
            if key not in self._cache:
                self._cache[key] = []
            return self._cache[key]

    def add_version(self, key, value):
        with self._lock:
            if key not in self._cache:
                self._cache[key] = []
            self._cache[key].append(value)


class ConnectionPool:
    """Database connection pool."""

    def __init__(self, max_size=10):
        self._connections = []
        self._max_size = max_size

    def get_connection(self):
        if self._connections:
            return self._connections.pop()
        return self._create_connection()

    def _create_connection(self):
        import sqlite3
        return sqlite3.connect("app.db")

    # Note: no release_connection or close method
''',
        "bugs": ["Unbounded cache growth — no eviction/TTL", "Version history grows without limit",
                 "Connection pool never returns connections", "No pool size enforcement on creation",
                 "No cleanup/close on shutdown"],
    },
    "race_condition": {
        "title": "Race Condition & Thread Safety",
        "language": "python",
        "code": '''
import threading
import time

class BankAccount:
    """Simple bank account — not thread-safe."""

    def __init__(self, balance=0):
        self.balance = balance
        self.transaction_log = []

    def deposit(self, amount):
        current = self.balance
        time.sleep(0.001)  # Simulate processing
        self.balance = current + amount
        self.transaction_log.append(f"+{amount}")

    def withdraw(self, amount):
        if self.balance >= amount:
            current = self.balance
            time.sleep(0.001)
            self.balance = current - amount
            self.transaction_log.append(f"-{amount}")
            return True
        return False

    def transfer(self, other, amount):
        if self.withdraw(amount):
            other.deposit(amount)
            return True
        return False


counter = 0

def increment():
    global counter
    for _ in range(100000):
        counter += 1

def run_counter_test():
    threads = [threading.Thread(target=increment) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    print(f"Expected: 400000, Got: {counter}")
''',
        "bugs": ["Read-modify-write race on balance", "Withdraw check-then-act is not atomic",
                 "Transfer is not atomic — can leave inconsistent state",
                 "Global counter increment is not atomic"],
    },
}


# ---------------------------------------------------------------------------
# Review prompt
# ---------------------------------------------------------------------------

CODE_REVIEW_PROMPT = """You are a senior software engineer performing a code review.
Analyze the following {language} code and provide:

1. **Security Issues** — vulnerabilities, injection risks, auth problems
2. **Bug Risks** — race conditions, edge cases, logic errors
3. **Resource Management** — leaks, unbounded growth, missing cleanup
4. **Best Practices** — improvements for production readiness

For each issue, state the severity (CRITICAL / HIGH / MEDIUM / LOW) and suggest a fix.

Code to review:
```{language}
{code}
```

Provide a concise, actionable review."""


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ReviewResult:
    """Result from a single code review."""
    model: str
    source: str  # "cloud" or "local"
    review_text: str
    latency_ms: float
    prompt_tokens: int = 0
    completion_tokens: int = 0
    estimated_cost_usd: float = 0.0
    quality_score: float = 0.0
    error: Optional[str] = None


@dataclass
class ComparisonResult:
    """Side-by-side comparison of cloud vs local review."""
    sample_key: str
    sample_title: str
    cloud: Optional[ReviewResult] = None
    local: Optional[ReviewResult] = None


# ---------------------------------------------------------------------------
# Cloud review via OpenAI
# ---------------------------------------------------------------------------

def review_with_cloud(code: str, language: str = "python",
                      model: str = "gpt-4o-mini") -> ReviewResult:
    """Review code using OpenAI cloud API."""
    client = OpenAI()
    prompt = CODE_REVIEW_PROMPT.format(language=language, code=code)

    start = time.time()
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=1024,
        )
        latency = (time.time() - start) * 1000

        usage = response.usage
        prompt_tokens = usage.prompt_tokens if usage else 0
        completion_tokens = usage.completion_tokens if usage else 0

        # GPT-4o-mini pricing: $0.15/1M input, $0.60/1M output
        cost = (prompt_tokens * 0.15 + completion_tokens * 0.60) / 1_000_000

        return ReviewResult(
            model=model,
            source="cloud",
            review_text=response.choices[0].message.content or "",
            latency_ms=round(latency, 1),
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            estimated_cost_usd=round(cost, 6),
        )
    except Exception as e:
        latency = (time.time() - start) * 1000
        return ReviewResult(
            model=model, source="cloud", review_text="",
            latency_ms=round(latency, 1), error=str(e),
        )


# ---------------------------------------------------------------------------
# Local review via Ollama
# ---------------------------------------------------------------------------

def _check_ollama_available(model: str = "qwen2:0.5b") -> bool:
    """Check if Ollama is running and the model is available."""
    try:
        import ollama as ollama_client
        models = ollama_client.list()
        model_names = [m.model for m in models.models] if hasattr(models, 'models') else []
        # Check for exact match or prefix match (e.g., "phi3" matches "phi3:latest")
        return any(model in name or name.startswith(model) for name in model_names)
    except Exception:
        return False


def review_with_ollama(code: str, language: str = "python",
                       model: str = "qwen2:0.5b") -> ReviewResult:
    """Review code using a local Ollama model."""
    prompt = CODE_REVIEW_PROMPT.format(language=language, code=code)

    if not _check_ollama_available(model):
        return _simulate_ollama_review(code, language, model)

    try:
        import ollama as ollama_client
        start = time.time()
        response = ollama_client.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            options={"temperature": 0.3, "num_predict": 1024},
        )
        latency = (time.time() - start) * 1000

        text = response.get("message", {}).get("content", "")
        eval_count = response.get("eval_count", len(text.split()) * 2)
        prompt_eval_count = response.get("prompt_eval_count", len(prompt.split()) * 2)

        return ReviewResult(
            model=f"{model} (local)",
            source="local",
            review_text=text,
            latency_ms=round(latency, 1),
            prompt_tokens=prompt_eval_count,
            completion_tokens=eval_count,
            estimated_cost_usd=0.0,  # Free — running locally
        )
    except Exception as e:
        return _simulate_ollama_review(code, language, model, note=str(e))


# ---------------------------------------------------------------------------
# Simulated Ollama fallback
# ---------------------------------------------------------------------------

_SIMULATED_REVIEWS: dict[str, str] = {
    "sql_injection": """## Code Review — SQL Injection Vulnerability

### 1. Security Issues

**CRITICAL — SQL Injection in `get_user()`**
The query uses f-string interpolation to build SQL. An attacker can pass
`' OR '1'='1' --` as username to bypass authentication.
**Fix:** Use parameterized queries: `cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))`

**CRITICAL — SQL Injection in `search_products()`**
String concatenation in the LIKE clause allows injection.
**Fix:** `cursor.execute("SELECT * FROM products WHERE name LIKE ?", (f"%{search_term}%",))`

### 2. Bug Risks

**HIGH — Plaintext Password Storage**
Passwords are compared in plaintext. If the DB is compromised, all credentials are exposed.
**Fix:** Use `bcrypt` or `argon2` to hash passwords. Compare hashes, not raw strings.

### 3. Resource Management

**MEDIUM — No Context Manager for DB Connection**
`conn.close()` may not execute if an exception occurs between `connect()` and `close()`.
**Fix:** Use `with sqlite3.connect("users.db") as conn:` context manager.

### 4. Best Practices
- Add input sanitization before DB queries
- Use an ORM (SQLAlchemy) to reduce manual SQL
- Add logging for failed authentication attempts""",

    "missing_validation": """## Code Review — Missing Input Validation

### 1. Security Issues

**CRITICAL — Path Traversal in `process_upload()`**
`filename` from user input is joined directly into `save_path`. An attacker can send
`{"filename": "../../etc/crontab", ...}` to write anywhere on the filesystem.
**Fix:** Sanitize filename with `os.path.basename(filename)` and validate against an allowlist.

**HIGH — No File Type Validation**
Any content type can be written to disk — could be executable code.
**Fix:** Validate file extensions and content types against an allowlist.

### 2. Bug Risks

**MEDIUM — No Range Validation in `calculate_discount()`**
Negative prices or discounts > 100% produce nonsensical results.
**Fix:** `assert 0 <= discount_percent <= 100` and `assert price >= 0`.

**MEDIUM — No Bounds Checking in `get_page()`**
Negative `page_num` or `page_size` of 0 produce empty or wrong results silently.
**Fix:** Validate `page_num >= 1` and `page_size >= 1`.

### 3. Resource Management

**LOW — JSON Load Without Size Limit**
Large uploads could exhaust memory during `json.load()`.
**Fix:** Check file size before loading; set a max upload size.

### 4. Best Practices
- Validate all user inputs at the boundary
- Use Pydantic models for structured input validation
- Return descriptive error messages for invalid inputs""",

    "memory_leak": """## Code Review — Resource & Memory Leak

### 1. Security Issues

**MEDIUM — Potential DoS via Cache Exhaustion**
No size limit on `_cache` dict. An attacker sending unique keys will exhaust server memory.
**Fix:** Add max size with LRU eviction or use `functools.lru_cache`.

### 2. Bug Risks

**HIGH — Unbounded Version History**
`add_version()` appends forever. Long-running systems will OOM.
**Fix:** Cap version history length; rotate old entries.

**HIGH — Connection Pool Never Returns Connections**
`get_connection()` pops from pool but there is no `release_connection()` method to return them.
All connections will be consumed, then new ones are created without limit.
**Fix:** Add `release_connection(conn)` that appends back to `_connections`.

### 3. Resource Management

**CRITICAL — No Pool Size Enforcement**
When the pool is empty, `_create_connection()` always creates a new one with no check against `_max_size`.
This defeats the purpose of connection pooling.
**Fix:** Block or raise when `len(active) >= _max_size`.

**HIGH — No Cleanup on Shutdown**
No `close()` or `__del__` method to close DB connections when the pool is destroyed.
**Fix:** Add `close_all()` and use as context manager.

### 4. Best Practices
- Add TTL (time-to-live) to cache entries
- Use `weakref` for optional cache entries
- Implement `__enter__`/`__exit__` for connection pool""",

    "race_condition": """## Code Review — Race Condition & Thread Safety

### 1. Security Issues

**HIGH — Financial Data Corruption**
Race conditions in `BankAccount` can lead to incorrect balances — money creation or loss.
This is a financial integrity issue.

### 2. Bug Risks

**CRITICAL — Race Condition in `deposit()`**
Read-modify-write pattern without locking:
```
current = self.balance   # Thread A reads 100
                          # Thread B reads 100
self.balance = current + amount  # Thread A writes 150
                                  # Thread B writes 150 (lost update!)
```
**Fix:** Use `threading.Lock` around all balance mutations.

**CRITICAL — Check-Then-Act Race in `withdraw()`**
Balance check and deduction are not atomic. Two threads can both pass the check and overdraw.
**Fix:** Hold lock during check AND update.

**HIGH — Non-Atomic Transfer**
`transfer()` calls `withdraw()` then `deposit()` as separate operations. If the process crashes
between them, money disappears from source but never arrives at destination.
**Fix:** Lock both accounts in consistent order to prevent deadlock.

**HIGH — Global Counter Race**
`counter += 1` is not atomic in Python (it's LOAD, ADD, STORE). With 4 threads, final count
will be less than 400,000.
**Fix:** Use `threading.Lock` or `threading.atomic` counter.

### 3. Best Practices
- Use `threading.Lock` or `threading.RLock` for all shared mutable state
- Consider `queue.Queue` for producer-consumer patterns
- Use `concurrent.futures` for simpler thread management""",
}


def _simulate_ollama_review(code: str, language: str, model: str,
                            note: str = "") -> ReviewResult:
    """Simulate an Ollama review when Ollama is not available."""
    # Match code to a known sample
    review_text = None
    for key, sample in CODE_SAMPLES.items():
        if sample["code"].strip() in code.strip() or code.strip() in sample["code"].strip():
            review_text = _SIMULATED_REVIEWS.get(key)
            break

    if not review_text:
        # Generic simulated review for custom code
        review_text = _generate_generic_simulated_review(code)

    # Simulate realistic local-model latency (faster than cloud)
    simulated_latency = 800 + len(code) * 0.5  # ~1-3 seconds

    prefix = f"⚠️ **Simulated Response** — Ollama (`{model}`) not available locally.\n"
    if note:
        prefix += f"Reason: {note}\n"
    prefix += "Install Ollama and pull a model for real local inference.\n\n"

    return ReviewResult(
        model=f"{model} (simulated)",
        source="local",
        review_text=prefix + review_text,
        latency_ms=round(simulated_latency, 1),
        prompt_tokens=len(code.split()) * 2,
        completion_tokens=len(review_text.split()) * 2,
        estimated_cost_usd=0.0,
    )


def _generate_generic_simulated_review(code: str) -> str:
    """Generate a generic simulated review for unknown code."""
    issues = []
    if "eval(" in code or "exec(" in code:
        issues.append("**CRITICAL** — Use of `eval()`/`exec()` can lead to code injection.")
    if "os.system(" in code or "subprocess.call(" in code:
        issues.append("**HIGH** — Shell command execution detected. Validate inputs to prevent command injection.")
    if "password" in code.lower() and "hash" not in code.lower():
        issues.append("**HIGH** — Password handling detected without apparent hashing.")
    if "except:" in code or "except Exception:" in code:
        issues.append("**MEDIUM** — Broad exception handling hides specific errors.")
    if "TODO" in code or "FIXME" in code:
        issues.append("**LOW** — Unresolved TODO/FIXME comments found.")

    if not issues:
        issues.append("**LOW** — No major issues detected in initial scan. Consider adding type hints and docstrings.")

    review = "## Code Review (Simulated)\n\n"
    review += "### Issues Found\n\n"
    for issue in issues:
        review += f"- {issue}\n"
    review += "\n### Recommendations\n"
    review += "- Add comprehensive input validation\n"
    review += "- Ensure proper error handling with specific exceptions\n"
    review += "- Add unit tests for edge cases\n"
    return review


# ---------------------------------------------------------------------------
# Quality scoring
# ---------------------------------------------------------------------------

_QUALITY_KEYWORDS = {
    "critical": 5, "high": 3, "medium": 2, "low": 1,
    "security": 3, "vulnerability": 4, "injection": 4,
    "fix": 2, "race condition": 4, "memory leak": 3,
    "best practice": 1, "recommendation": 1,
    "thread": 2, "lock": 2, "validation": 2,
}


def score_review_quality(review_text: str, known_bugs: list[str]) -> float:
    """
    Score a code review on a 0-10 scale.
    Rewards: identifying known bugs, actionable suggestions, severity labels.
    """
    if not review_text:
        return 0.0

    text_lower = review_text.lower()
    score = 0.0

    # Credit for identifying known bugs (up to 5 points)
    bugs_found = sum(1 for bug in known_bugs if _bug_mentioned(bug, text_lower))
    bug_ratio = bugs_found / max(len(known_bugs), 1)
    score += bug_ratio * 5.0

    # Credit for keyword coverage (up to 3 points)
    keyword_score = sum(
        weight for keyword, weight in _QUALITY_KEYWORDS.items()
        if keyword in text_lower
    )
    score += min(keyword_score / 10.0, 1.0) * 3.0

    # Credit for structure (up to 2 points)
    if "##" in review_text or "**" in review_text:
        score += 0.5
    if "fix" in text_lower or "instead" in text_lower or "should" in text_lower:
        score += 0.5
    if "```" in review_text:
        score += 0.5
    if len(review_text) > 200:
        score += 0.5

    return round(min(score, 10.0), 1)


def _bug_mentioned(bug_description: str, text: str) -> bool:
    """Check if a bug description is addressed in the review text."""
    keywords = bug_description.lower().replace("—", " ").replace("-", " ").split()
    # Require at least half the keywords to match
    matches = sum(1 for kw in keywords if len(kw) > 3 and kw in text)
    return matches >= max(len([k for k in keywords if len(k) > 3]) // 2, 1)


# ---------------------------------------------------------------------------
# Comparison
# ---------------------------------------------------------------------------

def compare_reviews(sample_key: str, cloud_model: str = "gpt-4o-mini",
                    local_model: str = "qwen2:0.5b",
                    run_cloud: bool = True,
                    run_local: bool = True) -> ComparisonResult:
    """Run code review through cloud and local models, compare results."""
    sample = CODE_SAMPLES[sample_key]
    code = sample["code"]
    language = sample["language"]
    bugs = sample["bugs"]

    result = ComparisonResult(sample_key=sample_key, sample_title=sample["title"])

    if run_cloud:
        cloud_review = review_with_cloud(code, language, cloud_model)
        cloud_review.quality_score = score_review_quality(cloud_review.review_text, bugs)
        result.cloud = cloud_review

    if run_local:
        local_review = review_with_ollama(code, language, local_model)
        local_review.quality_score = score_review_quality(local_review.review_text, bugs)
        result.local = local_review

    return result


# ---------------------------------------------------------------------------
# CLI demo
# ---------------------------------------------------------------------------

def run_demo(local_model: str = "qwen2:0.5b", cloud_model: str = "gpt-4o-mini"):
    """Run the full comparison demo from CLI."""
    print("=" * 70)
    print("  🔍 Edge Code Review Assistant — Cloud LLM vs Local SLM")
    print("=" * 70)

    ollama_ok = _check_ollama_available(local_model)
    if ollama_ok:
        print(f"\n✅ Ollama detected with model: {local_model}")
    else:
        print(f"\n⚠️  Ollama not available — using simulated responses for {local_model}")
    print(f"☁️  Cloud model: {cloud_model}")
    print()

    for key, sample in CODE_SAMPLES.items():
        print(f"\n{'─' * 70}")
        print(f"📋 Sample: {sample['title']}")
        print(f"   Known bugs: {len(sample['bugs'])}")
        print(f"{'─' * 70}")

        result = compare_reviews(key, cloud_model=cloud_model, local_model=local_model)

        if result.cloud:
            r = result.cloud
            print(f"\n  ☁️  Cloud ({r.model})")
            print(f"     Latency:  {r.latency_ms:.0f} ms")
            print(f"     Tokens:   {r.prompt_tokens} in / {r.completion_tokens} out")
            print(f"     Cost:     ${r.estimated_cost_usd:.6f}")
            print(f"     Quality:  {r.quality_score}/10")
            if r.error:
                print(f"     ❌ Error: {r.error}")

        if result.local:
            r = result.local
            print(f"\n  🖥️  Local ({r.model})")
            print(f"     Latency:  {r.latency_ms:.0f} ms")
            print(f"     Tokens:   {r.prompt_tokens} in / {r.completion_tokens} out")
            print(f"     Cost:     $0.000000 (free)")
            print(f"     Quality:  {r.quality_score}/10")
            if r.error:
                print(f"     ❌ Error: {r.error}")

        if result.cloud and result.local:
            speedup = result.cloud.latency_ms / max(result.local.latency_ms, 1)
            qdiff = result.cloud.quality_score - result.local.quality_score
            print(f"\n  📊 Comparison:")
            print(f"     Speed: Local is {speedup:.1f}x {'faster' if speedup > 1 else 'slower'}")
            print(f"     Quality gap: {qdiff:+.1f} points (cloud - local)")

    print(f"\n{'=' * 70}")
    print("  ✅ Demo complete!")
    print("=" * 70)


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Local SLM Code Review Demo")
    parser.add_argument("command", nargs="?", default="demo", choices=["demo"],
                        help="Command to run (default: demo)")
    parser.add_argument("--model", default="qwen2:0.5b",
                        help="Ollama model name (default: qwen2:0.5b)")
    parser.add_argument("--cloud-model", default="gpt-4o-mini",
                        help="Cloud model name (default: gpt-4o-mini)")
    args = parser.parse_args()

    if args.command == "demo":
        run_demo(local_model=args.model, cloud_model=args.cloud_model)
