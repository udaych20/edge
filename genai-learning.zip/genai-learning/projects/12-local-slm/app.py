"""
Project 12: Local SLM — Streamlit UI
Edge Code Review Assistant: Cloud LLM vs Local SLM side-by-side comparison.
"""

import streamlit as st
import time

from slm_demo import (
    CODE_SAMPLES,
    review_with_cloud,
    review_with_ollama,
    score_review_quality,
    _check_ollama_available,
)

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="P12 · Local SLM Code Review",
    page_icon="🖥️",
    layout="wide",
)

st.title("🖥️ Edge Code Review Assistant")
st.markdown("**Compare Cloud LLM vs Local SLM** — same prompt, side-by-side results")

# ---------------------------------------------------------------------------
# Sidebar — model selection
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Configuration")

    st.subheader("Cloud Model")
    cloud_model = st.selectbox(
        "OpenAI model",
        ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"],
        index=0,
    )

    st.subheader("Local Model")
    local_model = st.text_input("Ollama model name", value="qwen2:0.5b")

    ollama_ok = _check_ollama_available(local_model)
    if ollama_ok:
        st.success(f"✅ Ollama: `{local_model}` available")
    else:
        st.warning(f"⚠️ Ollama: `{local_model}` not found — using simulation")

    st.divider()
    st.subheader("Run Options")
    run_cloud = st.checkbox("Run Cloud Review", value=True)
    run_local = st.checkbox("Run Local Review", value=True)

    st.divider()
    st.markdown("**Pricing Reference (GPT-4o-mini)**")
    st.markdown("- Input: $0.15 / 1M tokens")
    st.markdown("- Output: $0.60 / 1M tokens")
    st.markdown("- Local: **$0.00** always")

# ---------------------------------------------------------------------------
# Code input
# ---------------------------------------------------------------------------
st.subheader("📝 Code Input")

input_mode = st.radio(
    "Choose input method",
    ["Select a sample (with known bugs)", "Paste custom code"],
    horizontal=True,
)

code_to_review = ""
known_bugs: list[str] = []
sample_title = "Custom Code"

if input_mode == "Select a sample (with known bugs)":
    sample_key = st.selectbox(
        "Sample",
        list(CODE_SAMPLES.keys()),
        format_func=lambda k: f"{CODE_SAMPLES[k]['title']}  ({len(CODE_SAMPLES[k]['bugs'])} known bugs)",
    )
    sample = CODE_SAMPLES[sample_key]
    sample_title = sample["title"]
    code_to_review = sample["code"]
    known_bugs = sample["bugs"]

    with st.expander("Known bugs in this sample", expanded=False):
        for bug in known_bugs:
            st.markdown(f"- {bug}")
else:
    code_to_review = st.text_area(
        "Paste code to review",
        height=300,
        placeholder="Paste Python code here...",
    )

if code_to_review.strip():
    st.code(code_to_review, language="python", line_numbers=True)

# ---------------------------------------------------------------------------
# Run review
# ---------------------------------------------------------------------------
if st.button("🔍 Run Code Review", type="primary", disabled=not code_to_review.strip()):
    if not run_cloud and not run_local:
        st.error("Enable at least one model in the sidebar.")
    else:
        col_cloud, col_local = st.columns(2)

        cloud_result = None
        local_result = None

        # --- Cloud review ---
        if run_cloud:
            with col_cloud:
                st.markdown("### ☁️ Cloud LLM")
                st.caption(f"Model: `{cloud_model}`")
                with st.spinner("Calling OpenAI API..."):
                    cloud_result = review_with_cloud(code_to_review, "python", cloud_model)
                    cloud_result.quality_score = score_review_quality(
                        cloud_result.review_text, known_bugs
                    )

        # --- Local review ---
        if run_local:
            with col_local:
                st.markdown("### 🖥️ Local SLM")
                status_label = "Running Ollama..." if ollama_ok else "Running simulation..."
                st.caption(f"Model: `{local_model}`" + ("" if ollama_ok else " (simulated)"))
                with st.spinner(status_label):
                    local_result = review_with_ollama(code_to_review, "python", local_model)
                    local_result.quality_score = score_review_quality(
                        local_result.review_text, known_bugs
                    )

        # --- Metrics ---
        st.divider()
        st.subheader("📊 Metrics Comparison")

        mc1, mc2, mc3, mc4 = st.columns(4)

        with mc1:
            st.metric(
                "☁️ Cloud Latency",
                f"{cloud_result.latency_ms:.0f} ms" if cloud_result else "—",
            )
            st.metric(
                "🖥️ Local Latency",
                f"{local_result.latency_ms:.0f} ms" if local_result else "—",
            )

        with mc2:
            st.metric(
                "☁️ Cloud Cost",
                f"${cloud_result.estimated_cost_usd:.6f}" if cloud_result else "—",
            )
            st.metric(
                "🖥️ Local Cost",
                "$0.000000" if local_result else "—",
            )

        with mc3:
            st.metric(
                "☁️ Cloud Tokens",
                f"{(cloud_result.prompt_tokens + cloud_result.completion_tokens):,}" if cloud_result else "—",
            )
            st.metric(
                "🖥️ Local Tokens",
                f"{(local_result.prompt_tokens + local_result.completion_tokens):,}" if local_result else "—",
            )

        with mc4:
            cloud_q = cloud_result.quality_score if cloud_result else 0
            local_q = local_result.quality_score if local_result else 0
            st.metric(
                "☁️ Cloud Quality",
                f"{cloud_q}/10" if cloud_result else "—",
            )
            st.metric(
                "🖥️ Local Quality",
                f"{local_q}/10" if local_result else "—",
            )

        # Speed comparison
        if cloud_result and local_result and local_result.latency_ms > 0:
            speedup = cloud_result.latency_ms / local_result.latency_ms
            if speedup > 1:
                st.info(f"⚡ Local model was **{speedup:.1f}x faster** than cloud")
            else:
                st.info(f"⚡ Cloud model was **{1/speedup:.1f}x faster** than local")

        # --- Review outputs ---
        st.divider()
        st.subheader("📄 Review Outputs")

        out_cloud, out_local = st.columns(2)

        if cloud_result:
            with out_cloud:
                st.markdown("#### ☁️ Cloud Review")
                if cloud_result.error:
                    st.error(f"Error: {cloud_result.error}")
                else:
                    st.markdown(cloud_result.review_text)

        if local_result:
            with out_local:
                st.markdown("#### 🖥️ Local Review")
                if local_result.error:
                    st.error(f"Error: {local_result.error}")
                else:
                    st.markdown(local_result.review_text)

# ---------------------------------------------------------------------------
# Footer
# ---------------------------------------------------------------------------
st.divider()
st.caption(
    "Project 12 · Local SLM — Edge Code Review Assistant · "
    "GenAI Learning Roadmap"
)
