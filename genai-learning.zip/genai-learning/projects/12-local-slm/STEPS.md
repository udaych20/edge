# Project 12: Local SLM — Edge Code Review Assistant

## 🎯 What You'll Learn
- What Small Language Models (SLMs) are and why they matter
- Running models locally with Ollama — zero API calls, full privacy
- Comparing cloud LLMs vs local SLMs: latency, cost, quality
- Building an edge-deployed code review assistant

## 📋 Concept: Small Language Models

**Cloud LLMs** (GPT-4o, Claude) are powerful but require:
- Internet connectivity and API keys
- Per-token costs that add up
- Sending potentially sensitive code to third parties

**Local SLMs** (Phi-3, Llama 3, CodeLlama, Mistral) run on your machine:
- No internet needed — works offline, on-premises, at the edge
- Zero cost per token after download
- Full data privacy — code never leaves your machine
- Lower latency for small tasks

**Trade-off**: SLMs are smaller (1B-7B params vs 100B+), so quality varies by task.

## 🛠️ Ollama Setup (Optional)

The demo works **without Ollama** using a built-in simulation mode. To use real local models:

### Install Ollama
```bash
# Linux
curl -fsSL https://ollama.com/install.sh | sh

# macOS — download from https://ollama.com/download
# Windows — download from https://ollama.com/download
```

### Pull a Code Model
```bash
ollama pull phi3                # Microsoft Phi-3 (3.8B) — fast, good at code
ollama pull codellama:7b        # Meta CodeLlama (7B) — specialized for code
ollama pull llama3.2:3b         # Meta Llama 3.2 (3B) — general purpose
```

### Verify
```bash
ollama list                     # See downloaded models
ollama run phi3 "Hello"         # Quick test
```

## 🚀 How to Run

### Prerequisites
```bash
cd projects/12-local-slm
pip install -r requirements.txt
```

### CLI Demo
```bash
# Run comparison demo (works without Ollama — uses simulation fallback)
python slm_demo.py demo

# Run with real Ollama model
python slm_demo.py demo --model phi3
```

### Streamlit UI (Port 8512)
```bash
streamlit run app.py --server.port 8512
```

## 📁 File Overview

| File | Purpose |
|------|---------|
| `slm_demo.py` | Core: code samples, cloud/local review, comparison framework |
| `app.py` | Streamlit UI with side-by-side comparison |
| `.env` | OpenAI API key for cloud comparison |
| `requirements.txt` | Dependencies |

## 🔍 What the Demo Shows

1. **Code Samples with Real Bugs** — SQL injection, missing validation, memory leaks, race conditions
2. **Cloud Review** — GPT-4o-mini analyzes the code via API
3. **Local Review** — Ollama (or simulated) SLM analyzes the same code
4. **Side-by-Side Comparison** — Latency, cost, quality score for each
5. **Quality Scoring** — Automated evaluation of both reviews

## 💡 Key Takeaways

- Local SLMs are **fast and free** for straightforward tasks
- Cloud LLMs provide **deeper analysis** for complex code
- Hybrid approach: use SLM for quick checks, escalate to cloud for critical reviews
- Privacy-sensitive environments (healthcare, finance, defense) benefit from local-only
