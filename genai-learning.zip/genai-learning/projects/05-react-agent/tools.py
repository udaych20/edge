"""
Simulated tools for the competitive intelligence agent.
Uses realistic but static data to avoid external API dependencies.
"""

import json
import math
from datetime import datetime


# ─── Tool 1: Web Search (Simulated) ──────────────────────────────────────────

SEARCH_DATABASE = {
    "tesla": [
        {"title": "Tesla Q4 2025 Earnings: Revenue Hits $32.1B", "snippet": "Tesla reported Q4 2025 revenue of $32.1B, up 18% YoY. EV deliveries reached 620K units. Margins compressed to 17.6% due to price cuts. Cybertruck production ramped to 100K/year. Energy storage deployed 14.7 GWh."},
        {"title": "Tesla vs Legacy Automakers: 2026 Market Analysis", "snippet": "Tesla holds 18.2% of global EV market (down from 22% in 2024). BYD leads at 24.1%. GM/Ford EV losses narrow but still negative margin. Tesla's FSD v13 achieved Level 3 in 4 US states."},
        {"title": "Tesla Robotaxi Launch: Austin Pilot Results", "snippet": "Tesla's robotaxi pilot in Austin TX completed 50K trips, 4.2/5 user rating. Revenue per mile: $2.10. Expansion to LA and SF planned for Q3 2026. Waymo still leads with 100K+ weekly trips."},
    ],
    "nvidia": [
        {"title": "NVIDIA FY2026 Revenue: $130B+", "snippet": "NVIDIA reported FY2026 revenue of $130.5B, up 78% YoY. Data center revenue $112B (86% of total). Blackwell B200 GPUs account for 60% of DC revenue. Gross margin: 73.2%."},
        {"title": "AI Chip Market 2026: NVIDIA Dominates", "snippet": "NVIDIA holds 82% of AI training accelerator market. AMD MI350 gaining at 12%. Intel Gaudi 3 at 3%. Custom chips (Google TPU, AWS Trainium) at 8%. Total AI chip market: $180B."},
        {"title": "NVIDIA CUDA Ecosystem Lock-in Analysis", "snippet": "NVIDIA's CUDA ecosystem has 5M+ developers. ROCm adoption growing but still <15% compatibility. Triton compiler gaining traction. Enterprise lock-in estimated at 3-5 year switching cost."},
    ],
    "cloud market": [
        {"title": "Cloud Infrastructure Market Share Q1 2026", "snippet": "AWS: 31% ($28B quarterly), Azure: 25% ($22B), GCP: 12% ($11B). Total cloud market: $90B/quarter. AI workloads driving 40% of new spend. Multi-cloud adoption at 78% of enterprises."},
        {"title": "Azure AI Services Growth", "snippet": "Microsoft Azure AI revenue grew 92% YoY, driven by OpenAI integration. Azure OpenAI Service has 85K enterprise customers. Copilot stack generating $5B+ annual run rate."},
    ],
    "default": [
        {"title": "Market Analysis Report", "snippet": "Comprehensive market data available. Check specific company or sector searches for detailed results."},
    ],
}


def web_search(query: str) -> str:
    """Search the web for information about a topic."""
    query_lower = query.lower()
    results = None
    for key, data in SEARCH_DATABASE.items():
        if key in query_lower:
            results = data
            break
    if not results:
        results = SEARCH_DATABASE["default"]

    formatted = []
    for r in results:
        formatted.append(f"**{r['title']}**\n{r['snippet']}")
    return "\n\n".join(formatted)


# ─── Tool 2: Company Financials ──────────────────────────────────────────────

FINANCIALS_DB = {
    "TSLA": {
        "company": "Tesla, Inc.",
        "ticker": "TSLA",
        "market_cap": "$890B",
        "revenue_ttm": "$115.2B",
        "net_income_ttm": "$12.8B",
        "gross_margin": "17.6%",
        "pe_ratio": 69.5,
        "ev_deliveries_2025": "2.1M units",
        "employees": "140,000",
        "yoy_revenue_growth": "18%",
    },
    "NVDA": {
        "company": "NVIDIA Corporation",
        "ticker": "NVDA",
        "market_cap": "$3.8T",
        "revenue_ttm": "$130.5B",
        "net_income_ttm": "$63.2B",
        "gross_margin": "73.2%",
        "pe_ratio": 55.2,
        "data_center_pct": "86%",
        "employees": "32,000",
        "yoy_revenue_growth": "78%",
    },
    "MSFT": {
        "company": "Microsoft Corporation",
        "ticker": "MSFT",
        "market_cap": "$3.5T",
        "revenue_ttm": "$264B",
        "net_income_ttm": "$88B",
        "gross_margin": "69.8%",
        "pe_ratio": 35.8,
        "cloud_revenue": "$88B",
        "employees": "228,000",
        "yoy_revenue_growth": "16%",
    },
    "AMZN": {
        "company": "Amazon.com, Inc.",
        "ticker": "AMZN",
        "market_cap": "$2.3T",
        "revenue_ttm": "$638B",
        "net_income_ttm": "$52B",
        "gross_margin": "48.2%",
        "pe_ratio": 42.1,
        "aws_revenue": "$112B",
        "employees": "1,540,000",
        "yoy_revenue_growth": "12%",
    },
    "GOOGL": {
        "company": "Alphabet Inc.",
        "ticker": "GOOGL",
        "market_cap": "$2.4T",
        "revenue_ttm": "$365B",
        "net_income_ttm": "$95B",
        "gross_margin": "57.4%",
        "pe_ratio": 24.8,
        "cloud_revenue": "$44B",
        "employees": "182,000",
        "yoy_revenue_growth": "14%",
    },
}


def get_company_financials(ticker: str) -> str:
    """Get financial data for a company by stock ticker symbol."""
    ticker_upper = ticker.upper()
    if ticker_upper in FINANCIALS_DB:
        data = FINANCIALS_DB[ticker_upper]
        return json.dumps(data, indent=2)
    return json.dumps({"error": f"No data for ticker '{ticker}'. Available: {list(FINANCIALS_DB.keys())}"})


# ─── Tool 3: Calculator ──────────────────────────────────────────────────────


def calculate(expression: str) -> str:
    """Evaluate a mathematical expression. Supports basic math and common functions."""
    allowed = {
        "abs": abs, "round": round, "min": min, "max": max,
        "sqrt": math.sqrt, "log": math.log, "log10": math.log10,
        "pow": pow, "ceil": math.ceil, "floor": math.floor,
    }
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)
        return str(result)
    except Exception as e:
        return f"Error: {e}"


# ─── Tool 4: Report Writer ──────────────────────────────────────────────────


def write_report_section(title: str, content: str) -> str:
    """Structure findings into a formatted report section."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    return f"""
## {title}
*Generated: {timestamp}*

{content}

---
"""


# ─── Tool Definitions (OpenAI function schema) ───────────────────────────────

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Search the web for current information about companies, markets, and trends. Use specific queries for best results.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query (e.g., 'Tesla Q4 2025 earnings')"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_company_financials",
            "description": "Get financial metrics for a public company. Use stock ticker symbols (e.g., TSLA, NVDA, MSFT, AMZN, GOOGL).",
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {"type": "string", "description": "Stock ticker symbol (e.g., 'TSLA')"},
                },
                "required": ["ticker"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "Perform mathematical calculations. Supports +, -, *, /, **, sqrt(), log(), round(), etc.",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "Math expression (e.g., '(32.1 / 115.2) * 100')"},
                },
                "required": ["expression"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_report_section",
            "description": "Create a structured section for the final analysis report.",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Section heading"},
                    "content": {"type": "string", "description": "Section content in markdown"},
                },
                "required": ["title", "content"],
            },
        },
    },
]

TOOL_FUNCTIONS = {
    "web_search": lambda args: web_search(args["query"]),
    "get_company_financials": lambda args: get_company_financials(args["ticker"]),
    "calculate": lambda args: calculate(args["expression"]),
    "write_report_section": lambda args: write_report_section(args["title"], args["content"]),
}
