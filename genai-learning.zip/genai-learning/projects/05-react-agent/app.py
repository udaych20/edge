"""
P05 – ReAct Agent: Streamlit UI
=================================
Research agent with step-by-step reasoning visualization.
"""

import streamlit as st
from react_agent import AgentRun, run_agent, DEMO_QUERIES

st.set_page_config(page_title="P05 – ReAct Agent", page_icon="🧠", layout="wide")

st.title("🧠 P05 – ReAct Agent: Competitive Intelligence")
st.caption("Autonomous research agent using Reason-Act-Observe loop")

with st.sidebar:
    st.header("Example Queries")
    for i, q in enumerate(DEMO_QUERIES):
        if st.button(q[:50] + "...", key=f"demo_{i}", use_container_width=True):
            st.session_state["query_input"] = q

    st.divider()
    max_steps = st.slider("Max iterations", 3, 15, 10)

# Input
default_q = st.session_state.get("query_input", "")
query = st.text_area("Enter your research query:", value=default_q, height=80)

if st.button("🚀 Run Research Agent", type="primary", use_container_width=True):
    if not query.strip():
        st.warning("⚠️ Please enter a research query or select an example from the sidebar.")
    else:
        with st.status("Agent is researching...", expanded=True) as status:
            result = run_agent(query, max_iterations=max_steps, verbose=False)
            status.update(label=f"Research complete in {result.total_time:.1f}s", state="complete")

        # Metrics
        c1, c2, c3 = st.columns(3)
        c1.metric("Steps", len(result.steps))
        c2.metric("Tool Calls", result.total_tool_calls)
        c3.metric("Time", f"{result.total_time:.1f}s")

        # Show reasoning steps
        with st.expander("🔍 Agent Reasoning Steps", expanded=False):
            for step in result.steps:
                st.markdown(f"### Step {step.step_number}")
                if step.tool_calls:
                    for tc in step.tool_calls:
                        st.markdown(f"🔧 **{tc['name']}**(`{tc['args']}`)")
                    for tr in step.tool_results:
                        st.code(tr["result"][:300], language="text")
                if step.is_final:
                    st.success("Agent decided it has enough information.")

        # Final report
        st.markdown("---")
        st.markdown("## 📊 Analysis Report")
        st.markdown(result.final_answer)
