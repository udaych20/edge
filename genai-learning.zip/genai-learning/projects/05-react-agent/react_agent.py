"""
ReAct Agent — Competitive Intelligence Research Agent
=====================================================
Implements the Reason-Act-Observe loop using OpenAI's tool-calling API.
The agent autonomously decides which tools to use and iterates until
it has enough information to produce a comprehensive analysis.
"""

import json
import os
import time
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI

from tools import TOOLS, TOOL_FUNCTIONS

load_dotenv()
client = OpenAI()

SYSTEM_PROMPT = """You are a senior competitive intelligence analyst. Your job is to research 
companies, markets, and competitive landscapes, then produce structured analysis reports.

Your approach:
1. REASON: Think about what information you need and which tools will get it
2. ACT: Use the available tools to gather data
3. OBSERVE: Analyze the results and decide if you need more information
4. REPEAT until you have comprehensive data
5. REPORT: Compile findings into a structured analysis

Be thorough — check multiple sources, compute relevant metrics, and provide
actionable insights. Always back your claims with data from your research.

Available tools: web_search, get_company_financials, calculate, write_report_section
"""


@dataclass
class AgentStep:
    """One step in the ReAct loop."""
    step_number: int
    reasoning: Optional[str] = None
    tool_calls: list = field(default_factory=list)
    tool_results: list = field(default_factory=list)
    is_final: bool = False
    final_answer: Optional[str] = None


@dataclass
class AgentRun:
    """Complete agent execution record."""
    query: str
    steps: list[AgentStep] = field(default_factory=list)
    final_answer: str = ""
    total_time: float = 0.0
    total_tool_calls: int = 0


def run_agent(query: str, max_iterations: int = 10, verbose: bool = True) -> AgentRun:
    """Execute the ReAct agent loop."""
    start = time.time()
    run = AgentRun(query=query)

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": query},
    ]

    for i in range(max_iterations):
        step = AgentStep(step_number=i + 1)

        if verbose:
            print(f"\n--- ReAct Step {i + 1} ---")

        # Call LLM
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            tools=TOOLS,
            temperature=0.2,
        )

        choice = response.choices[0]

        # Check if agent wants to use tools
        if choice.message.tool_calls:
            messages.append(choice.message)

            for tc in choice.message.tool_calls:
                tool_name = tc.function.name
                tool_args = json.loads(tc.function.arguments)

                step.tool_calls.append({"name": tool_name, "args": tool_args})

                if verbose:
                    args_str = json.dumps(tool_args, indent=None)
                    print(f"  🔧 {tool_name}({args_str})")

                # Execute tool
                if tool_name in TOOL_FUNCTIONS:
                    result = TOOL_FUNCTIONS[tool_name](tool_args)
                else:
                    result = f"Error: Unknown tool '{tool_name}'"

                step.tool_results.append({"tool": tool_name, "result": result[:500]})
                run.total_tool_calls += 1

                if verbose:
                    print(f"     ← {result[:150]}...")

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                })
        else:
            # Agent is done — final answer
            step.is_final = True
            step.final_answer = choice.message.content
            run.final_answer = choice.message.content

            if verbose:
                print(f"\n  💬 Final Answer (first 200 chars): {run.final_answer[:200]}...")

            run.steps.append(step)
            break

        run.steps.append(step)

    run.total_time = time.time() - start
    return run


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_QUERIES = [
    "Analyze Tesla's competitive position in the EV market. Include financial metrics, market share, and key risks/opportunities.",
    "Compare the AI chip market — who are the main players and how does NVIDIA maintain its dominance?",
    "Analyze the cloud infrastructure market: compare AWS, Azure, and GCP on revenue, market share, and AI strategy.",
]


def run_demo():
    print("=" * 70)
    print("  ReAct Agent — Competitive Intelligence Demo")
    print("=" * 70)

    # Run just the first query for demo (others can be tried in UI)
    query = DEMO_QUERIES[0]
    print(f"\n📋 Query: {query}\n")

    result = run_agent(query, verbose=True)

    print(f"\n{'=' * 70}")
    print(f"  SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Steps: {len(result.steps)}")
    print(f"  Tool calls: {result.total_tool_calls}")
    print(f"  Time: {result.total_time:.1f}s")
    print(f"\n{'=' * 70}")
    print(f"  FINAL REPORT")
    print(f"{'=' * 70}")
    print(result.final_answer)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python react_agent.py demo")
