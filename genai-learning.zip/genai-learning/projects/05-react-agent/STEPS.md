# P05 – ReAct Agent: Competitive Intelligence Research

## Concept
AI Agent using the **ReAct** (Reason + Act) pattern — the agent reasons about
what to do next, takes an action (tool call), observes the result, and repeats
until it has enough information to answer.

## Real-World Scenario
**Competitive Intelligence Agent** — A business analyst needs to research
companies. The agent can search the web, fetch company data, perform calculations,
and compile analysis reports. It decides which tools to use and in what order.

## Architecture
```
User Query: "Analyze Tesla's competitive position"
    │
    ▼
┌──────────────────────────────────────┐
│         ReAct Loop (LangGraph)       │
│  ┌─────────┐     ┌───────────────┐  │
│  │ REASON  │────▶│    ACT        │  │
│  │ (Think) │     │ (Call Tool)   │  │
│  └────▲────┘     └──────┬────────┘  │
│       │                 │            │
│       │    ┌────────────▼─────────┐  │
│       └────│    OBSERVE           │  │
│            │ (Process Result)     │  │
│            └──────────────────────┘  │
└──────────────────────────────────────┘
    │
    ▼
  Structured Analysis Report
```

## Steps

### Step 1: Understand the Tools
- **web_search**: Simulated web search (returns realistic data for demo)
- **get_company_financials**: Retrieves company financial metrics
- **calculate**: Performs mathematical calculations
- **write_report_section**: Structures findings into report format

### Step 2: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/05-react-agent
python3 react_agent.py demo
```

### Step 3: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8505
```

### Step 4: Try These Queries
1. "Analyze Tesla's competitive position vs traditional automakers"
2. "Compare the cloud market share of AWS, Azure, and GCP"
3. "Research the AI chip market and NVIDIA's dominance"

## Key Takeaways
- ReAct enables structured reasoning before each action
- The agent autonomously decides which tools to use and in what order
- Observation step lets the agent adapt strategy mid-execution
- LangGraph provides a state machine for the agent loop
