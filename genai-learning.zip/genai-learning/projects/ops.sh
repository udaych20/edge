#!/bin/bash
# ============================================================
# GenAI Projects — Operations Guide
# Azure VM: azureuser@10.0.0.32
# Projects: P01 (port 8501) through P18 (port 8518)
# ============================================================

BASE_DIR="/home/azureuser/genai-projects"
STREAMLIT="/home/azureuser/.local/bin/streamlit"

# All 18 projects with their ports
declare -A PROJECTS=(
    ["01-rag-pdf-qa"]=8501
    ["02-function-calling"]=8502
    ["03-structured-output"]=8503
    ["04-guardrails"]=8504
    ["05-react-agent"]=8505
    ["06-agent-workflows"]=8506
    ["07-multi-agent"]=8507
    ["08-mcp-server"]=8508
    ["09-a2a-protocol"]=8509
    ["10-advanced-rag"]=8510
    ["11-graphrag"]=8511
    ["12-local-slm"]=8512
    ["13-multimodal"]=8513
    ["14-voice-ai"]=8514
    ["15-evaluation"]=8515
    ["16-llmops"]=8516
    ["17-quantization"]=8517
    ["18-ai-gateway"]=8518
)

# --- Helper: resolve project name from arg (number or full name) ---
resolve_project() {
    local input="$1"
    # If just a number like "5" or "05", expand it
    if [[ "$input" =~ ^[0-9]+$ ]]; then
        input=$(printf "%02d" "$input")
        for proj in "${!PROJECTS[@]}"; do
            if [[ "$proj" == ${input}-* ]]; then
                echo "$proj"
                return
            fi
        done
    fi
    # If already a full name
    if [[ -n "${PROJECTS[$input]}" ]]; then
        echo "$input"
        return
    fi
    echo ""
}

# --- START a single project ---
start_one() {
    local proj="$1"
    local port="${PROJECTS[$proj]}"
    echo -n "Starting $proj on port $port ... "
    cd "$BASE_DIR/$proj"
    nohup $STREAMLIT run app.py \
        --server.address 0.0.0.0 \
        --server.port "$port" \
        --server.headless true \
        > streamlit.log 2>&1 &
    sleep 2
    if curl -s -o /dev/null -w '' http://localhost:$port 2>/dev/null; then
        echo "✅ UP"
    else
        echo "⏳ starting (check logs)"
    fi
}

# --- STOP a single project ---
stop_one() {
    local proj="$1"
    local port="${PROJECTS[$proj]}"
    local pids=$(lsof -ti:$port 2>/dev/null)
    if [ -n "$pids" ]; then
        echo "$pids" | xargs kill -9 2>/dev/null
        echo "Stopped $proj (port $port)"
    else
        echo "$proj (port $port) — not running"
    fi
}

# --- RESTART a single project ---
restart_one() {
    local proj="$1"
    stop_one "$proj"
    sleep 1
    start_one "$proj"
}

# --- STATUS of a single project ---
status_one() {
    local proj="$1"
    local port="${PROJECTS[$proj]}"
    local code=$(curl -s -o /dev/null -w '%{http_code}' http://localhost:$port 2>/dev/null)
    if [ "$code" = "200" ]; then
        echo "✅ $proj :$port — HTTP 200"
    else
        echo "❌ $proj :$port — DOWN (HTTP $code)"
    fi
}

# ============================================================
# COMMANDS
# ============================================================
CMD="${1:-help}"
TARGET="$2"

case "$CMD" in
    start)
        if [ -z "$TARGET" ] || [ "$TARGET" = "all" ]; then
            echo "=== Starting ALL projects ==="
            for proj in $(echo "${!PROJECTS[@]}" | tr ' ' '\n' | sort); do
                start_one "$proj"
            done
        else
            proj=$(resolve_project "$TARGET")
            if [ -z "$proj" ]; then
                echo "Unknown project: $TARGET"
                exit 1
            fi
            start_one "$proj"
        fi
        ;;
    stop)
        if [ -z "$TARGET" ] || [ "$TARGET" = "all" ]; then
            echo "=== Stopping ALL projects ==="
            for proj in $(echo "${!PROJECTS[@]}" | tr ' ' '\n' | sort); do
                stop_one "$proj"
            done
        else
            proj=$(resolve_project "$TARGET")
            if [ -z "$proj" ]; then
                echo "Unknown project: $TARGET"
                exit 1
            fi
            stop_one "$proj"
        fi
        ;;
    restart)
        if [ -z "$TARGET" ] || [ "$TARGET" = "all" ]; then
            echo "=== Restarting ALL projects ==="
            for proj in $(echo "${!PROJECTS[@]}" | tr ' ' '\n' | sort); do
                restart_one "$proj"
            done
        else
            proj=$(resolve_project "$TARGET")
            if [ -z "$proj" ]; then
                echo "Unknown project: $TARGET"
                exit 1
            fi
            restart_one "$proj"
        fi
        ;;
    status)
        echo "=== Project Status ==="
        for proj in $(echo "${!PROJECTS[@]}" | tr ' ' '\n' | sort); do
            if [ -z "$TARGET" ] || [ "$TARGET" = "all" ] || [ "$(resolve_project "$TARGET")" = "$proj" ]; then
                status_one "$proj"
            fi
        done
        ;;
    logs)
        proj=$(resolve_project "$TARGET")
        if [ -z "$proj" ]; then
            echo "Usage: $0 logs <project-number>"
            echo "Example: $0 logs 5"
            exit 1
        fi
        echo "=== Logs: $proj ==="
        tail -50 "$BASE_DIR/$proj/streamlit.log"
        ;;
    logs-follow)
        proj=$(resolve_project "$TARGET")
        if [ -z "$proj" ]; then
            echo "Usage: $0 logs-follow <project-number>"
            exit 1
        fi
        echo "=== Following logs: $proj (Ctrl+C to stop) ==="
        tail -f "$BASE_DIR/$proj/streamlit.log"
        ;;
    logs-all)
        echo "=== Recent logs from all projects ==="
        for proj in $(echo "${!PROJECTS[@]}" | tr ' ' '\n' | sort); do
            echo "--- $proj ---"
            tail -5 "$BASE_DIR/$proj/streamlit.log" 2>/dev/null || echo "(no log file)"
            echo ""
        done
        ;;
    help|*)
        echo "╔══════════════════════════════════════════════════════════╗"
        echo "║       GenAI Projects — Operations Manager               ║"
        echo "╠══════════════════════════════════════════════════════════╣"
        echo "║                                                        ║"
        echo "║  USAGE: bash ops.sh <command> [project]                ║"
        echo "║                                                        ║"
        echo "║  COMMANDS:                                             ║"
        echo "║    start [all|N]    Start project(s)                   ║"
        echo "║    stop  [all|N]    Stop project(s)                    ║"
        echo "║    restart [all|N]  Restart project(s)                 ║"
        echo "║    status [all|N]   Check HTTP status                  ║"
        echo "║    logs <N>         Show last 50 lines of log          ║"
        echo "║    logs-follow <N>  Tail -f the log (Ctrl+C to exit)   ║"
        echo "║    logs-all         Show recent logs from all projects ║"
        echo "║    help             Show this help                     ║"
        echo "║                                                        ║"
        echo "║  EXAMPLES:                                             ║"
        echo "║    bash ops.sh start all        # Start everything    ║"
        echo "║    bash ops.sh restart 5         # Restart P05        ║"
        echo "║    bash ops.sh stop 12           # Stop P12           ║"
        echo "║    bash ops.sh status            # Check all          ║"
        echo "║    bash ops.sh logs 1            # View P01 logs      ║"
        echo "║    bash ops.sh logs-follow 12    # Follow P12 logs    ║"
        echo "║                                                        ║"
        echo "╚══════════════════════════════════════════════════════════╝"
        ;;
esac
