# P08 – MCP Server: Custom Tool Server

## Concept
**Model Context Protocol (MCP)** — A standard protocol for LLM applications to
interact with external tools and data sources. MCP servers expose tools that
any MCP-compatible client can discover and invoke.

## Real-World Scenario
**DevOps Toolkit MCP Server** — Exposes server management tools:
- File operations (list, read, search)
- Database queries (SQLite)
- System metrics (CPU, memory, disk)
- Log analysis

Any MCP client (Claude Desktop, VS Code Copilot, custom apps) can connect
and use these tools.

## Steps

### Step 1: Understand MCP Architecture
```
MCP Client (Claude, Copilot, etc.)
    │
    │  JSON-RPC over stdio/SSE
    ▼
MCP Server (this project)
    │
    ├── Tool: file_list
    ├── Tool: file_read
    ├── Tool: db_query
    ├── Tool: system_metrics
    └── Tool: search_logs
```

### Step 2: Run the MCP Server
```bash
cd /home/azureuser/genai-projects/08-mcp-server
python3 mcp_server.py
```

### Step 3: Test with Built-in Client
```bash
python3 test_client.py
```

### Step 4: Launch Streamlit Dashboard
```bash
streamlit run app.py --server.port 8508
```

## Key Takeaways
- MCP standardizes tool exposure for LLM applications
- Server defines tools with JSON schemas; client discovers and invokes them
- Transport: stdio (local) or SSE (remote)
- FastMCP Python SDK simplifies server creation
