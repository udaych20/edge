"""
P08 – MCP Server: Streamlit UI
================================
Interactive DevOps toolkit with tool visualization.
"""

import streamlit as st
from mcp_server import DEMO_QUERIES, run_mcp_agent, setup_sample_data

st.set_page_config(page_title="P08 – MCP Server", page_icon="🔌", layout="wide")
st.title("🔌 P08 – MCP Server: DevOps Toolkit")
st.caption("AI assistant with MCP-style tools: files, database, logs, metrics")

# Initialize sample data
if "mcp_initialized" not in st.session_state:
    setup_sample_data()
    st.session_state.mcp_initialized = True

with st.sidebar:
    st.header("Available Tools")
    st.markdown("""
    - 📁 **file_list** — Browse files
    - 📄 **file_read** — Read file contents
    - 🗄️ **db_query** — SQL queries (read-only)
    - 📜 **search_logs** — Log analysis
    - 📊 **system_metrics** — Resource usage
    """)
    st.divider()
    st.header("Example Queries")
    for i, q in enumerate(DEMO_QUERIES):
        if st.button(q[:40] + "...", key=f"q_{i}", use_container_width=True):
            st.session_state["mcp_query"] = q

default_q = st.session_state.get("mcp_query", "")
query = st.text_input("Ask about the system:", value=default_q)

if st.button("🚀 Run Query", type="primary", use_container_width=True):
    if not query.strip():
        st.warning("⚠️ Please enter a query or select an example from the sidebar.")
    else:
        with st.spinner("Agent is investigating..."):
            result = run_mcp_agent(query, verbose=False)

        # Tool calls
        if result["tool_calls"]:
            with st.expander(f"🔧 Tool Calls ({len(result['tool_calls'])})", expanded=False):
                for tc in result["tool_calls"]:
                    st.markdown(f"**{tc['tool']}**(`{tc['args']}`)")
                    st.code(tc["result"][:300], language="json")

        st.markdown("### 💬 Answer")
        st.markdown(result["answer"])
