"""
MCP Server — DevOps Toolkit
=============================
Exposes tools for file operations, database queries, system metrics, and log analysis.
Uses the MCP Python SDK (FastMCP) for protocol-compliant tool exposure.

This module also includes a standalone demo mode that simulates MCP tool calls
through OpenAI function calling — so it works without an MCP client installed.
"""

import json
import os
import sqlite3
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
client = OpenAI()

# Working directory for file operations (sandbox)
WORK_DIR = Path(__file__).parent / "sandbox"
WORK_DIR.mkdir(exist_ok=True)
DB_PATH = WORK_DIR / "devops.db"


# ─── Setup Sample Data ──────────────────────────────────────────────────────

def setup_sample_data():
    """Create sample files and database for demos."""
    # Sample files
    (WORK_DIR / "config").mkdir(exist_ok=True)
    (WORK_DIR / "logs").mkdir(exist_ok=True)

    (WORK_DIR / "config" / "app.yaml").write_text(
        "server:\n  port: 8080\n  host: 0.0.0.0\n  workers: 4\n\n"
        "database:\n  host: db.internal\n  port: 5432\n  name: production\n  pool_size: 20\n\n"
        "cache:\n  redis_url: redis://cache.internal:6379\n  ttl: 300\n"
    )
    (WORK_DIR / "config" / "nginx.conf").write_text(
        "upstream backend {\n  server 10.0.1.10:8080;\n  server 10.0.1.11:8080;\n}\n\n"
        "server {\n  listen 443 ssl;\n  server_name api.example.com;\n  "
        "location / {\n    proxy_pass http://backend;\n  }\n}\n"
    )

    # Sample logs
    log_lines = []
    base_time = datetime.now() - timedelta(hours=2)
    levels = ["INFO", "INFO", "INFO", "WARN", "INFO", "ERROR", "INFO", "INFO", "WARN", "INFO"]
    msgs = [
        "Request processed: GET /api/users (200) 45ms",
        "Request processed: POST /api/orders (201) 120ms",
        "Cache hit for key: user:12345",
        "Slow query detected: SELECT * FROM orders WHERE... (2.3s)",
        "Request processed: GET /api/products (200) 32ms",
        "Database connection timeout after 30s (pool exhausted)",
        "Request processed: GET /api/health (200) 2ms",
        "Cache miss for key: product:catalog",
        "High memory usage: 85% of available heap",
        "Request processed: PUT /api/users/123 (200) 67ms",
    ]
    for i in range(50):
        t = base_time + timedelta(minutes=i * 2.4)
        level = levels[i % len(levels)]
        msg = msgs[i % len(msgs)]
        log_lines.append(f"{t.strftime('%Y-%m-%d %H:%M:%S')} [{level}] {msg}")

    (WORK_DIR / "logs" / "app.log").write_text("\n".join(log_lines))

    # SQLite database
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute("DROP TABLE IF EXISTS deployments")
    c.execute("""
        CREATE TABLE deployments (
            id INTEGER PRIMARY KEY,
            service TEXT,
            version TEXT,
            environment TEXT,
            deployed_at TEXT,
            deployed_by TEXT,
            status TEXT
        )
    """)
    deployments = [
        ("user-service", "v2.3.1", "production", "2026-04-07 06:00:00", "ci-bot", "success"),
        ("order-service", "v1.8.0", "production", "2026-04-06 22:00:00", "alex", "success"),
        ("payment-service", "v4.12.0", "production", "2026-04-06 18:00:00", "david", "failed"),
        ("user-service", "v2.3.0", "staging", "2026-04-06 14:00:00", "ci-bot", "success"),
        ("api-gateway", "v3.5.2", "production", "2026-04-05 10:00:00", "ci-bot", "success"),
    ]
    c.executemany("INSERT INTO deployments (service, version, environment, deployed_at, deployed_by, status) VALUES (?,?,?,?,?,?)", deployments)

    c.execute("DROP TABLE IF EXISTS incidents")
    c.execute("""
        CREATE TABLE incidents (
            id INTEGER PRIMARY KEY,
            title TEXT,
            severity TEXT,
            service TEXT,
            created_at TEXT,
            resolved_at TEXT,
            root_cause TEXT
        )
    """)
    incidents = [
        ("Payment gateway timeout", "P0", "payment-service", "2026-04-06 18:30:00", "2026-04-06 19:45:00", "Typo in EU endpoint URL"),
        ("High latency on user API", "P2", "user-service", "2026-04-05 14:00:00", "2026-04-05 15:30:00", "Missing DB index on users.email"),
        ("Memory leak in order processor", "P1", "order-service", "2026-04-04 08:00:00", None, "Under investigation"),
    ]
    c.executemany("INSERT INTO incidents (title, severity, service, created_at, resolved_at, root_cause) VALUES (?,?,?,?,?,?)", incidents)

    conn.commit()
    conn.close()


# ─── Tool Implementations ────────────────────────────────────────────────────

def tool_file_list(directory: str = ".") -> str:
    """List files and directories in the sandbox."""
    target = WORK_DIR / directory
    if not target.exists():
        return json.dumps({"error": f"Directory not found: {directory}"})
    if not str(target.resolve()).startswith(str(WORK_DIR.resolve())):
        return json.dumps({"error": "Access denied: path outside sandbox"})

    entries = []
    for item in sorted(target.iterdir()):
        entries.append({
            "name": item.name,
            "type": "directory" if item.is_dir() else "file",
            "size": item.stat().st_size if item.is_file() else None,
        })
    return json.dumps({"directory": directory, "entries": entries}, indent=2)


def tool_file_read(filepath: str) -> str:
    """Read a file from the sandbox."""
    target = WORK_DIR / filepath
    if not target.exists():
        return json.dumps({"error": f"File not found: {filepath}"})
    if not str(target.resolve()).startswith(str(WORK_DIR.resolve())):
        return json.dumps({"error": "Access denied: path outside sandbox"})

    content = target.read_text()
    return json.dumps({"file": filepath, "content": content, "size": len(content)})


def tool_db_query(query: str) -> str:
    """Execute a read-only SQL query on the DevOps database."""
    query_upper = query.strip().upper()
    if not query_upper.startswith("SELECT"):
        return json.dumps({"error": "Only SELECT queries are allowed"})

    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(query).fetchall()
        results = [dict(row) for row in rows]
        return json.dumps({"query": query, "row_count": len(results), "results": results}, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        conn.close()


def tool_search_logs(keyword: str, level: Optional[str] = None, last_n: int = 20) -> str:
    """Search application logs by keyword and optional level filter."""
    log_file = WORK_DIR / "logs" / "app.log"
    if not log_file.exists():
        return json.dumps({"error": "Log file not found"})

    lines = log_file.read_text().strip().split("\n")
    matches = []
    for line in lines:
        if keyword.lower() in line.lower():
            if level and f"[{level.upper()}]" not in line:
                continue
            matches.append(line)

    matches = matches[-last_n:]
    return json.dumps({
        "keyword": keyword,
        "level_filter": level,
        "total_matches": len(matches),
        "lines": matches,
    }, indent=2)


def tool_system_metrics() -> str:
    """Get simulated system metrics."""
    return json.dumps({
        "timestamp": datetime.now().isoformat(),
        "cpu_percent": 42.5,
        "memory": {"total_gb": 16.0, "used_gb": 11.2, "percent": 70.0},
        "disk": {"total_gb": 200.0, "used_gb": 142.0, "percent": 71.0},
        "network": {"bytes_sent_mb": 1250.3, "bytes_recv_mb": 3420.7},
        "load_average": [2.1, 1.8, 1.5],
        "top_processes": [
            {"name": "java (order-service)", "cpu": 18.2, "memory_mb": 2048},
            {"name": "python (ml-pipeline)", "cpu": 12.5, "memory_mb": 4096},
            {"name": "postgres", "cpu": 8.3, "memory_mb": 3072},
        ],
    }, indent=2)


# ─── OpenAI Function Schemas (for standalone demo) ───────────────────────────

TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "file_list",
            "description": "List files and directories in the sandbox workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "directory": {"type": "string", "description": "Relative path (default: '.')"},
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "file_read",
            "description": "Read the contents of a file in the sandbox.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string", "description": "Relative file path"},
                },
                "required": ["filepath"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "db_query",
            "description": "Execute a read-only SQL query. Tables: deployments (id, service, version, environment, deployed_at, deployed_by, status), incidents (id, title, severity, service, created_at, resolved_at, root_cause).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "SQL SELECT query"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_logs",
            "description": "Search application logs by keyword with optional level filter.",
            "parameters": {
                "type": "object",
                "properties": {
                    "keyword": {"type": "string", "description": "Search term"},
                    "level": {"type": "string", "enum": ["INFO", "WARN", "ERROR"], "description": "Log level filter"},
                    "last_n": {"type": "integer", "description": "Max results (default 20)"},
                },
                "required": ["keyword"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "system_metrics",
            "description": "Get current system resource metrics (CPU, memory, disk, network).",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]

TOOL_DISPATCH = {
    "file_list": lambda args: tool_file_list(args.get("directory", ".")),
    "file_read": lambda args: tool_file_read(args["filepath"]),
    "db_query": lambda args: tool_db_query(args["query"]),
    "search_logs": lambda args: tool_search_logs(args["keyword"], args.get("level"), args.get("last_n", 20)),
    "system_metrics": lambda args: tool_system_metrics(),
}


# ─── Agent with MCP Tools ────────────────────────────────────────────────────

def run_mcp_agent(query: str, verbose: bool = True) -> dict:
    """Run a DevOps agent that uses MCP tools via OpenAI function calling."""
    messages = [
        {
            "role": "system",
            "content": (
                "You are a DevOps assistant with access to server management tools. "
                "Use the available tools to answer questions about the system: "
                "file operations, database queries, log analysis, and system metrics. "
                "Always check the data before making claims."
            ),
        },
        {"role": "user", "content": query},
    ]

    tool_calls_log = []
    max_iterations = 8

    for _ in range(max_iterations):
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            tools=TOOLS_SCHEMA,
            temperature=0.1,
        )

        choice = response.choices[0]

        if choice.message.tool_calls:
            messages.append(choice.message)
            for tc in choice.message.tool_calls:
                name = tc.function.name
                args = json.loads(tc.function.arguments)

                if verbose:
                    print(f"  🔧 {name}({json.dumps(args)})")

                result = TOOL_DISPATCH[name](args)
                tool_calls_log.append({"tool": name, "args": args, "result": result[:500]})

                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": result,
                })
        else:
            return {
                "answer": choice.message.content,
                "tool_calls": tool_calls_log,
            }

    return {"answer": "Max iterations reached.", "tool_calls": tool_calls_log}


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_QUERIES = [
    "What files are in the config directory? Show me the app configuration.",
    "Show me all recent deployments and their status. Were there any failures?",
    "Search the logs for errors. What issues are happening?",
    "Give me a system health overview — check metrics and any recent incidents.",
]


def run_demo():
    setup_sample_data()

    print("=" * 70)
    print("  MCP Server Tools — DevOps Toolkit Demo")
    print("=" * 70)

    for i, query in enumerate(DEMO_QUERIES, 1):
        print(f"\n{'─' * 70}")
        print(f"  Query {i}: {query}")
        print(f"{'─' * 70}")

        start = time.time()
        result = run_mcp_agent(query, verbose=True)
        elapsed = time.time() - start

        print(f"\n  💬 Answer: {result['answer'][:200]}...")
        print(f"  ⏱️  {elapsed:.1f}s, {len(result['tool_calls'])} tool calls")

    print(f"\n{'=' * 70}")
    print("  All demos complete!")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python mcp_server.py demo")
