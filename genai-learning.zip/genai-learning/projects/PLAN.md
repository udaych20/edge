# GenAI Learning Roadmap — Demo Projects Master Plan

> **Created:** April 2026
> **Infrastructure:** Azure VM (10.0.0.32) + OpenAI API
> **Stack:** Python 3.12, latest libraries, Streamlit UIs
> **Repo:** c:\work\docs\genai\genai-learning\projects\

---

## Architecture

```
Azure VM (10.0.0.32)
├── /home/azureuser/genai-projects/
│   ├── 01-rag-pdf-qa/          (Port 8501)
│   ├── 02-function-calling/    (Port 8502)
│   ├── 03-structured-output/   (Port 8503)
│   ├── 04-guardrails/          (Port 8504)
│   ├── 05-react-agent/         (Port 8505)
│   ├── 06-agent-workflows/     (Port 8506)
│   ├── 07-multi-agent/         (Port 8507)
│   ├── 08-mcp-server/          (Port 8508)
│   ├── 09-a2a-protocol/        (Port 8509)
│   ├── 10-advanced-rag/        (Port 8510)
│   ├── 11-graphrag/            (Port 8511)
│   ├── 12-local-slm/           (Port 8512)
│   ├── 13-multimodal/          (Port 8513)
│   ├── 14-voice-ai/            (Port 8514)
│   ├── 15-evaluation/          (Port 8515)
│   ├── 16-llmops/              (Port 8516)
│   ├── 17-quantization/        (Port 8517)
│   ├── 18-ai-gateway/          (Port 8518)
│   ├── 19-langgraph-realtime-ops/ (Port 8519)
│   └── 20-crewai-business-workflow/ (Port 8520)
```

---

## Phase 1: Core Application Patterns (Concepts 6-10)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P01 | `01-rag-pdf-qa` | RAG + Vector DB | Enterprise knowledge base — Q&A over company policies, product docs, research papers | LangChain, ChromaDB, OpenAI Embeddings | ✅ Done |
| P02 | `02-function-calling` | Function Calling / Tool Use | AI assistant with live weather, stock, math, and dictionary tools — full tool-call loop with parallel & sequential chains | OpenAI Functions API | ✅ Done |
| P03 | `03-structured-output` | Structured Output | Multi-domain data extraction — invoices (finance), resumes (HR), medical prescriptions (healthcare), bug reports (engineering) | OpenAI Structured Outputs, Pydantic v2, Instructor | ✅ Done |
| P04 | `04-guardrails` | Guardrails & Safety | Production chatbot safety — prompt injection defense, PII redaction, topic control, toxicity filtering | Guardrails AI, Presidio, custom validators | ✅ Done |

## Phase 2: Agents & Orchestration (Concepts 11-16)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P05 | `05-react-agent` | AI Agents + ReAct | Competitive intelligence agent — researches companies, gathers financials, writes analysis reports | LangGraph, Tavily Search | ✅ Done |
| P06 | `06-agent-workflows` | Agentic Patterns | DevOps incident response — router classifies severity, planner creates runbook, reflection reviews fix quality | LangGraph state machines | ✅ Done |
| P07 | `07-multi-agent` | Multi-Agent Systems | Software team simulation — PM writes specs, Developer codes, QA tests, Tech Lead reviews | CrewAI | ✅ Done |
| P08 | `08-mcp-server` | MCP Protocol | Custom MCP server — file manager + database query + web scraper tools, usable from any MCP client | FastMCP (Python SDK) | ✅ Done |
| P09 | `09-a2a-protocol` | A2A Protocol | Cross-team agent collaboration — Sales agent discovers CRM agent, delegates lead processing via A2A | Google A2A SDK | ✅ Done |

## Phase 3: Advanced Techniques (Concepts 17-25)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P10 | `10-advanced-rag` | Advanced RAG | Legal contract analyzer — HyDE, reranking, CRAG self-correction, agentic retrieval from multi-source corpus | LangGraph, Cohere Rerank | ✅ Done |
| P11 | `11-graphrag` | GraphRAG | Fraud investigation network — extract entities/relationships from case files, traverse connections | Microsoft GraphRAG, NetworkX | ✅ Done |
| P12 | `12-local-slm` | SLMs | Edge-deployed code review assistant — runs locally via Ollama, no API calls, compares quality vs cloud LLMs | Ollama, Qwen2 0.5B | ✅ Done |
| P13 | `13-multimodal` | Multimodal AI | Insurance claims processor — analyze damage photos, extract form data, read charts from reports | GPT-4o Vision | ✅ Done |
| P14 | `14-voice-ai` | Voice & Audio AI | Meeting assistant — transcribe audio, generate summary, action items, and follow-up email | Whisper, OpenAI TTS | ✅ Done |
| P15 | `15-evaluation` | Evaluation & Observability | RAG quality dashboard — evaluate P01 with Ragas metrics, trace latency, measure faithfulness/relevancy | Ragas, LangSmith/Langfuse | ✅ Done |

## Phase 4: Production (Concepts 26-28)

| # | Project | Concepts | Real-World Scenario | Key Tech | Status |
|---|---------|----------|-------------------|----------|--------|
| P16 | `16-llmops` | LLMOps | Prompt CI/CD — version prompts, automated eval in GitHub Actions, cost tracking dashboard | Promptfoo, MLflow | ✅ Done |
| P17 | `17-quantization` | Quantization & Optimization | Model compression lab — quantize Mistral 7B to GGUF 4-bit, benchmark speed/quality tradeoffs | llama.cpp, llama-cpp-python | ✅ Done |
| P18 | `18-ai-gateway` | AI Gateway & Routing | Multi-provider gateway — unified API, smart routing by complexity, fallback chains, semantic caching | LiteLLM Proxy | ✅ Done |
| P19 | `19-langgraph-realtime-ops` | LangGraph Real-Time Ops | Incident command center — classify alerts, enrich with telemetry, branch on severity, escalate to human review, and generate remediation plan | LangGraph, OpenAI Structured Outputs | ✅ Done |
| P20 | `20-crewai-business-workflow` | CrewAI Business Workflow | Revenue operations launch crew — strategy, operations, messaging, and risk review collaborate to ship a business initiative | CrewAI | ✅ Done |

---

## Per-Project Structure

```
<project>/
├── STEPS.md             # Step-by-step guide: setup, run, understand
├── requirements.txt     # Python dependencies
├── .env                 # API keys (gitignored)
├── *.py                 # Core implementation files
├── app.py               # Streamlit UI (where applicable)
└── sample_data/         # Test data (where applicable)
```

---

## Execution Log

| Date | Project | Action | Result |
|------|---------|--------|--------|
| 2026-04-07 | P01 | Deployed + tested CLI + Streamlit | ✅ 3 PDFs ingested, Q&A working |
| 2026-04-07 | P02 | Deployed + tested 5 demos + Streamlit | ✅ All tool patterns working |
| 2026-04-07 | P03 | Deployed + fixed schema/render bugs | ✅ All 4 extractors working |
| 2026-04-07 | P04–P18 | Batch generated, deployed, tested | ✅ All 15 projects running |
| 2026-04-15 | P19,P20 | Added true LangGraph and CrewAI examples with Streamlit UIs | ✅ Repo now includes 20 projects |
| 2026-04-07 | P05,P06,P07,P08,P10,P11 | Fixed button/validation + session state bugs | ✅ All interactive inputs working |
| 2026-04-07 | P12 | Installed Ollama, pulled phi3 + qwen2:0.5b | ✅ Local SLM running on CPU |
| 2026-04-08 | All | Final cleanup, README, architecture docs | ✅ Git-ready |
