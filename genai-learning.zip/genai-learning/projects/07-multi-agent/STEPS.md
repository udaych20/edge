# P07 – Multi-Agent System: Software Team Simulation

## Concept
Multiple specialized AI agents collaborate on a task — each has a distinct role,
expertise, and communication style. Agents hand off work sequentially or in parallel.

## Real-World Scenario
**Software Development Team** — Given a feature request, a team of AI agents
simulates a real dev workflow:
1. **Product Manager** → writes user stories & acceptance criteria
2. **Developer** → generates implementation code
3. **QA Engineer** → writes test cases & identifies edge cases
4. **Tech Lead** → reviews everything, approves or requests changes

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/07-multi-agent
python3 multi_agent.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8507
```

### Step 3: Try Feature Requests
1. "Add a discount code field to the e-commerce checkout page"
2. "Build a user notification preferences API endpoint"
3. "Implement rate limiting for the public API"

## Key Takeaways
- Each agent has a specialized system prompt defining its role and output format
- Sequential handoff: PM → Dev → QA → Tech Lead
- Agents receive context from previous agents' outputs
- This pattern scales to larger teams with parallel tracks
