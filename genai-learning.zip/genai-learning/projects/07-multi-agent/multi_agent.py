"""
Multi-Agent System — Software Development Team Simulation
==========================================================
Four specialized agents collaborate on a feature request:
  1. Product Manager  → User stories & acceptance criteria
  2. Developer        → Implementation code
  3. QA Engineer      → Test cases & edge cases  
  4. Tech Lead        → Code review & approval
"""

import json
import os
import time
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
client = OpenAI()


# ─── Agent Definitions ───────────────────────────────────────────────────────

AGENTS = {
    "product_manager": {
        "name": "Sarah (Product Manager)",
        "emoji": "📋",
        "system_prompt": """You are Sarah, a Senior Product Manager at a SaaS company.
Given a feature request, you produce:
1. **User Stories** — In the format "As a [role], I want [feature], so that [benefit]"
2. **Acceptance Criteria** — Clear, testable conditions (Given/When/Then format)
3. **Priority & Scope** — Estimated effort (S/M/L/XL) and suggested MVP scope
4. **Dependencies** — Any prerequisites or related features

Be specific and practical. Think about edge cases the developer will need to handle.
Output in structured markdown.""",
    },
    "developer": {
        "name": "Alex (Senior Developer)",
        "emoji": "💻",
        "system_prompt": """You are Alex, a Senior Full-Stack Developer.
Given user stories and acceptance criteria from the PM, you produce:
1. **Technical Design** — Brief architecture/approach (2-3 sentences)
2. **Implementation Code** — Working Python code with proper structure
3. **API Endpoints** — If applicable, define REST endpoints with request/response
4. **Database Changes** — Schema changes needed (if any)

Write clean, production-quality Python code. Use type hints, docstrings, and proper error handling.
Follow SOLID principles. Output in structured markdown with code blocks.""",
    },
    "qa_engineer": {
        "name": "Maya (QA Engineer)",
        "emoji": "🧪",
        "system_prompt": """You are Maya, a Senior QA Engineer.
Given the user stories AND the implementation code, you produce:
1. **Test Plan** — Overview of testing strategy
2. **Test Cases** — Specific test cases in Given/When/Then format, covering:
   - Happy path scenarios
   - Edge cases & boundary conditions
   - Error handling scenarios
   - Security considerations
3. **Pytest Code** — Actual pytest test functions that test the implementation

Be thorough — your job is to catch bugs before production. Think about:
- Empty inputs, nulls, special characters
- Concurrent access, race conditions
- Authentication/authorization bypass
- Input validation and SQL injection

Output in structured markdown with code blocks.""",
    },
    "tech_lead": {
        "name": "Raj (Tech Lead)",
        "emoji": "👨‍💼",
        "system_prompt": """You are Raj, a Tech Lead with 15 years of experience.
Given the PM's specs, developer's code, and QA's tests, you conduct a code review:
1. **Overall Assessment** — APPROVE / REQUEST_CHANGES / REJECT
2. **Architecture Review** — Is the design sound? Scalable? Maintainable?
3. **Code Quality** — Clean code, naming, structure, SOLID adherence
4. **Security Review** — Any vulnerabilities? Input validation? Auth checks?
5. **Performance** — Any N+1 queries, missing indexes, memory concerns?
6. **Missing Items** — What was missed? What should be added before merging?
7. **Score** — Rate 1-10 with justification

Be constructive but thorough. This goes to production serving real users.
Output in structured markdown.""",
    },
}


@dataclass
class AgentOutput:
    agent_name: str
    agent_role: str
    emoji: str
    output: str
    time_seconds: float


@dataclass
class TeamResult:
    feature_request: str
    agent_outputs: list[AgentOutput] = field(default_factory=list)
    total_time: float = 0.0


def run_agent(agent_key: str, messages: list[dict]) -> tuple[str, float]:
    """Run a single agent and return (output, time)."""
    agent = AGENTS[agent_key]
    start = time.time()

    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": agent["system_prompt"]},
            *messages,
        ],
        temperature=0.3,
        max_tokens=2000,
    )

    output = response.choices[0].message.content
    elapsed = time.time() - start
    return output, elapsed


def run_team(feature_request: str, verbose: bool = True) -> TeamResult:
    """Run the full multi-agent workflow: PM → Dev → QA → Tech Lead."""
    start = time.time()
    result = TeamResult(feature_request=feature_request)
    accumulated_context = ""

    # Agent 1: Product Manager
    if verbose:
        print(f"\n{'='*60}")
        print(f"  📋 Sarah (Product Manager) is working...")
        print(f"{'='*60}")

    pm_output, pm_time = run_agent("product_manager", [
        {"role": "user", "content": f"Feature request:\n{feature_request}"},
    ])
    result.agent_outputs.append(AgentOutput(
        agent_name="Sarah", agent_role="Product Manager",
        emoji="📋", output=pm_output, time_seconds=pm_time,
    ))
    accumulated_context += f"\n## PM Specs:\n{pm_output}"
    if verbose:
        print(f"  Done in {pm_time:.1f}s")

    # Agent 2: Developer
    if verbose:
        print(f"\n{'='*60}")
        print(f"  💻 Alex (Senior Developer) is working...")
        print(f"{'='*60}")

    dev_output, dev_time = run_agent("developer", [
        {"role": "user", "content": (
            f"Feature request: {feature_request}\n\n"
            f"Product Manager's specs:\n{pm_output}\n\n"
            "Please implement this feature."
        )},
    ])
    result.agent_outputs.append(AgentOutput(
        agent_name="Alex", agent_role="Senior Developer",
        emoji="💻", output=dev_output, time_seconds=dev_time,
    ))
    accumulated_context += f"\n## Developer Implementation:\n{dev_output}"
    if verbose:
        print(f"  Done in {dev_time:.1f}s")

    # Agent 3: QA Engineer
    if verbose:
        print(f"\n{'='*60}")
        print(f"  🧪 Maya (QA Engineer) is working...")
        print(f"{'='*60}")

    qa_output, qa_time = run_agent("qa_engineer", [
        {"role": "user", "content": (
            f"Feature request: {feature_request}\n\n"
            f"PM Specs:\n{pm_output}\n\n"
            f"Developer's Implementation:\n{dev_output}\n\n"
            "Please write comprehensive tests."
        )},
    ])
    result.agent_outputs.append(AgentOutput(
        agent_name="Maya", agent_role="QA Engineer",
        emoji="🧪", output=qa_output, time_seconds=qa_time,
    ))
    accumulated_context += f"\n## QA Tests:\n{qa_output}"
    if verbose:
        print(f"  Done in {qa_time:.1f}s")

    # Agent 4: Tech Lead Review
    if verbose:
        print(f"\n{'='*60}")
        print(f"  👨‍💼 Raj (Tech Lead) is reviewing...")
        print(f"{'='*60}")

    review_output, review_time = run_agent("tech_lead", [
        {"role": "user", "content": (
            f"Feature request: {feature_request}\n\n"
            f"{accumulated_context}\n\n"
            "Please conduct a thorough code review."
        )},
    ])
    result.agent_outputs.append(AgentOutput(
        agent_name="Raj", agent_role="Tech Lead",
        emoji="👨‍💼", output=review_output, time_seconds=review_time,
    ))
    if verbose:
        print(f"  Done in {review_time:.1f}s")

    result.total_time = time.time() - start
    return result


# ─── Demo ─────────────────────────────────────────────────────────────────────

DEMO_FEATURES = [
    "Add a discount code / promo code field to the e-commerce checkout page. Users should be able to enter a code, validate it in real-time, and see the discounted total before placing their order.",
    "Build a user notification preferences API. Users can choose which notification channels (email, SMS, push, in-app) they want for different event types (order updates, promotions, security alerts).",
    "Implement rate limiting for our public REST API. Different tiers (free: 100/hr, pro: 1000/hr, enterprise: 10000/hr). Return proper 429 responses with retry-after headers.",
]


def run_demo():
    print("=" * 70)
    print("  Multi-Agent Team — Software Development Simulation")
    print("=" * 70)

    feature = DEMO_FEATURES[0]
    print(f"\n📌 Feature Request:\n{feature}\n")

    result = run_team(feature, verbose=True)

    print(f"\n{'=' * 70}")
    print(f"  TEAM OUTPUT SUMMARY — {result.total_time:.1f}s total")
    print(f"{'=' * 70}")
    for ao in result.agent_outputs:
        print(f"\n{ao.emoji} {ao.agent_name} ({ao.agent_role}) — {ao.time_seconds:.1f}s")
        print(f"{'─' * 40}")
        print(ao.output[:300] + "...")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python multi_agent.py demo")
