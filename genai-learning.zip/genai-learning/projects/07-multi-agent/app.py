"""
P07 – Multi-Agent Team: Streamlit UI
======================================
"""
import streamlit as st
from multi_agent import DEMO_FEATURES, run_team

st.set_page_config(page_title="P07 – Multi-Agent Team", page_icon="👥", layout="wide")
st.title("👥 P07 – Multi-Agent Software Team")
st.caption("PM → Developer → QA → Tech Lead collaborative workflow")

with st.sidebar:
    st.header("Sample Features")
    for i, feat in enumerate(DEMO_FEATURES):
        if st.button(feat[:45] + "...", key=f"feat_{i}", use_container_width=True):
            st.session_state["feat_input"] = feat

default_feat = st.session_state.get("feat_input", "")
feature = st.text_area("📌 Feature Request:", value=default_feat, height=100)

if st.button("🚀 Run Team", type="primary", use_container_width=True):
    if not feature.strip():
        st.warning("⚠️ Please enter a feature request or select a sample from the sidebar.")
    else:
        with st.status("Team is working...", expanded=True) as status:
            result = run_team(feature, verbose=False)
            status.update(label=f"Done in {result.total_time:.1f}s", state="complete")

        for ao in result.agent_outputs:
            with st.expander(f"{ao.emoji} {ao.agent_name} ({ao.agent_role}) — {ao.time_seconds:.1f}s", expanded=True):
                st.markdown(ao.output)
