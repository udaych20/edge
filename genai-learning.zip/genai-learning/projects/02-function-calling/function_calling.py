"""
Function Calling Engine — Core logic for the tool-use loop.
Demonstrates:
  1. Single tool call — LLM calls one tool
  2. Parallel tool calls — LLM calls multiple tools at once
  3. Sequential chain — output of tool A feeds into tool B
  4. Autonomous loop — LLM keeps calling tools until it has the answer
"""

import json
import os

from dotenv import load_dotenv
from openai import OpenAI

from tools import TOOL_DEFINITIONS, TOOL_FUNCTIONS

load_dotenv()

client = OpenAI()

SYSTEM_PROMPT = """\
You are a helpful assistant with access to the following tools:
- get_weather: Look up current weather for a city
- calculate: Evaluate math expressions
- get_stock_price: Look up stock prices by ticker symbol
- get_word_definition: Look up AI/ML term definitions

Use tools whenever a question requires real-time data, calculations, or lookups.
You may call multiple tools in parallel when the queries are independent.
Always provide a natural language summary after receiving tool results.
"""


def chat(
    user_message: str,
    conversation: list | None = None,
    model: str = "gpt-4o-mini",
    verbose: bool = True,
) -> dict:
    """
    Run the full function-calling loop:
    User message → LLM → (optional tool calls → execute → feed back) → final answer.

    Returns: {"answer": str, "tool_calls": list[dict], "messages": list}
    """
    if conversation is None:
        conversation = [{"role": "system", "content": SYSTEM_PROMPT}]

    conversation.append({"role": "user", "content": user_message})
    tool_calls_log = []
    iteration = 0
    max_iterations = 10  # safety limit

    while iteration < max_iterations:
        iteration += 1

        if verbose:
            print(f"\n--- LLM Call #{iteration} ---")

        response = client.chat.completions.create(
            model=model,
            messages=conversation,
            tools=TOOL_DEFINITIONS,
        )

        message = response.choices[0].message
        conversation.append(message)

        # If no tool calls, we have the final answer
        if not message.tool_calls:
            if verbose:
                print(f"💬 Final Answer: {message.content[:200]}...")
            return {
                "answer": message.content,
                "tool_calls": tool_calls_log,
                "messages": conversation,
            }

        # Process tool calls (may be parallel — multiple calls at once)
        if verbose:
            print(f"🔧 Tool calls requested: {len(message.tool_calls)}")

        for tool_call in message.tool_calls:
            func_name = tool_call.function.name
            func_args = json.loads(tool_call.function.arguments)

            if verbose:
                print(f"   → {func_name}({json.dumps(func_args)})")

            # Execute the tool
            if func_name in TOOL_FUNCTIONS:
                result = TOOL_FUNCTIONS[func_name](**func_args)
            else:
                result = json.dumps({"error": f"Unknown function: {func_name}"})

            if verbose:
                print(f"   ← {result[:150]}...")

            # Log
            tool_calls_log.append({
                "iteration": iteration,
                "function": func_name,
                "arguments": func_args,
                "result": json.loads(result),
            })

            # Feed result back to LLM
            conversation.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": result,
            })

    return {
        "answer": "Maximum iterations reached without a final answer.",
        "tool_calls": tool_calls_log,
        "messages": conversation,
    }


# ============================================================================
# Demo scenarios
# ============================================================================

def demo_single_tool():
    """Demo 1: Single tool call."""
    print("\n" + "=" * 60)
    print("DEMO 1: Single Tool Call")
    print("=" * 60)
    result = chat("What's the weather in Tokyo?")
    print(f"\n✅ Answer: {result['answer']}")
    print(f"   Tools used: {len(result['tool_calls'])}")
    return result


def demo_parallel_tools():
    """Demo 2: Parallel tool calls — LLM calls multiple tools at once."""
    print("\n" + "=" * 60)
    print("DEMO 2: Parallel Tool Calls")
    print("=" * 60)
    result = chat(
        "Compare the weather in London and Paris, and also tell me AAPL and MSFT stock prices."
    )
    print(f"\n✅ Answer: {result['answer']}")
    print(f"   Tools used: {len(result['tool_calls'])}")
    return result


def demo_sequential_chain():
    """Demo 3: Sequential chain — results from one call feed into the next."""
    print("\n" + "=" * 60)
    print("DEMO 3: Sequential Tool Chain")
    print("=" * 60)
    result = chat(
        "What's NVDA's stock price? Then calculate what 100 shares would be worth."
    )
    print(f"\n✅ Answer: {result['answer']}")
    print(f"   Tools used: {len(result['tool_calls'])}")
    return result


def demo_no_tool_needed():
    """Demo 4: LLM answers directly without tools (graceful fallback)."""
    print("\n" + "=" * 60)
    print("DEMO 4: No Tool Needed (Direct Answer)")
    print("=" * 60)
    result = chat("What is 2 + 2?")
    print(f"\n✅ Answer: {result['answer']}")
    print(f"   Tools used: {len(result['tool_calls'])}")
    return result


def demo_mixed_query():
    """Demo 5: Complex mixed query requiring multiple tool types."""
    print("\n" + "=" * 60)
    print("DEMO 5: Mixed Query (Weather + Calculation + Definition)")
    print("=" * 60)
    result = chat(
        "What's the temperature in Mumbai in Fahrenheit? "
        "Also calculate sqrt(625) * 3.14, "
        "and define what 'hallucination' means in AI."
    )
    print(f"\n✅ Answer: {result['answer']}")
    print(f"   Tools used: {len(result['tool_calls'])}")
    return result


# ============================================================================
# CLI
# ============================================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        demo_single_tool()
        demo_parallel_tools()
        demo_sequential_chain()
        demo_no_tool_needed()
        demo_mixed_query()
        print("\n" + "=" * 60)
        print("ALL DEMOS COMPLETE ✅")
        print("=" * 60)
    elif len(sys.argv) > 1 and sys.argv[1] == "chat":
        print("💬 Function Calling Chat (type 'quit' to exit)")
        print("Available tools: weather, calculator, stocks, AI dictionary")
        print("-" * 40)
        conversation = [{"role": "system", "content": SYSTEM_PROMPT}]
        while True:
            user_input = input("\nYou: ").strip()
            if user_input.lower() in ("quit", "exit", "q"):
                break
            result = chat(user_input, conversation=conversation, verbose=True)
            print(f"\nAssistant: {result['answer']}")
            conversation = result["messages"]
    else:
        print("Usage:")
        print("  python function_calling.py demo   # Run all 5 demos")
        print("  python function_calling.py chat   # Interactive chat")
