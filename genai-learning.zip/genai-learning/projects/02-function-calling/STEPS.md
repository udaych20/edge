# P02: Function Calling / Tool Use — Step-by-Step Guide

## Concept Covered
- **Concept 8:** Function Calling / Tool Use

## Real-World Scenario
AI assistant with live external tools — weather API, stock market data, scientific calculator, and technical dictionary. Demonstrates the full tool-call loop: LLM decides which tools to call, executes them (including parallel calls), and synthesizes results into natural language.

## Architecture
```
User Message → LLM (with tool schemas) → Tool Call Decision
    → Execute Tool(s) → Return Results → LLM Synthesizes → Final Answer
    ↑____________________________________↓ (loop until done)
```

## Files
| File | Purpose |
|------|---------|
| `tools.py` | 4 tool implementations + JSON Schema definitions (weather, calculator, stocks, dictionary) |
| `function_calling.py` | Core engine: tool-call loop, 5 demo scenarios, interactive CLI chat |
| `app.py` | Streamlit web UI with chat interface showing tool call details |
| `.env` | OpenAI API key |
| `requirements.txt` | Python dependencies |

## Steps to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run All 5 Demo Scenarios
```bash
python3 function_calling.py demo
```

**Demos included:**
| Demo | Scenario | Pattern |
|------|----------|---------|
| 1 | "Weather in Tokyo?" | Single tool call |
| 2 | "London vs Paris weather + AAPL & MSFT prices" | Parallel tool calls (4 at once) |
| 3 | "NVDA price → calculate 100 shares value" | Sequential chain (tool A → tool B) |
| 4 | "What is 2+2?" | Direct answer / fallback |
| 5 | "Mumbai weather + sqrt(625)×3.14 + define hallucination" | Mixed parallel (3 different tools) |

### 3. Interactive Chat Mode
```bash
python3 function_calling.py chat
# Type natural language queries, see tools being called in real-time
```

### 4. Run Streamlit UI
```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8502
# Open http://<server-ip>:8502
```

## Key Learning Points
1. **Tool Schemas** — JSON Schema defines each tool's name, description, and parameters
2. **LLM Decision** — The model autonomously decides IF and WHICH tools to call
3. **Parallel Calls** — LLM can request multiple independent tool calls in a single response
4. **Sequential Chains** — Output from one tool feeds into the next (NVDA price → calculate value)
5. **Tool Call Loop** — Engine loops: LLM → tool calls → results → LLM → (more tools or final answer)
6. **Graceful Fallback** — LLM answers directly when no tool is needed
7. **Result Synthesis** — LLM combines multi-tool results into coherent natural language

## What to Experiment With
- Add a new tool (e.g., `send_email`, `create_calendar_event`) to `tools.py`
- Try queries that require 3+ sequential steps
- Observe how parallel vs. sequential patterns emerge from different queries
- Compare `gpt-4o-mini` vs `gpt-4o` tool-calling reliability
