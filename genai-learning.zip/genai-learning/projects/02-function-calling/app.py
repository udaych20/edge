"""
Streamlit UI for Function Calling Demo
Run: streamlit run app.py
"""

import json
import streamlit as st
from dotenv import load_dotenv
from function_calling import chat, SYSTEM_PROMPT

load_dotenv()

st.set_page_config(page_title="Function Calling Demo", page_icon="🔧", layout="wide")
st.title("🔧 Function Calling / Tool Use")
st.markdown("**Concept 8:** LLMs invoking external tools via OpenAI Function Calling API")

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")
    model = st.selectbox("Model", ["gpt-4o-mini", "gpt-4o"], index=0)

    st.markdown("---")
    st.header("🧰 Available Tools")
    st.markdown("""
    | Tool | What It Does |
    |------|-------------|
    | **get_weather** | City weather (temp, humidity, wind) |
    | **calculate** | Math expressions (sqrt, log, etc.) |
    | **get_stock_price** | Stock price by ticker |
    | **get_word_definition** | AI/ML term definitions |
    """)

    st.markdown("---")
    st.header("💡 Try These Queries")
    example_queries = [
        "What's the weather in Tokyo?",
        "Compare weather in London and Paris, and get AAPL stock price",
        "What's NVDA stock price? Calculate the value of 100 shares",
        "Calculate sqrt(625) * pi",
        "Define 'RAG' and 'embedding'",
        "Is it warmer in Mumbai or Sydney? By how many degrees?",
    ]
    for q in example_queries:
        st.code(q, language=None)

    st.markdown("---")
    st.markdown("### How It Works")
    st.markdown("""
    1. You send a message
    2. LLM decides which tool(s) to call
    3. Tools execute and return results
    4. LLM summarizes results in natural language
    5. Loop repeats if more tools needed
    """)

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
if "chat_display" not in st.session_state:
    st.session_state.chat_display = []

if st.sidebar.button("🗑️ Clear Chat"):
    st.session_state.messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    st.session_state.chat_display = []
    st.rerun()

# ---------------------------------------------------------------------------
# Chat display
# ---------------------------------------------------------------------------
for msg in st.session_state.chat_display:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("tool_calls"):
            with st.expander(f"🔧 Tool Calls ({len(msg['tool_calls'])})"):
                for tc in msg["tool_calls"]:
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown(f"**{tc['function']}**")
                        st.json(tc["arguments"])
                    with col2:
                        st.markdown("**Result:**")
                        st.json(tc["result"])

# ---------------------------------------------------------------------------
# Chat input
# ---------------------------------------------------------------------------
if user_input := st.chat_input("Ask something (weather, stocks, math, definitions)..."):
    # Show user message
    st.session_state.chat_display.append({"role": "user", "content": user_input})
    with st.chat_message("user"):
        st.markdown(user_input)

    # Get response
    with st.chat_message("assistant"):
        with st.spinner("Thinking & calling tools..."):
            result = chat(
                user_message=user_input,
                conversation=st.session_state.messages,
                model=model,
                verbose=False,
            )

        st.markdown(result["answer"])

        if result["tool_calls"]:
            with st.expander(f"🔧 Tool Calls ({len(result['tool_calls'])})"):
                for tc in result["tool_calls"]:
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown(f"**{tc['function']}**")
                        st.json(tc["arguments"])
                    with col2:
                        st.markdown("**Result:**")
                        st.json(tc["result"])

    st.session_state.chat_display.append({
        "role": "assistant",
        "content": result["answer"],
        "tool_calls": result["tool_calls"],
    })
    st.session_state.messages = result["messages"]
