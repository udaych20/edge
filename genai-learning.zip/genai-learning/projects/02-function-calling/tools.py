"""
Tools — Simulated external functions the LLM can call.
Each tool has: implementation, JSON schema definition, and description.
Demonstrates: single tools, parallel calls, multi-step tool chains.
"""

import json
import math
from datetime import datetime, timezone


# ============================================================================
# Tool Implementations (these simulate real APIs)
# ============================================================================

def get_weather(city: str, unit: str = "celsius") -> str:
    """Simulate a weather API call."""
    # In production, this would call OpenWeatherMap, etc.
    weather_data = {
        "london": {"temp_c": 14, "condition": "Cloudy", "humidity": 78, "wind_kph": 20},
        "new york": {"temp_c": 22, "condition": "Sunny", "humidity": 55, "wind_kph": 12},
        "tokyo": {"temp_c": 26, "condition": "Partly Cloudy", "humidity": 65, "wind_kph": 8},
        "paris": {"temp_c": 18, "condition": "Rainy", "humidity": 82, "wind_kph": 15},
        "sydney": {"temp_c": 20, "condition": "Clear", "humidity": 60, "wind_kph": 18},
        "mumbai": {"temp_c": 33, "condition": "Hot & Humid", "humidity": 85, "wind_kph": 10},
    }

    city_lower = city.lower().strip()
    data = weather_data.get(city_lower)
    if not data:
        return json.dumps({"error": f"Weather data not available for '{city}'. Available: {', '.join(weather_data.keys())}"})

    temp = data["temp_c"]
    if unit.lower() == "fahrenheit":
        temp = round(temp * 9 / 5 + 32, 1)
        unit_label = "°F"
    else:
        unit_label = "°C"

    return json.dumps({
        "city": city.title(),
        "temperature": f"{temp}{unit_label}",
        "condition": data["condition"],
        "humidity": f"{data['humidity']}%",
        "wind": f"{data['wind_kph']} kph",
        "retrieved_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    })


def calculate(expression: str) -> str:
    """Safely evaluate a math expression."""
    # Whitelist safe math functions
    safe_names = {
        "abs": abs, "round": round, "min": min, "max": max,
        "sqrt": math.sqrt, "pow": pow, "log": math.log, "log10": math.log10,
        "sin": math.sin, "cos": math.cos, "tan": math.tan,
        "pi": math.pi, "e": math.e,
    }
    try:
        # Only allow safe characters
        allowed = set("0123456789+-*/().,%^ abcdefghijklmnopqrstuvwxyz")
        if not all(c in allowed for c in expression.lower()):
            return json.dumps({"error": "Expression contains invalid characters"})

        result = eval(expression, {"__builtins__": {}}, safe_names)
        return json.dumps({"expression": expression, "result": result})
    except Exception as e:
        return json.dumps({"error": f"Calculation failed: {str(e)}"})


def get_stock_price(ticker: str) -> str:
    """Simulate a stock price API."""
    stocks = {
        "AAPL": {"price": 195.50, "change": +1.25, "pct": "+0.64%", "name": "Apple Inc."},
        "GOOG": {"price": 175.20, "change": -0.80, "pct": "-0.45%", "name": "Alphabet Inc."},
        "MSFT": {"price": 420.10, "change": +3.15, "pct": "+0.76%", "name": "Microsoft Corp."},
        "AMZN": {"price": 185.75, "change": +2.40, "pct": "+1.31%", "name": "Amazon.com Inc."},
        "TSLA": {"price": 245.30, "change": -5.20, "pct": "-2.08%", "name": "Tesla Inc."},
        "NVDA": {"price": 890.60, "change": +12.30, "pct": "+1.40%", "name": "NVIDIA Corp."},
    }

    ticker_upper = ticker.upper().strip()
    data = stocks.get(ticker_upper)
    if not data:
        return json.dumps({"error": f"Ticker '{ticker}' not found. Available: {', '.join(stocks.keys())}"})

    return json.dumps({
        "ticker": ticker_upper,
        "name": data["name"],
        "price": f"${data['price']:.2f}",
        "change": f"${data['change']:+.2f}",
        "percent_change": data["pct"],
        "as_of": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    })


def get_word_definition(word: str) -> str:
    """Simulate a dictionary API."""
    definitions = {
        "rag": "Retrieval-Augmented Generation — a technique that enhances LLMs by retrieving relevant documents from external knowledge bases before generating a response.",
        "hallucination": "In AI, when a language model generates plausible-sounding but factually incorrect or fabricated information.",
        "embedding": "A dense numerical vector representation of text that captures semantic meaning, enabling similarity comparisons.",
        "transformer": "A neural network architecture based on self-attention mechanisms, forming the basis of modern LLMs like GPT and BERT.",
        "token": "The basic unit of text processed by an LLM, typically a word, subword, or character depending on the tokenizer.",
        "fine-tuning": "The process of further training a pre-trained model on a specific dataset to adapt it for a particular task or domain.",
    }

    word_lower = word.lower().strip()
    defn = definitions.get(word_lower)
    if not defn:
        return json.dumps({"error": f"Definition not found for '{word}'. Try: {', '.join(definitions.keys())}"})

    return json.dumps({"word": word, "definition": defn})


# ============================================================================
# Tool Schemas (JSON Schema for OpenAI function calling)
# ============================================================================

TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get the current weather for a city including temperature, condition, humidity, and wind speed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "The city name, e.g., 'London', 'New York', 'Tokyo'",
                    },
                    "unit": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature unit. Defaults to celsius.",
                    },
                },
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate",
            "description": "Evaluate a mathematical expression. Supports basic arithmetic (+, -, *, /), powers (**), and functions (sqrt, log, sin, cos, etc.).",
            "parameters": {
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "The math expression to evaluate, e.g., '(15 * 3) + sqrt(144)'",
                    },
                },
                "required": ["expression"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_stock_price",
            "description": "Get the current stock price, daily change, and percent change for a given ticker symbol.",
            "parameters": {
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Stock ticker symbol, e.g., 'AAPL', 'GOOG', 'MSFT'",
                    },
                },
                "required": ["ticker"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_word_definition",
            "description": "Look up the definition of an AI/ML technical term.",
            "parameters": {
                "type": "object",
                "properties": {
                    "word": {
                        "type": "string",
                        "description": "The word or term to define, e.g., 'RAG', 'embedding'",
                    },
                },
                "required": ["word"],
            },
        },
    },
]

# Map function name → callable
TOOL_FUNCTIONS = {
    "get_weather": get_weather,
    "calculate": calculate,
    "get_stock_price": get_stock_price,
    "get_word_definition": get_word_definition,
}
