# P19 - LangGraph Real-Time Ops

## Concept
This project shows a true **LangGraph** workflow for real-time operations response:
- **StateGraph orchestration** for multi-step incident handling
- **Conditional routing** based on severity
- **Tool-like telemetry enrichment** before planning remediation
- **Human review gates** for high-severity incidents

## Real-World Scenario
**Incident Command Center** - An operations team receives live alerts from systems
like PagerDuty, Datadog, or cloud monitoring. The workflow classifies severity,
pulls telemetry, investigates likely causes, routes high-severity incidents through
human review, and prepares an actionable response plan.

## Steps

### Step 1: Run CLI Demo
```bash
cd /home/azureuser/genai-projects/19-langgraph-realtime-ops
python3 langgraph_ops.py demo
```

### Step 2: Launch Streamlit UI
```bash
streamlit run app.py --server.port 8519
```

### Step 3: Try Realistic Alerts
Use the sidebar examples or paste your own production-style alert:
- Payments API outage after deployment
- Database saturation and replica lag
- Authentication failures for a region or customer segment

Toggle whether high-severity incidents should be escalated for human review
or auto-approved for immediate response.

## Key Takeaways
- LangGraph is a strong fit when workflows need **state**, **branching**, and
  **operator visibility**
- Conditional edges make escalation logic explicit and easy to debug
- A graph is often easier to reason about than a long imperative agent loop
- This pattern maps naturally to real incident response and operations automation
