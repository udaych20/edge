"""
P19 - LangGraph Real-Time Ops
=============================
Real-time incident triage and response workflow using LangGraph.
"""

from __future__ import annotations

import json
import os
import time
from typing import Any, Literal, TypedDict

from dotenv import load_dotenv
from langgraph.graph import END, START, StateGraph
from openai import OpenAI, OpenAIError
from pydantic import BaseModel, Field

load_dotenv()
client: OpenAI | None = None


class IncidentClassification(BaseModel):
    severity: Literal["P0", "P1", "P2", "P3"]
    category: str = Field(description="Primary incident category")
    summary: str = Field(description="Short plain-English summary")
    customer_impact: str = Field(description="How customers are affected")


class InvestigationNotes(BaseModel):
    suspected_root_cause: str
    evidence: list[str]
    immediate_actions: list[str]
    owner_team: str


class ResponsePlan(BaseModel):
    recommended_action: str
    rollback_plan: str
    stakeholder_message: str
    next_steps: list[str]


class OpsState(TypedDict, total=False):
    alert_text: str
    approval_mode: str
    classification: dict[str, Any]
    telemetry: dict[str, Any]
    investigation: dict[str, Any]
    human_review: dict[str, Any]
    response_plan: dict[str, Any]
    final_summary: str
    timeline: list[str]
    total_time: float


TELEMETRY_SNAPSHOTS = {
    "payments": {
        "cpu_pct": 79,
        "error_rate_pct": 18.6,
        "p95_latency_ms": 2450,
        "active_alerts": ["5xx spike", "checkout timeout", "retry storm"],
        "suggested_team": "Payments Platform",
    },
    "database": {
        "cpu_pct": 88,
        "error_rate_pct": 11.1,
        "p95_latency_ms": 1900,
        "active_alerts": ["replica lag", "connection saturation"],
        "suggested_team": "Database Reliability",
    },
    "auth": {
        "cpu_pct": 52,
        "error_rate_pct": 6.4,
        "p95_latency_ms": 980,
        "active_alerts": ["token validation failures", "login retries"],
        "suggested_team": "Identity",
    },
    "default": {
        "cpu_pct": 61,
        "error_rate_pct": 4.8,
        "p95_latency_ms": 720,
        "active_alerts": ["service degradation"],
        "suggested_team": "Core Platform",
    },
}


DEMO_ALERTS = [
    "PagerDuty: Payments API error rate jumped to 19 percent in the last 5 minutes. Checkout requests are timing out across US-East after the latest deployment.",
    "Datadog: Primary Postgres cluster is nearing connection limit. API latency is rising and the on-call team sees replica lag increasing every minute.",
    "Cloud monitoring: Authentication service reports repeated token validation failures for enterprise customers in Europe. Login success rate dropped from 99 to 91 percent.",
]


def append_timeline(state: OpsState, message: str) -> list[str]:
    timeline = list(state.get("timeline", []))
    timeline.append(message)
    return timeline


def get_client() -> OpenAI:
    global client
    if client is None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError(
                "Missing OPENAI_API_KEY. Add it to your environment or a .env file before running this project."
            )
        try:
            client = OpenAI(api_key=api_key)
        except OpenAIError as exc:
            raise RuntimeError(f"Failed to initialize OpenAI client: {exc}") from exc
    return client


def classify_alert(state: OpsState) -> OpsState:
    completion = get_client().beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an incident commander for a SaaS operations team. "
                    "Classify the alert severity and summarize customer impact. "
                    "Use P0 for severe outage or revenue or data-loss impact, P1 for "
                    "major user-facing degradation, P2 for moderate degradation, "
                    "and P3 for low urgency issues."
                ),
            },
            {"role": "user", "content": state["alert_text"]},
        ],
        response_format=IncidentClassification,
        temperature=0.0,
    )
    parsed = completion.choices[0].message.parsed
    return {
        "classification": parsed.model_dump(),
        "timeline": append_timeline(
            state,
            f"Classified incident as {parsed.severity} in category {parsed.category}.",
        ),
    }


def fetch_telemetry(state: OpsState) -> OpsState:
    alert_lower = state["alert_text"].lower()
    if "payment" in alert_lower or "checkout" in alert_lower:
        snapshot = TELEMETRY_SNAPSHOTS["payments"]
    elif "postgres" in alert_lower or "database" in alert_lower or "replica" in alert_lower:
        snapshot = TELEMETRY_SNAPSHOTS["database"]
    elif "auth" in alert_lower or "token" in alert_lower or "login" in alert_lower:
        snapshot = TELEMETRY_SNAPSHOTS["auth"]
    else:
        snapshot = TELEMETRY_SNAPSHOTS["default"]

    return {
        "telemetry": snapshot,
        "timeline": append_timeline(
            state,
            f"Pulled telemetry snapshot for {snapshot['suggested_team']}.",
        ),
    }


def investigate_incident(state: OpsState) -> OpsState:
    classification = json.dumps(state["classification"], indent=2)
    telemetry = json.dumps(state["telemetry"], indent=2)
    completion = get_client().beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a senior site reliability engineer. Review the incident "
                    "classification and telemetry, then provide likely root cause, "
                    "evidence, immediate actions, and the owning team."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Alert:\n{state['alert_text']}\n\n"
                    f"Classification:\n{classification}\n\n"
                    f"Telemetry:\n{telemetry}"
                ),
            },
        ],
        response_format=InvestigationNotes,
        temperature=0.2,
    )
    parsed = completion.choices[0].message.parsed
    return {
        "investigation": parsed.model_dump(),
        "timeline": append_timeline(
            state,
            f"Investigation prepared for owner team {parsed.owner_team}.",
        ),
    }


def should_require_human_review(state: OpsState) -> str:
    severity = state["classification"]["severity"]
    return "human_review" if severity in {"P0", "P1"} else "plan_response"


def human_review(state: OpsState) -> OpsState:
    severity = state["classification"]["severity"]
    owner_team = state["investigation"]["owner_team"]
    mode = state.get("approval_mode", "escalate")
    review = {
        "required": True,
        "decision": "approved" if mode == "approve" else "escalated",
        "reviewer": "Incident Commander",
        "reason": (
            f"{severity} incident requires a senior on-call handoff to {owner_team}."
            if mode != "approve"
            else f"{severity} incident approved for immediate automated response."
        ),
    }
    return {
        "human_review": review,
        "timeline": append_timeline(
            state,
            f"Human review decision: {review['decision']}.",
        ),
    }


def plan_response(state: OpsState) -> OpsState:
    completion = get_client().beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are an operations response coordinator. Produce a short, "
                    "practical response plan with rollback, stakeholder update, and "
                    "next steps that an on-call team can execute immediately."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Alert:\n{state['alert_text']}\n\n"
                    f"Classification:\n{json.dumps(state['classification'], indent=2)}\n\n"
                    f"Telemetry:\n{json.dumps(state['telemetry'], indent=2)}\n\n"
                    f"Investigation:\n{json.dumps(state['investigation'], indent=2)}\n\n"
                    f"Human Review:\n{json.dumps(state.get('human_review', {}), indent=2)}"
                ),
            },
        ],
        response_format=ResponsePlan,
        temperature=0.2,
    )
    parsed = completion.choices[0].message.parsed
    return {
        "response_plan": parsed.model_dump(),
        "timeline": append_timeline(state, "Generated response and rollback plan."),
    }


def finalize_response(state: OpsState) -> OpsState:
    classification = state["classification"]
    investigation = state["investigation"]
    response_plan = state["response_plan"]
    human_review_state = state.get("human_review", {})

    summary = (
        f"Severity {classification['severity']} {classification['category']} incident. "
        f"Summary: {classification['summary']} "
        f"Likely cause: {investigation['suspected_root_cause']} "
        f"Owner: {investigation['owner_team']}. "
        f"Action: {response_plan['recommended_action']} "
        f"Rollback: {response_plan['rollback_plan']} "
        f"Human review: {human_review_state.get('decision', 'not required')}."
    )

    return {
        "final_summary": summary,
        "timeline": append_timeline(state, "Prepared final operator summary."),
    }


def build_graph():
    graph = StateGraph(OpsState)
    graph.add_node("classify_alert", classify_alert)
    graph.add_node("fetch_telemetry", fetch_telemetry)
    graph.add_node("investigate_incident", investigate_incident)
    graph.add_node("human_review", human_review)
    graph.add_node("plan_response", plan_response)
    graph.add_node("finalize_response", finalize_response)

    graph.add_edge(START, "classify_alert")
    graph.add_edge("classify_alert", "fetch_telemetry")
    graph.add_edge("fetch_telemetry", "investigate_incident")
    graph.add_conditional_edges(
        "investigate_incident",
        should_require_human_review,
        {
            "human_review": "human_review",
            "plan_response": "plan_response",
        },
    )
    graph.add_edge("human_review", "plan_response")
    graph.add_edge("plan_response", "finalize_response")
    graph.add_edge("finalize_response", END)
    return graph.compile()


OPS_GRAPH = None


def run_ops_workflow(alert_text: str, approval_mode: str = "escalate") -> OpsState:
    global OPS_GRAPH
    if OPS_GRAPH is None:
        OPS_GRAPH = build_graph()
    start = time.time()
    result = OPS_GRAPH.invoke(
        {
            "alert_text": alert_text,
            "approval_mode": approval_mode,
            "timeline": [],
        }
    )
    result["total_time"] = time.time() - start
    return result


def run_demo() -> None:
    print("=" * 72)
    print("P19 - LangGraph Real-Time Ops Demo")
    print("=" * 72)
    print()
    result = run_ops_workflow(DEMO_ALERTS[0], approval_mode="escalate")
    print("Alert:")
    print(DEMO_ALERTS[0])
    print()
    print("Summary:")
    print(result["final_summary"])
    print()
    print("Timeline:")
    for item in result["timeline"]:
        print(f"- {item}")
    print()
    print(f"Completed in {result['total_time']:.1f}s")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python langgraph_ops.py demo")
