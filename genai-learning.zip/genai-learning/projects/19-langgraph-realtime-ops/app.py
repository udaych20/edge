"""
P19 - LangGraph Real-Time Ops: Streamlit UI
"""

import json

import streamlit as st

import langgraph_ops as ops

st.set_page_config(page_title="P19 - LangGraph Real-Time Ops", page_icon="OPS", layout="wide")
st.title("P19 - LangGraph Real-Time Ops")
st.caption("Real-time incident triage, investigation, and escalation with LangGraph")

with st.sidebar:
    st.header("Sample Alerts")
    demo_alerts = getattr(ops, "DEMO_ALERTS", [])
    for i, alert in enumerate(demo_alerts):
        if st.button(alert[:55] + "...", key=f"alert_{i}", use_container_width=True):
            st.session_state["ops_alert"] = alert

    approval_mode = st.radio(
        "High-severity handling",
        ["escalate", "approve"],
        format_func=lambda x: "Escalate to human review" if x == "escalate" else "Auto-approve remediation",
    )

default_alert = st.session_state.get("ops_alert", "")
alert_text = st.text_area("Incoming alert", value=default_alert, height=140)

if st.button("Run LangGraph Workflow", type="primary", use_container_width=True):
    if not alert_text.strip():
        st.warning("Please enter an alert or choose a sample from the sidebar.")
    else:
        try:
            with st.status("Workflow running...", expanded=True) as status:
                result = ops.run_ops_workflow(alert_text, approval_mode=approval_mode)
                status.update(label=f"Done in {result['total_time']:.1f}s", state="complete")
        except Exception as exc:
            st.error(str(exc))
            st.info("Set OPENAI_API_KEY in your shell or add it to a .env file in this project folder, then rerun.")
            st.stop()

        col1, col2 = st.columns([1, 1])
        with col1:
            st.subheader("Classification")
            st.json(result["classification"])
            st.subheader("Telemetry Snapshot")
            st.json(result["telemetry"])
        with col2:
            st.subheader("Investigation")
            st.json(result["investigation"])
            st.subheader("Human Review")
            st.json(result.get("human_review", {"required": False}))

        st.subheader("Response Plan")
        st.json(result["response_plan"])

        st.subheader("Final Summary")
        st.success(result["final_summary"])

        with st.expander("Execution Timeline", expanded=True):
            for item in result["timeline"]:
                st.markdown(f"- {item}")

        with st.expander("Raw State"):
            st.code(json.dumps(result, indent=2))
