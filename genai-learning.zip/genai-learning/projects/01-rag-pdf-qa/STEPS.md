# P01: RAG PDF Q&A — Step-by-Step Guide

## Concept Covered
- **Concept 6:** Retrieval-Augmented Generation (RAG)
- **Concept 7:** Vector Databases (ChromaDB)

## Real-World Scenario
Enterprise knowledge base — employees upload company policies, product documentation, and research papers, then ask natural-language questions and get grounded answers with source citations.

## Architecture
```
PDFs → PyPDFLoader → RecursiveCharacterTextSplitter → OpenAI Embeddings
    → ChromaDB (vector store) → Similarity Retrieval → LLM (GPT-4o-mini)
    → Grounded Answer + Source Citations
```

## Files
| File | Purpose |
|------|---------|
| `rag_pipeline.py` | Core RAG engine: ingest (load→chunk→embed→store) + query (retrieve→augment→generate) |
| `app.py` | Streamlit web UI with upload, ingest, and chat interface |
| `create_sample_pdfs.py` | Generates 3 sample PDFs for testing (company policy, product guide, AI research) |
| `.env` | OpenAI API key |
| `requirements.txt` | Python dependencies |

## Steps to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt reportlab
```

### 2. Create Sample PDFs (optional — or use your own)
```bash
python3 create_sample_pdfs.py
# Creates 3 PDFs in ./sample_pdfs/
```

### 3. Ingest Documents (CLI)
```bash
python3 rag_pipeline.py ingest ./sample_pdfs
# Loads PDFs → chunks → embeds → stores in ChromaDB
```

### 4. Query via CLI
```bash
python3 rag_pipeline.py query "What is the remote work policy?"
python3 rag_pipeline.py query "How does RAG work?"
python3 rag_pipeline.py query "What is Widget Pro pricing?"
```

### 5. Run Streamlit UI
```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
# Open http://<server-ip>:8501
```

## Key Learning Points
1. **Document Loading** — PyPDFLoader extracts text from PDF pages
2. **Chunking** — RecursiveCharacterTextSplitter splits text into overlapping chunks (1000 chars, 200 overlap)
3. **Embedding** — `text-embedding-3-small` converts chunks to 1536-dim vectors
4. **Vector Storage** — ChromaDB stores and indexes embeddings for fast similarity search
5. **Retrieval** — Top-K most similar chunks found via cosine similarity
6. **Augmented Generation** — Retrieved chunks injected into system prompt, LLM generates grounded answer
7. **Source Attribution** — Each answer includes source file and page number

## What to Experiment With
- Change `chunk_size` (200–2000) and see how it affects answer quality
- Change `top_k` (1–10) and observe retrieval precision vs. recall
- Try `gpt-4o` vs `gpt-4o-mini` and compare answer quality
- Upload your own PDFs and test domain-specific Q&A
