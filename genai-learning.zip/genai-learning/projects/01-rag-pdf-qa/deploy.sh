#!/bin/bash
# Deploy P01 (RAG PDF Q&A) to Azure VM
# Usage: bash deploy.sh

set -e

VM_IP="10.0.0.32"
VM_USER="azureuser"
KEY_FILE="C:/Users/NA20177316/Downloads/cloud-central-dev-ui-key.pem"
REMOTE_DIR="/home/azureuser/genai-projects/01-rag-pdf-qa"

echo "=== Deploying P01: RAG PDF Q&A to Azure VM ==="

# 1. Create remote directory
echo "[1/4] Creating remote directory..."
ssh -i "$KEY_FILE" -o StrictHostKeyChecking=no "$VM_USER@$VM_IP" \
    "mkdir -p $REMOTE_DIR"

# 2. Copy project files
echo "[2/4] Copying project files..."
scp -i "$KEY_FILE" -o StrictHostKeyChecking=no \
    requirements.txt .env rag_pipeline.py app.py create_sample_pdfs.py \
    "$VM_USER@$VM_IP:$REMOTE_DIR/"

# 3. Install dependencies
echo "[3/4] Installing dependencies on VM..."
ssh -i "$KEY_FILE" "$VM_USER@$VM_IP" << 'EOF'
cd /home/azureuser/genai-projects/01-rag-pdf-qa
python3 -m pip install --upgrade pip
pip install -r requirements.txt
pip install reportlab
EOF

# 4. Create sample PDFs and ingest
echo "[4/4] Creating sample PDFs and running ingestion..."
ssh -i "$KEY_FILE" "$VM_USER@$VM_IP" << 'EOF'
cd /home/azureuser/genai-projects/01-rag-pdf-qa
python3 create_sample_pdfs.py
python3 rag_pipeline.py ingest ./sample_pdfs
EOF

echo ""
echo "=== Deployment complete! ==="
echo "To run the Streamlit app:"
echo "  ssh -i \"$KEY_FILE\" $VM_USER@$VM_IP"
echo "  cd $REMOTE_DIR"
echo "  streamlit run app.py --server.address 0.0.0.0 --server.port 8501"
echo ""
echo "Then open: http://$VM_IP:8501"
