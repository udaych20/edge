"""
Streamlit UI for RAG PDF Q&A
Run: streamlit run app.py
"""

import os
import tempfile
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

from rag_pipeline import chunk_documents, create_vectorstore, load_pdfs, load_vectorstore, query

load_dotenv()

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(page_title="RAG PDF Q&A", page_icon="📄", layout="wide")
st.title("📄 RAG PDF Q&A")
st.markdown("**Concept 6 & 7:** Retrieval-Augmented Generation + Vector Databases")
st.markdown("Upload PDFs → Ask questions → Get grounded answers with sources")

# ---------------------------------------------------------------------------
# Sidebar: Settings
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")
    model = st.selectbox("LLM Model", ["gpt-4o-mini", "gpt-4o"], index=0)
    chunk_size = st.slider("Chunk Size", 200, 2000, 1000, step=100)
    chunk_overlap = st.slider("Chunk Overlap", 0, 500, 200, step=50)
    top_k = st.slider("Top-K Chunks to Retrieve", 1, 10, 5)

    st.markdown("---")
    st.markdown("### How It Works")
    st.markdown("""
    1. **Upload** PDF files
    2. **Chunk** documents into smaller pieces
    3. **Embed** chunks using OpenAI embeddings
    4. **Store** embeddings in ChromaDB (vector DB)
    5. **Retrieve** relevant chunks for your query
    6. **Generate** answer grounded in retrieved context
    """)

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "vectorstore" not in st.session_state:
    st.session_state.vectorstore = None
if "ingested" not in st.session_state:
    st.session_state.ingested = False
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# ---------------------------------------------------------------------------
# Step 1: Upload PDFs
# ---------------------------------------------------------------------------
st.header("1️⃣ Upload PDFs")
uploaded_files = st.file_uploader(
    "Drop your PDF files here",
    type=["pdf"],
    accept_multiple_files=True,
)

if uploaded_files and st.button("📥 Ingest Documents", type="primary"):
    with st.status("Processing documents...", expanded=True) as status:
        # Save uploads to temp directory
        with tempfile.TemporaryDirectory() as tmp_dir:
            for f in uploaded_files:
                dest = Path(tmp_dir) / f.name
                dest.write_bytes(f.getvalue())

            # Load
            st.write("📖 Loading PDFs...")
            documents = load_pdfs(tmp_dir)
            st.write(f"  ✅ Loaded **{len(documents)} pages** from {len(uploaded_files)} files")

            # Chunk
            st.write("✂️ Chunking documents...")
            chunks = chunk_documents(documents, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
            st.write(f"  ✅ Created **{len(chunks)} chunks**")

            # Embed & store
            st.write("🧮 Embedding & storing in ChromaDB...")
            st.session_state.vectorstore = create_vectorstore(chunks)
            st.write(f"  ✅ Stored in vector database")

        st.session_state.ingested = True
        st.session_state.chat_history = []
        status.update(label="✅ Ingestion complete!", state="complete")

# ---------------------------------------------------------------------------
# Step 2: Also allow loading existing vector store
# ---------------------------------------------------------------------------
chroma_path = Path(__file__).parent / "chroma_db"
if chroma_path.exists() and not st.session_state.ingested:
    if st.button("📂 Load existing vector store"):
        st.session_state.vectorstore = load_vectorstore()
        st.session_state.ingested = True
        st.success("Loaded existing vector store!")

# ---------------------------------------------------------------------------
# Step 3: Q&A
# ---------------------------------------------------------------------------
if st.session_state.ingested:
    st.header("2️⃣ Ask Questions")

    # Show chat history
    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg.get("sources"):
                with st.expander(f"📚 Sources ({len(msg['sources'])} chunks)"):
                    for i, src in enumerate(msg["sources"], 1):
                        st.markdown(f"**[{i}]** `{src['source']}` — Page {src['page']}")
                        st.caption(src["content"])

    # Chat input
    if user_question := st.chat_input("Ask a question about your documents..."):
        # Show user message
        st.session_state.chat_history.append({"role": "user", "content": user_question})
        with st.chat_message("user"):
            st.markdown(user_question)

        # Get answer
        with st.chat_message("assistant"):
            with st.spinner("Searching documents & generating answer..."):
                result = query(
                    question=user_question,
                    vectorstore=st.session_state.vectorstore,
                    model=model,
                    top_k=top_k,
                )
            st.markdown(result["answer"])
            with st.expander(f"📚 Sources ({result['num_chunks']} chunks)"):
                for i, src in enumerate(result["sources"], 1):
                    st.markdown(f"**[{i}]** `{src['source']}` — Page {src['page']}")
                    st.caption(src["content"])

        st.session_state.chat_history.append({
            "role": "assistant",
            "content": result["answer"],
            "sources": result["sources"],
        })

else:
    st.info("👆 Upload PDF files and click **Ingest Documents** to get started.")
