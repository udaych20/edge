"""
Generate sample PDFs for testing the RAG pipeline.
Creates 3 small PDFs about different topics.
Run: python create_sample_pdfs.py
"""

import os
from pathlib import Path

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
except ImportError:
    print("reportlab not installed. Installing...")
    os.system("pip install reportlab")
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet

SAMPLE_DIR = Path(__file__).parent / "sample_pdfs"

DOCUMENTS = {
    "company_policy.pdf": {
        "title": "Acme Corp — Company Policies",
        "content": [
            ("Remote Work Policy",
             "Acme Corp allows all full-time employees to work remotely up to 3 days per week. "
             "Employees must be available during core hours (10 AM - 4 PM EST). Remote work "
             "arrangements must be approved by the direct manager. Employees working remotely "
             "are expected to maintain the same level of productivity and responsiveness. "
             "A stable internet connection of at least 50 Mbps is required. The company provides "
             "a $500 annual stipend for home office setup."),
            ("Leave Policy",
             "Full-time employees receive 20 days of paid time off (PTO) per year, accruing at "
             "1.67 days per month. Unused PTO up to 5 days can be carried over to the next year. "
             "Sick leave is provided at 10 days per year and does not carry over. Parental leave "
             "is 12 weeks for primary caregivers and 4 weeks for secondary caregivers, fully paid. "
             "Bereavement leave is 5 days for immediate family."),
            ("Expense Reimbursement",
             "Business travel expenses are reimbursed within 30 days of submission. Flights must "
             "be booked in economy class for trips under 6 hours. Hotel accommodations are capped "
             "at $200 per night in most cities and $300 in high-cost cities (NYC, SF, London). "
             "Meal expenses are reimbursed up to $75 per day. All expenses over $50 require receipts. "
             "The expense report must be submitted via the internal portal within 14 days of travel."),
        ],
    },
    "product_guide.pdf": {
        "title": "Acme Widget Pro — Product Guide",
        "content": [
            ("Overview",
             "The Acme Widget Pro is a next-generation productivity tool designed for enterprise "
             "teams. It features real-time collaboration, AI-powered analytics, and seamless "
             "integration with over 200 third-party tools. The Widget Pro supports up to 10,000 "
             "concurrent users per workspace and offers 99.99% uptime SLA."),
            ("Pricing",
             "Acme Widget Pro is available in three tiers: Starter ($10/user/month) includes "
             "basic features and 10 GB storage. Professional ($25/user/month) adds AI analytics, "
             "custom workflows, and 100 GB storage. Enterprise (custom pricing) includes SSO, "
             "SCIM provisioning, dedicated support, unlimited storage, and custom SLAs. Annual "
             "billing receives a 20% discount. A 14-day free trial is available for all tiers."),
            ("Technical Specifications",
             "The platform is built on a microservices architecture running on Kubernetes. "
             "Data is encrypted at rest (AES-256) and in transit (TLS 1.3). The API supports "
             "REST and GraphQL with rate limits of 1000 requests per minute on Professional "
             "and 5000 on Enterprise. SDKs are available for Python, JavaScript, Java, and Go. "
             "The system supports SAML 2.0 and OAuth 2.0 for authentication."),
        ],
    },
    "ai_research.pdf": {
        "title": "Introduction to Retrieval-Augmented Generation",
        "content": [
            ("What is RAG?",
             "Retrieval-Augmented Generation (RAG) is a technique that enhances Large Language "
             "Models by providing them with relevant external knowledge at inference time. Instead "
             "of relying solely on parametric knowledge learned during training, RAG systems "
             "retrieve relevant documents from a knowledge base and include them in the prompt "
             "context. This approach significantly reduces hallucinations and allows models to "
             "answer questions about private or recent data without fine-tuning."),
            ("How RAG Works",
             "A typical RAG pipeline consists of three stages: (1) Indexing — documents are split "
             "into chunks, converted to embeddings using models like text-embedding-3-small, and "
             "stored in a vector database such as ChromaDB, Pinecone, or Weaviate. (2) Retrieval "
             "— when a user asks a question, the query is embedded and used to find the most "
             "similar chunks via approximate nearest neighbor search. (3) Generation — the "
             "retrieved chunks are combined with the original question in a prompt, and an LLM "
             "generates a grounded answer."),
            ("Advanced RAG Techniques",
             "Several techniques improve basic RAG: HyDE generates a hypothetical answer to "
             "improve retrieval. Reranking uses cross-encoders to re-score retrieved chunks. "
             "Corrective RAG (CRAG) adds a verification step that falls back to web search if "
             "retrieval quality is low. Agentic RAG uses an AI agent to dynamically decide "
             "whether retrieval is needed and which sources to query. GraphRAG builds a knowledge "
             "graph from documents to capture entity relationships."),
        ],
    },
}


def create_pdfs():
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()

    for filename, doc_data in DOCUMENTS.items():
        filepath = SAMPLE_DIR / filename
        doc = SimpleDocTemplate(str(filepath), pagesize=letter)
        story = []

        # Title
        story.append(Paragraph(doc_data["title"], styles["Title"]))
        story.append(Spacer(1, 20))

        # Sections
        for section_title, section_content in doc_data["content"]:
            story.append(Paragraph(section_title, styles["Heading2"]))
            story.append(Spacer(1, 10))
            story.append(Paragraph(section_content, styles["BodyText"]))
            story.append(Spacer(1, 15))

        doc.build(story)
        print(f"  Created: {filepath}")

    print(f"\n✅ {len(DOCUMENTS)} sample PDFs created in {SAMPLE_DIR}/")


if __name__ == "__main__":
    create_pdfs()
