"""
RAG Pipeline — Core engine for PDF Q&A
Demonstrates: Document loading, chunking, embedding, vector storage, retrieval, generation.
"""

import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

load_dotenv()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
CHROMA_DIR = Path(__file__).parent / "chroma_db"
COLLECTION_NAME = "pdf_docs"

SYSTEM_PROMPT = """\
You are a helpful assistant that answers questions based ONLY on the provided context.
If the context does not contain enough information to answer, say "I don't have enough information to answer that based on the provided documents."
Always cite which part of the context supports your answer.

Context:
{context}
"""


# ---------------------------------------------------------------------------
# 1. Load PDFs
# ---------------------------------------------------------------------------
def load_pdfs(pdf_dir: str) -> list:
    """Load all PDF files from a directory."""
    pdf_path = Path(pdf_dir)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF directory not found: {pdf_dir}")

    documents = []
    for pdf_file in sorted(pdf_path.glob("*.pdf")):
        print(f"  Loading: {pdf_file.name}")
        loader = PyPDFLoader(str(pdf_file))
        documents.extend(loader.load())
    print(f"  Loaded {len(documents)} pages from {pdf_dir}")
    return documents


# ---------------------------------------------------------------------------
# 2. Chunk documents
# ---------------------------------------------------------------------------
def chunk_documents(documents: list, chunk_size: int = 1000, chunk_overlap: int = 200) -> list:
    """Split documents into chunks using recursive character splitter."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    print(f"  Split into {len(chunks)} chunks (size={chunk_size}, overlap={chunk_overlap})")
    return chunks


# ---------------------------------------------------------------------------
# 3. Create / load vector store
# ---------------------------------------------------------------------------
def create_vectorstore(chunks: list, persist_dir: str | None = None) -> Chroma:
    """Create a ChromaDB vector store from document chunks."""
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    persist = str(persist_dir) if persist_dir else str(CHROMA_DIR)

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=persist,
    )
    print(f"  Stored {len(chunks)} chunks in ChromaDB at {persist}")
    return vectorstore


def load_vectorstore(persist_dir: str | None = None) -> Chroma:
    """Load an existing ChromaDB vector store."""
    embeddings = OpenAIEmbeddings(model="text-embedding-3-small")
    persist = str(persist_dir) if persist_dir else str(CHROMA_DIR)

    vectorstore = Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=persist,
    )
    count = vectorstore._collection.count()
    print(f"  Loaded vector store with {count} chunks from {persist}")
    return vectorstore


# ---------------------------------------------------------------------------
# 4. Build RAG chain
# ---------------------------------------------------------------------------
def build_rag_chain(vectorstore: Chroma, model: str = "gpt-4o-mini", top_k: int = 5):
    """Build a LangChain RAG chain: retrieve → augment → generate."""
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": top_k},
    )

    llm = ChatOpenAI(model=model, temperature=0)

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "{question}"),
    ])

    def format_docs(docs):
        return "\n\n---\n\n".join(
            f"[Source: {d.metadata.get('source', 'unknown')}, Page {d.metadata.get('page', '?')}]\n{d.page_content}"
            for d in docs
        )

    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )
    return chain, retriever


# ---------------------------------------------------------------------------
# 5. Ingest pipeline  (load → chunk → store)
# ---------------------------------------------------------------------------
def ingest(pdf_dir: str, chunk_size: int = 1000, chunk_overlap: int = 200) -> Chroma:
    """Full ingestion pipeline: PDFs → chunks → vector store."""
    print("=" * 60)
    print("STEP 1: Loading PDFs")
    print("=" * 60)
    documents = load_pdfs(pdf_dir)

    print("\n" + "=" * 60)
    print("STEP 2: Chunking documents")
    print("=" * 60)
    chunks = chunk_documents(documents, chunk_size, chunk_overlap)

    print("\n" + "=" * 60)
    print("STEP 3: Creating vector store (embedding + storing)")
    print("=" * 60)
    vectorstore = create_vectorstore(chunks)

    print("\n✅ Ingestion complete!")
    return vectorstore


# ---------------------------------------------------------------------------
# 6. Query pipeline
# ---------------------------------------------------------------------------
def query(question: str, vectorstore: Chroma | None = None, model: str = "gpt-4o-mini", top_k: int = 5) -> dict:
    """Ask a question against the vector store. Returns answer + source chunks."""
    if vectorstore is None:
        vectorstore = load_vectorstore()

    chain, retriever = build_rag_chain(vectorstore, model=model, top_k=top_k)

    # Get retrieved docs for transparency
    retrieved_docs = retriever.invoke(question)
    answer = chain.invoke(question)

    sources = [
        {
            "source": d.metadata.get("source", "unknown"),
            "page": d.metadata.get("page", "?"),
            "content": d.page_content[:200] + "...",
        }
        for d in retrieved_docs
    ]

    return {"answer": answer, "sources": sources, "num_chunks": len(retrieved_docs)}


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python rag_pipeline.py ingest <pdf_dir>")
        print("  python rag_pipeline.py query  \"your question here\"")
        sys.exit(1)

    command = sys.argv[1]

    if command == "ingest":
        pdf_dir = sys.argv[2] if len(sys.argv) > 2 else "./sample_pdfs"
        ingest(pdf_dir)

    elif command == "query":
        if len(sys.argv) < 3:
            print("Please provide a question.")
            sys.exit(1)
        question = sys.argv[2]
        result = query(question)
        print(f"\n{'=' * 60}")
        print(f"Question: {question}")
        print(f"{'=' * 60}")
        print(f"\nAnswer:\n{result['answer']}")
        print(f"\n--- Sources ({result['num_chunks']} chunks) ---")
        for i, src in enumerate(result["sources"], 1):
            print(f"\n[{i}] {src['source']} (page {src['page']})")
            print(f"    {src['content']}")
    else:
        print(f"Unknown command: {command}")
