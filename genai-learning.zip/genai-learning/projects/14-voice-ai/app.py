"""
Voice & Audio AI — Meeting Assistant (Streamlit UI)
Tabs: Transcription, Meeting Summary, Text-to-Speech, Full Pipeline
"""

import io
import tempfile
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

from voice_ai import (
    SAMPLE_TRANSCRIPT,
    VOICES,
    TTS_MODELS,
    transcribe_audio,
    summarize_meeting,
    generate_follow_up_email,
    text_to_speech,
    MeetingSummary,
)

load_dotenv()

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(page_title="Voice AI — Meeting Assistant", page_icon="🎙️", layout="wide")
st.title("🎙️ Voice & Audio AI — Meeting Assistant")
st.caption("Whisper transcription · Structured summarization · OpenAI TTS")

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab1, tab2, tab3, tab4 = st.tabs([
    "🎤 Transcription",
    "📋 Meeting Summary",
    "🔊 Text-to-Speech",
    "🔄 Full Pipeline",
])

# ===== TAB 1: Transcription ==============================================
with tab1:
    st.header("Audio Transcription (Whisper)")
    st.markdown(
        "Upload an audio file to transcribe with OpenAI Whisper, "
        "or paste a transcript directly."
    )

    input_method = st.radio(
        "Input method:", ["Upload audio file", "Paste transcript text", "Use sample transcript"],
        horizontal=True, key="t1_input",
    )

    if input_method == "Upload audio file":
        uploaded = st.file_uploader(
            "Upload audio (mp3, wav, m4a, webm — max 25MB)",
            type=["mp3", "wav", "m4a", "webm", "mp4", "mpeg", "mpga"],
            key="t1_upload",
        )
        lang = st.text_input("Language code (optional, e.g. 'en', 'es', 'fr'):", key="t1_lang")

        if uploaded and st.button("Transcribe", key="t1_btn"):
            with st.spinner("Transcribing with Whisper..."):
                with tempfile.NamedTemporaryFile(
                    delete=False, suffix=Path(uploaded.name).suffix
                ) as tmp:
                    tmp.write(uploaded.read())
                    tmp_path = tmp.name
                try:
                    transcript = transcribe_audio(tmp_path, language=lang or None)
                    st.session_state["transcript"] = transcript
                    st.success("Transcription complete!")
                    st.text_area("Transcript:", transcript, height=300)
                except Exception as e:
                    st.error(f"Transcription failed: {e}")
                finally:
                    Path(tmp_path).unlink(missing_ok=True)

    elif input_method == "Paste transcript text":
        pasted = st.text_area("Paste your transcript:", height=300, key="t1_paste")
        if pasted:
            st.session_state["transcript"] = pasted
            st.info(f"Transcript loaded — {len(pasted)} characters")

    else:  # Sample transcript
        st.session_state["transcript"] = SAMPLE_TRANSCRIPT
        with st.expander("View sample transcript", expanded=False):
            st.text(SAMPLE_TRANSCRIPT)
        st.success("Sample transcript loaded (Q1 Product Planning Meeting)")


# ===== TAB 2: Meeting Summary ============================================
with tab2:
    st.header("Meeting Summary & Action Items")
    st.markdown("Generate a structured summary from a meeting transcript.")

    transcript_source = st.radio(
        "Transcript source:",
        ["From Transcription tab", "Paste new transcript", "Use sample"],
        horizontal=True, key="t2_source",
    )

    transcript_text = ""
    if transcript_source == "From Transcription tab":
        transcript_text = st.session_state.get("transcript", "")
        if not transcript_text:
            st.warning("No transcript found. Go to the Transcription tab first.")
    elif transcript_source == "Paste new transcript":
        transcript_text = st.text_area("Paste transcript:", height=250, key="t2_paste")
    else:
        transcript_text = SAMPLE_TRANSCRIPT
        st.info("Using sample meeting transcript")

    if transcript_text and st.button("Generate Summary", key="t2_btn"):
        with st.spinner("Analyzing meeting with GPT-4o..."):
            try:
                summary = summarize_meeting(transcript_text)
                st.session_state["summary"] = summary

                # Display summary
                col1, col2 = st.columns(2)
                with col1:
                    st.subheader(f"📋 {summary.title}")
                    st.markdown(f"**Date:** {summary.date}")
                    st.markdown(f"**Duration:** {summary.duration_minutes} min")
                    st.markdown(f"**Sentiment:** {summary.overall_sentiment}")
                    st.markdown(f"**Follow-up:** {summary.follow_up_date}")

                    st.markdown("**Attendees:**")
                    for a in summary.attendees:
                        st.markdown(f"- {a}")

                with col2:
                    st.markdown("**Key Decisions:**")
                    for i, d in enumerate(summary.key_decisions, 1):
                        st.markdown(f"{i}. {d}")

                    st.markdown("**Discussion Highlights:**")
                    for h in summary.discussion_highlights:
                        st.markdown(f"- {h}")

                # Action items table
                st.subheader("📌 Action Items")
                action_data = [
                    {
                        "Priority": item.priority.upper(),
                        "Owner": item.owner,
                        "Task": item.task,
                        "Due Date": item.due_date,
                    }
                    for item in summary.action_items
                ]
                st.table(action_data)

                # Follow-up email
                with st.expander("📧 Generate Follow-up Email"):
                    if st.button("Draft Email", key="t2_email_btn"):
                        with st.spinner("Drafting email..."):
                            email = generate_follow_up_email(summary)
                            st.session_state["email"] = email
                            st.markdown(email)

                if "email" in st.session_state:
                    st.markdown("---")
                    st.markdown(st.session_state["email"])

            except Exception as e:
                st.error(f"Summary generation failed: {e}")


# ===== TAB 3: Text-to-Speech =============================================
with tab3:
    st.header("Text-to-Speech (OpenAI TTS)")
    st.markdown("Convert any text to natural-sounding speech.")

    tts_text = st.text_area(
        "Enter text to convert:",
        value="Welcome to the Voice AI demo. This is a sample of OpenAI's text-to-speech capabilities.",
        height=150,
        key="t3_text",
    )

    col1, col2 = st.columns(2)
    with col1:
        voice = st.selectbox("Voice:", VOICES, index=VOICES.index("nova"), key="t3_voice")
    with col2:
        model = st.selectbox("Model:", TTS_MODELS, key="t3_model")

    st.caption(
        "**tts-1**: Fast, good quality  ·  **tts-1-hd**: Slower, higher quality"
    )

    if tts_text and st.button("Generate Speech", key="t3_btn"):
        with st.spinner(f"Generating speech with {voice} voice..."):
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                    tmp_path = tmp.name

                text_to_speech(tts_text, tmp_path, voice=voice, model=model)

                audio_bytes = Path(tmp_path).read_bytes()
                st.audio(audio_bytes, format="audio/mp3")
                st.success(f"Generated {len(audio_bytes) / 1024:.1f} KB of audio")

                st.download_button(
                    "Download MP3",
                    data=audio_bytes,
                    file_name=f"tts_{voice}.mp3",
                    mime="audio/mpeg",
                )
                Path(tmp_path).unlink(missing_ok=True)

            except Exception as e:
                st.error(f"TTS failed: {e}")

    # Voice preview section
    with st.expander("🎧 Voice Comparison"):
        st.markdown(
            "Each voice has a distinct character:\n"
            "- **alloy** — Neutral, balanced\n"
            "- **echo** — Warm, conversational\n"
            "- **fable** — Expressive, storytelling\n"
            "- **onyx** — Deep, authoritative\n"
            "- **nova** — Friendly, professional\n"
            "- **shimmer** — Clear, upbeat"
        )


# ===== TAB 4: Full Pipeline ==============================================
with tab4:
    st.header("Full Meeting Pipeline")
    st.markdown("**Transcript → Summary → Action Items → Email → Audio**")

    pipe_source = st.radio(
        "Transcript source:",
        ["Use sample transcript", "From Transcription tab", "Paste transcript"],
        horizontal=True, key="t4_source",
    )

    pipe_transcript = ""
    if pipe_source == "Use sample transcript":
        pipe_transcript = SAMPLE_TRANSCRIPT
        st.info("Using sample Q1 Product Planning meeting transcript")
    elif pipe_source == "From Transcription tab":
        pipe_transcript = st.session_state.get("transcript", "")
        if not pipe_transcript:
            st.warning("No transcript in session. Use Transcription tab first.")
    else:
        pipe_transcript = st.text_area("Paste transcript:", height=200, key="t4_paste")

    col1, col2 = st.columns(2)
    with col1:
        pipe_voice = st.selectbox("TTS Voice:", VOICES, index=VOICES.index("nova"), key="t4_voice")
    with col2:
        generate_tts = st.checkbox("Generate audio summary", value=True, key="t4_tts")

    if pipe_transcript and st.button("Run Full Pipeline", key="t4_btn", type="primary"):

        # Step 1: Summary
        status = st.status("Running Meeting Assistant Pipeline...", expanded=True)

        with status:
            st.write("**Step 1/4:** Analyzing transcript...")
            try:
                summary = summarize_meeting(pipe_transcript)
                st.write(f"✅ Summary: {summary.title} ({summary.duration_minutes} min)")
            except Exception as e:
                st.error(f"Summary failed: {e}")
                st.stop()

            # Step 2: Action items (already in summary)
            st.write(f"**Step 2/4:** Extracted {len(summary.action_items)} action items")

            # Step 3: Email
            st.write("**Step 3/4:** Drafting follow-up email...")
            try:
                email = generate_follow_up_email(summary)
                st.write("✅ Email drafted")
            except Exception as e:
                st.error(f"Email generation failed: {e}")
                email = None

            # Step 4: TTS
            audio_bytes = None
            if generate_tts:
                st.write("**Step 4/4:** Converting summary to speech...")
                try:
                    tts_text = f"Meeting summary: {summary.title}. "
                    tts_text += f"Attended by {', '.join(summary.attendees)}. "
                    tts_text += "Key decisions: " + ". ".join(summary.key_decisions) + ". "
                    tts_text += f"Next follow-up: {summary.follow_up_date}."

                    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                        tmp_path = tmp.name
                    text_to_speech(tts_text, tmp_path, voice=pipe_voice)
                    audio_bytes = Path(tmp_path).read_bytes()
                    Path(tmp_path).unlink(missing_ok=True)
                    st.write(f"✅ Audio generated ({len(audio_bytes) / 1024:.1f} KB)")
                except Exception as e:
                    st.warning(f"TTS failed (non-critical): {e}")
            else:
                st.write("**Step 4/4:** TTS skipped")

            status.update(label="Pipeline complete!", state="complete")

        # Display results
        st.divider()

        # Summary card
        st.subheader(f"📋 {summary.title}")
        rcol1, rcol2, rcol3, rcol4 = st.columns(4)
        rcol1.metric("Duration", f"{summary.duration_minutes} min")
        rcol2.metric("Attendees", len(summary.attendees))
        rcol3.metric("Decisions", len(summary.key_decisions))
        rcol4.metric("Action Items", len(summary.action_items))

        # Key decisions
        with st.expander("✅ Key Decisions", expanded=True):
            for i, d in enumerate(summary.key_decisions, 1):
                st.markdown(f"{i}. {d}")

        # Action items
        with st.expander("📌 Action Items", expanded=True):
            action_data = [
                {
                    "Priority": item.priority.upper(),
                    "Owner": item.owner,
                    "Task": item.task,
                    "Due Date": item.due_date,
                }
                for item in summary.action_items
            ]
            st.table(action_data)

        # Email
        if email:
            with st.expander("📧 Follow-up Email", expanded=False):
                st.markdown(email)

        # Audio
        if audio_bytes:
            with st.expander("🔊 Audio Summary", expanded=True):
                st.audio(audio_bytes, format="audio/mp3")
                st.download_button(
                    "Download Audio Summary",
                    data=audio_bytes,
                    file_name="meeting_summary.mp3",
                    mime="audio/mpeg",
                )


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("About")
    st.markdown(
        """
        **Meeting Assistant** combines three OpenAI capabilities:

        1. **Whisper** — Speech-to-text transcription
        2. **GPT-4o** — Structured meeting analysis
        3. **TTS** — Text-to-speech audio generation

        ---
        **Pipeline:**
        ```
        Audio → Transcript → Summary → Email
                                ↓
                          Audio Summary
        ```

        ---
        **Supported Audio Formats:**
        mp3, mp4, mpeg, mpga, m4a, wav, webm

        **TTS Voices:**
        alloy, echo, fable, onyx, nova, shimmer
        """
    )
    st.markdown("---")
    st.caption("Project 14 — GenAI Learning Series")
