# Project 14: Voice & Audio AI — Meeting Assistant

## Concept: Voice AI (Whisper + TTS)

### What is Voice AI?
Voice AI combines speech-to-text (STT) and text-to-speech (TTS) capabilities to enable
applications that understand and produce spoken language. The two key technologies:

1. **Whisper (Speech-to-Text)** — OpenAI's automatic speech recognition model
   - Supports 99+ languages
   - Handles accents, background noise, technical jargon
   - Can translate non-English audio to English
   - Input: audio file → Output: text transcript

2. **Text-to-Speech (TTS)** — Convert text back to natural-sounding audio
   - OpenAI offers multiple voices: alloy, echo, fable, onyx, nova, shimmer
   - Two models: `tts-1` (fast, lower quality) and `tts-1-hd` (slower, higher quality)
   - Output formats: mp3, opus, aac, flac, wav, pcm

### Audio Processing Pipeline
```
Audio File → Whisper API → Text Transcript
                              ↓
                         LLM Analysis (GPT-4o)
                              ↓
                    Structured Summary (Pydantic)
                              ↓
                         TTS API → Audio Summary
```

### Real-World Scenario: Meeting Assistant
Our demo builds a complete meeting assistant that:
1. **Transcribes** meeting audio (or accepts text transcript)
2. **Summarizes** the meeting with structured output (title, attendees, decisions, action items)
3. **Generates** a follow-up email from the summary
4. **Converts** the summary to audio for on-the-go listening

### Key Concepts

#### Whisper API Usage
```python
from openai import OpenAI
client = OpenAI()

# Transcribe audio file
with open("meeting.mp3", "rb") as f:
    transcript = client.audio.transcriptions.create(
        model="whisper-1",
        file=f,
        response_format="text"
    )
```

#### TTS API Usage
```python
response = client.audio.speech.create(
    model="tts-1",
    voice="nova",
    input="Meeting summary: We decided to launch in Q3..."
)
response.stream_to_file("summary.mp3")
```

#### Structured Meeting Output
```python
class MeetingSummary(BaseModel):
    title: str
    attendees: list[str]
    key_decisions: list[str]
    action_items: list[ActionItem]
    follow_up_date: str
```

### Supported Audio Formats
- **Input (Whisper)**: mp3, mp4, mpeg, mpga, m4a, wav, webm (max 25MB)
- **Output (TTS)**: mp3, opus, aac, flac, wav, pcm

### Voice Options
| Voice | Description |
|-------|-------------|
| alloy | Neutral, balanced |
| echo | Warm, conversational |
| fable | Expressive, storytelling |
| onyx | Deep, authoritative |
| nova | Friendly, professional |
| shimmer | Clear, upbeat |

## Project Structure
```
14-voice-ai/
├── .env              # OpenAI API key
├── requirements.txt  # Dependencies
├── voice_ai.py       # Core: transcription, summarization, TTS
├── app.py            # Streamlit UI (port 8514)
└── STEPS.md          # This file
```

## Setup & Run

### 1. Install Dependencies
```bash
cd 14-voice-ai
pip install -r requirements.txt
```

### 2. Set Environment Variable
```bash
cp .env.example .env
# Edit .env with your OpenAI API key
```

### 3. CLI Demo (no audio needed)
```bash
python voice_ai.py demo
```
This runs the full pipeline using a simulated meeting transcript:
- Generates structured summary
- Extracts action items
- Drafts follow-up email
- (Optionally) converts summary to speech

### 4. Run Streamlit App
```bash
streamlit run app.py --server.address 0.0.0.0 --server.port 8514 --server.headless true
```

### 5. Deploy to VM
```bash
# From local machine
scp -r 14-voice-ai/ azureuser@<VM_IP>:~/genai-projects/
ssh azureuser@<VM_IP>
cd ~/genai-projects/14-voice-ai
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8514 --server.headless true
```

## Demo Modes

### Text-Only Mode (Default)
Works without any audio files — uses a built-in sample meeting transcript.
Perfect for environments without microphone/speaker access.

### Full Audio Mode
When audio files are available:
1. Upload MP3/WAV to transcribe via Whisper
2. Generate TTS audio output
3. Play audio directly in the Streamlit UI

## Port: 8514
