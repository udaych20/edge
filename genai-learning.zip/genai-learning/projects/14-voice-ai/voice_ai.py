"""
Voice & Audio AI — Meeting Assistant
Core implementation: Whisper transcription, meeting summarization, and TTS.
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel, Field

load_dotenv()

client = OpenAI()

# ---------------------------------------------------------------------------
# Pydantic models for structured meeting output
# ---------------------------------------------------------------------------

class ActionItem(BaseModel):
    owner: str = Field(description="Person responsible")
    task: str = Field(description="What needs to be done")
    due_date: str = Field(description="Target completion date")
    priority: str = Field(description="high / medium / low")


class MeetingSummary(BaseModel):
    title: str = Field(description="Short meeting title")
    date: str = Field(description="Meeting date")
    attendees: list[str] = Field(description="List of attendees")
    duration_minutes: int = Field(description="Approx meeting length in minutes")
    key_decisions: list[str] = Field(description="Important decisions made")
    action_items: list[ActionItem] = Field(description="Tasks assigned during the meeting")
    discussion_highlights: list[str] = Field(description="Key discussion points")
    follow_up_date: str = Field(description="Next meeting or follow-up date")
    overall_sentiment: str = Field(description="positive / neutral / mixed / negative")


# ---------------------------------------------------------------------------
# Sample meeting transcript (simulated)
# ---------------------------------------------------------------------------

SAMPLE_TRANSCRIPT = """
[Meeting Start — 10:00 AM, January 15, 2026]

Sarah Chen (Product Manager): Good morning everyone. Thanks for joining the Q1 product planning meeting. Let me do a quick roll call — I see David, Priya, and Marcus. Perfect, let's get started.

David Park (Engineering Lead): Morning, Sarah. I've got the technical feasibility notes ready for the features we discussed last week.

Priya Sharma (Design Lead): Hi all. I've also prepared the updated wireframes for the dashboard redesign.

Sarah Chen: Great. Let's start with the dashboard redesign since that's our top priority. Priya, can you walk us through the latest designs?

Priya Sharma: Sure. Based on user research, we're proposing three major changes. First, a consolidated metrics view that combines the five separate charts into one interactive dashboard. Second, a customizable widget system so users can arrange their own layout. Third, an AI-powered insights panel that highlights anomalies automatically.

Marcus Johnson (Data Science Lead): I love the AI insights panel idea. We've actually been prototyping something similar. We can surface trend anomalies and provide natural language explanations. My team estimates about three weeks for a working prototype.

David Park: The widget system is technically complex. We'd need to build a drag-and-drop framework and a persistence layer for user configurations. I'd estimate six to eight weeks for the full implementation, but we could do a simplified version in four weeks.

Sarah Chen: Let's go with the simplified widget system for the initial release. We can iterate in Q2. David, can your team start on that next sprint?

David Park: Yes, we can start next Monday. I'll assign two senior engineers to it.

Sarah Chen: Perfect. Now, about the AI insights panel — Marcus, what data pipeline changes would we need?

Marcus Johnson: We'll need to set up a real-time anomaly detection service. I recommend using our existing data warehouse but adding a streaming layer. Priya, for the UI, I'd suggest we keep it simple — a card-based layout showing the top three insights with expandable details.

Priya Sharma: That works. I'll have mockups for the insights panel by end of this week. One thing to flag — we should also add a feedback mechanism so users can rate whether insights are helpful. That data will improve the model over time.

Sarah Chen: Excellent point. Let's make sure that's included. David, any concerns about integrating the anomaly detection service?

David Park: We'll need to set up a new microservice and API endpoint. My concern is latency — we need the insights to load within two seconds. Marcus, can we cache the results?

Marcus Johnson: Absolutely. We can pre-compute insights every fifteen minutes and cache them. Real-time will only be needed for critical alerts. That should easily meet the two-second requirement.

Sarah Chen: Good solution. Let's also discuss the mobile experience. Our mobile users are up forty percent quarter over quarter. Priya, are the designs responsive?

Priya Sharma: Yes, we've designed mobile-first this time. The widget system will stack vertically on mobile, and the insights panel will show as a swipeable card deck. I'll share the mobile prototypes by Thursday.

Sarah Chen: Wonderful. Let me summarize what we've decided today. One — we're going with the simplified widget system for Q1, targeting four weeks. Two — the AI insights panel will be built in parallel with a three-week prototype timeline. Three — we'll include a feedback mechanism for insights. Four — mobile-first responsive design for all new components.

Sarah Chen: For action items — David, start the widget system next Monday with two senior engineers. Marcus, begin the anomaly detection prototype this week. Priya, deliver the insights panel mockups and mobile prototypes by Thursday. I'll update the product roadmap and send a revised timeline to stakeholders by Friday.

Sarah Chen: Our next sync will be January 29th, same time. Any questions? ... Great. Thanks everyone, productive meeting!

[Meeting End — 10:47 AM]
"""


# ---------------------------------------------------------------------------
# 1. Transcription (Whisper API)
# ---------------------------------------------------------------------------

def transcribe_audio(audio_path: str, language: Optional[str] = None) -> str:
    """Transcribe an audio file using OpenAI Whisper API."""
    path = Path(audio_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    supported = {".mp3", ".mp4", ".mpeg", ".mpga", ".m4a", ".wav", ".webm"}
    if path.suffix.lower() not in supported:
        raise ValueError(f"Unsupported format '{path.suffix}'. Supported: {supported}")

    file_size = path.stat().st_size
    if file_size > 25 * 1024 * 1024:
        raise ValueError(f"File too large ({file_size / 1024 / 1024:.1f}MB). Max 25MB.")

    with open(path, "rb") as f:
        kwargs = {"model": "whisper-1", "file": f, "response_format": "text"}
        if language:
            kwargs["language"] = language
        transcript = client.audio.transcriptions.create(**kwargs)

    return transcript if isinstance(transcript, str) else transcript.text


def translate_audio(audio_path: str) -> str:
    """Translate non-English audio to English using Whisper."""
    path = Path(audio_path)
    if not path.exists():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")

    with open(path, "rb") as f:
        translation = client.audio.translations.create(
            model="whisper-1", file=f, response_format="text"
        )

    return translation if isinstance(translation, str) else translation.text


# ---------------------------------------------------------------------------
# 2. Meeting Summarizer (Structured Output)
# ---------------------------------------------------------------------------

def summarize_meeting(transcript: str) -> MeetingSummary:
    """Analyze a meeting transcript and produce a structured summary."""
    system_prompt = """You are an expert meeting analyst. Given a meeting transcript,
produce a detailed structured summary. Be precise with names, dates, and action items.
For due dates, infer reasonable dates based on context (e.g., "by Thursday" relative to the
meeting date). Return valid JSON matching the requested schema."""

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Summarize this meeting transcript:\n\n{transcript}"},
        ],
        response_format={"type": "json_schema", "json_schema": {
            "name": "MeetingSummary",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "date": {"type": "string"},
                    "attendees": {"type": "array", "items": {"type": "string"}},
                    "duration_minutes": {"type": "integer"},
                    "key_decisions": {"type": "array", "items": {"type": "string"}},
                    "action_items": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "owner": {"type": "string"},
                                "task": {"type": "string"},
                                "due_date": {"type": "string"},
                                "priority": {"type": "string"},
                            },
                            "required": ["owner", "task", "due_date", "priority"],
                            "additionalProperties": False,
                        },
                    },
                    "discussion_highlights": {"type": "array", "items": {"type": "string"}},
                    "follow_up_date": {"type": "string"},
                    "overall_sentiment": {"type": "string"},
                },
                "required": [
                    "title", "date", "attendees", "duration_minutes",
                    "key_decisions", "action_items", "discussion_highlights",
                    "follow_up_date", "overall_sentiment",
                ],
                "additionalProperties": False,
            },
        }},
        temperature=0.3,
    )

    data = json.loads(response.choices[0].message.content)
    return MeetingSummary(**data)


# ---------------------------------------------------------------------------
# 3. Follow-up Email Generator
# ---------------------------------------------------------------------------

def generate_follow_up_email(summary: MeetingSummary) -> str:
    """Generate a professional follow-up email from a meeting summary."""
    summary_text = summary.model_dump_json(indent=2)

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a professional executive assistant. Write a clear, concise "
                    "follow-up email based on the meeting summary. Include: greeting, "
                    "meeting recap, key decisions, action items table (owner | task | due date), "
                    "and next meeting date. Keep it professional but friendly."
                ),
            },
            {"role": "user", "content": f"Write a follow-up email for this meeting:\n\n{summary_text}"},
        ],
        temperature=0.4,
    )

    return response.choices[0].message.content


# ---------------------------------------------------------------------------
# 4. Text-to-Speech (TTS)
# ---------------------------------------------------------------------------

VOICES = ["alloy", "echo", "fable", "onyx", "nova", "shimmer"]
TTS_MODELS = ["tts-1", "tts-1-hd"]


def text_to_speech(
    text: str,
    output_path: str = "output.mp3",
    voice: str = "nova",
    model: str = "tts-1",
    response_format: str = "mp3",
) -> str:
    """Convert text to speech using OpenAI TTS API."""
    if voice not in VOICES:
        raise ValueError(f"Invalid voice '{voice}'. Choose from: {VOICES}")
    if model not in TTS_MODELS:
        raise ValueError(f"Invalid model '{model}'. Choose from: {TTS_MODELS}")

    # TTS has a 4096-char limit per request
    if len(text) > 4096:
        text = text[:4093] + "..."

    response = client.audio.speech.create(
        model=model,
        voice=voice,
        input=text,
        response_format=response_format,
    )

    response.stream_to_file(output_path)
    return output_path


# ---------------------------------------------------------------------------
# 5. Full Pipeline
# ---------------------------------------------------------------------------

def run_full_pipeline(
    transcript: str,
    generate_audio: bool = False,
    voice: str = "nova",
) -> dict:
    """Run the complete meeting assistant pipeline."""
    print("=" * 60)
    print("  Meeting Assistant — Full Pipeline")
    print("=" * 60)

    # Step 1: Summarize
    print("\n[1/3] Generating meeting summary...")
    summary = summarize_meeting(transcript)
    print(f"  ✓ Title: {summary.title}")
    print(f"  ✓ Attendees: {', '.join(summary.attendees)}")
    print(f"  ✓ Decisions: {len(summary.key_decisions)}")
    print(f"  ✓ Action Items: {len(summary.action_items)}")

    # Step 2: Follow-up email
    print("\n[2/3] Drafting follow-up email...")
    email = generate_follow_up_email(summary)
    print("  ✓ Email generated")

    # Step 3: TTS (optional)
    audio_path = None
    if generate_audio:
        print("\n[3/3] Converting summary to speech...")
        tts_text = f"Meeting summary: {summary.title}. "
        tts_text += f"Attended by {', '.join(summary.attendees)}. "
        tts_text += "Key decisions: " + ". ".join(summary.key_decisions) + ". "
        tts_text += f"Next follow-up: {summary.follow_up_date}."
        audio_path = text_to_speech(tts_text, "meeting_summary.mp3", voice=voice)
        print(f"  ✓ Audio saved to {audio_path}")
    else:
        print("\n[3/3] Skipping TTS (use --audio flag to enable)")

    return {
        "summary": summary,
        "email": email,
        "audio_path": audio_path,
    }


# ---------------------------------------------------------------------------
# CLI interface
# ---------------------------------------------------------------------------

def print_summary(summary: MeetingSummary) -> None:
    """Pretty-print a meeting summary."""
    print(f"\n{'─' * 60}")
    print(f"  📋 {summary.title}")
    print(f"{'─' * 60}")
    print(f"  Date: {summary.date}")
    print(f"  Duration: {summary.duration_minutes} minutes")
    print(f"  Sentiment: {summary.overall_sentiment}")
    print(f"  Follow-up: {summary.follow_up_date}")

    print(f"\n  👥 Attendees:")
    for a in summary.attendees:
        print(f"     • {a}")

    print(f"\n  ✅ Key Decisions:")
    for i, d in enumerate(summary.key_decisions, 1):
        print(f"     {i}. {d}")

    print(f"\n  📌 Action Items:")
    for item in summary.action_items:
        print(f"     [{item.priority.upper()}] {item.owner}: {item.task} (due: {item.due_date})")

    print(f"\n  💬 Discussion Highlights:")
    for h in summary.discussion_highlights:
        print(f"     • {h}")


def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python voice_ai.py demo              — Run full pipeline with sample transcript")
        print("  python voice_ai.py demo --audio       — Same + generate TTS audio")
        print("  python voice_ai.py transcribe <file>  — Transcribe an audio file")
        print("  python voice_ai.py tts <text> [voice] — Convert text to speech")
        return

    command = sys.argv[1].lower()

    if command == "demo":
        generate_audio = "--audio" in sys.argv
        result = run_full_pipeline(SAMPLE_TRANSCRIPT, generate_audio=generate_audio)

        print_summary(result["summary"])

        print(f"\n{'─' * 60}")
        print("  📧 Follow-up Email")
        print(f"{'─' * 60}")
        print(result["email"])

    elif command == "transcribe":
        if len(sys.argv) < 3:
            print("Error: provide audio file path")
            return
        transcript = transcribe_audio(sys.argv[2])
        print("Transcript:")
        print(transcript)

    elif command == "tts":
        if len(sys.argv) < 3:
            print("Error: provide text to convert")
            return
        text = sys.argv[2]
        voice = sys.argv[3] if len(sys.argv) > 3 else "nova"
        path = text_to_speech(text, voice=voice)
        print(f"Audio saved to: {path}")

    else:
        print(f"Unknown command: {command}")


if __name__ == "__main__":
    main()
