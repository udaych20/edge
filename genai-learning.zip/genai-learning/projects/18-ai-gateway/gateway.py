"""
AI Gateway — Unified Multi-Provider LLM Gateway
Core implementation: routing, caching, fallback, rate limiting, cost tracking.
"""

import os
import sys
import json
import time
import hashlib
import random
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime

import numpy as np
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class ProviderConfig:
    """Configuration for a single LLM provider/model."""
    name: str
    model: str
    tier: str  # "economy", "balanced", "premium"
    priority: int  # lower = higher priority in fallback
    input_cost_per_1k: float  # $ per 1K input tokens
    output_cost_per_1k: float  # $ per 1K output tokens
    max_rpm: int = 60  # requests per minute
    timeout: float = 30.0
    system_prompt_prefix: str = ""  # simulate different providers
    simulated_failure_rate: float = 0.0  # for demo: probability of simulated failure


@dataclass
class GatewayConfig:
    """Top-level gateway configuration."""
    enable_smart_routing: bool = True
    enable_semantic_cache: bool = True
    enable_rate_limiting: bool = True
    enable_fallback: bool = True
    enable_cost_tracking: bool = True
    cache_similarity_threshold: float = 0.88
    cache_max_entries: int = 200
    default_fallback_chain: list[str] = field(default_factory=lambda: [
        "openai-gpt4o", "openai-gpt4o-mini", "openai-gpt35"
    ])
    complexity_thresholds: dict = field(default_factory=lambda: {
        "simple_max": 0.3,
        "balanced_max": 0.65,
    })


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------

@dataclass
class GatewayRequest:
    query: str
    preferred_provider: Optional[str] = None
    max_tokens: int = 1024
    temperature: float = 0.7
    metadata: dict = field(default_factory=dict)


@dataclass
class GatewayResponse:
    content: str
    provider_used: str
    model_used: str
    cached: bool = False
    cache_similarity: float = 0.0
    latency_ms: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0
    complexity_score: float = 0.0
    routing_tier: str = ""
    fallback_attempts: int = 0
    rate_limited: bool = False
    timestamp: str = ""


@dataclass
class RequestLog:
    timestamp: str
    query_preview: str
    provider: str
    model: str
    cached: bool
    latency_ms: float
    input_tokens: int
    output_tokens: int
    cost_usd: float
    complexity: float
    tier: str
    fallback_attempts: int


# ---------------------------------------------------------------------------
# Complexity Analyser
# ---------------------------------------------------------------------------

class ComplexityAnalyser:
    """Analyse query complexity to inform routing decisions."""

    CODE_KEYWORDS = {
        "function", "class", "def ", "import", "variable", "algorithm",
        "code", "program", "debug", "compile", "syntax", "refactor",
        "implement", "api", "database", "sql", "regex", "loop",
        "recursion", "async", "await", "deploy", "docker", "kubernetes",
    }
    MATH_KEYWORDS = {
        "calculate", "equation", "integral", "derivative", "matrix",
        "probability", "statistics", "proof", "theorem", "formula",
        "algebra", "calculus", "geometry", "optimization", "gradient",
    }
    COMPLEX_INDICATORS = {
        "explain in detail", "step by step", "compare and contrast",
        "analyse", "analyze", "evaluate", "design", "architect",
        "trade-offs", "tradeoffs", "best practices", "comprehensive",
        "multi-step", "complex", "advanced", "in-depth",
    }

    @staticmethod
    def analyse(query: str) -> tuple[float, dict]:
        """Return (score 0-1, breakdown dict)."""
        q = query.lower()
        words = q.split()
        word_count = len(words)
        sentence_count = max(1, q.count(".") + q.count("?") + q.count("!"))

        # Factors
        length_score = min(1.0, word_count / 100)
        code_hits = sum(1 for kw in ComplexityAnalyser.CODE_KEYWORDS if kw in q)
        code_score = min(1.0, code_hits / 3)
        math_hits = sum(1 for kw in ComplexityAnalyser.MATH_KEYWORDS if kw in q)
        math_score = min(1.0, math_hits / 2)
        complex_hits = sum(1 for kw in ComplexityAnalyser.COMPLEX_INDICATORS if kw in q)
        complex_score = min(1.0, complex_hits / 2)
        question_marks = q.count("?")
        multi_part = min(1.0, question_marks / 3) if question_marks > 1 else 0.0

        composite = (
            length_score * 0.15 +
            code_score * 0.30 +
            math_score * 0.25 +
            complex_score * 0.20 +
            multi_part * 0.10
        )
        composite = round(min(1.0, composite), 3)

        breakdown = {
            "word_count": word_count,
            "sentence_count": sentence_count,
            "length_score": round(length_score, 3),
            "code_score": round(code_score, 3),
            "math_score": round(math_score, 3),
            "complexity_score": round(complex_score, 3),
            "multi_part_score": round(multi_part, 3),
            "composite": composite,
        }
        return composite, breakdown


# ---------------------------------------------------------------------------
# Semantic Cache
# ---------------------------------------------------------------------------

class SemanticCache:
    """Embedding-based semantic cache for LLM responses."""

    def __init__(self, client: OpenAI, threshold: float = 0.88, max_entries: int = 200):
        self.client = client
        self.threshold = threshold
        self.max_entries = max_entries
        self.entries: list[dict] = []  # {query, embedding, response, provider, timestamp, hits}
        self.stats = {"hits": 0, "misses": 0, "total_saved_usd": 0.0}

    # ---- helpers ----
    def _embed(self, text: str) -> list[float]:
        resp = self.client.embeddings.create(input=text, model="text-embedding-3-small")
        return resp.data[0].embedding

    @staticmethod
    def _cosine(a: list[float], b: list[float]) -> float:
        va, vb = np.array(a), np.array(b)
        denom = np.linalg.norm(va) * np.linalg.norm(vb)
        if denom == 0:
            return 0.0
        return float(np.dot(va, vb) / denom)

    # ---- public API ----
    def lookup(self, query: str) -> tuple[Optional[dict], float]:
        """Return (cached_entry | None, best_similarity)."""
        emb = self._embed(query)
        best_sim = 0.0
        best_entry = None
        for entry in self.entries:
            sim = self._cosine(emb, entry["embedding"])
            if sim > best_sim:
                best_sim = sim
                best_entry = entry
        if best_entry and best_sim >= self.threshold:
            best_entry["hits"] += 1
            self.stats["hits"] += 1
            return best_entry, best_sim
        self.stats["misses"] += 1
        return None, best_sim

    def store(self, query: str, response: str, provider: str, cost: float):
        emb = self._embed(query)
        if len(self.entries) >= self.max_entries:
            # evict least-hit entry
            self.entries.sort(key=lambda e: e["hits"])
            self.entries.pop(0)
        self.entries.append({
            "query": query,
            "embedding": emb,
            "response": response,
            "provider": provider,
            "timestamp": datetime.now().isoformat(),
            "hits": 0,
            "cost_saved_per_hit": cost,
        })

    def get_entries_display(self) -> list[dict]:
        """Entries without embedding vectors (for display)."""
        return [
            {k: v for k, v in e.items() if k != "embedding"}
            for e in self.entries
        ]

    @property
    def hit_rate(self) -> float:
        total = self.stats["hits"] + self.stats["misses"]
        return self.stats["hits"] / total if total else 0.0


# ---------------------------------------------------------------------------
# Rate Limiter (token-bucket)
# ---------------------------------------------------------------------------

class TokenBucketRateLimiter:
    """Per-provider token-bucket rate limiter."""

    def __init__(self):
        self.buckets: dict[str, dict] = {}

    def register(self, provider_name: str, max_rpm: int):
        self.buckets[provider_name] = {
            "tokens": float(max_rpm),
            "max": float(max_rpm),
            "refill_rate": max_rpm / 60.0,  # tokens per second
            "last_refill": time.time(),
            "total_requests": 0,
            "rejected": 0,
        }

    def _refill(self, bucket: dict):
        now = time.time()
        elapsed = now - bucket["last_refill"]
        bucket["tokens"] = min(bucket["max"], bucket["tokens"] + elapsed * bucket["refill_rate"])
        bucket["last_refill"] = now

    def allow(self, provider_name: str) -> bool:
        bucket = self.buckets.get(provider_name)
        if not bucket:
            return True
        self._refill(bucket)
        if bucket["tokens"] >= 1.0:
            bucket["tokens"] -= 1.0
            bucket["total_requests"] += 1
            return True
        bucket["rejected"] += 1
        return False

    def get_stats(self) -> dict[str, dict]:
        return {
            name: {
                "tokens_available": round(b["tokens"], 1),
                "max_tokens": b["max"],
                "total_requests": b["total_requests"],
                "rejected": b["rejected"],
            }
            for name, b in self.buckets.items()
        }


# ---------------------------------------------------------------------------
# Cost Tracker
# ---------------------------------------------------------------------------

class CostTracker:
    """Track costs per request, aggregate by provider/model/time."""

    def __init__(self):
        self.records: list[dict] = []

    def record(self, provider: str, model: str, input_tokens: int, output_tokens: int,
               input_cost_per_1k: float, output_cost_per_1k: float) -> float:
        cost = (input_tokens / 1000) * input_cost_per_1k + (output_tokens / 1000) * output_cost_per_1k
        cost = round(cost, 6)
        self.records.append({
            "timestamp": datetime.now().isoformat(),
            "provider": provider,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cost_usd": cost,
        })
        return cost

    @property
    def total_cost(self) -> float:
        return round(sum(r["cost_usd"] for r in self.records), 6)

    @property
    def total_tokens(self) -> int:
        return sum(r["input_tokens"] + r["output_tokens"] for r in self.records)

    def by_provider(self) -> dict[str, float]:
        agg: dict[str, float] = {}
        for r in self.records:
            agg[r["provider"]] = agg.get(r["provider"], 0.0) + r["cost_usd"]
        return {k: round(v, 6) for k, v in agg.items()}

    def by_model(self) -> dict[str, float]:
        agg: dict[str, float] = {}
        for r in self.records:
            agg[r["model"]] = agg.get(r["model"], 0.0) + r["cost_usd"]
        return {k: round(v, 6) for k, v in agg.items()}

    def recent(self, n: int = 20) -> list[dict]:
        return self.records[-n:]


# ---------------------------------------------------------------------------
# AI Gateway
# ---------------------------------------------------------------------------

class AIGateway:
    """Unified AI Gateway with routing, caching, fallback, rate-limiting, cost tracking."""

    DEFAULT_PROVIDERS: list[ProviderConfig] = [
        ProviderConfig(
            name="openai-gpt4o",
            model="gpt-4o",
            tier="premium",
            priority=1,
            input_cost_per_1k=0.0025,
            output_cost_per_1k=0.01,
            max_rpm=30,
            system_prompt_prefix="You are a premium-tier AI assistant (GPT-4o). Provide thorough, high-quality answers.",
        ),
        ProviderConfig(
            name="openai-gpt4o-mini",
            model="gpt-4o-mini",
            tier="balanced",
            priority=2,
            input_cost_per_1k=0.00015,
            output_cost_per_1k=0.0006,
            max_rpm=60,
            system_prompt_prefix="You are a balanced-tier AI assistant (GPT-4o-mini). Provide clear, concise answers.",
        ),
        ProviderConfig(
            name="openai-gpt35",
            model="gpt-3.5-turbo",
            tier="economy",
            priority=3,
            input_cost_per_1k=0.0005,
            output_cost_per_1k=0.0015,
            max_rpm=90,
            system_prompt_prefix="You are an economy-tier AI assistant (GPT-3.5-turbo). Provide quick, helpful answers.",
        ),
        ProviderConfig(
            name="simulated-anthropic",
            model="gpt-4o-mini",
            tier="balanced",
            priority=4,
            input_cost_per_1k=0.00025,
            output_cost_per_1k=0.00125,
            max_rpm=40,
            system_prompt_prefix=(
                "You are Claude by Anthropic (simulated). "
                "Respond helpfully and mention you are Claude when appropriate."
            ),
            simulated_failure_rate=0.15,
        ),
        ProviderConfig(
            name="simulated-google",
            model="gpt-4o-mini",
            tier="economy",
            priority=5,
            input_cost_per_1k=0.000125,
            output_cost_per_1k=0.000375,
            max_rpm=50,
            system_prompt_prefix=(
                "You are Gemini by Google (simulated). "
                "Respond helpfully and mention you are Gemini when appropriate."
            ),
            simulated_failure_rate=0.15,
        ),
    ]

    def __init__(self, config: Optional[GatewayConfig] = None, providers: Optional[list[ProviderConfig]] = None):
        self.config = config or GatewayConfig()
        self.client = OpenAI()
        self.providers: dict[str, ProviderConfig] = {}
        self.analyser = ComplexityAnalyser()
        self.cache = SemanticCache(
            self.client,
            threshold=self.config.cache_similarity_threshold,
            max_entries=self.config.cache_max_entries,
        )
        self.rate_limiter = TokenBucketRateLimiter()
        self.cost_tracker = CostTracker()
        self.request_logs: list[RequestLog] = []

        for p in (providers or self.DEFAULT_PROVIDERS):
            self.register_provider(p)

    # ---- Provider management ----
    def register_provider(self, provider: ProviderConfig):
        self.providers[provider.name] = provider
        self.rate_limiter.register(provider.name, provider.max_rpm)

    def get_provider(self, name: str) -> Optional[ProviderConfig]:
        return self.providers.get(name)

    # ---- Smart routing ----
    def _select_tier(self, complexity: float) -> str:
        thresholds = self.config.complexity_thresholds
        if complexity <= thresholds["simple_max"]:
            return "economy"
        elif complexity <= thresholds["balanced_max"]:
            return "balanced"
        return "premium"

    def _pick_provider_for_tier(self, tier: str) -> Optional[ProviderConfig]:
        candidates = [p for p in self.providers.values() if p.tier == tier]
        candidates.sort(key=lambda p: p.priority)
        return candidates[0] if candidates else None

    # ---- Fallback chain ----
    def _build_chain(self, preferred: Optional[str] = None) -> list[str]:
        if preferred and preferred in self.providers:
            chain = [preferred] + [n for n in self.config.default_fallback_chain if n != preferred]
        else:
            chain = list(self.config.default_fallback_chain)
        # append any providers not yet in chain
        for name in self.providers:
            if name not in chain:
                chain.append(name)
        return chain

    # ---- LLM call ----
    def _call_provider(self, provider: ProviderConfig, query: str, max_tokens: int, temperature: float) -> dict:
        """Call the provider. Returns dict with content, usage. Raises on failure."""
        # simulate failure for demo
        if provider.simulated_failure_rate > 0 and random.random() < provider.simulated_failure_rate:
            raise RuntimeError(f"Simulated failure for {provider.name}")

        messages = []
        if provider.system_prompt_prefix:
            messages.append({"role": "system", "content": provider.system_prompt_prefix})
        messages.append({"role": "user", "content": query})

        resp = self.client.chat.completions.create(
            model=provider.model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        choice = resp.choices[0]
        usage = resp.usage
        return {
            "content": choice.message.content or "",
            "input_tokens": usage.prompt_tokens if usage else 0,
            "output_tokens": usage.completion_tokens if usage else 0,
            "total_tokens": usage.total_tokens if usage else 0,
        }

    # ---- Main entry point ----
    def route(self, request: GatewayRequest) -> GatewayResponse:
        """Route a request through the gateway pipeline."""
        start = time.time()
        timestamp = datetime.now().isoformat()

        # 1. Complexity analysis
        complexity, _ = self.analyser.analyse(request.query)
        tier = self._select_tier(complexity) if self.config.enable_smart_routing else "balanced"

        # 2. Semantic cache lookup
        if self.config.enable_semantic_cache:
            cached, similarity = self.cache.lookup(request.query)
            if cached:
                latency = round((time.time() - start) * 1000, 1)
                resp = GatewayResponse(
                    content=cached["response"],
                    provider_used=cached["provider"],
                    model_used="(cached)",
                    cached=True,
                    cache_similarity=round(similarity, 4),
                    latency_ms=latency,
                    complexity_score=complexity,
                    routing_tier=tier,
                    timestamp=timestamp,
                )
                self._log(request, resp)
                return resp

        # 3. Determine provider (smart route or preferred)
        if request.preferred_provider and request.preferred_provider in self.providers:
            selected = self.providers[request.preferred_provider]
        elif self.config.enable_smart_routing:
            selected = self._pick_provider_for_tier(tier)
            if not selected:
                selected = list(self.providers.values())[0]
        else:
            selected = list(self.providers.values())[0]

        # 4. Build fallback chain starting from selected
        chain = self._build_chain(selected.name) if self.config.enable_fallback else [selected.name]

        # 5. Try chain
        last_error = None
        attempts = 0
        for provider_name in chain:
            provider = self.providers.get(provider_name)
            if not provider:
                continue

            # Rate limiting
            if self.config.enable_rate_limiting and not self.rate_limiter.allow(provider_name):
                attempts += 1
                continue

            try:
                result = self._call_provider(provider, request.query, request.max_tokens, request.temperature)
                latency = round((time.time() - start) * 1000, 1)

                # Cost tracking
                cost = 0.0
                if self.config.enable_cost_tracking:
                    cost = self.cost_tracker.record(
                        provider.name, provider.model,
                        result["input_tokens"], result["output_tokens"],
                        provider.input_cost_per_1k, provider.output_cost_per_1k,
                    )

                # Cache the response
                if self.config.enable_semantic_cache:
                    self.cache.store(request.query, result["content"], provider.name, cost)

                resp = GatewayResponse(
                    content=result["content"],
                    provider_used=provider.name,
                    model_used=provider.model,
                    latency_ms=latency,
                    input_tokens=result["input_tokens"],
                    output_tokens=result["output_tokens"],
                    total_tokens=result["total_tokens"],
                    cost_usd=cost,
                    complexity_score=complexity,
                    routing_tier=tier,
                    fallback_attempts=attempts,
                    timestamp=timestamp,
                )
                self._log(request, resp)
                return resp

            except Exception as exc:
                last_error = exc
                attempts += 1
                continue

        # All providers failed
        latency = round((time.time() - start) * 1000, 1)
        resp = GatewayResponse(
            content=f"All providers failed. Last error: {last_error}",
            provider_used="none",
            model_used="none",
            latency_ms=latency,
            complexity_score=complexity,
            routing_tier=tier,
            fallback_attempts=attempts,
            timestamp=timestamp,
        )
        self._log(request, resp)
        return resp

    # ---- Logging ----
    def _log(self, request: GatewayRequest, response: GatewayResponse):
        preview = request.query[:80] + ("…" if len(request.query) > 80 else "")
        self.request_logs.append(RequestLog(
            timestamp=response.timestamp,
            query_preview=preview,
            provider=response.provider_used,
            model=response.model_used,
            cached=response.cached,
            latency_ms=response.latency_ms,
            input_tokens=response.input_tokens,
            output_tokens=response.output_tokens,
            cost_usd=response.cost_usd,
            complexity=response.complexity_score,
            tier=response.routing_tier,
            fallback_attempts=response.fallback_attempts,
        ))

    # ---- Dashboard helpers ----
    def get_dashboard_stats(self) -> dict:
        total_requests = len(self.request_logs)
        cached_requests = sum(1 for l in self.request_logs if l.cached)
        avg_latency = (
            round(sum(l.latency_ms for l in self.request_logs) / total_requests, 1)
            if total_requests else 0
        )
        return {
            "total_requests": total_requests,
            "cached_requests": cached_requests,
            "cache_hit_rate": round(cached_requests / total_requests, 3) if total_requests else 0,
            "avg_latency_ms": avg_latency,
            "total_cost_usd": self.cost_tracker.total_cost,
            "total_tokens": self.cost_tracker.total_tokens,
            "cost_by_provider": self.cost_tracker.by_provider(),
            "cost_by_model": self.cost_tracker.by_model(),
            "rate_limiter_stats": self.rate_limiter.get_stats(),
            "requests_by_tier": self._count_by_tier(),
        }

    def _count_by_tier(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for l in self.request_logs:
            counts[l.tier] = counts.get(l.tier, 0) + 1
        return counts


# ---------------------------------------------------------------------------
# CLI Demo
# ---------------------------------------------------------------------------

def run_demo():
    """Run an interactive demo showing all gateway features."""
    print("=" * 70)
    print("  AI Gateway — Enterprise Demo")
    print("=" * 70)

    gateway = AIGateway()

    demo_queries = [
        ("Hello!", "Simple greeting → economy tier"),
        ("What is Python?", "Basic factual → economy tier"),
        ("Explain the difference between TCP and UDP with examples", "Medium explanation → balanced tier"),
        ("What is Python?", "Repeat query → should hit cache"),
        ("Tell me about the Python programming language", "Similar to cached → semantic cache test"),
        (
            "Write a Python function that implements a binary search tree with "
            "insert, delete, and search operations. Include type hints and explain "
            "the time complexity of each operation step by step.",
            "Complex code request → premium tier"
        ),
        ("Hi there!", "Similar to 'Hello!' → cache test"),
    ]

    for query, description in demo_queries:
        print(f"\n{'─' * 60}")
        print(f"📝 {description}")
        print(f"   Query: {query[:70]}{'…' if len(query) > 70 else ''}")
        print(f"{'─' * 60}")

        req = GatewayRequest(query=query)
        resp = gateway.route(req)

        print(f"   Provider : {resp.provider_used} ({resp.model_used})")
        print(f"   Tier     : {resp.routing_tier}")
        print(f"   Cached   : {'✅ HIT' if resp.cached else '❌ MISS'}"
              + (f" (similarity: {resp.cache_similarity:.3f})" if resp.cached else ""))
        print(f"   Latency  : {resp.latency_ms:.0f} ms")
        print(f"   Tokens   : {resp.total_tokens}")
        print(f"   Cost     : ${resp.cost_usd:.6f}")
        print(f"   Fallbacks: {resp.fallback_attempts}")
        print(f"   Complexity: {resp.complexity_score:.3f}")
        print(f"   Response : {resp.content[:120]}…" if len(resp.content) > 120 else f"   Response : {resp.content}")

    # Summary
    stats = gateway.get_dashboard_stats()
    print(f"\n{'=' * 70}")
    print("  GATEWAY SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Total requests  : {stats['total_requests']}")
    print(f"  Cache hit rate  : {stats['cache_hit_rate']:.1%}")
    print(f"  Avg latency     : {stats['avg_latency_ms']:.0f} ms")
    print(f"  Total cost      : ${stats['total_cost_usd']:.6f}")
    print(f"  Total tokens    : {stats['total_tokens']}")
    print(f"  Cost by provider: {json.dumps(stats['cost_by_provider'], indent=4)}")
    print(f"  Requests by tier: {json.dumps(stats['requests_by_tier'], indent=4)}")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python gateway.py demo")
