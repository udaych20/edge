# Project 18: AI Gateway — Unified Multi-Provider LLM Gateway

## What You'll Build
An enterprise AI Gateway that provides a unified API layer for routing requests across multiple LLM providers. The gateway handles smart complexity-based routing, fallback chains, semantic caching, rate limiting, and cost tracking — all the infrastructure an enterprise needs to manage LLM usage at scale.

## Real-World Scenario
**Enterprise AI Platform**: Your organization uses multiple LLM providers (OpenAI, Anthropic, Google). Different teams need different models for different tasks. Without a gateway, each team manages their own API keys, has no cost visibility, no caching, no fallback handling, and no unified logging. The AI Gateway solves all of this with a single entry point.

## Why Enterprises Need an AI Gateway

### The Problem
- **Cost explosion**: Teams use GPT-4o for simple FAQ lookups that GPT-3.5 could handle
- **No resilience**: When OpenAI has an outage, everything breaks
- **Duplicate requests**: The same question gets sent to the API 100 times/day
- **No visibility**: Finance has no idea what AI costs per team/project
- **Rate limit chaos**: One team's burst usage rate-limits everyone else

### The Gateway Solution
```
┌─────────────────────────────────────────────┐
│                 AI Gateway                   │
│                                              │
│  ┌──────────┐  ┌──────────┐  ┌───────────┐ │
│  │  Smart    │  │ Semantic │  │  Rate     │ │
│  │  Router   │  │  Cache   │  │  Limiter  │ │
│  └────┬─────┘  └────┬─────┘  └─────┬─────┘ │
│       │              │              │        │
│  ┌────┴──────────────┴──────────────┴─────┐ │
│  │          Fallback Chain Manager         │ │
│  └────┬──────────┬──────────┬─────────────┘ │
│       │          │          │                │
│  ┌────▼───┐ ┌───▼────┐ ┌──▼──────┐         │
│  │ OpenAI │ │Anthropic│ │ Google  │         │
│  │ GPT-4o │ │ Claude  │ │ Gemini  │         │
│  └────────┘ └────────┘ └─────────┘         │
│                                              │
│  ┌──────────┐  ┌──────────┐                 │
│  │  Cost    │  │ Request  │                 │
│  │ Tracker  │  │  Logger  │                 │
│  └──────────┘  └──────────┘                 │
└─────────────────────────────────────────────┘
```

## Key Concepts

### 1. Smart Routing
Route queries to the optimal model based on complexity:
- **Simple queries** (greetings, yes/no, lookups) → cheap model (GPT-4o-mini)
- **Medium queries** (summaries, explanations) → balanced model
- **Complex queries** (code generation, math proofs, multi-step reasoning) → premium model (GPT-4o)

Complexity is analyzed by examining token count, presence of code/math, question depth, and domain specificity.

### 2. Fallback Chains
Define ordered lists of providers to try:
```
Primary: GPT-4o → Fallback 1: Claude → Fallback 2: GPT-4o-mini
```
If the primary fails (timeout, rate limit, error), automatically try the next provider. The user gets a response regardless of individual provider issues.

### 3. Semantic Caching
Instead of exact-match caching, use embedding similarity:
- "What is Python?" and "Tell me about the Python language" are semantically similar
- Cache the first response, serve it for the second query
- Saves cost and reduces latency dramatically for repeated/similar questions

### 4. Rate Limiting
Token-bucket algorithm per provider:
- Each provider gets a bucket of N tokens (requests)
- Tokens refill at a fixed rate
- When bucket is empty, requests are queued or routed elsewhere

### 5. Cost Tracking
Track every request's cost based on model pricing:
- Input tokens × input price per token
- Output tokens × output price per token
- Aggregate by provider, model, time period, and feature

## How to Run

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Run the CLI Demo
```bash
python gateway.py demo
```

### Run the Streamlit UI
```bash
streamlit run app.py --server.port 8518
```

## Architecture Details

### Provider Registry
Each provider is registered with:
- **Name & model**: Identifier and which model to call
- **Priority**: Order in fallback chain
- **Cost profile**: Price per input/output token
- **Quality tier**: simple / balanced / premium
- **Rate limits**: Max requests per minute

### Request Flow
1. Request arrives at gateway
2. **Rate limiter** checks if provider has capacity
3. **Semantic cache** checks for similar previous query
4. If cache miss, **smart router** selects optimal provider
5. **Fallback chain** handles any failures
6. Response is cached, costs tracked, everything logged
7. Response returned to caller

## What You'll Learn
- How to build a production API gateway pattern for LLMs
- Complexity-based routing algorithms
- Semantic similarity caching with embeddings
- Token-bucket rate limiting
- Cost tracking and observability for AI systems
- Fallback and resilience patterns

## Port
This project runs on **port 8518**.
