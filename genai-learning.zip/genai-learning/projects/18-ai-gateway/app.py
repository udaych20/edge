"""
AI Gateway — Streamlit UI
Enterprise dashboard for the unified LLM gateway.
Port: 8518
"""

import os
import json
import streamlit as st
from dataclasses import asdict

from gateway import (
    AIGateway,
    GatewayConfig,
    GatewayRequest,
    ProviderConfig,
)

# ---------------------------------------------------------------------------
# Session state initialisation
# ---------------------------------------------------------------------------

def _init():
    if "gateway" not in st.session_state:
        st.session_state.gw_config = GatewayConfig()
        st.session_state.gateway = AIGateway(config=st.session_state.gw_config)
    if "history" not in st.session_state:
        st.session_state.history = []


_init()
gw: AIGateway = st.session_state.gateway

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(page_title="AI Gateway", page_icon="🌐", layout="wide")
st.title("🌐 AI Gateway — Unified LLM Gateway")
st.caption("Smart routing · Fallback chains · Semantic caching · Cost tracking")

tab_console, tab_dash, tab_config, tab_cache = st.tabs([
    "🖥️ Gateway Console",
    "📊 Dashboard",
    "⚙️ Configuration",
    "🗃️ Cache Inspector",
])

# ---------------------------------------------------------------------------
# TAB 1 — Gateway Console
# ---------------------------------------------------------------------------

with tab_console:
    st.header("Gateway Console")
    st.markdown("Send a query through the gateway and observe routing decisions, caching, and cost.")

    col_input, col_opts = st.columns([3, 1])

    with col_input:
        query = st.text_area("Enter your query", height=100, placeholder="Ask anything…")

    with col_opts:
        provider_names = ["auto (smart route)"] + list(gw.providers.keys())
        preferred = st.selectbox("Provider", provider_names)
        max_tokens = st.slider("Max tokens", 64, 2048, 1024, step=64)
        temperature = st.slider("Temperature", 0.0, 1.5, 0.7, step=0.1)

    if st.button("🚀 Send through Gateway", type="primary", use_container_width=True):
        if not query.strip():
            st.warning("Please enter a query.")
        else:
            preferred_provider = None if preferred.startswith("auto") else preferred
            req = GatewayRequest(
                query=query.strip(),
                preferred_provider=preferred_provider,
                max_tokens=max_tokens,
                temperature=temperature,
            )
            with st.spinner("Routing through gateway…"):
                resp = gw.route(req)
            st.session_state.history.append(resp)

            # --- display result ---
            st.success("Response received!")

            meta_cols = st.columns(6)
            meta_cols[0].metric("Provider", resp.provider_used)
            meta_cols[1].metric("Model", resp.model_used)
            meta_cols[2].metric("Tier", resp.routing_tier)
            meta_cols[3].metric("Cached", "HIT ✅" if resp.cached else "MISS")
            meta_cols[4].metric("Latency", f"{resp.latency_ms:.0f} ms")
            meta_cols[5].metric("Cost", f"${resp.cost_usd:.6f}")

            if resp.cached:
                st.info(f"Cache similarity: {resp.cache_similarity:.4f}")

            st.markdown("**Response:**")
            st.markdown(resp.content)

            with st.expander("Request details"):
                st.json({
                    "complexity_score": resp.complexity_score,
                    "routing_tier": resp.routing_tier,
                    "input_tokens": resp.input_tokens,
                    "output_tokens": resp.output_tokens,
                    "total_tokens": resp.total_tokens,
                    "fallback_attempts": resp.fallback_attempts,
                    "timestamp": resp.timestamp,
                })

    # Request history
    if st.session_state.history:
        st.divider()
        st.subheader("Request History")
        for i, r in enumerate(reversed(st.session_state.history)):
            tag = "🟢 CACHED" if r.cached else "🔵 LIVE"
            with st.expander(f"{tag} [{r.routing_tier}] {r.provider_used} — ${r.cost_usd:.6f} — {r.latency_ms:.0f}ms"):
                st.write(r.content[:500])

# ---------------------------------------------------------------------------
# TAB 2 — Dashboard
# ---------------------------------------------------------------------------

with tab_dash:
    st.header("Gateway Dashboard")

    stats = gw.get_dashboard_stats()

    # Top-level metrics
    m1, m2, m3, m4, m5, m6 = st.columns(6)
    m1.metric("Total Requests", stats["total_requests"])
    m2.metric("Cache Hit Rate", f"{stats['cache_hit_rate']:.1%}")
    m3.metric("Avg Latency", f"{stats['avg_latency_ms']:.0f} ms")
    m4.metric("Total Cost", f"${stats['total_cost_usd']:.4f}")
    m5.metric("Total Tokens", f"{stats['total_tokens']:,}")
    m6.metric("Cached Requests", stats["cached_requests"])

    st.divider()

    col_a, col_b = st.columns(2)

    with col_a:
        st.subheader("Cost by Provider")
        cost_prov = stats["cost_by_provider"]
        if cost_prov:
            st.bar_chart(cost_prov)
        else:
            st.info("No data yet. Send some queries first.")

        st.subheader("Requests by Tier")
        tier_data = stats["requests_by_tier"]
        if tier_data:
            st.bar_chart(tier_data)
        else:
            st.info("No data yet.")

    with col_b:
        st.subheader("Cost by Model")
        cost_model = stats["cost_by_model"]
        if cost_model:
            st.bar_chart(cost_model)
        else:
            st.info("No data yet.")

        st.subheader("Rate Limiter Status")
        rl_stats = stats["rate_limiter_stats"]
        if rl_stats:
            for name, info in rl_stats.items():
                fill = info["tokens_available"] / info["max_tokens"] if info["max_tokens"] else 0
                st.write(f"**{name}**")
                st.progress(min(1.0, fill), text=f"{info['tokens_available']:.0f} / {info['max_tokens']:.0f} tokens")
                st.caption(f"Served: {info['total_requests']} | Rejected: {info['rejected']}")

    # Recent request log
    st.divider()
    st.subheader("Recent Request Log")
    logs = gw.request_logs[-20:]
    if logs:
        log_data = []
        for l in reversed(logs):
            log_data.append({
                "Time": l.timestamp[11:19],
                "Provider": l.provider,
                "Model": l.model,
                "Cached": "✅" if l.cached else "—",
                "Tier": l.tier,
                "Latency (ms)": l.latency_ms,
                "Tokens": l.input_tokens + l.output_tokens,
                "Cost ($)": f"{l.cost_usd:.6f}",
                "Complexity": f"{l.complexity:.3f}",
                "Fallbacks": l.fallback_attempts,
                "Query": l.query_preview[:50],
            })
        st.dataframe(log_data, use_container_width=True)
    else:
        st.info("No requests logged yet.")

# ---------------------------------------------------------------------------
# TAB 3 — Configuration
# ---------------------------------------------------------------------------

with tab_config:
    st.header("Gateway Configuration")
    st.markdown("Toggle features and adjust settings. Changes apply to future requests.")

    cfg = st.session_state.gw_config

    col_tog, col_params = st.columns(2)

    with col_tog:
        st.subheader("Feature Toggles")
        new_routing = st.toggle("Smart Routing", value=cfg.enable_smart_routing)
        new_cache = st.toggle("Semantic Cache", value=cfg.enable_semantic_cache)
        new_rl = st.toggle("Rate Limiting", value=cfg.enable_rate_limiting)
        new_fb = st.toggle("Fallback Chains", value=cfg.enable_fallback)
        new_ct = st.toggle("Cost Tracking", value=cfg.enable_cost_tracking)

    with col_params:
        st.subheader("Routing Parameters")
        simple_max = st.slider("Simple tier max complexity", 0.0, 1.0, cfg.complexity_thresholds["simple_max"], 0.05)
        balanced_max = st.slider("Balanced tier max complexity", 0.0, 1.0, cfg.complexity_thresholds["balanced_max"], 0.05)
        cache_thresh = st.slider("Cache similarity threshold", 0.5, 1.0, cfg.cache_similarity_threshold, 0.01)

    if st.button("💾 Apply Configuration", type="primary"):
        cfg.enable_smart_routing = new_routing
        cfg.enable_semantic_cache = new_cache
        cfg.enable_rate_limiting = new_rl
        cfg.enable_fallback = new_fb
        cfg.enable_cost_tracking = new_ct
        cfg.complexity_thresholds["simple_max"] = simple_max
        cfg.complexity_thresholds["balanced_max"] = balanced_max
        cfg.cache_similarity_threshold = cache_thresh
        gw.cache.threshold = cache_thresh
        st.success("Configuration updated!")

    st.divider()
    st.subheader("Fallback Chain Order")
    chain_text = st.text_input(
        "Comma-separated provider names",
        value=", ".join(cfg.default_fallback_chain),
    )
    if st.button("Update Fallback Chain"):
        names = [n.strip() for n in chain_text.split(",") if n.strip()]
        valid = [n for n in names if n in gw.providers]
        if valid:
            cfg.default_fallback_chain = valid
            st.success(f"Fallback chain: {' → '.join(valid)}")
        else:
            st.error("No valid provider names found.")

    st.divider()
    st.subheader("Registered Providers")
    for name, prov in gw.providers.items():
        with st.expander(f"{name} — {prov.model} ({prov.tier})"):
            st.write(f"**Priority:** {prov.priority}")
            st.write(f"**Input cost:** ${prov.input_cost_per_1k}/1K tokens")
            st.write(f"**Output cost:** ${prov.output_cost_per_1k}/1K tokens")
            st.write(f"**Max RPM:** {prov.max_rpm}")
            st.write(f"**Simulated failure rate:** {prov.simulated_failure_rate:.0%}")

# ---------------------------------------------------------------------------
# TAB 4 — Cache Inspector
# ---------------------------------------------------------------------------

with tab_cache:
    st.header("Cache Inspector")

    cache = gw.cache
    entries = cache.get_entries_display()

    c1, c2, c3 = st.columns(3)
    c1.metric("Cached Entries", len(entries))
    c2.metric("Cache Hits", cache.stats["hits"])
    c3.metric("Hit Rate", f"{cache.hit_rate:.1%}")

    st.divider()

    if entries:
        st.subheader("Cached Entries")
        for i, entry in enumerate(entries):
            with st.expander(
                f"#{i + 1} — {entry['query'][:60]}{'…' if len(entry['query']) > 60 else ''} "
                f"(hits: {entry['hits']})"
            ):
                st.write(f"**Provider:** {entry['provider']}")
                st.write(f"**Cached at:** {entry['timestamp']}")
                st.write(f"**Hits:** {entry['hits']}")
                st.write(f"**Saved per hit:** ${entry['cost_saved_per_hit']:.6f}")
                st.write("**Cached response:**")
                st.markdown(entry["response"][:500])

        st.divider()
        st.subheader("Similarity Test")
        test_query = st.text_input("Test a query against the cache")
        if st.button("Test Similarity") and test_query:
            with st.spinner("Computing embeddings…"):
                result, sim = cache.lookup(test_query)
            if result:
                st.success(f"Cache HIT — similarity: {sim:.4f}")
                st.write(f"Matched: *{result['query']}*")
                st.write(result["response"][:300])
            else:
                st.warning(f"Cache MISS — best similarity: {sim:.4f} (threshold: {cache.threshold})")
    else:
        st.info("Cache is empty. Send some queries through the Gateway Console first.")


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

with st.sidebar:
    st.header("AI Gateway")
    st.markdown(
        "Unified API gateway for multiple LLM providers with "
        "smart routing, caching, fallback chains, and cost tracking."
    )
    st.divider()
    st.markdown("**Features:**")
    features = {
        "Smart Routing": gw.config.enable_smart_routing,
        "Semantic Cache": gw.config.enable_semantic_cache,
        "Rate Limiting": gw.config.enable_rate_limiting,
        "Fallback Chains": gw.config.enable_fallback,
        "Cost Tracking": gw.config.enable_cost_tracking,
    }
    for feat, enabled in features.items():
        st.write(f"{'✅' if enabled else '❌'} {feat}")

    st.divider()
    st.markdown(f"**Providers:** {len(gw.providers)}")
    st.markdown(f"**Cache entries:** {len(gw.cache.entries)}")
    st.markdown(f"**Total cost:** ${gw.cost_tracker.total_cost:.4f}")
    st.divider()
    st.caption("Project 18 · GenAI Learning · Port 8518")
