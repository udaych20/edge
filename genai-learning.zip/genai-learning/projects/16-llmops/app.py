"""
LLMOps Dashboard — Streamlit UI for Prompt Versioning, A/B Testing & Cost Tracking.
Port: 8516
"""

import json
import streamlit as st
from llmops import (
    PromptRegistry, CostTracker, ABTester, AutoEval,
    PromptVersion, SAMPLE_TEST_INPUTS, seed_registry, MODEL_PRICING,
)

# --------------------------------------------------------------------------- #
#  Page config
# --------------------------------------------------------------------------- #
st.set_page_config(page_title="LLMOps Dashboard", page_icon="⚙️", layout="wide")

# --------------------------------------------------------------------------- #
#  Shared state
# --------------------------------------------------------------------------- #

@st.cache_resource
def get_services():
    registry = PromptRegistry()
    tracker = CostTracker()
    evaluator = AutoEval(tracker)
    ab_tester = ABTester(registry, tracker, evaluator)
    seed_registry(registry)
    return registry, tracker, ab_tester, evaluator

registry, tracker, ab_tester, evaluator = get_services()

# --------------------------------------------------------------------------- #
#  Header
# --------------------------------------------------------------------------- #
st.title("⚙️ LLMOps Dashboard")
st.caption("Prompt versioning · A/B testing · Cost tracking · Auto evaluation")

tab1, tab2, tab3 = st.tabs(["📋 Prompt Registry", "🔬 A/B Testing", "💰 Cost Dashboard"])

# =========================================================================== #
#  Tab 1 — Prompt Registry
# =========================================================================== #
with tab1:
    st.header("Prompt Registry")

    use_cases = registry.list_use_cases()
    if not use_cases:
        st.info("No prompts registered yet. The sample prompts will be loaded on first run.")
    else:
        selected_uc = st.selectbox("Select use case", use_cases, key="reg_uc")
        versions = registry.get_versions(selected_uc)

        # Version overview table
        st.subheader(f"Versions — {selected_uc}")
        for v in versions:
            status_icon = {"draft": "📝", "active": "✅", "archived": "📦"}.get(v["status"], "❓")
            with st.expander(f"{status_icon} v{v['version']} — {v['name']} [{v['status']}]"):
                col1, col2, col3 = st.columns([2, 1, 1])
                with col1:
                    st.text_area("System Prompt", v["system_prompt"], height=150,
                                 key=f"prompt_{selected_uc}_{v['version']}", disabled=True)
                with col2:
                    st.metric("Model", v["model"])
                    st.metric("Temperature", v["temperature"])
                with col3:
                    st.metric("Status", v["status"])
                    st.write(f"**Hash:** `{v.get('content_hash', 'N/A')}`")
                    if v.get("metadata"):
                        st.write(f"**Tags:** {', '.join(v['metadata'].get('tags', []))}")

                # Promote actions
                if v["status"] == "draft":
                    if st.button(f"Promote v{v['version']} to Active",
                                 key=f"promote_{selected_uc}_{v['version']}"):
                        if registry.promote(selected_uc, v["version"], "active"):
                            st.success(f"v{v['version']} promoted to active!")
                            st.rerun()
                elif v["status"] == "active":
                    if st.button(f"Archive v{v['version']}",
                                 key=f"archive_{selected_uc}_{v['version']}"):
                        if registry.promote(selected_uc, v["version"], "archived"):
                            st.success(f"v{v['version']} archived!")
                            st.rerun()

        # Compare versions
        st.subheader("Compare Versions")
        if len(versions) >= 2:
            col1, col2 = st.columns(2)
            with col1:
                v1 = st.selectbox("Version A", [v["version"] for v in versions],
                                  key="diff_v1")
            with col2:
                v2 = st.selectbox("Version B", [v["version"] for v in versions],
                                  index=min(1, len(versions) - 1), key="diff_v2")
            if v1 != v2:
                diff = registry.get_diff(selected_uc, v1, v2)
                if diff:
                    for field, change in diff.items():
                        st.write(f"**{field}**")
                        col1, col2 = st.columns(2)
                        with col1:
                            st.code(str(change["v1"]), language="text")
                        with col2:
                            st.code(str(change["v2"]), language="text")
                else:
                    st.info("No differences found.")

        # Add new prompt version
        st.subheader("Create New Version")
        with st.form("new_prompt"):
            new_name = st.text_input("Name", placeholder="My Prompt v3")
            new_uc = st.text_input("Use Case", value=selected_uc if use_cases else "",
                                   placeholder="customer_support")
            new_system = st.text_area("System Prompt", height=150,
                                      placeholder="You are a helpful assistant...")
            nc1, nc2 = st.columns(2)
            with nc1:
                new_model = st.selectbox("Model", list(MODEL_PRICING.keys()))
            with nc2:
                new_temp = st.slider("Temperature", 0.0, 2.0, 0.7, 0.1)

            if st.form_submit_button("Register Prompt"):
                if new_name and new_uc and new_system:
                    pv = PromptVersion(
                        name=new_name, use_case=new_uc,
                        system_prompt=new_system, model=new_model,
                        temperature=new_temp,
                    )
                    registry.register(pv)
                    st.success(f"Registered '{new_name}' as new version for '{new_uc}'!")
                    st.rerun()
                else:
                    st.warning("Please fill in all required fields.")

# =========================================================================== #
#  Tab 2 — A/B Testing
# =========================================================================== #
with tab2:
    st.header("A/B Testing")

    ab_col1, ab_col2 = st.columns([1, 1])

    with ab_col1:
        st.subheader("Run New Test")
        ab_use_cases = registry.list_use_cases()
        if not ab_use_cases:
            st.info("Register prompts first in the Prompt Registry tab.")
        else:
            ab_uc = st.selectbox("Use case", ab_use_cases, key="ab_uc")
            ab_versions = registry.get_versions(ab_uc)
            version_nums = [v["version"] for v in ab_versions]

            if len(version_nums) < 2:
                st.warning("Need at least 2 versions to run A/B test.")
            else:
                vc1, vc2 = st.columns(2)
                with vc1:
                    ab_v1 = st.selectbox("Version A", version_nums, key="ab_v1")
                with vc2:
                    ab_v2 = st.selectbox("Version B", version_nums,
                                         index=min(1, len(version_nums) - 1), key="ab_v2")

                # Show prompt previews
                p_a = registry.get_version(ab_uc, ab_v1)
                p_b = registry.get_version(ab_uc, ab_v2)
                if p_a and p_b:
                    pc1, pc2 = st.columns(2)
                    with pc1:
                        st.caption(f"**v{ab_v1}** — {p_a['name']}")
                        st.code(p_a["system_prompt"][:200] + "..." if len(p_a["system_prompt"]) > 200
                                else p_a["system_prompt"], language="text")
                    with pc2:
                        st.caption(f"**v{ab_v2}** — {p_b['name']}")
                        st.code(p_b["system_prompt"][:200] + "..." if len(p_b["system_prompt"]) > 200
                                else p_b["system_prompt"], language="text")

                # Test inputs
                default_inputs = SAMPLE_TEST_INPUTS.get(ab_uc, ["Hello, how can you help?"])
                test_input_text = st.text_area(
                    "Test inputs (one per line)",
                    value="\n".join(default_inputs[:2]),
                    height=120, key="ab_inputs",
                )
                run_eval = st.checkbox("Run auto-evaluation (LLM-as-judge)", value=True)

                if st.button("▶ Run A/B Test", type="primary"):
                    inputs = [line.strip() for line in test_input_text.strip().split("\n") if line.strip()]
                    if not inputs:
                        st.warning("Provide at least one test input.")
                    elif ab_v1 == ab_v2:
                        st.warning("Select two different versions.")
                    else:
                        with st.spinner(f"Running A/B test ({len(inputs)} inputs)..."):
                            results = ab_tester.run_test(ab_uc, ab_v1, ab_v2, inputs, run_eval)
                            st.session_state["ab_results"] = results

    with ab_col2:
        st.subheader("Results")

        # Show results from current run or loaded file
        results = st.session_state.get("ab_results")
        if results:
            summary = ABTester.summarize(results)

            # Winner banner
            winner = summary.get("winner", "N/A")
            reason = summary.get("reason", "")
            if "Tie" in winner:
                st.info(f"🤝 **{winner}** — {reason}")
            else:
                st.success(f"🏆 **Winner: {winner}** — {reason}")

            # Metrics
            mc1, mc2, mc3 = st.columns(3)
            with mc1:
                st.metric("Quality A (mean)", f"{summary['quality_a']['mean']:.1f}/10")
                st.metric("Quality B (mean)", f"{summary['quality_b']['mean']:.1f}/10")
            with mc2:
                st.metric("Latency A (mean)", f"{summary['latency_a']['mean']:.2f}s")
                st.metric("Latency B (mean)", f"{summary['latency_b']['mean']:.2f}s")
            with mc3:
                st.metric("Cost A (total)", f"${summary['cost_a_total']:.6f}")
                st.metric("Cost B (total)", f"${summary['cost_b_total']:.6f}")

            # Detailed results
            st.subheader("Detailed Results")
            for i, r in enumerate(results):
                with st.expander(f"Test {i+1}: {r.input_text[:60]}..."):
                    dc1, dc2 = st.columns(2)
                    with dc1:
                        st.caption(f"**Version A (v{r.version_a})**")
                        st.write(r.output_a)
                        st.caption(f"⏱ {r.latency_a:.2f}s · 💰 ${r.cost_a:.6f} · ⭐ {r.quality_a}/10")
                    with dc2:
                        st.caption(f"**Version B (v{r.version_b})**")
                        st.write(r.output_b)
                        st.caption(f"⏱ {r.latency_b:.2f}s · 💰 ${r.cost_b:.6f} · ⭐ {r.quality_b}/10")
        else:
            # Load previous results
            saved_files = ab_tester.list_results()
            if saved_files:
                st.caption("Or load a previous test:")
                selected_file = st.selectbox("Saved results", saved_files, key="load_ab")
                if st.button("Load"):
                    loaded = ab_tester.load_results(selected_file)
                    if loaded:
                        st.session_state["ab_results"] = loaded
                        st.rerun()
            else:
                st.info("Run an A/B test to see results here.")

# =========================================================================== #
#  Tab 3 — Cost Dashboard
# =========================================================================== #
with tab3:
    st.header("Cost Dashboard")

    cost_summary = tracker.get_summary()

    # Top-level metrics
    kc1, kc2, kc3, kc4 = st.columns(4)
    with kc1:
        st.metric("Total Cost", f"${cost_summary.get('total_cost', 0):.6f}")
    with kc2:
        st.metric("Total Requests", cost_summary.get("total_requests", 0))
    with kc3:
        st.metric("Total Tokens", f"{cost_summary.get('total_tokens', 0):,}")
    with kc4:
        avg_cost = (cost_summary["total_cost"] / cost_summary["total_requests"]
                    if cost_summary.get("total_requests") else 0)
        st.metric("Avg Cost/Request", f"${avg_cost:.6f}")

    st.divider()

    dc1, dc2 = st.columns(2)

    with dc1:
        # By project
        st.subheader("Cost by Project")
        by_project = tracker.get_by_project()
        if by_project:
            for proj, data in sorted(by_project.items(), key=lambda x: -x[1]["cost"]):
                st.write(f"**{proj}**")
                pc1, pc2, pc3 = st.columns(3)
                with pc1:
                    st.metric("Cost", f"${data['cost']:.6f}", label_visibility="collapsed")
                with pc2:
                    st.write(f"🔢 {data['requests']} reqs")
                with pc3:
                    st.write(f"📊 {data['tokens']:,} tokens")
        else:
            st.info("No cost data yet. Run an A/B test to generate cost records.")

    with dc2:
        # By model
        st.subheader("Cost by Model")
        by_model = tracker.get_by_model()
        if by_model:
            for model, data in sorted(by_model.items(), key=lambda x: -x[1]["cost"]):
                pricing = MODEL_PRICING.get(model, {})
                st.write(f"**{model}** — ${pricing.get('input', '?')}/{pricing.get('output', '?')} per 1M tokens")
                mc1, mc2, mc3 = st.columns(3)
                with mc1:
                    st.metric("Cost", f"${data['cost']:.6f}", label_visibility="collapsed")
                with mc2:
                    st.write(f"🔢 {data['requests']} reqs")
                with mc3:
                    st.write(f"📊 {data['tokens']:,} tokens")

    st.divider()

    # By day
    st.subheader("Cost by Day")
    by_day = tracker.get_by_day()
    if by_day:
        day_data = sorted(by_day.items())
        cols = st.columns(min(len(day_data), 7))
        for i, (day, data) in enumerate(day_data[-7:]):
            with cols[i % len(cols)]:
                st.metric(day, f"${data['cost']:.6f}")
                st.caption(f"{data['requests']} reqs · {data['tokens']:,} tok")
    else:
        st.info("No daily data yet.")

    st.divider()

    # Pricing reference
    st.subheader("Model Pricing Reference")
    pricing_data = []
    for model, prices in MODEL_PRICING.items():
        pricing_data.append({
            "Model": model,
            "Input ($/1M tokens)": f"${prices['input']:.2f}",
            "Output ($/1M tokens)": f"${prices['output']:.2f}",
            "Input ($/1K tokens)": f"${prices['input']/1000:.6f}",
            "Output ($/1K tokens)": f"${prices['output']/1000:.6f}",
        })
    st.table(pricing_data)

    # Raw records
    with st.expander("📄 Raw Cost Records"):
        records = tracker.get_records()
        if records:
            st.json(records[-20:])  # Show last 20
        else:
            st.info("No records.")
