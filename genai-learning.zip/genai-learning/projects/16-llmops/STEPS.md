# Project 16: LLMOps — Prompt Versioning, A/B Testing & Cost Tracking

## What You'll Learn
- **Prompt Versioning**: Manage prompts as versioned artifacts with lifecycle states
- **A/B Testing**: Compare prompt versions with statistical rigor
- **Cost Tracking**: Monitor token usage and costs per project/model/day
- **Automated Evaluation**: Use LLM-as-judge for quality scoring

## LLMOps Concepts

### Why LLMOps?
LLMOps applies DevOps/MLOps principles to LLM applications:
- **Prompt Management** — Prompts are code. Version them, review them, promote them.
- **Experimentation** — A/B test prompt changes before deploying to production.
- **Observability** — Track costs, latency, and quality metrics per request.
- **Evaluation** — Automated quality checks catch regressions before users do.

### Prompt Lifecycle
```
draft → active → archived
```
- **Draft**: New or experimental prompt versions under development
- **Active**: Production-ready prompts serving live traffic
- **Archived**: Previous versions kept for audit trail and rollback

### A/B Testing Flow
```
Test Inputs → [Version A] → Results A ─┐
                                        ├→ Compare (latency, cost, quality)
Test Inputs → [Version B] → Results B ─┘
```

### Cost Model
Token-based pricing varies by model:
| Model | Input (per 1M tokens) | Output (per 1M tokens) |
|-------|----------------------|----------------------|
| gpt-4o-mini | $0.15 | $0.60 |
| gpt-4o | $2.50 | $10.00 |

## Architecture
```
┌─────────────────────────────────────────┐
│           Streamlit UI (:8516)          │
│  ┌───────────┬──────────┬────────────┐  │
│  │  Prompt   │   A/B    │   Cost     │  │
│  │ Registry  │ Testing  │ Dashboard  │  │
│  └─────┬─────┴────┬─────┴─────┬──────┘  │
│        │          │           │          │
│  ┌─────┴──────────┴───────────┴──────┐  │
│  │         llmops.py                 │  │
│  │  PromptRegistry | ABTester       │  │
│  │  CostTracker    | AutoEval       │  │
│  └───────────────────────────────────┘  │
│        │                                │
│  ┌─────┴─────────┐                      │
│  │  JSON Storage  │                      │
│  │  prompts.json  │                      │
│  │  costs.json    │                      │
│  │  ab_results/   │                      │
│  └───────────────┘                      │
└─────────────────────────────────────────┘
```

## Files
| File | Purpose |
|------|---------|
| `llmops.py` | Core: PromptRegistry, ABTester, CostTracker, AutoEval |
| `app.py` | Streamlit UI with 3 tabs |
| `requirements.txt` | Dependencies |
| `.env` | OpenAI API key |

## Run Locally
```bash
pip install -r requirements.txt
# CLI demo
python llmops.py demo
# Web UI
streamlit run app.py --server.port 8516
```

## Deploy to Server
```bash
cd /home/azureuser/genai-projects/16-llmops
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8516 --server.headless true
```

## Key Takeaways
1. **Version everything** — Prompts, models, temperatures are all config that should be tracked
2. **Measure before changing** — A/B test with real inputs before promoting a new prompt version
3. **Track costs proactively** — Token costs compound quickly; per-project tracking prevents surprises
4. **Automate evaluation** — LLM-as-judge catches quality regressions faster than manual review
