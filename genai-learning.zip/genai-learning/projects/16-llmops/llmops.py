"""
LLMOps — Prompt Versioning, A/B Testing, Cost Tracking & Automated Evaluation.

Core module providing:
- PromptRegistry: JSON-based prompt versioning with lifecycle management
- ABTester: Compare two prompt versions with latency/cost/quality metrics
- CostTracker: Token usage and cost tracking per project/model/day
- AutoEval: LLM-as-judge quality scoring
"""

import json
import os
import time
import hashlib
import statistics
from datetime import datetime, date
from pathlib import Path
from typing import Optional
from copy import deepcopy

from dotenv import load_dotenv
from openai import OpenAI
from pydantic import BaseModel, Field

load_dotenv()

client = OpenAI()
DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# --------------------------------------------------------------------------- #
#  Model pricing (per 1M tokens)
# --------------------------------------------------------------------------- #
MODEL_PRICING = {
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4-turbo": {"input": 10.00, "output": 30.00},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
}

# --------------------------------------------------------------------------- #
#  Pydantic schemas
# --------------------------------------------------------------------------- #

class PromptVersion(BaseModel):
    version: int = 1
    name: str
    use_case: str
    system_prompt: str
    model: str = "gpt-4o-mini"
    temperature: float = 0.7
    status: str = "draft"  # draft | active | archived
    created_at: str = Field(default_factory=lambda: datetime.now().isoformat())
    metadata: dict = Field(default_factory=dict)
    content_hash: str = ""

    def compute_hash(self) -> str:
        content = f"{self.system_prompt}|{self.model}|{self.temperature}"
        return hashlib.sha256(content.encode()).hexdigest()[:12]


class ABResult(BaseModel):
    test_id: str
    use_case: str
    version_a: int
    version_b: int
    input_text: str
    output_a: str = ""
    output_b: str = ""
    latency_a: float = 0.0
    latency_b: float = 0.0
    tokens_a: dict = Field(default_factory=dict)
    tokens_b: dict = Field(default_factory=dict)
    cost_a: float = 0.0
    cost_b: float = 0.0
    quality_a: float = 0.0
    quality_b: float = 0.0
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class CostRecord(BaseModel):
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    project: str = "default"
    model: str = "gpt-4o-mini"
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0
    purpose: str = ""


# --------------------------------------------------------------------------- #
#  Prompt Registry
# --------------------------------------------------------------------------- #

class PromptRegistry:
    """JSON-based prompt versioning system with lifecycle management."""

    def __init__(self, filepath: Optional[str] = None):
        self.filepath = Path(filepath) if filepath else DATA_DIR / "prompts.json"
        self._data: dict[str, list[dict]] = {}
        self._load()

    def _load(self):
        if self.filepath.exists():
            self._data = json.loads(self.filepath.read_text(encoding="utf-8"))
        else:
            self._data = {}

    def _save(self):
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        self.filepath.write_text(
            json.dumps(self._data, indent=2, default=str), encoding="utf-8"
        )

    def register(self, prompt: PromptVersion) -> PromptVersion:
        """Add a new prompt version to the registry."""
        key = prompt.use_case
        if key not in self._data:
            self._data[key] = []

        existing = self._data[key]
        prompt.version = len(existing) + 1
        prompt.content_hash = prompt.compute_hash()
        self._data[key].append(prompt.model_dump())
        self._save()
        return prompt

    def get_versions(self, use_case: str) -> list[dict]:
        """Get all versions for a use case."""
        return self._data.get(use_case, [])

    def get_version(self, use_case: str, version: int) -> Optional[dict]:
        """Get a specific version."""
        versions = self.get_versions(use_case)
        for v in versions:
            if v["version"] == version:
                return v
        return None

    def get_active(self, use_case: str) -> Optional[dict]:
        """Get the currently active version for a use case."""
        for v in reversed(self.get_versions(use_case)):
            if v["status"] == "active":
                return v
        return None

    def promote(self, use_case: str, version: int, new_status: str) -> bool:
        """Change version status: draft → active → archived."""
        valid_transitions = {
            "draft": ["active", "archived"],
            "active": ["archived"],
            "archived": [],
        }
        versions = self.get_versions(use_case)
        for v in versions:
            if v["version"] == version:
                allowed = valid_transitions.get(v["status"], [])
                if new_status not in allowed:
                    return False
                # If promoting to active, archive any current active version
                if new_status == "active":
                    for other in versions:
                        if other["status"] == "active" and other["version"] != version:
                            other["status"] = "archived"
                v["status"] = new_status
                self._save()
                return True
        return False

    def get_diff(self, use_case: str, v1: int, v2: int) -> dict:
        """Compare two versions and return differences."""
        ver1 = self.get_version(use_case, v1)
        ver2 = self.get_version(use_case, v2)
        if not ver1 or not ver2:
            return {"error": "Version not found"}

        diff = {}
        for field in ["system_prompt", "model", "temperature", "status"]:
            if ver1.get(field) != ver2.get(field):
                diff[field] = {"v1": ver1.get(field), "v2": ver2.get(field)}
        return diff

    def list_use_cases(self) -> list[str]:
        """List all registered use cases."""
        return list(self._data.keys())

    def get_all(self) -> dict:
        """Return all registry data."""
        return deepcopy(self._data)


# --------------------------------------------------------------------------- #
#  Cost Tracker
# --------------------------------------------------------------------------- #

class CostTracker:
    """Track token usage and costs per request, project, and day."""

    def __init__(self, filepath: Optional[str] = None):
        self.filepath = Path(filepath) if filepath else DATA_DIR / "costs.json"
        self._records: list[dict] = []
        self._load()

    def _load(self):
        if self.filepath.exists():
            self._records = json.loads(self.filepath.read_text(encoding="utf-8"))
        else:
            self._records = []

    def _save(self):
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        self.filepath.write_text(
            json.dumps(self._records, indent=2, default=str), encoding="utf-8"
        )

    @staticmethod
    def calculate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
        """Calculate cost in USD for a given request."""
        pricing = MODEL_PRICING.get(model, MODEL_PRICING["gpt-4o-mini"])
        input_cost = (prompt_tokens / 1_000_000) * pricing["input"]
        output_cost = (completion_tokens / 1_000_000) * pricing["output"]
        return round(input_cost + output_cost, 6)

    def record(self, model: str, prompt_tokens: int, completion_tokens: int,
               project: str = "default", purpose: str = "") -> CostRecord:
        """Record a cost entry."""
        cost = self.calculate_cost(model, prompt_tokens, completion_tokens)
        rec = CostRecord(
            project=project,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
            cost_usd=cost,
            purpose=purpose,
        )
        self._records.append(rec.model_dump())
        self._save()
        return rec

    def get_summary(self) -> dict:
        """Get overall cost summary."""
        if not self._records:
            return {"total_cost": 0, "total_tokens": 0, "total_requests": 0}
        return {
            "total_cost": round(sum(r["cost_usd"] for r in self._records), 6),
            "total_tokens": sum(r["total_tokens"] for r in self._records),
            "total_requests": len(self._records),
            "total_prompt_tokens": sum(r["prompt_tokens"] for r in self._records),
            "total_completion_tokens": sum(r["completion_tokens"] for r in self._records),
        }

    def get_by_project(self) -> dict[str, dict]:
        """Aggregate costs per project."""
        projects: dict[str, dict] = {}
        for r in self._records:
            p = r["project"]
            if p not in projects:
                projects[p] = {"cost": 0.0, "tokens": 0, "requests": 0}
            projects[p]["cost"] = round(projects[p]["cost"] + r["cost_usd"], 6)
            projects[p]["tokens"] += r["total_tokens"]
            projects[p]["requests"] += 1
        return projects

    def get_by_day(self) -> dict[str, dict]:
        """Aggregate costs per day."""
        days: dict[str, dict] = {}
        for r in self._records:
            day = r["timestamp"][:10]
            if day not in days:
                days[day] = {"cost": 0.0, "tokens": 0, "requests": 0}
            days[day]["cost"] = round(days[day]["cost"] + r["cost_usd"], 6)
            days[day]["tokens"] += r["total_tokens"]
            days[day]["requests"] += 1
        return days

    def get_by_model(self) -> dict[str, dict]:
        """Aggregate costs per model."""
        models: dict[str, dict] = {}
        for r in self._records:
            m = r["model"]
            if m not in models:
                models[m] = {"cost": 0.0, "tokens": 0, "requests": 0}
            models[m]["cost"] = round(models[m]["cost"] + r["cost_usd"], 6)
            models[m]["tokens"] += r["total_tokens"]
            models[m]["requests"] += 1
        return models

    def get_records(self) -> list[dict]:
        """Return all records."""
        return list(self._records)


# --------------------------------------------------------------------------- #
#  Auto Eval — LLM-as-Judge
# --------------------------------------------------------------------------- #

class AutoEval:
    """LLM-as-judge automated quality scoring."""

    JUDGE_PROMPT = """You are an expert evaluator. Score the following AI-generated response on a scale of 1-10.

Criteria:
- Relevance: Does it address the user's input? (1-10)
- Quality: Is the response well-structured and helpful? (1-10)
- Conciseness: Is it appropriately concise without missing key points? (1-10)

User Input: {input_text}

AI Response: {output_text}

Respond with ONLY a JSON object:
{{"relevance": <score>, "quality": <score>, "conciseness": <score>, "overall": <average_score>, "explanation": "<brief explanation>"}}"""

    def __init__(self, cost_tracker: Optional[CostTracker] = None):
        self.cost_tracker = cost_tracker

    def score(self, input_text: str, output_text: str,
              judge_model: str = "gpt-4o-mini") -> dict:
        """Score a response using LLM-as-judge."""
        prompt = self.JUDGE_PROMPT.format(
            input_text=input_text, output_text=output_text
        )
        try:
            response = client.chat.completions.create(
                model=judge_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                response_format={"type": "json_object"},
            )
            usage = response.usage
            if self.cost_tracker and usage:
                self.cost_tracker.record(
                    model=judge_model,
                    prompt_tokens=usage.prompt_tokens,
                    completion_tokens=usage.completion_tokens,
                    project="llmops-eval",
                    purpose="auto-eval-judge",
                )
            result = json.loads(response.choices[0].message.content)
            return result
        except Exception as e:
            return {"relevance": 0, "quality": 0, "conciseness": 0,
                    "overall": 0, "explanation": f"Eval error: {e}"}


# --------------------------------------------------------------------------- #
#  A/B Tester
# --------------------------------------------------------------------------- #

class ABTester:
    """Run A/B tests comparing two prompt versions."""

    def __init__(self, registry: PromptRegistry, cost_tracker: CostTracker,
                 evaluator: Optional[AutoEval] = None):
        self.registry = registry
        self.cost_tracker = cost_tracker
        self.evaluator = evaluator or AutoEval(cost_tracker)
        self.results_dir = DATA_DIR / "ab_results"
        self.results_dir.mkdir(exist_ok=True)

    def _run_prompt(self, prompt_config: dict, user_input: str) -> dict:
        """Execute a single prompt and collect metrics."""
        start = time.time()
        try:
            response = client.chat.completions.create(
                model=prompt_config["model"],
                messages=[
                    {"role": "system", "content": prompt_config["system_prompt"]},
                    {"role": "user", "content": user_input},
                ],
                temperature=prompt_config["temperature"],
            )
            latency = time.time() - start
            usage = response.usage
            prompt_tokens = usage.prompt_tokens if usage else 0
            completion_tokens = usage.completion_tokens if usage else 0
            cost = self.cost_tracker.calculate_cost(
                prompt_config["model"], prompt_tokens, completion_tokens
            )
            self.cost_tracker.record(
                model=prompt_config["model"],
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                project="llmops-ab-test",
                purpose=f"ab-test-{prompt_config.get('use_case', 'unknown')}",
            )
            return {
                "output": response.choices[0].message.content,
                "latency": round(latency, 3),
                "tokens": {"prompt": prompt_tokens, "completion": completion_tokens,
                           "total": prompt_tokens + completion_tokens},
                "cost": cost,
            }
        except Exception as e:
            return {"output": f"Error: {e}", "latency": time.time() - start,
                    "tokens": {}, "cost": 0.0}

    def run_test(self, use_case: str, version_a: int, version_b: int,
                 test_inputs: list[str], run_eval: bool = True) -> list[ABResult]:
        """Run A/B test across all test inputs."""
        prompt_a = self.registry.get_version(use_case, version_a)
        prompt_b = self.registry.get_version(use_case, version_b)
        if not prompt_a or not prompt_b:
            raise ValueError(f"Prompt versions not found for '{use_case}'")

        results = []
        for i, inp in enumerate(test_inputs):
            test_id = f"{use_case}-{version_a}v{version_b}-{i}"
            res_a = self._run_prompt(prompt_a, inp)
            res_b = self._run_prompt(prompt_b, inp)

            quality_a, quality_b = 0.0, 0.0
            if run_eval:
                eval_a = self.evaluator.score(inp, res_a["output"])
                eval_b = self.evaluator.score(inp, res_b["output"])
                quality_a = eval_a.get("overall", 0)
                quality_b = eval_b.get("overall", 0)

            result = ABResult(
                test_id=test_id,
                use_case=use_case,
                version_a=version_a,
                version_b=version_b,
                input_text=inp,
                output_a=res_a["output"],
                output_b=res_b["output"],
                latency_a=res_a["latency"],
                latency_b=res_b["latency"],
                tokens_a=res_a["tokens"],
                tokens_b=res_b["tokens"],
                cost_a=res_a["cost"],
                cost_b=res_b["cost"],
                quality_a=quality_a,
                quality_b=quality_b,
            )
            results.append(result)

        # Save results
        fname = f"{use_case}_{version_a}_vs_{version_b}_{datetime.now():%Y%m%d_%H%M%S}.json"
        out_file = self.results_dir / fname
        out_file.write_text(
            json.dumps([r.model_dump() for r in results], indent=2, default=str),
            encoding="utf-8",
        )
        return results

    @staticmethod
    def summarize(results: list[ABResult]) -> dict:
        """Statistical summary of A/B test results."""
        if not results:
            return {}
        latencies_a = [r.latency_a for r in results]
        latencies_b = [r.latency_b for r in results]
        costs_a = [r.cost_a for r in results]
        costs_b = [r.cost_b for r in results]
        quality_a = [r.quality_a for r in results if r.quality_a > 0]
        quality_b = [r.quality_b for r in results if r.quality_b > 0]

        def _stats(vals):
            if not vals:
                return {"mean": 0, "median": 0, "stdev": 0}
            return {
                "mean": round(statistics.mean(vals), 4),
                "median": round(statistics.median(vals), 4),
                "stdev": round(statistics.stdev(vals), 4) if len(vals) > 1 else 0,
            }

        summary = {
            "num_tests": len(results),
            "version_a": results[0].version_a,
            "version_b": results[0].version_b,
            "latency_a": _stats(latencies_a),
            "latency_b": _stats(latencies_b),
            "cost_a_total": round(sum(costs_a), 6),
            "cost_b_total": round(sum(costs_b), 6),
            "quality_a": _stats(quality_a),
            "quality_b": _stats(quality_b),
        }

        # Determine winner
        qa = summary["quality_a"]["mean"]
        qb = summary["quality_b"]["mean"]
        if qa > qb + 0.5:
            summary["winner"] = f"Version A (v{results[0].version_a})"
            summary["reason"] = f"Higher quality ({qa} vs {qb})"
        elif qb > qa + 0.5:
            summary["winner"] = f"Version B (v{results[0].version_b})"
            summary["reason"] = f"Higher quality ({qb} vs {qa})"
        else:
            ca, cb = summary["cost_a_total"], summary["cost_b_total"]
            if ca < cb * 0.9:
                summary["winner"] = f"Version A (v{results[0].version_a})"
                summary["reason"] = f"Similar quality, lower cost (${ca} vs ${cb})"
            elif cb < ca * 0.9:
                summary["winner"] = f"Version B (v{results[0].version_b})"
                summary["reason"] = f"Similar quality, lower cost (${cb} vs ${ca})"
            else:
                summary["winner"] = "Tie"
                summary["reason"] = "No significant difference"
        return summary

    def list_results(self) -> list[str]:
        """List saved A/B test result files."""
        return sorted(f.name for f in self.results_dir.glob("*.json"))

    def load_results(self, filename: str) -> list[ABResult]:
        """Load saved A/B test results."""
        fp = self.results_dir / filename
        if not fp.exists():
            return []
        data = json.loads(fp.read_text(encoding="utf-8"))
        return [ABResult(**d) for d in data]


# --------------------------------------------------------------------------- #
#  Sample Data — 3 use cases × 2 versions
# --------------------------------------------------------------------------- #

SAMPLE_PROMPTS = [
    # ── Customer Support ──
    PromptVersion(
        name="Customer Support v1",
        use_case="customer_support",
        system_prompt="You are a helpful customer support agent. Answer the customer's question clearly and concisely. Be polite and professional.",
        model="gpt-4o-mini",
        temperature=0.5,
        metadata={"author": "team-a", "tags": ["support", "v1"]},
    ),
    PromptVersion(
        name="Customer Support v2",
        use_case="customer_support",
        system_prompt="You are an expert customer support representative for a SaaS company. Follow this structure:\n1. Acknowledge the customer's concern\n2. Provide a clear solution with step-by-step instructions\n3. Offer additional help\nKeep responses under 150 words. Use a warm, empathetic tone.",
        model="gpt-4o-mini",
        temperature=0.3,
        metadata={"author": "team-a", "tags": ["support", "v2", "structured"]},
    ),
    # ── Summarization ──
    PromptVersion(
        name="Summarizer v1",
        use_case="summarization",
        system_prompt="Summarize the following text. Keep it brief.",
        model="gpt-4o-mini",
        temperature=0.3,
        metadata={"author": "team-b", "tags": ["summarization", "v1"]},
    ),
    PromptVersion(
        name="Summarizer v2",
        use_case="summarization",
        system_prompt="You are a professional content summarizer. Create a structured summary with:\n- **Key Points**: Top 3-5 bullet points\n- **Main Takeaway**: One sentence capturing the essence\n- **Action Items**: Any actionable items mentioned\nKeep the total summary under 100 words.",
        model="gpt-4o-mini",
        temperature=0.2,
        metadata={"author": "team-b", "tags": ["summarization", "v2", "structured"]},
    ),
    # ── Code Review ──
    PromptVersion(
        name="Code Reviewer v1",
        use_case="code_review",
        system_prompt="Review the following code and provide feedback.",
        model="gpt-4o-mini",
        temperature=0.4,
        metadata={"author": "team-c", "tags": ["code-review", "v1"]},
    ),
    PromptVersion(
        name="Code Reviewer v2",
        use_case="code_review",
        system_prompt="You are a senior software engineer conducting a code review. Analyze the code for:\n1. **Bugs**: Logical errors or edge cases\n2. **Security**: Potential vulnerabilities (injection, auth issues)\n3. **Performance**: Inefficiencies or scaling concerns\n4. **Readability**: Naming, structure, documentation\nRate severity as 🔴 Critical, 🟡 Warning, or 🟢 Suggestion. Be specific with line references.",
        model="gpt-4o-mini",
        temperature=0.2,
        metadata={"author": "team-c", "tags": ["code-review", "v2", "structured"]},
    ),
]

SAMPLE_TEST_INPUTS = {
    "customer_support": [
        "I've been charged twice for my subscription this month. Can you help me get a refund?",
        "How do I reset my password? I've been locked out of my account for 2 days.",
        "Your API has been returning 500 errors for the past hour. This is affecting our production system.",
    ],
    "summarization": [
        "Artificial intelligence has transformed multiple industries over the past decade. In healthcare, AI assists with diagnosis and drug discovery. In finance, it powers fraud detection and algorithmic trading. The technology sector uses AI for code generation, testing, and deployment automation. However, concerns about bias, job displacement, and ethical use continue to drive regulatory discussions worldwide. The EU's AI Act represents the first comprehensive regulatory framework, while the US takes a more sector-specific approach.",
        "The quarterly report shows revenue growth of 15% year-over-year, driven primarily by expansion in the Asia-Pacific region. Operating margins improved by 2 percentage points due to cost optimization initiatives. The company launched three new products and expanded its engineering team by 50 employees. Customer retention rate remains strong at 94%. Looking ahead, management projects continued growth but acknowledges macroeconomic headwinds.",
    ],
    "code_review": [
        '''def get_user(user_id):
    query = f"SELECT * FROM users WHERE id = {user_id}"
    result = db.execute(query)
    return result[0] if result else None

def process_payment(amount, card_number):
    log.info(f"Processing payment of ${amount} for card {card_number}")
    response = payment_api.charge(amount, card_number)
    return response''',
        '''import pickle
import os

def load_config(filepath):
    with open(filepath, 'rb') as f:
        config = pickle.load(f)
    return config

def run_command(user_input):
    os.system(user_input)
    return "Command executed"''',
    ],
}


def seed_registry(registry: PromptRegistry):
    """Populate the registry with sample prompts."""
    for prompt in SAMPLE_PROMPTS:
        existing = registry.get_versions(prompt.use_case)
        if not existing:
            registry.register(prompt)
    # Promote v1 of each to active
    for uc in registry.list_use_cases():
        v1 = registry.get_version(uc, 1)
        if v1 and v1["status"] == "draft":
            registry.promote(uc, 1, "active")


# --------------------------------------------------------------------------- #
#  CLI Demo
# --------------------------------------------------------------------------- #

def demo():
    """Run a full LLMOps demo from the command line."""
    print("=" * 60)
    print("  LLMOps Demo — Prompt Versioning, A/B Testing, Cost Tracking")
    print("=" * 60)

    registry = PromptRegistry()
    tracker = CostTracker()
    evaluator = AutoEval(tracker)
    ab_tester = ABTester(registry, tracker, evaluator)

    # 1. Seed prompts
    print("\n📋 Seeding prompt registry...")
    seed_registry(registry)
    for uc in registry.list_use_cases():
        versions = registry.get_versions(uc)
        print(f"  {uc}: {len(versions)} versions")
        for v in versions:
            print(f"    v{v['version']} [{v['status']}] — {v['name']}")

    # 2. A/B Test (customer_support)
    use_case = "customer_support"
    test_inputs = SAMPLE_TEST_INPUTS[use_case][:2]  # Use 2 inputs for demo
    print(f"\n🔬 Running A/B test: {use_case} (v1 vs v2)")
    print(f"   Test inputs: {len(test_inputs)}")

    results = ab_tester.run_test(use_case, 1, 2, test_inputs, run_eval=True)

    summary = ABTester.summarize(results)
    print(f"\n📊 A/B Test Results:")
    print(f"   Winner: {summary.get('winner', 'N/A')}")
    print(f"   Reason: {summary.get('reason', 'N/A')}")
    print(f"   Quality A (mean): {summary['quality_a']['mean']}")
    print(f"   Quality B (mean): {summary['quality_b']['mean']}")
    print(f"   Cost A: ${summary['cost_a_total']}")
    print(f"   Cost B: ${summary['cost_b_total']}")

    # 3. Cost summary
    print(f"\n💰 Cost Summary:")
    cost_summary = tracker.get_summary()
    print(f"   Total requests: {cost_summary['total_requests']}")
    print(f"   Total tokens: {cost_summary['total_tokens']:,}")
    print(f"   Total cost: ${cost_summary['total_cost']:.6f}")

    by_project = tracker.get_by_project()
    for proj, data in by_project.items():
        print(f"   [{proj}] ${data['cost']:.6f} ({data['requests']} reqs)")

    print("\n✅ Demo complete! Run `streamlit run app.py --server.port 8516` for the web UI.")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        demo()
    else:
        print("Usage: python llmops.py demo")
        print("  Or run: streamlit run app.py --server.port 8516")
