# GenAI Learning

A curated collection of resources, examples, and hands-on notebooks for learning Generative AI (GenAI) from fundamentals to advanced applications.

## 📚 Table of Contents

- [Overview](#overview)
- [Prerequisites](#prerequisites)
- [Course Structure](#course-structure)
- [Getting Started](#getting-started)
- [Modules](#modules)
- [Resources](#resources)
- [Contributing](#contributing)

## Overview

This repository provides a structured learning path for Generative AI, covering:

- **Large Language Models (LLMs)** – Understanding how models like GPT, LLaMA, and Gemini work
- **Prompt Engineering** – Crafting effective prompts for better outputs
- **Retrieval-Augmented Generation (RAG)** – Combining LLMs with your own data
- **Fine-tuning** – Adapting pre-trained models for specific tasks
- **AI Agents** – Building autonomous AI systems
- **Responsible AI** – Ethics, safety, and best practices

## Prerequisites

- Basic Python programming knowledge
- Familiarity with machine learning concepts (helpful but not required)
- Python 3.9+ installed

## Course Structure

```
genai-learning/
├── 01_introduction/          # What is GenAI? Key concepts & terminology
├── 02_prompt_engineering/    # Prompt patterns, few-shot, chain-of-thought
├── 03_llm_apis/              # Working with OpenAI, HuggingFace, Google APIs
├── 04_rag/                   # Retrieval-Augmented Generation
├── 05_fine_tuning/           # Fine-tuning LLMs on custom data
├── 06_agents/                # Building AI agents with LangChain / LlamaIndex
├── 07_responsible_ai/        # Ethics, bias, safety, and governance
└── projects/                 # End-to-end capstone projects
```

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/WEE-VLSI/genai-learning.git
cd genai-learning
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # On Windows: venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up API keys

Copy `.env.example` to `.env` and fill in your API keys:

```bash
cp .env.example .env
```

### 5. Launch Jupyter

```bash
jupyter notebook
```

## Modules

### Module 1 – Introduction to Generative AI
- What is Generative AI?
- History: from RNNs → Transformers → LLMs
- Key concepts: tokens, embeddings, attention
- Popular models overview (GPT-4, Claude, Gemini, LLaMA)

📓 Notebook: [`01_introduction/01_intro_to_genai.ipynb`](01_introduction/01_intro_to_genai.ipynb)

---

### Module 2 – Prompt Engineering
- Zero-shot, one-shot, few-shot prompting
- Chain-of-Thought (CoT) reasoning
- Prompt templates and best practices
- System vs. user messages

📓 Notebook: [`02_prompt_engineering/01_prompt_basics.ipynb`](02_prompt_engineering/01_prompt_basics.ipynb)

---

### Module 3 – Working with LLM APIs
- OpenAI Chat Completions API
- HuggingFace Inference API
- Streaming responses
- Managing cost and rate limits

📓 Notebook: [`03_llm_apis/01_openai_basics.ipynb`](03_llm_apis/01_openai_basics.ipynb)

---

### Module 4 – Retrieval-Augmented Generation (RAG)
- Why RAG? Solving hallucination and knowledge cutoffs
- Document loaders, text splitters, embeddings
- Vector stores (FAISS, Chroma, Pinecone)
- Building a simple Q&A system over your documents

📓 Notebook: [`04_rag/01_simple_rag.ipynb`](04_rag/01_simple_rag.ipynb)

---

### Module 5 – Fine-tuning LLMs
- When to fine-tune vs. prompt engineer
- Parameter-Efficient Fine-Tuning (PEFT) with LoRA
- Preparing datasets
- Training and evaluating a fine-tuned model

📓 Notebook: [`05_fine_tuning/01_lora_finetune.ipynb`](05_fine_tuning/01_lora_finetune.ipynb)

---

### Module 6 – AI Agents
- ReAct pattern (Reason + Act)
- Tool use: search, calculators, code execution
- LangChain agents
- Multi-agent systems

📓 Notebook: [`06_agents/01_react_agent.ipynb`](06_agents/01_react_agent.ipynb)

---

### Module 7 – Responsible AI
- Bias and fairness in LLMs
- Prompt injection and jailbreaking attacks
- Content filtering and safety layers
- EU AI Act & governance frameworks

📓 Notebook: [`07_responsible_ai/01_bias_and_safety.ipynb`](07_responsible_ai/01_bias_and_safety.ipynb)

---

## Resources

### Official Documentation
- [OpenAI Documentation](https://platform.openai.com/docs)
- [HuggingFace Documentation](https://huggingface.co/docs)
- [LangChain Documentation](https://python.langchain.com)
- [Google AI Documentation](https://ai.google.dev)

### Recommended Reading
- [Attention Is All You Need](https://arxiv.org/abs/1706.03762) – Original Transformer paper
- [Language Models are Few-Shot Learners](https://arxiv.org/abs/2005.14165) – GPT-3 paper
- [RLHF: Learning to summarize from human feedback](https://arxiv.org/abs/2009.01325)
- [RAG: Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks](https://arxiv.org/abs/2005.11401)

### Online Courses
- [DeepLearning.AI – ChatGPT Prompt Engineering for Developers](https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/)
- [fast.ai – Practical Deep Learning](https://course.fast.ai/)
- [Hugging Face NLP Course](https://huggingface.co/learn/nlp-course)

### Community
- [r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA/)
- [HuggingFace Forums](https://discuss.huggingface.co/)
- [LangChain Discord](https://discord.gg/langchain)

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/add-new-module`)
3. Commit your changes (`git commit -m 'Add new module on XYZ'`)
4. Push to the branch (`git push origin feature/add-new-module`)
5. Open a Pull Request

## License

This project is licensed under the MIT License – see the [LICENSE](LICENSE) file for details.