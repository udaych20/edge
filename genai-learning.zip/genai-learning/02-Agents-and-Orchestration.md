# Agents & Orchestration — Detailed Guide

> **Prerequisites:** Core Application Patterns (RAG, Function Calling, Structured Output)  
> **Goal:** Understand how to build autonomous AI agents, orchestrate multi-step workflows, and leverage emerging interoperability protocols (MCP, A2A).

---

## Table of Contents

1. [AI Agents](#1-ai-agents)
2. [Agent Workflows (Agentic Patterns)](#2-agent-workflows-agentic-patterns)
3. [ReAct (Reason + Act)](#3-react-reason--act)
4. [Multi-Agent Systems](#4-multi-agent-systems)
5. [Agent-to-Agent Protocol (A2A)](#5-agent-to-agent-protocol-a2a)
6. [Model Context Protocol (MCP)](#6-model-context-protocol-mcp)

---

## 1. AI Agents

### What Is It?

An AI Agent is an **LLM-powered system that can autonomously plan, reason, use tools, and take actions** to achieve a goal. Unlike a simple chatbot that responds to one query at a time, an agent operates in a **loop** — observing, thinking, acting, and iterating until the task is done.

### Key Difference: Chatbot vs. Agent

| Aspect | Chatbot | Agent |
|--------|---------|-------|
| **Interaction** | Single turn: question → answer | Multi-turn loop: plan → act → observe → repeat |
| **Tool use** | Limited or none | Core capability — calls APIs, searches, writes code |
| **Autonomy** | User drives every step | Agent decides next steps independently |
| **Memory** | Within conversation only | Short-term + long-term memory |
| **Goal** | Answer the question | Complete the task |

### Agent Architecture

```
┌──────────────────────────────────────────────────┐
│                    AI AGENT                        │
│                                                    │
│  ┌─────────┐   ┌──────────┐   ┌──────────────┐  │
│  │ Planning │──▶│ Reasoning│──▶│   Execution   │  │
│  │ Module   │   │ (LLM)   │   │   (Tools)     │  │
│  └─────────┘   └──────────┘   └──────────────┘  │
│       ▲              │               │            │
│       │              ▼               ▼            │
│  ┌─────────┐   ┌──────────┐   ┌──────────────┐  │
│  │  Memory  │◀──│ Observe  │◀──│  Environment  │  │
│  │ (State)  │   │ Result   │   │  (World)      │  │
│  └─────────┘   └──────────┘   └──────────────┘  │
└──────────────────────────────────────────────────┘
```

### Core Components

| Component | Description | Example |
|-----------|-------------|---------|
| **LLM (Brain)** | Reasoning engine that decides what to do next | GPT-4o, Claude 3.5, Llama 3 |
| **Tools** | Functions the agent can call | Web search, code execution, file I/O, APIs |
| **Memory** | Short-term (conversation) + long-term (vector DB) | Chat history, task state, learned facts |
| **Planning** | Strategy for decomposing complex tasks | Break "write a report" into research → outline → draft → revise |
| **Observation** | Processing tool outputs and environment feedback | Parse API response, read file contents |

### The Agent Loop

```python
while not task_complete:
    # 1. Think: LLM reasons about current state
    thought = llm.think(goal, memory, observations)
    
    # 2. Act: LLM decides on next action
    action = llm.decide_action(thought, available_tools)
    
    # 3. Execute: Run the chosen tool
    observation = execute_tool(action)
    
    # 4. Update: Store observation in memory
    memory.add(observation)
    
    # 5. Check: Is the goal achieved?
    task_complete = llm.evaluate(goal, memory)
```

### Agent Frameworks

| Framework | By | Highlights | Best For |
|-----------|---|------------|----------|
| **LangGraph** | LangChain | Graph-based agent workflows, persistence, streaming | Production agents with complex flows |
| **OpenAI Agents SDK** | OpenAI | Native tool calling, code interpreter, file search | OpenAI-ecosystem agents |
| **CrewAI** | Open-source | Role-based agents, intuitive API | Multi-agent teams |
| **AutoGen** | Microsoft | Conversational agents, code execution | Research, collaborative agent systems |
| **Smolagents** | Hugging Face | Lightweight, code-based agents | Open-source model agents |
| **Semantic Kernel** | Microsoft | Enterprise-grade, .NET + Python | Enterprise integration |

### Use Cases

- **Coding agents** — GitHub Copilot, Cursor, Devin (write, test, debug code)
- **Research agents** — Deep Research by OpenAI/Google (multi-step web research)
- **Customer support** — Autonomous ticket resolution with tool access
- **Data analysis** — Query databases, generate charts, write reports
- **Personal assistants** — Schedule meetings, draft emails, manage tasks

### Hands-On: Simple Agent with LangGraph

```python
from langgraph.prebuilt import create_react_agent
from langchain_openai import ChatOpenAI
from langchain_community.tools.tavily_search import TavilySearchResults

# Define tools
search = TavilySearchResults(max_results=3)
tools = [search]

# Create agent
agent = create_react_agent(
    model=ChatOpenAI(model="gpt-4o"),
    tools=tools,
)

# Run
result = agent.invoke({
    "messages": [{"role": "user", "content": "What happened in AI news today?"}]
})
print(result["messages"][-1].content)
```

### Learning Resources

1. **DeepLearning.AI "AI Agents in LangGraph"** — Best starting course for agent development
2. **OpenAI Agents SDK Documentation** — Official guide for building agents with OpenAI
3. **Anthropic "Building Effective Agents" Blog** — Excellent design principles and patterns

---

## 2. Agent Workflows (Agentic Patterns)

### What Is It?

Agentic patterns are **design patterns for structuring how agents think, act, and collaborate**. Just like software has design patterns (MVC, Observer), AI agents have recurring architectural patterns that solve common problems.

### The Four Foundational Patterns (Andrew Ng)

#### Pattern 1: Reflection

The agent **reviews and critiques its own output**, then iterates to improve.

```
┌──────────┐     ┌───────────┐     ┌──────────┐
│ Generate  │────▶│  Critique  │────▶│  Revise   │──┐
│ (Draft)   │     │  (Review)  │     │ (Improve) │  │
└──────────┘     └───────────┘     └──────────┘  │
      ▲                                           │
      └───────────────────────────────────────────┘
                    (iterate until good enough)
```

**Use cases:** Code review, writing improvement, bug fixing  
**Example:** Agent writes code → reviews for bugs → fixes issues → reviews again

#### Pattern 2: Tool Use

The agent **selects and uses external tools** to gather information or take actions.

```
┌──────────┐     ┌───────────┐     ┌──────────┐
│ Analyze   │────▶│  Select    │────▶│ Execute   │
│ Task      │     │  Tool      │     │  Tool     │
└──────────┘     └───────────┘     └──────────┘
                                         │
                                         ▼
                                   ┌──────────┐
                                   │ Process   │
                                   │ Result    │
                                   └──────────┘
```

**Use cases:** Any task requiring external data or actions  
**Example:** Agent searches web, queries database, calls API

#### Pattern 3: Planning

The agent **decomposes a complex task into subtasks** before execution.

```
┌──────────┐     ┌───────────────┐     ┌──────────────┐
│ Complex   │────▶│  Decompose    │────▶│ Execute      │
│ Task      │     │  into Steps   │     │ Step by Step │
└──────────┘     └───────────────┘     └──────────────┘

Example:
"Create a market analysis report"
  ├── Step 1: Research industry trends
  ├── Step 2: Gather competitor data
  ├── Step 3: Analyze financial metrics
  ├── Step 4: Write executive summary
  └── Step 5: Format final report
```

**Use cases:** Research, report generation, complex data analysis  
**Example:** Task decomposition → dependency ordering → sequential/parallel execution

#### Pattern 4: Multi-Agent Collaboration

Multiple specialized agents **work together**, each handling part of the task.

```
┌────────────┐     ┌──────────────┐     ┌────────────┐
│ Researcher │     │  Writer       │     │  Editor     │
│ Agent      │────▶│  Agent        │────▶│  Agent      │
└────────────┘     └──────────────┘     └────────────┘
```

**Use cases:** Complex creative tasks, software development, analysis  
**Example:** One agent researches, another writes, a third reviews

### Advanced Workflow Patterns

| Pattern | Description | When to Use |
|---------|-------------|-------------|
| **Router** | Classifies input and routes to specialized handler | Multi-domain chatbots, triage systems |
| **Parallelization** | Run multiple agents/tools simultaneously | Independent subtasks (e.g., search multiple sources) |
| **Orchestrator-Worker** | Central LLM delegates subtasks to worker agents | Complex tasks with dynamic decomposition |
| **Evaluator-Optimizer** | One LLM generates, another evaluates and suggests improvements | Quality-critical outputs |
| **Fallback Chain** | Try primary approach; if it fails, fall back to alternatives | Resilient production systems |
| **Human-in-the-Loop** | Agent pauses for human approval at critical decision points | High-stakes actions (payments, deletions) |

### LangGraph Workflow Example

```python
from langgraph.graph import StateGraph, MessagesState, START, END
from langchain_openai import ChatOpenAI

llm = ChatOpenAI(model="gpt-4o")

# Define nodes
def researcher(state: MessagesState):
    response = llm.invoke([
        {"role": "system", "content": "You are a researcher. Find key facts."},
        *state["messages"]
    ])
    return {"messages": [response]}

def writer(state: MessagesState):
    response = llm.invoke([
        {"role": "system", "content": "You are a writer. Create a summary from the research."},
        *state["messages"]
    ])
    return {"messages": [response]}

def reviewer(state: MessagesState):
    response = llm.invoke([
        {"role": "system", "content": "You are a reviewer. Check for accuracy and clarity."},
        *state["messages"]
    ])
    return {"messages": [response]}

# Build graph
workflow = StateGraph(MessagesState)
workflow.add_node("researcher", researcher)
workflow.add_node("writer", writer)
workflow.add_node("reviewer", reviewer)

workflow.add_edge(START, "researcher")
workflow.add_edge("researcher", "writer")
workflow.add_edge("writer", "reviewer")
workflow.add_edge("reviewer", END)

app = workflow.compile()
result = app.invoke({"messages": [{"role": "user", "content": "Explain quantum computing"}]})
```

### Learning Resources

1. **Andrew Ng's Agentic Design Patterns** — Blog series defining the four patterns
2. **LangGraph Documentation** — Definitive guide for building agent workflows
3. **CrewAI Documentation** — High-level multi-agent workflow design

---

## 3. ReAct (Reason + Act)

### What Is It?

ReAct is a prompting/agent paradigm where the LLM **alternates between reasoning (thinking about what to do) and acting (executing a tool)**. Each step produces a Thought → Action → Observation triple.

### How It Works

```
User: What is the population of the capital of France?

Thought 1: I need to find the capital of France first.
Action 1:  search("capital of France")
Observation 1: The capital of France is Paris.

Thought 2: Now I need to find the population of Paris.
Action 2:  search("population of Paris 2024")
Observation 2: The population of Paris is approximately 2.1 million.

Thought 3: I now have enough information to answer.
Answer: The population of Paris, the capital of France, is approximately 2.1 million.
```

### Why It's Important

- **Transparent reasoning** — you can see the agent's thought process
- **Multi-hop reasoning** — solves problems requiring multiple steps
- **Self-correcting** — agent can recognize mistakes and retry
- **Foundation for modern agents** — most agent frameworks implement ReAct

### ReAct vs. Other Approaches

| Approach | Reasoning | Action | Strengths |
|----------|-----------|--------|-----------|
| **Standard prompting** | Internal only | None | Simple but limited |
| **Chain-of-Thought (CoT)** | Explicit | None | Better reasoning but no tools |
| **Act-only** | None | Yes | Tools but no reasoning trace |
| **ReAct** | Explicit | Yes | Best of both — reasoning + tools |

### Learning Resources

1. **Original ReAct Paper** — "ReAct: Synergizing Reasoning and Acting" (arXiv)
2. **LangChain ReAct Agent Tutorial** — Practical implementation guide
3. **Hugging Face Agents Course** — Covers ReAct and other agent paradigms

---

## 4. Multi-Agent Systems

### What Is It?

A multi-agent system uses **multiple specialized AI agents that collaborate** to accomplish complex tasks. Each agent has a defined role, expertise, and set of tools — like a team of specialists working together.

### Why Multi-Agent?

| Single Agent Limitations | Multi-Agent Advantages |
|-------------------------|----------------------|
| Context window overflow on complex tasks | Each agent has focused, manageable context |
| Jack-of-all-trades, master of none | Specialized agents excel at their role |
| Hard to debug monolithic agent | Modular — debug/improve individual agents |
| No separation of concerns | Clear responsibility boundaries |
| Single point of failure | Resilient — one agent failing doesn't block all |

### Multi-Agent Architecture Patterns

#### Pattern 1: Sequential Pipeline

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│ Agent A   │────▶│ Agent B   │────▶│ Agent C   │────▶│  Output   │
│ Research  │     │ Analysis  │     │ Writing   │     │          │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
```
**Use:** Document processing pipelines, staged content creation

#### Pattern 2: Hierarchical (Manager + Workers)

```
              ┌──────────────┐
              │  Manager      │
              │  Agent        │
              └──────┬───────┘
         ┌───────────┼───────────┐
         ▼           ▼           ▼
   ┌──────────┐ ┌──────────┐ ┌──────────┐
   │ Worker A  │ │ Worker B  │ │ Worker C  │
   │ Research  │ │ Code      │ │ Test      │
   └──────────┘ └──────────┘ └──────────┘
```
**Use:** Software development, project management

#### Pattern 3: Debate / Adversarial

```
   ┌──────────┐         ┌──────────┐
   │ Agent A   │◀───────▶│ Agent B   │
   │ (Pro)     │ Debate  │ (Con)     │
   └──────────┘         └──────────┘
         │                     │
         └──────────┬──────────┘
                    ▼
             ┌──────────┐
             │  Judge     │
             │  Agent     │
             └──────────┘
```
**Use:** Decision-making, risk analysis, balanced content generation

#### Pattern 4: Swarm / Dynamic

```
   ┌──────────┐     ┌──────────┐     ┌──────────┐
   │ Agent A   │────▶│ Agent B   │────▶│ Agent C   │
   └──────────┘     └──────────┘     └──────────┘
         ▲                                  │
         └──────────────────────────────────┘
              (hand off based on context)
```
**Use:** Customer support (route to specialist), dynamic task distribution

### Framework Comparison

| Framework | Architecture | Language | Key Feature |
|-----------|-------------|----------|-------------|
| **CrewAI** | Role-based teams | Python | Simplest API for multi-agent; crew/agent/task abstraction |
| **AutoGen (Microsoft)** | Conversational | Python | Agents chat with each other; strong code execution |
| **LangGraph** | Graph-based | Python | Most flexible; custom state machines; production-ready |
| **OpenAI Swarm** | Handoff-based | Python | Lightweight; agents hand off to each other |
| **Semantic Kernel** | Plugin-based | Python/.NET | Enterprise-grade; Azure integration |

### CrewAI Example

```python
from crewai import Agent, Task, Crew

# Define agents with roles
researcher = Agent(
    role="Senior Researcher",
    goal="Find comprehensive information about AI trends in 2026",
    backstory="You are an expert AI researcher with access to the latest publications.",
    tools=[search_tool],
    llm="gpt-4o",
)

writer = Agent(
    role="Technical Writer",
    goal="Write a clear, engaging article based on research findings",
    backstory="You are a skilled technical writer for a major tech blog.",
    llm="gpt-4o",
)

editor = Agent(
    role="Editor",
    goal="Review and polish the article for publication",
    backstory="You are a meticulous editor ensuring accuracy and readability.",
    llm="gpt-4o",
)

# Define tasks
research_task = Task(
    description="Research the top AI trends in 2026",
    agent=researcher,
    expected_output="A detailed research brief with key findings and sources",
)

writing_task = Task(
    description="Write a 1000-word article based on the research brief",
    agent=writer,
    expected_output="A well-structured article with introduction, body, and conclusion",
)

editing_task = Task(
    description="Review, fact-check, and polish the article",
    agent=editor,
    expected_output="Final publication-ready article",
)

# Assemble crew and run
crew = Crew(
    agents=[researcher, writer, editor],
    tasks=[research_task, writing_task, editing_task],
    verbose=True,
)
result = crew.kickoff()
print(result)
```

### Communication Patterns Between Agents

| Pattern | Description | Frameworks |
|---------|-------------|-----------|
| **Message passing** | Agents send messages directly to each other | AutoGen, LangGraph |
| **Shared state** | Agents read/write to a common state object | LangGraph (StateGraph) |
| **Task queue** | Tasks placed in queue, agents pick them up | CrewAI (sequential/parallel) |
| **Handoff** | Active agent transfers conversation to another agent | OpenAI Swarm |
| **Blackboard** | Shared knowledge base all agents can read/write | Custom implementations |

### Learning Resources

1. **CrewAI Documentation** — Best intro to multi-agent; well-designed tutorials
2. **AutoGen by Microsoft** — Research-grade multi-agent system with strong code execution
3. **LangGraph Multi-Agent Tutorial** — Advanced patterns with graph-based orchestration

---

## 5. Agent-to-Agent Protocol (A2A)

### What Is It?

**A2A (Agent-to-Agent)** is an **open protocol by Google (April 2025)** that enables AI agents built by different vendors, on different frameworks, to **discover each other, communicate, and collaborate** in a standardized way. Think of it as **HTTP for AI agents**.

### Why It Matters

- Today, agents from different systems **can't talk to each other**
- A2A provides a **universal communication layer** between agents
- Enables a future where you can compose agents from different vendors into workflows
- Backed by Google and a growing consortium of companies

### Core Concepts

| Concept | Description |
|---------|-------------|
| **Agent Card** | JSON metadata file (like a business card) describing an agent's capabilities, endpoint, and authentication |
| **Task** | The unit of work — a client sends a task to a remote agent |
| **Message** | Communication between agents within a task (text, files, structured data) |
| **Artifact** | Output produced by an agent (files, data, results) |
| **Push Notifications** | Server-sent events for real-time task updates |

### How It Works

```
┌────────────────┐                    ┌────────────────┐
│  Client Agent   │                    │  Remote Agent   │
│  (Requestor)    │                    │  (Provider)     │
├────────────────┤                    ├────────────────┤
│ 1. Discover     │──GET /agent.json──▶│ Agent Card      │
│    capabilities │◀──Agent Card──────│ returned        │
│                 │                    │                 │
│ 2. Send task    │──POST /tasks──────▶│ Receive task    │
│                 │                    │                 │
│ 3. Check status │──GET /tasks/{id}──▶│ Process task    │
│                 │◀──Status update────│                 │
│                 │                    │                 │
│ 4. Get result   │◀──Artifact────────│ Return result   │
└────────────────┘                    └────────────────┘
```

### Agent Card Example

```json
{
  "name": "Research Agent",
  "description": "Performs deep web research on any topic",
  "url": "https://research-agent.example.com",
  "version": "1.0.0",
  "capabilities": {
    "streaming": true,
    "pushNotifications": true
  },
  "skills": [
    {
      "id": "web-research",
      "name": "Web Research",
      "description": "Searches the web and synthesizes findings into a report",
      "inputModes": ["text/plain"],
      "outputModes": ["text/plain", "application/pdf"]
    }
  ],
  "authentication": {
    "schemes": ["bearer"]
  }
}
```

### A2A vs. MCP

| Aspect | A2A | MCP |
|--------|-----|-----|
| **Purpose** | Agent ↔ Agent communication | Agent ↔ Tool/Resource connection |
| **Analogy** | "How agents talk to each other" | "How agents use tools" |
| **Initiated by** | Google (April 2025) | Anthropic (Nov 2024) |
| **Unit of work** | Task (may be long-running) | Tool call (typically quick) |
| **Discovery** | Agent Cards (JSON) | Tool manifests |
| **Relationship** | **Complementary** — A2A connects agents, MCP connects tools | **Complementary** — an agent uses MCP for tools and A2A to talk to other agents |

### Use Case: Enterprise Workflow

```
┌──────────────┐  A2A   ┌──────────────┐  A2A   ┌──────────────┐
│ Sales Agent   │───────▶│ CRM Agent     │───────▶│ Finance Agent │
│ (Salesforce)  │        │ (HubSpot)     │        │ (SAP)         │
└──────────────┘        └──────────────┘        └──────────────┘
        │                                               │
        │              A2A                              │
        └──────────────────────────────────────────────┘
        
Scenario: "Process this new lead"
1. Sales Agent receives lead → sends to CRM Agent via A2A
2. CRM Agent creates contact → sends to Finance Agent via A2A  
3. Finance Agent runs credit check → returns result via A2A
4. Sales Agent compiles full lead profile
```

### Current Status (2026)

- Protocol specification is stable (v1.x)
- Python and JavaScript SDKs available
- Growing ecosystem of A2A-compatible agents
- Major vendors adopting: Google, Salesforce, SAP, ServiceNow, and others

### Learning Resources

1. **Google A2A Protocol Spec** (github.com/google/A2A) — Official specification
2. **Google Cloud A2A Blog** — Announcement and overview
3. **A2A Python/JS SDK Samples** — Reference implementations on GitHub

---

## 6. Model Context Protocol (MCP)

### What Is It?

**MCP (Model Context Protocol)** is an **open standard by Anthropic (November 2024)** that defines how LLM applications connect to **external tools, data sources, and resources** through a universal, standardized interface. Think of it as a **USB-C port for AI** — any tool that speaks MCP can plug into any LLM app that supports MCP.

### Why It Matters

- Before MCP: Every AI app needed **custom integrations** for every tool (N×M problem)
- With MCP: Build one MCP server per tool, connect to any MCP client (N+M)
- **Universal standard** — supported by Claude, VS Code/Copilot, Cursor, Windsurf, and more
- **Community-driven** — thousands of open-source MCP servers available

### The N×M → N+M Breakthrough

```
BEFORE MCP (N×M integrations):          AFTER MCP (N+M):
                                         
App1 ──── Tool A                         App1 ──┐
App1 ──── Tool B                         App2 ──┤      ┌── Tool A
App1 ──── Tool C                         App3 ──┤──MCP──── Tool B
App2 ──── Tool A       ─────▶           App4 ──┘      └── Tool C
App2 ──── Tool B                         
App2 ──── Tool C                         3 apps + 3 tools = 6 integrations
App3 ──── Tool A                         (instead of 9)
...                                      
3 apps × 3 tools = 9 integrations
```

### Architecture

```
┌────────────────┐         ┌─────────────────┐         ┌──────────────┐
│   MCP Client    │◀═══════▶│   MCP Server    │◀═══════▶│  External     │
│   (LLM App)     │  JSON-  │   (Middleware)   │         │  Resource     │
│                  │  RPC    │                  │         │              │
│  Examples:       │  over   │  Examples:       │         │  Examples:    │
│  - Claude        │  stdio/ │  - GitHub MCP    │         │  - GitHub API │
│  - VS Code       │  SSE/   │  - Postgres MCP  │         │  - Database   │
│  - Cursor        │  HTTP   │  - Slack MCP     │         │  - Slack API  │
└────────────────┘         └─────────────────┘         └──────────────┘
```

### Three Primitives

| Primitive | Description | Example |
|-----------|-------------|---------|
| **Tools** | Functions the LLM can invoke (model-controlled) | `create_issue`, `query_database`, `send_message` |
| **Resources** | Data the app can read (application-controlled) | File contents, database schemas, API docs |
| **Prompts** | Reusable prompt templates (user-controlled) | "Summarize this PR", "Review this code" |

### Transport Mechanisms

| Transport | How It Works | Use Case |
|-----------|-------------|----------|
| **stdio** | Server runs as subprocess, communicates via stdin/stdout | Local tools (VS Code extensions, CLI tools) |
| **SSE (Server-Sent Events)** | HTTP-based, server pushes events to client | Remote servers, web-hosted tools |
| **Streamable HTTP** | Latest transport; HTTP POST + optional streaming | Modern remote MCP servers (replacing SSE) |

### Building an MCP Server (Python)

```python
# weather_server.py — MCP server that provides weather tools
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Weather Server")

@mcp.tool()
def get_weather(city: str, unit: str = "celsius") -> str:
    """Get current weather for a city."""
    # In production, call a real weather API
    return f"Weather in {city}: 22°{unit[0].upper()}, partly cloudy"

@mcp.tool()
def get_forecast(city: str, days: int = 5) -> str:
    """Get weather forecast for upcoming days."""
    return f"{days}-day forecast for {city}: Mostly sunny, highs around 24°C"

@mcp.resource("weather://cities")
def list_supported_cities() -> str:
    """List all cities with weather data."""
    return "London, Paris, New York, Tokyo, Sydney"

if __name__ == "__main__":
    mcp.run()
```

### Connecting MCP to Claude Desktop

```json
// claude_desktop_config.json
{
  "mcpServers": {
    "weather": {
      "command": "python",
      "args": ["weather_server.py"],
      "transport": "stdio"
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_TOKEN": "ghp_xxx"
      }
    }
  }
}
```

### Connecting MCP to VS Code (Copilot)

```json
// .vscode/mcp.json
{
  "servers": {
    "weather": {
      "command": "python",
      "args": ["weather_server.py"],
      "type": "stdio"
    }
  }
}
```

### Popular MCP Servers

| Server | What It Does |
|--------|-------------|
| **GitHub MCP** | Create issues, PRs, search repos, manage branches |
| **PostgreSQL MCP** | Query databases, inspect schemas |
| **Filesystem MCP** | Read/write/search files on local filesystem |
| **Slack MCP** | Send messages, search channels, manage threads |
| **Google Drive MCP** | Read/search documents in Google Drive |
| **Puppeteer MCP** | Browser automation (screenshots, scraping) |
| **Azure MCP** | Manage Azure resources, deploy apps |
| **Memory MCP** | Persistent knowledge graph for agent memory |

### MCP + A2A Together

```
┌──────────────────────────────────────────────────┐
│                  YOUR AI APP                      │
│                                                    │
│   ┌───────────┐    ┌───────────┐                  │
│   │ Agent A    │───▶│ Agent B    │  ◀── A2A         │
│   └─────┬─────┘    └─────┬─────┘   (agent-to-     │
│         │                │          agent)          │
│     ┌───┴───┐        ┌───┴───┐                     │
│     │ MCP   │        │ MCP   │     ◀── MCP          │
│     │Server │        │Server │     (agent-to-tool)  │
│     └───┬───┘        └───┬───┘                     │
│         │                │                          │
│     ┌───┴───┐        ┌───┴───┐                     │
│     │GitHub │        │ Slack │                      │
│     │ API   │        │ API   │                      │
│     └───────┘        └───────┘                     │
└──────────────────────────────────────────────────┘
```

### Learning Resources

1. **Anthropic MCP Specification** (modelcontextprotocol.io) — Official docs, tutorials, SDK reference
2. **MCP GitHub Organization** (github.com/modelcontextprotocol) — Server repos, SDKs, examples
3. **VS Code + Copilot MCP Documentation** — Setting up MCP in your development environment

---

## Summary & Next Steps

| Concept | Key Takeaway | Complexity |
|---------|-------------|-----------|
| **AI Agents** | LLMs + tools + loops = autonomous task execution | Medium |
| **Agentic Patterns** | Reflection, tool use, planning, collaboration | Medium |
| **ReAct** | Interleaved reasoning + acting — the foundation | Low |
| **Multi-Agent** | Specialized agents collaborating beats one generalist | High |
| **A2A** | Universal language for agents to talk to each other | Medium |
| **MCP** | Universal standard for agents to use tools | Medium |

**Recommended learning order within this section:**
1. ReAct → 2. AI Agents (LangGraph) → 3. Agentic Patterns → 4. MCP → 5. Multi-Agent → 6. A2A

**Next:** [03-Advanced-Developments.md](03-Advanced-Developments.md) — Advanced RAG, GraphRAG, Multimodal AI, Evaluation
