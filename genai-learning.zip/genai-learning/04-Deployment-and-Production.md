# Deployment & Production — Detailed Guide

> **Prerequisites:** Core Patterns, Agents, Advanced Techniques  
> **Goal:** Learn how to take GenAI applications from prototype to production — versioning, optimization, cost management, and reliable serving.

---

## Table of Contents

1. [LLMOps](#1-llmops)
2. [Quantization & Optimization](#2-quantization--optimization)
3. [AI Gateway & Routing](#3-ai-gateway--routing)

---

## 1. LLMOps

### What Is It?

LLMOps (Large Language Model Operations) is the set of **practices, tools, and workflows** for managing the lifecycle of LLM-powered applications in production — from prompt versioning and evaluation to monitoring, cost tracking, and CI/CD. It's **DevOps/MLOps adapted for the GenAI era**.

### Why It Matters

- Prompts are code — they need **version control and testing**
- LLM costs can **spiral** without monitoring ($0.01/request × 1M requests = $10,000)
- Model outputs **drift** — what works today may not work next month
- Compliance requires **audit trails** of model inputs/outputs

### LLMOps Lifecycle

```
┌─────────────────────────────────────────────────────────────────┐
│                        LLMOps LIFECYCLE                          │
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐   │
│  │ Develop   │─▶│ Evaluate  │─▶│ Deploy   │─▶│ Monitor      │   │
│  │           │  │           │  │          │  │              │   │
│  │ • Prompt  │  │ • Metrics │  │ • CI/CD  │  │ • Latency    │   │
│  │   design  │  │ • A/B     │  │ • Blue/  │  │ • Cost       │   │
│  │ • RAG     │  │   tests   │  │   Green  │  │ • Quality    │   │
│  │   tuning  │  │ • Regr.   │  │ • Canary │  │ • Drift      │   │
│  │ • Model   │  │   tests   │  │          │  │ • Errors     │   │
│  │   select  │  │           │  │          │  │              │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘   │
│       ▲                                           │              │
│       └───────────────────────────────────────────┘              │
│                      (feedback loop)                             │
└─────────────────────────────────────────────────────────────────┘
```

### Key Practices

| Practice | Description | Tools |
|----------|-------------|-------|
| **Prompt versioning** | Track prompt changes like code (who, when, what) | LangSmith, Braintrust, PromptLayer |
| **Evaluation pipelines** | Automated quality tests before deployment | Ragas, Promptfoo, DeepEval |
| **A/B testing** | Compare different prompts/models on live traffic | Braintrust, custom with feature flags |
| **Cost tracking** | Monitor token usage and spend per endpoint/user | LangSmith, Helicone, custom dashboards |
| **Latency monitoring** | Track p50/p95/p99 response times | Any APM + LLM tracing |
| **Caching** | Cache identical/similar requests to reduce cost + latency | GPTCache, Redis semantic cache |
| **Rate limiting** | Protect against abuse and runaway costs | API gateway, custom middleware |
| **Logging & Audit** | Store all inputs/outputs for debugging and compliance | Langfuse, LangSmith, custom logging |

### Cost Optimization Strategies

| Strategy | Potential Savings | How |
|----------|------------------|-----|
| **Model routing** | 30-70% | Use cheap models for easy tasks, expensive for hard ones |
| **Prompt optimization** | 10-30% | Shorter prompts = fewer tokens = lower cost |
| **Caching** | 20-50% | Cache common queries; semantic similarity cache |
| **Batch processing** | 50% | OpenAI Batch API: 50% cheaper, 24hr turnaround |
| **Fine-tuning small model** | 60-80% | Replace GPT-4 with fine-tuned GPT-4o-mini for specific tasks |
| **Token budgets** | Variable | Set per-user/per-request token limits |

### Tools

| Tool | Category | Highlights |
|------|----------|-----------|
| **LangSmith** | Full platform | Tracing, evals, datasets, prompt hub, monitoring |
| **Braintrust** | Full platform | Evals, logging, prompt playground, experiments |
| **Langfuse** | Open-source | Tracing, analytics, prompt management |
| **PromptLayer** | Prompt management | Version control, A/B testing, analytics |
| **Helicone** | Observability | Logging, cost tracking, caching, rate limiting |
| **MLflow** | ML lifecycle | Experiment tracking with LLM support |
| **Promptfoo** | Evaluation | CLI-based prompt testing, CI/CD integration |

### CI/CD for LLM Apps

```yaml
# .github/workflows/llm-ci.yml
name: LLM CI Pipeline

on: [push, pull_request]

jobs:
  eval:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Install dependencies
        run: pip install promptfoo ragas

      - name: Run prompt evaluations
        run: |
          promptfoo eval \
            --config prompts/eval-config.yaml \
            --output results.json
      
      - name: Check quality thresholds
        run: |
          python scripts/check_thresholds.py results.json \
            --min-faithfulness 0.9 \
            --min-relevancy 0.85 \
            --max-cost-per-query 0.02
      
      - name: Upload results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: eval-results
          path: results.json
```

### Learning Resources

1. **MLflow LLM Tracking Documentation** — Experiment tracking for LLM apps
2. **Weights & Biases Prompts** — Prompt versioning and management
3. **PromptLayer Documentation** — Dedicated prompt operations platform

---

## 2. Quantization & Optimization

### What Is It?

**Quantization** reduces the precision of model weights (e.g., from 16-bit to 4-bit), dramatically shrinking model size and speeding up inference while preserving most of the quality. It's how you run a 70B model on a single GPU or a 7B model on a laptop.

### Why It Matters

- **70B model in FP16** = ~140 GB → won't fit on most hardware
- **70B model in 4-bit** = ~35 GB → fits on a single 48GB GPU
- **3-5× inference speedup** with minimal quality loss
- Enables **on-device/edge deployment** of capable models

### Precision Levels

| Precision | Bits per Weight | Size (7B model) | Quality | Use Case |
|-----------|----------------|-----------------|---------|----------|
| **FP32** | 32 | ~28 GB | Baseline | Training only |
| **FP16 / BF16** | 16 | ~14 GB | Near-FP32 | Standard GPU inference |
| **INT8** | 8 | ~7 GB | ~99% of FP16 | Balanced quality/speed |
| **INT4 (GPTQ/AWQ)** | 4 | ~3.5 GB | ~95-97% of FP16 | Local/edge deployment |
| **GGUF Q4_K_M** | ~4.5 avg | ~4 GB | ~96% of FP16 | CPU inference (llama.cpp) |
| **2-bit** | 2 | ~1.75 GB | Significant drop | Extreme compression |

### Quantization Methods

| Method | Type | How It Works | Best For |
|--------|------|-------------|----------|
| **GPTQ** | Post-training (PTQ) | Calibration dataset → layer-by-layer quantization | GPU inference |
| **AWQ** | Post-training (PTQ) | Activation-aware: preserves important weights | GPU inference; often better than GPTQ |
| **GGUF** | Post-training (PTQ) | llama.cpp format; multiple quant levels (Q4_K_M, Q5_K_M, etc.) | CPU inference, local deployment |
| **bitsandbytes** | On-the-fly | Quantizes during model loading (4-bit/8-bit) | Quick experiments; QLoRA fine-tuning |
| **SmoothQuant** | Post-training | Smooths activation outliers before quantization | INT8 on both weights and activations |
| **AQLM** | Post-training | Additive quantization with codebooks | Extreme 2-bit compression |

### Inference Engines

| Engine | Highlights | Best For |
|--------|-----------|----------|
| **vLLM** | PagedAttention, continuous batching, high throughput | Production GPU serving |
| **llama.cpp** | CPU + GPU; GGUF format; lightweight | Local/edge inference |
| **TGI (Text Generation Inference)** | By Hugging Face; Flash Attention, tensor parallelism | Hugging Face ecosystem |
| **TensorRT-LLM** | By NVIDIA; maximum GPU performance | NVIDIA GPU production serving |
| **Ollama** | Wraps llama.cpp with easy CLI/API | Developer-friendly local LLMs |
| **SGLang** | Radix attention, structured output optimization | Advanced serving needs |

### Quick Start: Quantized Model with vLLM

```python
# Serve a quantized model
# Terminal: pip install vllm

from vllm import LLM, SamplingParams

# Load AWQ-quantized 70B model (fits in ~35GB VRAM)
llm = LLM(
    model="TheBloke/Llama-2-70B-Chat-AWQ",
    quantization="awq",
    tensor_parallel_size=2,  # use 2 GPUs
)

params = SamplingParams(temperature=0.7, max_tokens=256)
outputs = llm.generate(["Explain quantum computing:"], params)
print(outputs[0].outputs[0].text)
```

### Quick Start: GGUF with llama.cpp (CPU)

```bash
# Runs on CPU — no GPU needed
# Install: pip install llama-cpp-python

from llama_cpp import Llama

llm = Llama(
    model_path="./models/mistral-7b-instruct-v0.2.Q4_K_M.gguf",
    n_ctx=4096,
    n_threads=8,
)

output = llm(
    "Explain quantum computing in simple terms:",
    max_tokens=256,
    temperature=0.7,
)
print(output["choices"][0]["text"])
```

### Other Optimization Techniques

| Technique | What It Does | Impact |
|-----------|-------------|--------|
| **Flash Attention** | Memory-efficient attention computation | 2-4× speedup, less memory |
| **KV Cache Optimization** | PagedAttention (vLLM): manages KV cache like virtual memory | 2-4× throughput increase |
| **Continuous Batching** | Dynamic batching of concurrent requests | Better GPU utilization |
| **Speculative Decoding** | Small model drafts tokens, large model verifies | 2-3× speedup |
| **Tensor Parallelism** | Split model across multiple GPUs | Serve models larger than single GPU |
| **Prefix Caching** | Cache KV states for common prompt prefixes | Faster repeated system prompts |

### Learning Resources

1. **Hugging Face Quantization Documentation** — GPTQ, AWQ, bitsandbytes guides
2. **llama.cpp** (github.com/ggerganov/llama.cpp) — GGUF quantization and CPU inference
3. **vLLM Documentation** (docs.vllm.ai) — High-performance serving engine

---

## 3. AI Gateway & Routing

### What Is It?

An AI Gateway is a **proxy layer** between your application and LLM providers that handles **load balancing, fallback, caching, rate limiting, cost tracking, and model routing**. Think of it as an **API gateway (like Kong or NGINX) specifically designed for LLM API traffic**.

### Why It Matters

- **Vendor lock-in** — Don't tie your app to one provider
- **Reliability** — Fallback to another model if one is down
- **Cost control** — Route cheap tasks to cheap models
- **Observability** — Single point for logging all LLM traffic
- **Security** — Centralized API key management, content filtering

### Architecture

```
┌──────────────┐
│  Your App     │
└──────┬───────┘
       │ (single API)
       ▼
┌──────────────────────────────────────────┐
│           AI GATEWAY                      │
│                                           │
│  ┌──────────┐  ┌──────────┐  ┌────────┐ │
│  │ Routing   │  │ Caching   │  │ Rate   │ │
│  │ Engine    │  │           │  │ Limit  │ │
│  └──────────┘  └──────────┘  └────────┘ │
│  ┌──────────┐  ┌──────────┐  ┌────────┐ │
│  │ Fallback  │  │ Logging   │  │ Cost   │ │
│  │ Chain     │  │ & Trace   │  │ Track  │ │
│  └──────────┘  └──────────┘  └────────┘ │
└──────────────────┬──────┬───────┬───────┘
                   │      │       │
            ┌──────┘      │       └──────┐
            ▼             ▼              ▼
     ┌──────────┐  ┌──────────┐  ┌──────────┐
     │ OpenAI    │  │ Anthropic │  │ Azure    │
     │ API       │  │ API       │  │ OpenAI   │
     └──────────┘  └──────────┘  └──────────┘
```

### Key Features

| Feature | Description |
|---------|-------------|
| **Unified API** | Single API that routes to any provider (OpenAI, Anthropic, Google, etc.) |
| **Fallback** | If provider A fails, automatically try provider B |
| **Load balancing** | Distribute requests across multiple API keys or endpoints |
| **Semantic caching** | Cache similar (not just identical) requests |
| **Cost tracking** | Track token usage and cost per user/feature/model |
| **Rate limiting** | Per-user, per-endpoint, per-model limits |
| **Model routing** | Route requests to different models based on complexity/cost rules |
| **Retries** | Automatic retry with exponential backoff |
| **Logging** | Centralized logging of all requests/responses |

### Smart Model Routing

```
┌──────────────────────────────────────────────────┐
│               SMART ROUTER                        │
│                                                    │
│  Simple query ────▶ GPT-4o-mini ($0.15/1M)       │
│  "What time is it in London?"                      │
│                                                    │
│  Medium query ────▶ GPT-4o ($2.50/1M)             │
│  "Summarize this 3-page document"                  │
│                                                    │
│  Complex query ───▶ Claude Opus ($15/1M)           │
│  "Analyze this codebase and suggest architecture"  │
└──────────────────────────────────────────────────┘
```

### Gateway Solutions

| Tool | Type | Highlights |
|------|------|-----------|
| **LiteLLM** | Open-source proxy | 100+ providers on unified API; drop-in OpenAI replacement |
| **Portkey AI** | Managed service | Gateway + observability; reliability features; virtual keys |
| **Azure AI Gateway** | Azure service | Azure API Management policies for OpenAI; enterprise-grade |
| **Helicone** | Managed service | Proxy + observability; caching; cost tracking |
| **Kong AI Gateway** | Open-source + enterprise | Extends Kong API gateway for AI; rate limiting, auth |
| **Cloudflare AI Gateway** | Managed | Edge-deployed; caching, rate limiting, logging |

### LiteLLM Example

```python
# LiteLLM — unified API for all providers
# pip install litellm

from litellm import completion

# Call OpenAI
response = completion(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
)

# Call Anthropic — same API!
response = completion(
    model="claude-3-5-sonnet-20241022",
    messages=[{"role": "user", "content": "Hello!"}],
)

# Call local model via Ollama — same API!
response = completion(
    model="ollama/llama3",
    messages=[{"role": "user", "content": "Hello!"}],
)
```

### LiteLLM Proxy Server

```yaml
# config.yaml for LiteLLM proxy
model_list:
  - model_name: "gpt-4o"
    litellm_params:
      model: "openai/gpt-4o"
      api_key: "sk-..."
  
  - model_name: "gpt-4o"  # Fallback
    litellm_params:
      model: "azure/gpt-4o"
      api_key: "..."
      api_base: "https://my-azure.openai.azure.com/"

  - model_name: "cheap-model"
    litellm_params:
      model: "openai/gpt-4o-mini"
      api_key: "sk-..."

router_settings:
  routing_strategy: "latency-based-routing"
  num_retries: 3
  fallbacks: [{"gpt-4o": ["cheap-model"]}]
```

```bash
# Start proxy
litellm --config config.yaml --port 4000

# Use from any OpenAI-compatible client
curl http://localhost:4000/v1/chat/completions \
  -H "Authorization: Bearer sk-your-proxy-key" \
  -d '{"model": "gpt-4o", "messages": [{"role": "user", "content": "Hello"}]}'
```

### Learning Resources

1. **LiteLLM Documentation** (docs.litellm.ai) — Unified API and proxy server
2. **Portkey AI Documentation** — Enterprise AI gateway features
3. **Azure API Management for OpenAI** — Enterprise gateway patterns

---

## Production Readiness Checklist

```
□ Evaluation pipeline running in CI/CD
□ Prompt versions tracked and tested
□ Fallback chain configured (primary + backup models)
□ Rate limiting per user and per endpoint
□ Cost tracking and alerting (budget thresholds)
□ Input/output logging for debugging
□ Guardrails on input (prompt injection) and output (toxicity, PII)
□ Latency monitoring with p95/p99 alerting
□ Caching for common/repeated queries
□ Model routing for cost optimization
□ Graceful degradation plan (what happens when LLM is down?)
□ Data retention policy for logged conversations
□ Load testing completed (know your throughput limits)
```

---

## Summary

| Concept | Key Takeaway |
|---------|-------------|
| **LLMOps** | Treat prompts as code — version, test, monitor, iterate |
| **Quantization** | Run large models on small hardware with minimal quality loss |
| **AI Gateway** | Never call LLM APIs directly from your app — use a proxy layer |

---

> **You've completed the GenAI Learning Roadmap!**  
> Go back to [00-GenAI-Learning-Roadmap.md](00-GenAI-Learning-Roadmap.md) for the overview.
